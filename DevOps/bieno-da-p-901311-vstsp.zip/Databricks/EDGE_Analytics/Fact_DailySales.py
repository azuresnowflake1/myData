# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *
from datetime import datetime

dss_year = dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/Staging/Incremental/Transaction/DSS/")
dss_month = dbutils.fs.ls(dss_year[-1][0])
dss_date = dbutils.fs.ls(dss_month[-1][0])
dss_file = dbutils.fs.ls(dss_date[-1][0])
path_dss = dss_file[-1][0]

distributor_year = dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/Transformed/Dimensions/Distributor/")
distributor_month = dbutils.fs.ls(distributor_year[-1][0])
distributor_date = dbutils.fs.ls(distributor_month[-1][0])
distributor_file = dbutils.fs.ls(distributor_date[-1][0])
path_dis = distributor_file[-1][0]

sm_year = dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/Transformed/Dimensions/Salesman/")
sm_month = dbutils.fs.ls(sm_year[-1][0])
sm_date = dbutils.fs.ls(sm_month[-1][0])
sm_file = dbutils.fs.ls(sm_date[-1][0])
path_sm = sm_file[-1][0]


prod_year = dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/Transformed/Dimensions/Product/")
prod_month = dbutils.fs.ls(prod_year[-1][0])
prod_date = dbutils.fs.ls(prod_month[-1][0])
prod_file = dbutils.fs.ls(prod_date[-1][0])
path_prod = prod_file[-1][0]

dis_year = dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/Transformed/Dimensions/Distributor/")
dis_month = dbutils.fs.ls(dis_year[-1][0])
dis_date = dbutils.fs.ls(dis_month[-1][0])
dis_file = dbutils.fs.ls(dis_date[-1][0])
path_dis = dis_file[-1][0]

# COMMAND ----------

path_dis

# COMMAND ----------

dss = (spark.read
        .option("header",True)
        .csv(path_dss)
      )

dis = ( spark.read
        .option("header",True)
        .csv(path_dis)      
      )

sm = spark.read.csv(path_sm , header='true')

prod = spark.read.csv(path_prod , header='true')

# COMMAND ----------

dss = dss.withColumn("GrossSalesValue",dss["GrossSalesValue"].cast(IntegerType()))
dss = dss.withColumn('InvoiceDate', 
                   date_format(col('InvoiceDate'), 'yyyy-MM-dd'))
#dss = dss.withColumn('month_year_key',concat)

# COMMAND ----------

dss_distributor = dss.join(dis,dss.SiteCode == dis.site_code, how = 'left' )

# COMMAND ----------

dss_intermediate = dss_distributor.select(col("ArticleCode").alias("product_code")
                ,col("InvoiceNumber")
                ,concat(col("distributor_code"),lit("_"),date_format(col("InvoiceDate"),"yyyy")).alias("dist_code_year")
                ,col("distributor_code").alias("transactional_distributor_code")
                ,col("distributor_code").alias("master_distributor_code")
                ,col("SiteCode").alias("transactional_site_code")
                ,col("SiteCode").alias("master_site_code")
                ,col("OutletCode").alias("transactional_outlet_code")
                ,col("OutletCode").alias("master_outlet_code")
                ,date_format(col("InvoiceDate"),"yyyyMMdd").cast("String").alias("invoice_date")
                ,col("SalesmanCode").alias("transactional_salesman_code")
                ,col("SalesmanCode").alias("master_salesman_code")
                ,col("invoicetype")
                ,col("customerZRSSFlag")
                ,col("SalesReturnReferenceInvoiceNumber")
                ,col("GrossSalesValue")
                ,(col("GrossSalesValue")/1000000).alias("gsv_million")
                ,col("NetInvoiceValue")
                ,col("GrossSalesWithReturnValue").alias("gross_sales_with_return_val")
                ,col("SalesReturnValue").alias("sales_return_val")
                ,col("OnInvoiceDiscountValue").alias("on_inv_discount_val")
                ,col("NetInvoiceValue").alias("net_invoice_val")
                ,col("ValueAddedTax").alias("ValueAddedTax")
                ,col("OffInvoiceDiscountValue").alias("off_inv_discount_val")
                ,col("TurnoverValue").alias("turn_over_value")
                ,col("SalesWithReturnPCQuantity").alias("sales_with_return_pc_qty")
                ,col("SalesReturnPCQuantity").alias("sales_return_pc_qty")
                ,col("SalesCSVolume").alias("sales_cs_vol")
                ,col("SalesKGVolume").alias("sales_kg_vol")
                ,col("SalesLTVolume").alias("sales_lt_vol")
                ,col("FreePCQuantity").alias("sales_pc_vol")
                                          
                ).withColumn("last_inserted_datetime",current_timestamp()).withColumn("last_modified_datetime",current_timestamp()).withColumn("dist_site_year", concat(col("master_distributor_code"), lit("_"), col("master_site_code"), lit("_"), substring(col("invoice_date"),1,4)))



# COMMAND ----------

#Dss_temp.groupBy("product_code","distributor_code","site_code").sum("GrossSalesValue")

# COMMAND ----------

dss = dss_intermediate

# COMMAND ----------

sm_sf_mid = sm.select(col("salesman_code"), col("salesforce")).distinct()

df1 = dss.join(sm_sf_mid,dss.master_salesman_code == sm_sf_mid.salesman_code, how = 'left')


# COMMAND ----------

cat_prod_mid = prod.select(col("product_code"), col("brand"), col("category_code"), col("cotc"), concat(col("brand"), lit("_"),col("Category_code"), lit("_"), col("cotc")).alias("brand_cat_core")).distinct()

df = df1.join(cat_prod_mid.select(col("product_code"), col("brand_cat_core"), col("category_code")), on = "product_code", how = "left")


# COMMAND ----------

sm_sf = sm_sf_mid.select(col("salesforce")).distinct()

cat_prod_core = cat_prod_mid.select(col("brand"), col("category_code"), col("cotc"), col("brand_cat_core")).distinct()

cat_prod = cat_prod_mid.select(col("product_code"), col("category_code")).distinct()

dis_site = dis.select(col("distributor_code"), col("site_code")).distinct()

# COMMAND ----------

update_dt = datetime.today().strftime('%Y/%m/%d/')
update_dt
file=("/mnt/adls/EDGE_Analytics/Datalake/Transformed/Transactional/DSS/"+update_dt)
df.coalesce(1).write.mode("overwrite").option("header", "true")\
.option("emptyValue", None)\
.option("nullValue", None).csv(file)

file=("/mnt/adls/EDGE_Analytics/Datalake/Transformed/Masters/Distributor_site/"+update_dt)
dis_site.coalesce(1).write.mode("overwrite").option("header", "true")\
.option("emptyValue", None)\
.option("nullValue", None).csv(file)

file=("/mnt/adls/EDGE_Analytics/Datalake/Transformed/Masters/unique_sf/"+update_dt)
sm_sf.coalesce(1).write.mode("overwrite").option("header", "true")\
.option("emptyValue", None)\
.option("nullValue", None).csv(file)

file=("/mnt/adls/EDGE_Analytics/Datalake/Transformed/Masters/Product_cat_core/"+update_dt)
cat_prod_core.coalesce(1).write.mode("overwrite").option("header", "true")\
.option("emptyValue", None)\
.option("nullValue", None).csv(file)

file=("/mnt/adls/EDGE_Analytics/Datalake/Transformed/Masters/Category_product/"+update_dt)
cat_prod.coalesce(1).write.mode("overwrite").option("header", "true")\
.option("emptyValue", None)\
.option("nullValue", None).csv(file)