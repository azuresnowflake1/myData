# Databricks notebook source
from datetime import datetime, timezone

utc_dt = datetime.now(timezone.utc) # UTC time

import pytz

tz = pytz.timezone('Asia/Bangkok')
vn_now = datetime.now(tz)

print(vn_now)

# COMMAND ----------

from pyspark.sql import types

# COMMAND ----------

salesmanMaster= "/mnt/adls/EDGE_Analytics/Datalake/Transformed/Dimensions/Salesman"
spgToPHMap    = "/mnt/adls/EDGE_Analytics/Datalake/Transformed/Dimensions/SPG_TO_PH_MAP"
prodPath      = "/mnt/adls/EDGE_Analytics/Datalake/Transformed/Dimensions/Product"
histOutletMap = "/mnt/adls/EDGE_Analytics/Datalake/Transformed/Dimensions/Hist_Outlet_Map"
outletSPG     = "/mnt/adls/EDGE_Analytics/Datalake/Transformed/Dimensions/Hist_SPG_Map"

# COMMAND ----------

yearSM = str(max([i.name.replace('/','') for i in dbutils.fs.ls (salesmanMaster)]))
monthSM= str(max([i.name.replace('/','') for i in dbutils.fs.ls (salesmanMaster +"/" +str(yearSM))]))
daySM  = str(max([i.name.replace('/','') for i in dbutils.fs.ls (salesmanMaster +"/"+str(yearSM)+"/"+str(monthSM))]))

yearPH = str(max([i.name.replace('/','') for i in dbutils.fs.ls (spgToPHMap)]))
monthPH= str(max([i.name.replace('/','') for i in dbutils.fs.ls (spgToPHMap +"/" +str(yearPH))]))
dayPH  = str(max([i.name.replace('/','') for i in dbutils.fs.ls (spgToPHMap +"/"+str(yearPH)+"/"+str(monthPH))]))

yearPD = str(max([i.name.replace('/','') for i in dbutils.fs.ls (prodPath)]))
monthPD= str(max([i.name.replace('/','') for i in dbutils.fs.ls (prodPath +"/" +str(yearPD))]))
dayPD  = str(max([i.name.replace('/','') for i in dbutils.fs.ls (prodPath +"/"+str(yearPD)+"/"+str(monthPD))]))

om_schema = types.StructType([
  types.StructField("date",types.StringType()),
  types.StructField("old_outlet_code",types.StringType()),
  types.StructField("master_outlet_code",types.StringType()),
  types.StructField("master_distributor_code",types.StringType()),
  types.StructField("master_site_code",types.StringType())
])

dataOM= spark.read.option("header","true").schema(om_schema).csv(histOutletMap)
dataOM.createOrReplaceTempView ("hist_outlet_map")

dataSM= spark.read.option("header","true").csv(salesmanMaster+"/"+yearSM+"/"+monthSM+"/"+daySM)
dataSM.createOrReplaceTempView ("dim_salesman")

dataPH= spark.read.option("header","true").csv(spgToPHMap+"/"+yearPH+"/"+monthPH+"/"+dayPH)
dataPH.createOrReplaceTempView ("spg_to_ph_map")

dataPD= spark.read.option("header","true").csv(prodPath+"/"+yearPD+"/"+monthPD+"/"+dayPD)
dataPD.createOrReplaceTempView ("dim_product")

# COMMAND ----------

# MAGIC %sql
# MAGIC /* CREATE BELOW TEMPORARY TABLE TO GET THE SET OF EXPECTED SPGs POSSIBLE FOR A PARTICULAR STANDARD SPG */
# MAGIC drop view if exists vw_expected_spg_for_each_product_group;
# MAGIC create temporary view vw_expected_spg_for_each_product_group as
# MAGIC select 
# MAGIC salesman_product_group_code,
# MAGIC standardised_salesman_product_group,
# MAGIC trim(expected_spg) expected_spg
# MAGIC from (
# MAGIC select distinct 
# MAGIC  salesman_product_group_code,
# MAGIC  standardised_salesman_product_group,
# MAGIC  --explode(split(expected_spg,';')) expected_spg
# MAGIC  explode(split(case when expected_spg is null then 'dummy' else expected_spg end,';')) expected_spg
# MAGIC from dim_salesman
# MAGIC ) q;

# COMMAND ----------

# MAGIC %sql
# MAGIC /* CREATE BELOW TEMPORARY VIEW JOINING DSS AND HISTORICAL OUTLET MAPPING TO CREATE A FLATTENED VIEW TO BRING IN MASTER RELATED FIELDS */
# MAGIC drop view if exists vw_fact_daily_sales_interim;
# MAGIC 
# MAGIC create temporary view vw_fact_daily_sales_interim as
# MAGIC select 
# MAGIC country_code,
# MAGIC dss.product_code,
# MAGIC pd.division,
# MAGIC invoice_number,
# MAGIC site_code_year,
# MAGIC transactional_distributor_code,
# MAGIC nvl(master_distributor_code, transactional_distributor_code) as master_distributor_code,
# MAGIC transactional_site_code,
# MAGIC nvl(master_site_code, transactional_site_code) as master_site_code,
# MAGIC transactional_outlet_code,
# MAGIC nvl(lpad(om.master_outlet_code,10,'0'), transactional_outlet_code) as master_outlet_code,
# MAGIC invoice_date,
# MAGIC transactional_salesman_code,
# MAGIC sm.salesman_product_group_code,
# MAGIC sm.standardised_salesman_product_group transactional_spg, 
# MAGIC nvl(cast(sm.no_of_salespersons_serving_outlet_in_this_spg as int),0) no_of_salespersons,
# MAGIC invoicetype,
# MAGIC customer_ZRSS_flag,
# MAGIC sales_ret_ref_invoice_number,
# MAGIC gross_sales_val,
# MAGIC gross_sales_val_mn,
# MAGIC net_invoice_val,
# MAGIC gross_sales_return_val,
# MAGIC sales_return_val,
# MAGIC on_invoice_discount_val,
# MAGIC value_added_tax,
# MAGIC off_inv_discount_val,
# MAGIC turn_over_val,
# MAGIC sales_with_return_pc_qty,
# MAGIC sales_return_pc_qty,
# MAGIC sales_pc_qty,
# MAGIC sales_cs_vol,
# MAGIC sales_kg_vol,
# MAGIC sales_lt_vol,
# MAGIC free_pc_qty,
# MAGIC dss.salesforce,
# MAGIC dss.brand,
# MAGIC dss.category_code,
# MAGIC brand_cat_core,
# MAGIC year_id,
# MAGIC month_id,
# MAGIC time_key
# MAGIC from fact_daily_sales dss
# MAGIC left outer join hist_outlet_map om 
# MAGIC on dss.transactional_outlet_code = lpad(om.old_outlet_code,10,'0')
# MAGIC left outer join dim_salesman sm 
# MAGIC on dss.transactional_salesman_code= sm.salesman_code
# MAGIC left outer join dim_product pd
# MAGIC on dss.product_code = pd.product_code;

# COMMAND ----------

# %sql
# select count(1)
# from vw_fact_daily_sales_interim;

# COMMAND ----------

spark.sql(" drop table if exists ref_latest_master_outlet")

dbutils.fs.rm("/mnt/adls/EDGE_Analytics/Datalake/temp/spg_hist_map/ref_latest_master_outlet/",True)

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC  create table if not exists ref_latest_master_outlet
# MAGIC  (
# MAGIC  time_key int,
# MAGIC  master_outlet_code string,
# MAGIC  transactional_salesman_code string,
# MAGIC  transactional_salesman_product_group string,
# MAGIC  salesman_product_group_code string,
# MAGIC  no_of_salespersons int,
# MAGIC  division string
# MAGIC  )
# MAGIC using delta
# MAGIC location "/mnt/adls/EDGE_Analytics/Datalake/temp/spg_hist_map/ref_latest_master_outlet/"

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC truncate table ref_latest_master_outlet;
# MAGIC 
# MAGIC insert into ref_latest_master_outlet
# MAGIC select *
# MAGIC from 
# MAGIC (with latest_master_outlet as
# MAGIC   (select 
# MAGIC     master_outlet_code,
# MAGIC     max(time_key) time_key,
# MAGIC     max(transactional_salesman_code) transactional_salesman_code
# MAGIC     from (
# MAGIC     select
# MAGIC       master_outlet_code,
# MAGIC       max(time_key) over (partition by master_outlet_code order by time_key desc) time_key,
# MAGIC       first(transactional_salesman_code) over (partition by master_outlet_code order by time_key desc) transactional_salesman_code
# MAGIC     from vw_fact_daily_sales_interim
# MAGIC     )q
# MAGIC     group by master_outlet_code
# MAGIC   )
# MAGIC   select 
# MAGIC   distinct
# MAGIC   dss.time_key,
# MAGIC   dss.master_outlet_code,
# MAGIC   dss.transactional_salesman_code,
# MAGIC   dss.transactional_spg as transactional_salesman_product_group,
# MAGIC   dss.salesman_product_group_code,
# MAGIC   dss.no_of_salespersons,
# MAGIC   null division
# MAGIC   from vw_fact_daily_sales_interim dss
# MAGIC   inner join latest_master_outlet lm 
# MAGIC   on lm.master_outlet_code= dss.master_outlet_code 
# MAGIC   and dss.time_key=lm.time_key
# MAGIC   and dss.transactional_salesman_code= lm.transactional_salesman_code
# MAGIC )q;

# COMMAND ----------

# %sql
# select 
# dss.time_key,
# dss.master_outlet_code,
# dss.transactional_salesman_code,
# dss.transactional_spg,
# dss.product_code,
# dss.division
# from vw_fact_daily_sales_interim dss 
# where master_outlet_code='0003078095'
# --'0000530511'
# order by 1 desc;

# select * from ref_latest_master_outlet where master_outlet_code='0003078095';

# COMMAND ----------

# MAGIC %sql
# MAGIC select master_outlet_code, count(1) cnt
# MAGIC from ref_latest_master_outlet 
# MAGIC group by master_outlet_code
# MAGIC having count(1) > 1;
# MAGIC -- select master_outlet_code, time_key, transactional_salesman_code, salesman_product_group_code, 
# MAGIC -- standardised_salesman_product_group, no_of_salespersons
# MAGIC -- from vw_fact_daily_sales where master_outlet_code in ('0000530511')
# MAGIC -- order by master_outlet_code, time_key desc;

# COMMAND ----------

# MAGIC %sql
# MAGIC drop view if exists vw_hist_spg_master;
# MAGIC create temporary view vw_hist_spg_master as
# MAGIC select 
# MAGIC time_key,
# MAGIC master_outlet_code,
# MAGIC master_salesman_code,
# MAGIC standard_spg as master_spg,
# MAGIC map.product_hierarchy division
# MAGIC from 
# MAGIC (select 
# MAGIC   time_key,
# MAGIC   master_outlet_code,
# MAGIC   transactional_salesman_code as master_salesman_code,
# MAGIC   transactional_salesman_product_group as standard_spg,
# MAGIC   no_of_salespersons
# MAGIC   from ref_latest_master_outlet
# MAGIC   union all
# MAGIC   select 
# MAGIC   time_key,
# MAGIC   master_outlet_code,
# MAGIC   transactional_salesman_code as master_salesman_code,
# MAGIC   transactional_spg as standard_spg,
# MAGIC   2 no_of_salespersons
# MAGIC   from (
# MAGIC   select 
# MAGIC   dss.time_key,
# MAGIC   dss.master_outlet_code,
# MAGIC   dss.transactional_salesman_code,
# MAGIC   dss.transactional_spg,
# MAGIC   row_number() over(partition by dss.master_outlet_code order by time_key desc) rn
# MAGIC   from vw_fact_daily_sales_interim dss
# MAGIC   inner join 
# MAGIC   (select 
# MAGIC     lkp.master_outlet_code,
# MAGIC     vw.expected_spg
# MAGIC     from ref_latest_master_outlet lkp
# MAGIC     inner join vw_expected_spg_for_each_product_group vw 
# MAGIC     on lkp.transactional_salesman_product_group = vw.standardised_salesman_product_group
# MAGIC     and lkp.salesman_product_group_code = vw.salesman_product_group_code
# MAGIC     where no_of_salespersons > 1
# MAGIC   ) lkp
# MAGIC   on dss.master_outlet_code= lkp.master_outlet_code
# MAGIC   and dss.transactional_spg= (case when lkp.expected_spg='dummy' then dss.transactional_spg else lkp.expected_spg end)
# MAGIC   )q where rn=1
# MAGIC )q
# MAGIC inner join spg_to_ph_map map on q.standard_spg= map.standardised_spg;

# COMMAND ----------

hist_spg_master= spark.sql("select * from vw_hist_spg_master")
hist_spg_master.repartition(5) \
               .write \
               .mode("overwrite") \
               .parquet (outletSPG)

# COMMAND ----------

# REMOVING NON PART FILES BEFORE INITIATING COPY ACTIVITY USING POLYBASE
fileInfo= dbutils.fs.ls(outletSPG)
fileList= [str(i.name) for i in fileInfo]

def filterNonPartFiles (fileName):
  if 'part' in fileName:
    return False
  else:
    return True

nonPartFiles = list(filter(filterNonPartFiles, fileList))

for file in nonPartFiles:
  dbutils.fs.rm(outletSPG+"/{}".format(file))

# COMMAND ----------

from datetime import datetime, timezone

utc_dt = datetime.now(timezone.utc) # UTC time

import pytz

tz = pytz.timezone('Asia/Bangkok')
vn_now = datetime.now(tz)

print(vn_now)