# Databricks notebook source
from datetime import datetime, timezone

utc_dt = datetime.now(timezone.utc) # UTC time

import pytz

tz = pytz.timezone('Asia/Bangkok')
vn_now = datetime.now(tz)

print(vn_now)

# COMMAND ----------

dbutils.widgets.text("Salesforce_Hierarchy", "","")
dbutils.widgets.text("accesss_control", "","")

IP_Salesforce_Hierarchy = dbutils.widgets.get("Salesforce_Hierarchy")
#/mnt/adls/EDGE_Analytics/Datalake/Staging/Incremental/Masters/Salesforce_Hierarchy/
OP_accesss_control = dbutils.widgets.get("accesss_control")
#/mnt/adls/EDGE_Analytics/Datalake/Transformed/access_control_table/
OP_accesss_control_access = OP_accesss_control + "access/"

OP_accesss_control_mid = OP_accesss_control + "mid/"

print(IP_Salesforce_Hierarchy)
print(OP_accesss_control)
print(OP_accesss_control_access)
print(OP_accesss_control_mid)


# COMMAND ----------

from pyspark.sql.functions import col,concat,lit
from pyspark.sql.types import *

# COMMAND ----------

salesforce_hierarchy_year = dbutils.fs.ls(IP_Salesforce_Hierarchy)
print(salesforce_hierarchy_year)
#salesforce_hierarchy_year = dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/Staging/Incremental/Masters/Salesforce_Hierarchy/")
salesforce_hierarchy_month = dbutils.fs.ls(salesforce_hierarchy_year[-1][0])
print(salesforce_hierarchy_month)
salesforce_hierarchy_date = dbutils.fs.ls(salesforce_hierarchy_month[-1][0])
print(salesforce_hierarchy_month)
salesforce_hierarchy_file = dbutils.fs.ls(salesforce_hierarchy_date[-1][0])
print(salesforce_hierarchy_file)
path_salesforce_hierarchy = salesforce_hierarchy_file[-1][0]
print(path_salesforce_hierarchy)

# COMMAND ----------

from pyspark.sql import functions as f
from datetime import datetime
df_salesforce_hierarchy = spark.read.csv(path_salesforce_hierarchy, header='true')

# COMMAND ----------

df_salesforce_hierarchy_columns_renamed = df_salesforce_hierarchy.select(col("Site"),col("Role"),col("Role Name").alias("role_name"),col("Role business scope assignment").alias("role_business_scope_assignment"),col("Role Email").alias("role_email")).where(
col("Role").isin(["ASM", "BM","Supervisor"])).distinct()

display(df_salesforce_hierarchy_columns_renamed)

# COMMAND ----------

df2 = df_salesforce_hierarchy_columns_renamed.select(col("Site"),col("Role"),col("role_Email"),col("role_business_scope_assignment").alias("role_biz"),concat(col("Site"), lit("_"), col("role_business_scope_assignment")).alias("key_col")).distinct()
#df2 = df_salesforce_hierarchy_columns_renamed.select(col("Site"),col("role_Email")).distinct()

# COMMAND ----------

df2.show()

# COMMAND ----------

df3=df2.select(col("Site"),col("role_biz"),col("key_col")).distinct()

# COMMAND ----------

df3.show()

# COMMAND ----------

#file=("/mnt/adls/EDGE_Analytics/Datalake/Transformed/Masters/Salesman/"+update_dt)
df2.coalesce(1).write.mode("overwrite").option("header", "true")\
.option("emptyValue", None)\
.option("nullValue", None).csv(OP_accesss_control_access)


# COMMAND ----------

#file=("/mnt/adls/EDGE_Analytics/Datalake/Transformed/Masters/Salesman/"+update_dt)
df3.coalesce(1).write.mode("overwrite").option("header", "true")\
.option("emptyValue", None)\
.option("nullValue", None).csv(OP_accesss_control_mid)

# COMMAND ----------

from datetime import datetime, timezone

utc_dt = datetime.now(timezone.utc) # UTC time

import pytz

tz = pytz.timezone('Asia/Bangkok')
vn_now = datetime.now(tz)

print(vn_now)