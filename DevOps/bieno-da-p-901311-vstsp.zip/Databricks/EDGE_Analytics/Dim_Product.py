# Databricks notebook source
from datetime import datetime, timezone

utc_dt = datetime.now(timezone.utc) # UTC time

import pytz

tz = pytz.timezone('Asia/Bangkok')
vn_now = datetime.now(tz)

print(vn_now)

# COMMAND ----------

from pyspark.sql import functions as f
from datetime import datetime
from pyspark.sql.functions import col,substring,when,isnull
from pyspark.sql import types

# COMMAND ----------

dbutils.widgets.text("IP_Product", "","")
dbutils.widgets.text("OP_Product", "","")
dbutils.widgets.text("IP_Product_IDX", "","")

Input_Product = dbutils.widgets.get("IP_Product")
Input_Product_IDX = dbutils.widgets.get("IP_Product_IDX")
Output_Product = dbutils.widgets.get("OP_Product")

print(Input_Product)
print("----------")
print(Input_Product_IDX)
#/mnt/adls/EDGE_Analytics/Datalake/Processed/FMT/
print("----------")
print(Output_Product)

# COMMAND ----------

ph_year = dbutils.fs.ls(Input_Product)
#ph_year = dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/Staging/Incremental/Masters/Product_Hierarchy_Mapping/")
ph_month = dbutils.fs.ls(ph_year[-1][0])
ph_date = dbutils.fs.ls(ph_month[-1][0])
ph_file = dbutils.fs.ls(ph_date[-1][0])
path_ph = ph_file[0][0]

print(path_ph)


# COMMAND ----------

ph_index_yr = str(max([i.name.replace('/','') for i in dbutils.fs.ls (Input_Product_IDX)])).zfill(0)
ph_index_mon = str(max([i.name.replace('/','') for i in dbutils.fs.ls (Input_Product_IDX +"/" +str(ph_index_yr))])).zfill(0)
ph_index_day  = str(max([i.name.replace('/','') for i in dbutils.fs.ls (Input_Product_IDX +"/"+str(ph_index_yr)+"/"+str(ph_index_mon))])).zfill(0)
                     
path_phi = Input_Product_IDX+ph_index_yr+"/"+ph_index_mon+"/"+ph_index_day + "/VN_LOCAL_PH_INDEX.csv"

#path_phi = "dbfs:/mnt/adls/EDGE_Analytics/Datalake/Processed/FMT/2021/01/05/VN_LOCAL_PH_INDEX.csv"
                   
print(path_phi)



# COMMAND ----------

df_PH= spark.read.csv(path_ph , header='true')

# COMMAND ----------

df_PHI= spark.read.csv(path_phi , header='true')

df_phi = df_PHI.select(col("Small C").alias("category"),col("Index").alias("sorting_index"))

# COMMAND ----------


df1=df_PH.select(col("Material").cast("int").alias("product_code"),col("CD DP Name").alias("dp_name"),col("Portfolio").alias("cotc"),col("Packsize").alias("packsize"),col("Packgroup").alias("packgroup"),col("Brand Variant").alias("brand_variant"),col("Subbrand").alias("subbrand"),col("Brand").alias("brand"),col("Segment").alias("segment"),col("CCBT").alias("ccbt"),col("Small C").alias("category"), substring(col("PH9"),1,4).alias("category_code"),col("Big C").alias("division"),col("CD View  1").alias("cd_view_1"),col("CD View 2").alias("cd_view_2")).distinct()
                

# COMMAND ----------

df_out = df1.join(df_phi,df1.category == df_phi.category,how='left').select(df1["*"],when(isnull(df_phi["sorting_index"] ),9999).otherwise(df_phi["sorting_index"]).alias("sorting_index")) 

# COMMAND ----------

#df_out.select(col("sorting_index")).distinct().show()

# COMMAND ----------

df_out.count()

# COMMAND ----------

update_dt = datetime.today().strftime('%Y/%m/%d/')
file_dt=(Output_Product+update_dt)
#file=("/mnt/adls/EDGE_Analytics/Datalake/Transformed/Dimensions/Product/"+update_dt)
df_out.coalesce(1).write.mode("overwrite").option("header", "true")\
.option("emptyValue", None)\
.option("nullValue", None).csv(file_dt)

# COMMAND ----------

from datetime import datetime, timezone

utc_dt = datetime.now(timezone.utc) # UTC time

import pytz

tz = pytz.timezone('Asia/Bangkok')
vn_now = datetime.now(tz)

print(vn_now)