# Databricks notebook source
dbutils.widgets.text("IP_Pre_Distributor", "","")
dbutils.widgets.text("OP_Distributor", "","")
Input_Pre_Distributor= dbutils.widgets.get("IP_Pre_Distributor")
Output_Distributor= dbutils.widgets.get("OP_Distributor")

dbutils.widgets.text("IP_Pre_U2K2", "","")
dbutils.widgets.text("OP_U2K2", "","")
Input_Pre_U2K2= dbutils.widgets.get("IP_Pre_U2K2")
Output_U2K2= dbutils.widgets.get("OP_U2K2")

dbutils.widgets.text("IP_Customer", "","")
dbutils.widgets.text("IP_Pre_Customer", "","")
dbutils.widgets.text("OP_Customer", "","")
Input_Pre_Customer = dbutils.widgets.get("IP_Pre_Customer")
Input_Customer = dbutils.widgets.get("IP_Customer")
Output_Customer = dbutils.widgets.get("OP_Customer")

# COMMAND ----------

from pyspark.sql.functions import *
from datetime import datetime
from pyspark.sql import Window

dml_year = dbutils.fs.ls(Input_Pre_Distributor)
#dml_year = dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/Staging/Incremental/Masters/Pre_Distributor/")
dml_month = dbutils.fs.ls(dml_year[-1][0])
dml_date = dbutils.fs.ls(dml_month[-1][0])
dml_file = dbutils.fs.ls(dml_date[-1][0])
path_dm = dml_file[-1][0]

u2k_year = dbutils.fs.ls(Input_Pre_U2K2)
#u2k_year = dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/Staging/Incremental/Masters/Pre_U2K2_NGDMS_Mapping/")
u2k_month = dbutils.fs.ls(u2k_year[-1][0])
u2k_date = dbutils.fs.ls(u2k_month[-1][0])
u2k_file = dbutils.fs.ls(u2k_date[-1][0])
path_u2k = u2k_file[-1][0]

cm_new_year = dbutils.fs.ls(Input_Pre_Customer)
#cm_year = dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/Staging/Incremental/Masters/Pre_Customer/")
cm_new_month = dbutils.fs.ls(cm_new_year[-1][0])
cm_new_date = dbutils.fs.ls(cm_new_month[-1][0])
cm_new_file = dbutils.fs.ls(cm_new_date[-1][0])
path_cm_new = cm_new_file[-1][0]

print(path_cm_new)

cm_year = dbutils.fs.ls(Input_Customer)
#cm_year = dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/Staging/Incremental/Masters/Customer/")
cm_month = dbutils.fs.ls(cm_year[-1][0])
cm_date = dbutils.fs.ls(cm_month[-1][0])
cm_file = dbutils.fs.ls(cm_date[-1][0])
path_cm = cm_file[-1][0]



# COMMAND ----------

df_U2k_unfiltered = spark.read.csv(path_u2k , header='true')
df_DM_unfiltered = spark.read.csv(path_dm, header='true')

df_CM_new = spark.read.csv(path_cm_new, header='true').withColumn("load_dt", (translate(lit(path_cm[76:86]), "/", "")).cast("int"))
df_CM_unsorted = df_CM_new.unionAll(spark.read.csv(path_cm, header='true')).distinct()


df_DM = df_DM_unfiltered.filter(col("LAND1") == 'VN')
df_U2k = df_U2k_unfiltered.filter(col("ZLAND1") == 'VN')
df_cm = df_CM_unsorted.withColumn("row_num", row_number().over(Window.partitionBy( col("SALESORG"), col("CUST_SALES"), col("DIVISION"), col("DISTR_CHAN")).orderBy(col("load_dt").desc()))).filter(col("COUNTRY")=="VN").filter(col("row_num") == 1).drop("row_num")

# COMMAND ----------

df_dm_fin = df_DM.withColumn("NAME1", when(col("NAME1")==lit(None), lit("UNKNOWN")).otherwise(col("NAME1")))
df_U2k_fin = df_U2k.withColumn("ZNGDMS_SITE", when(col("ZNGDMS_SITE")==lit(None), lit("UNKNOWN")).otherwise(col("ZNGDMS_SITE")))

# COMMAND ----------

update_dt = datetime.today().strftime('%Y/%m/%d/')
file_dm=(Output_Distributor+update_dt)
#file_dm=("/mnt/adls/EDGE_Analytics/Datalake/Staging/Incremental/Masters/Distributor/"+update_dt)
df_dm_fin.coalesce(1).write.mode("overwrite").option("header", "true")\
.option("emptyValue", None)\
.option("nullValue", None).csv(file_dm)

file_U2K=(Output_U2K2+update_dt)
#file_U2K=("/mnt/adls/EDGE_Analytics/Datalake/Staging/Incremental/Masters/U2K2_NGDMS_Mapping/"+update_dt)
df_U2k_fin.coalesce(1).write.mode("overwrite").option("header", "true")\
.option("emptyValue", None)\
.option("nullValue", None).csv(file_U2K)

file_cm=(Output_Customer+update_dt)
#file_cm=("/mnt/adls/EDGE_Analytics/Datalake/Staging/Incremental/Masters/Customer/"+update_dt)
df_cm.coalesce(1).write.mode("overwrite").option("header", "true")\
.option("emptyValue", None)\
.option("nullValue", None).csv(file_cm)

# COMMAND ----------

