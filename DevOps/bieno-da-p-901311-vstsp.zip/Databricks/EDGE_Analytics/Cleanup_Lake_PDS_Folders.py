# Databricks notebook source
dbutils.widgets.text("Path", "","")
Path= dbutils.widgets.get("Path")

print("Path given is" + Path)

if ((Path is None) or (Path=="")) :
  Path="this_is_a_dummy_path"

print(Path)

# COMMAND ----------

full_path="/mnt/adls/EDGE_Analytics/Datalake/"+Path
print(full_path)

# COMMAND ----------

dbutils.fs.rm(full_path,True)

# COMMAND ----------

print("Cleanup comleted")