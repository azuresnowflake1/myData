# Databricks notebook source
from datetime import datetime, timezone

utc_dt = datetime.now(timezone.utc) # UTC time

import pytz

tz = pytz.timezone('Asia/Bangkok')
vn_now = datetime.now(tz)

print(vn_now)

# COMMAND ----------

from datetime import datetime
dateTimeObj = datetime.now()
dateTime= str(dateTimeObj.strftime("%Y%m%d%H%M%S"))

from pyspark.sql.functions \
import col, date_format, unix_timestamp, from_unixtime, date_sub,substring,concat,to_date,translate,input_file_name,split,regexp_replace,concat_ws
from pyspark.sql.types import *
import datetime as dt

spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.conf.set("spark.sql.sources.partitionOverwriteMode","dynamic")

# COMMAND ----------

dssv_year1 = dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/Staging/Historical/Transaction/DSS_Validation_Hist/")
path_dssv1 = dssv_year1[-1][0]

# COMMAND ----------

dssv_year2 = dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/Staging/Historical/Transaction/DSS_Validation/")
path_dssv2 = dssv_year2[-1][0]

# COMMAND ----------

dssv_year3 = dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/Staging/Historical/Transaction/DSS_Validation_Outlet_Level_Hist/")
path_dssv3 = dssv_year3[-1][0]

# COMMAND ----------

df_dssv1 = spark.read.csv(path_dssv1+'*.csv' , header='true').withColumn("filename", input_file_name()).distinct()

# COMMAND ----------

df_dssv2 = spark.read.csv(path_dssv2+'*.csv' , header='true').withColumn("filename", input_file_name()).distinct()

# COMMAND ----------

df_dssv3 = spark.read.csv(path_dssv3+'*.csv' , header='true').withColumn("filename", input_file_name()).distinct()

# COMMAND ----------

df_dssv3=df_dssv3.select( col("Date"),col("SiteCode"),col("Outlet"),col("filename"),col("GSV")).withColumn("GSV",regexp_replace(col("GSV"), ',', '').cast("double"))

# COMMAND ----------

df_dssv3.createOrReplaceTempView('dssv3')

# COMMAND ----------

df_dssv_out = spark.sql("""
select Sitecode,Date,filename, null as SiteName, null as DistributorType,sum(cast(translate(GSV,',','') as double)) as gsv
from dssv3
group by sitecode,date,filename
""")

# COMMAND ----------

df_dssv1 = df_dssv1.select(
  col("Sitecode"),\
  to_date(col("Date"), "dd.MM.yyyy").alias("Date"),\
  col("SiteName"),\
  col("DistributorType"),\
  col("GSV"),\
  translate(col("filename"),' ','_').alias("file_name"),\
  substring(col("Date"),7,4).cast("int").alias("year"),\
  substring(col("Date"),4,2).cast("int").alias("month_num"),\
  substring(col("Date"),1,2).cast("int").alias("day")).distinct()

# COMMAND ----------

df_dssv2 = df_dssv2.select(
  col("Sitecode"),\
  to_date(col("Date"), "dd.MM.yyyy").alias("Date"),\
  col("SiteName"),\
  col("DistributorType"),\
  col("GSV"),\
  translate(col("filename"),' ','_').alias("file_name"),\
  substring(col("Date"),7,4).cast("int").alias("year"),\
  substring(col("Date"),4,2).cast("int").alias("month_num"),\
  substring(col("Date"),1,2).cast("int").alias("day")).distinct()

# COMMAND ----------

df_dssv4 = df_dssv_out.select(
  col("Sitecode"),\
  to_date(col("Date"), "dd.MM.yyyy").alias("Date"),\
  col("SiteName"),\
  col("DistributorType"),\
  col("GSV"),\
  translate(col("filename"),' ','_').alias("file_name"),\
  substring(col("Date"),7,4).cast("int").alias("year"),\
  substring(col("Date"),4,2).cast("int").alias("month_num"),\
  substring(col("Date"),1,2).cast("int").alias("day")).distinct()

# COMMAND ----------

df_dss=df_dssv1.unionAll(df_dssv2).unionAll(df_dssv4)

# COMMAND ----------

df_dss.createOrReplaceTempView('dss_vldtn')

# COMMAND ----------

spark.sql("""

select * from (
select  *,reverse(split(file_name,'/'))[0], concat_ws("",split(reverse(split(file_name,'/'))[0],'%20')),
split(reverse(split(file_name,'/'))[0],'%20')[7] as file_dt, split(reverse(split(file_name,'/'))[0],'%20')[10] as file_wk,

row_number() over( partition by SiteCode,date order by split(reverse(split(file_name,'/'))[0],'%20')[7] desc,split(reverse(split(file_name,'/'))[0],'%20')[10] desc ) as rownum

from dss_vldtn
-- where date between '2020-01-01' and '2020-12-31' and Sitecode='3002'
) a where rownum=1
"""
).createOrReplaceTempView('vw_dss_le_data')


# COMMAND ----------

bdlDeltaPath="/mnt/adls/BDL_Gen2/BusinessDataLake/CD/SecSales/Global/Online_Countries/Transactional/OnlineInvoiceSKUSales/OnlineInvoiceSKUSales_hist_parquet/"

dssBdlDFHist = spark.read \
                    .format("delta") \
                    .load(bdlDeltaPath)
dssBdlDFHist.createOrReplaceTempView("online_invoice_sku_sales")

# COMMAND ----------

spark.sql("""

select invoicedate as date,SiteCode,sum(GrossSalesValue)*100 as gsv from online_invoice_sku_sales
where CountryCode='VN'
group by SiteCode,invoicedate

"""
).createOrReplaceTempView('vw_dss_bdl')


# COMMAND ----------

spark.sql("""

select invoice_date as date,transactional_site_code as sitecode, sum(gross_sales_val) as gsv from fact_daily_sales 
where country_code='VN'
group by transactional_site_code ,invoice_date

"""
).createOrReplaceTempView('vw_dss_dwh')


# COMMAND ----------

df_out=spark.sql("""

select 
a.date as bdl_date
,a.sitecode as bdl_site
,a.GSV as bdl_gsv

,b.date as le_date
,b.sitecode as le_site
,b.gsv as le_gsv

,c.date as dwh_date
,c.sitecode as dwh_site
,c.gsv as dwh_gsv

from
vw_dss_bdl a
left outer join vw_dss_le_data b
on a.date=b.date
and a.sitecode=b.Sitecode

left outer join vw_dss_dwh c
on a.date=c.date
and a.sitecode=c.Sitecode

where a.date >='2018-10-01'
and b.date >='2018-10-01'
and c.date >='2018-10-01'

""")


# COMMAND ----------

dbutils.fs.rm("/mnt/adls/EDGE_Analytics/Datalake/Transformed/Transactional/Validation/",True)

# COMMAND ----------

file=("/mnt/adls/EDGE_Analytics/Datalake/Transformed/Transactional/Validation/")

df_out.coalesce(1).write.mode("overwrite").option("header", "true")\
.option("emptyValue", None)\
.option("nullValue", None).csv(file)

# COMMAND ----------

from datetime import datetime, timezone

utc_dt = datetime.now(timezone.utc) # UTC time

import pytz

tz = pytz.timezone('Asia/Bangkok')
vn_now = datetime.now(tz)

print(vn_now)