# Databricks notebook source
dbutils.widgets.text("IP_SPG_TO_PH_MAP", "","")
dbutils.widgets.text("OP_SPG_TO_PH_MAP", "","")
Input_SPG_TO_PH_MAP= dbutils.widgets.get("IP_SPG_TO_PH_MAP")
Output_SPG_TO_PH_MAP = dbutils.widgets.get("OP_SPG_TO_PH_MAP")

print(Input_SPG_TO_PH_MAP)
print(Output_SPG_TO_PH_MAP)

# COMMAND ----------

"""
spg_year = dbutils.fs.ls(Input_SPG_TO_PH_MAP)
#spg_year = dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/Staging/Incremental/Masters/Standardized_SPGtoPH_Mapping/")
spg_month = dbutils.fs.ls(spg_year[-1][0])
spg_date = dbutils.fs.ls(spg_month[-1][0])
spg_file = dbutils.fs.ls(spg_date[-1][0])
path_spg = spg_file[0][0]
"""

spg_year = str(max([i.name.replace('/','') for i in dbutils.fs.ls (Input_SPG_TO_PH_MAP)])).zfill(0)
spg_month = str(max([i.name.replace('/','') for i in dbutils.fs.ls (Input_SPG_TO_PH_MAP +"/" +str(spg_year))])).zfill(0)
spg_date  = str(max([i.name.replace('/','') for i in dbutils.fs.ls (Input_SPG_TO_PH_MAP +"/"+str(spg_year)+"/"+str(spg_month))])).zfill(0)
                     
path_spg = Input_SPG_TO_PH_MAP+spg_year+"/"+spg_month+"/"+spg_date + "/VN_STANDARD_SPG_PH_MAP.csv"

#path_phi = "dbfs:/mnt/adls/EDGE_Analytics/Datalake/Processed/FMT/2021/01/05/VN_LOCAL_PH_INDEX.csv"
                   
print(path_spg)



# COMMAND ----------

from pyspark.sql.functions import *
from datetime import *
from pyspark.sql import Window
df1 = spark.read.csv(path_spg , header='true')

# COMMAND ----------

df = df1.select(col("Salesforce").alias("salesforce"), col("Standardised SPG").alias("standardised_spg"), col("Product Hierachy").alias("product_hierarchy"))

# COMMAND ----------

list1=[
  ['UNASG','UNASG','F&RFs'],
  ['UNASG','UNASG','Personal Care'],
  ['UNASG','UNASG','Homecare']
]

# COMMAND ----------

columns = ["salesforce","standardised_spg","product_hierarchy"]
df2 = spark.createDataFrame(data=list1, schema = columns)
df2.printSchema()

# COMMAND ----------

df=df.union(df2)

# COMMAND ----------

update_dt = datetime.today().strftime('%Y/%m/%d/')
file_dt=(Output_SPG_TO_PH_MAP+update_dt)

#file=("/mnt/adls/EDGE_Analytics/Datalake/Transformed/Masters/SPG_TO_PH_MAP/"+update_dt)
df.coalesce(1).write.mode("overwrite").option("header", "true")\
.option("emptyValue", None)\
.option("nullValue", None).csv(file_dt)