# Databricks notebook source
from datetime import datetime, timezone

utc_dt = datetime.now(timezone.utc) # UTC time

import pytz

tz = pytz.timezone('Asia/Bangkok')
vn_now = datetime.now(tz)

print(vn_now)

# COMMAND ----------

from pyspark.sql import types

salesmanMaster= "/mnt/adls/EDGE_Analytics/Datalake/Transformed/Dimensions/Salesman/"
spgToPHMap    = "/mnt/adls/EDGE_Analytics/Datalake/Transformed/Dimensions/SPG_TO_PH_MAP/"
prodPath      = "/mnt/adls/EDGE_Analytics/Datalake/Transformed/Dimensions/Product/"
histOutletMap = "/mnt/adls/EDGE_Analytics/Datalake/Transformed/Dimensions/Hist_Outlet_Map"
outletSPG     = "/mnt/adls/EDGE_Analytics/Datalake/Transformed/Dimensions/Hist_SPG_Map"



dailyOutletSPG = "/mnt/adls/EDGE_Analytics/Datalake/Transformed/Dimensions/ref_daily_spg_outlet_map"

# COMMAND ----------

yearSM = str(max([i.name.replace('/','') for i in dbutils.fs.ls (salesmanMaster)]))
monthSM= str(max([i.name.replace('/','') for i in dbutils.fs.ls (salesmanMaster +"/" +str(yearSM))])).zfill(0)
daySM  = str(max([i.name.replace('/','') for i in dbutils.fs.ls (salesmanMaster +"/"+str(yearSM)+"/"+str(monthSM))])).zfill(0)

yearPH = str(max([i.name.replace('/','') for i in dbutils.fs.ls (spgToPHMap)]))
monthPH= str(max([i.name.replace('/','') for i in dbutils.fs.ls (spgToPHMap +"/" +str(yearPH))])).zfill(0)
dayPH  = str(max([i.name.replace('/','') for i in dbutils.fs.ls (spgToPHMap +"/"+str(yearPH)+"/"+str(monthPH))])).zfill(0)

yearPD = str(max([i.name.replace('/','') for i in dbutils.fs.ls (prodPath)]))
monthPD= str(max([i.name.replace('/','') for i in dbutils.fs.ls (prodPath +"/" +str(yearPD))])).zfill(0)
dayPD  = str(max([i.name.replace('/','') for i in dbutils.fs.ls (prodPath +"/"+str(yearPD)+"/"+str(monthPD))])).zfill(0)

om_schema = types.StructType([
  types.StructField("date",types.StringType()),
  types.StructField("old_outlet_code",types.StringType()),
  types.StructField("master_outlet_code",types.StringType()),
  types.StructField("master_distributor_code",types.StringType()),
  types.StructField("master_site_code",types.StringType())
])

dataOM= spark.read.option("header","true").schema(om_schema).csv(histOutletMap)
dataOM.createOrReplaceTempView ("hist_outlet_map")

dataSM= spark.read.option("header","true").csv(salesmanMaster+yearSM+"/"+monthSM+"/"+daySM)
dataSM.createOrReplaceTempView ("dim_salesman")

dataPH= spark.read.option("header","true").csv(spgToPHMap+yearPH+"/"+monthPH+"/"+dayPH)
dataPH.createOrReplaceTempView ("spg_to_ph_map")

dataPD= spark.read.option("header","true").csv(prodPath+yearPD+"/"+monthPD+"/"+dayPD)
dataPD.createOrReplaceTempView ("dim_product")

outletSPGDF = spark.read.parquet(outletSPG)
outletSPGDF.createOrReplaceTempView("dim_master_outlet_spg")


dlyoutletSPGDF= spark.read.option("header","true").parquet(dailyOutletSPG)
dlyoutletSPGDF.createOrReplaceTempView ("daily_outlet_spg")

# COMMAND ----------

# MAGIC %sql
# MAGIC /* CREATE BELOW TEMPORARY TABLE TO GET THE SET OF EXPECTED SPGs POSSIBLE FOR A PARTICULAR STANDARD SPG */
# MAGIC 
# MAGIC create or replace temporary view vw_expected_spg_for_each_product_group as
# MAGIC select 
# MAGIC salesman_product_group_code,
# MAGIC standardised_salesman_product_group,
# MAGIC num_slsp,
# MAGIC trim(expected_spg) expected_spg,
# MAGIC r.salesforce
# MAGIC from (
# MAGIC select distinct 
# MAGIC salesman_product_group_code,
# MAGIC  standardised_salesman_product_group,
# MAGIC  expected_spg,
# MAGIC  no_of_salespersons_serving_outlet_in_this_spg as num_slsp
# MAGIC from dim_salesman 
# MAGIC --where no_of_salespersons_serving_outlet_in_this_spg > 1
# MAGIC ) q
# MAGIC left join (select distinct salesforce, standardised_spg from spg_to_ph_map) r
# MAGIC on trim(q.standardised_salesman_product_group)=trim(r.standardised_spg)
# MAGIC ;

# COMMAND ----------

# MAGIC %sql
# MAGIC drop view if exists view_fact_daily_sales;
# MAGIC create temporary view view_fact_daily_sales as
# MAGIC select 
# MAGIC country_code,
# MAGIC product_code,
# MAGIC dss.division,
# MAGIC invoice_number,
# MAGIC site_code_year,
# MAGIC transactional_distributor_code,
# MAGIC master_distributor_code,
# MAGIC transactional_site_code,
# MAGIC master_site_code,
# MAGIC transactional_outlet_code,
# MAGIC dss.master_outlet_code,
# MAGIC invoice_date,
# MAGIC 
# MAGIC dss.transactional_salesman_code,
# MAGIC spg.transactional_salesman_code as master_salesman_code,
# MAGIC --master_salesman_code,
# MAGIC dss.salesman_product_group_code,
# MAGIC transactional_spg,
# MAGIC spg.salesman_product_group_code as master_spg,
# MAGIC --master_spg,
# MAGIC 
# MAGIC dss.no_of_salespersons,
# MAGIC invoicetype,
# MAGIC customer_ZRSS_flag,
# MAGIC sales_ret_ref_invoice_number,
# MAGIC gross_sales_val,
# MAGIC gross_sales_val_mn,
# MAGIC net_invoice_val,
# MAGIC gross_sales_return_val,
# MAGIC sales_return_val,
# MAGIC on_invoice_discount_val,
# MAGIC value_added_tax,
# MAGIC off_inv_discount_val,
# MAGIC turn_over_val,
# MAGIC sales_with_return_pc_qty,
# MAGIC sales_return_pc_qty,
# MAGIC sales_pc_qty,
# MAGIC sales_cs_vol,
# MAGIC sales_kg_vol,
# MAGIC sales_lt_vol,
# MAGIC free_pc_qty,
# MAGIC coalesce(sm2.salesforce ,dss.salesforce) as salesforce,
# MAGIC brand,
# MAGIC category_code,
# MAGIC brand_cat_core,
# MAGIC year_id,
# MAGIC month_id,
# MAGIC dss.time_key
# MAGIC from
# MAGIC (select 
# MAGIC   country_code,
# MAGIC   dss.product_code,
# MAGIC   pd.division,
# MAGIC   invoice_number,
# MAGIC   site_code_year,
# MAGIC   transactional_distributor_code,
# MAGIC   nvl(master_distributor_code, transactional_distributor_code) as master_distributor_code,
# MAGIC   transactional_site_code,
# MAGIC   nvl(master_site_code, transactional_site_code) as master_site_code,
# MAGIC   transactional_outlet_code,
# MAGIC   nvl(lpad(om.master_outlet_code,10,'0'), transactional_outlet_code) as master_outlet_code,
# MAGIC   invoice_date,
# MAGIC   transactional_salesman_code,
# MAGIC   sm.salesman_product_group_code,
# MAGIC   sm.standardised_salesman_product_group transactional_spg, 
# MAGIC   nvl(cast(sm.no_of_salespersons_serving_outlet_in_this_spg as int),0) no_of_salespersons,
# MAGIC   invoicetype,
# MAGIC   customer_ZRSS_flag,
# MAGIC   sales_ret_ref_invoice_number,
# MAGIC   gross_sales_val,
# MAGIC   gross_sales_val_mn,
# MAGIC   net_invoice_val,
# MAGIC   gross_sales_return_val,
# MAGIC   sales_return_val,
# MAGIC   on_invoice_discount_val,
# MAGIC   value_added_tax,
# MAGIC   off_inv_discount_val,
# MAGIC   turn_over_val,
# MAGIC   sales_with_return_pc_qty,
# MAGIC   sales_return_pc_qty,
# MAGIC   sales_pc_qty,
# MAGIC   sales_cs_vol,
# MAGIC   sales_kg_vol,
# MAGIC   sales_lt_vol,
# MAGIC   free_pc_qty,
# MAGIC   dss.salesforce,
# MAGIC   coalesce(pd.brand,dss.brand) as brand,
# MAGIC   coalesce(pd.category_code,dss.category_code) as category_code,
# MAGIC   coalesce(concat(pd.brand,'_',pd.category_code,'_',pd.cotc),brand_cat_core) as brand_cat_core,
# MAGIC   year_id,
# MAGIC   month_id,
# MAGIC   time_key
# MAGIC   from fact_daily_sales dss
# MAGIC   left outer join hist_outlet_map om 
# MAGIC   on dss.transactional_outlet_code = lpad(om.old_outlet_code,10,'0')
# MAGIC   left outer join dim_salesman sm 
# MAGIC   on dss.transactional_salesman_code= sm.salesman_code
# MAGIC   left outer join dim_product pd
# MAGIC   on dss.product_code = pd.product_code
# MAGIC  ) dss
# MAGIC  left outer join daily_outlet_spg as spg
# MAGIC -- left outer join dim_master_outlet_spg spg
# MAGIC  on dss.master_outlet_code = spg.master_outlet_code 
# MAGIC   and dss.division= spg.division 
# MAGIC   and dss.master_site_code = spg.site_code
# MAGIC 
# MAGIC /* left outer join dim_salesman sm2 
# MAGIC   on spg.transactional_salesman_code= sm2.salesman_code */
# MAGIC  left outer join (select distinct salesman_product_group_code,salesforce from vw_expected_spg_for_each_product_group ) sm2 
# MAGIC   on coalesce(spg.salesman_product_group_code,'UNASG')= coalesce(sm2.salesman_product_group_code ,'UNASG')

# COMMAND ----------

from datetime import datetime, timezone

utc_dt = datetime.now(timezone.utc) # UTC time

import pytz

tz = pytz.timezone('Asia/Bangkok')
vn_now = datetime.now(tz)

print(vn_now)