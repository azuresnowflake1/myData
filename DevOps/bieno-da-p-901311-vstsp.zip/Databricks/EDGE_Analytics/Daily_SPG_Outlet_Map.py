# Databricks notebook source
from datetime import datetime, timezone

utc_dt = datetime.now(timezone.utc) # UTC time

import pytz

tz = pytz.timezone('Asia/Bangkok')

vn_now = datetime.now(tz)

print(vn_now)

# COMMAND ----------

from pyspark.sql import types

# COMMAND ----------

salesmanMaster= "/mnt/adls/EDGE_Analytics/Datalake/Transformed/Dimensions/Salesman"

yearSM = str(max([i.name.replace('/','') for i in dbutils.fs.ls (salesmanMaster)]))
monthSM= str(max([i.name.replace('/','') for i in dbutils.fs.ls (salesmanMaster +"/" +str(yearSM))]))
daySM  = str(max([i.name.replace('/','') for i in dbutils.fs.ls (salesmanMaster +"/"+str(yearSM)+"/"+str(monthSM))]))


dataSM= spark.read.option("header","true").csv(salesmanMaster+"/"+yearSM+"/"+monthSM+"/"+daySM)
dataSM.createOrReplaceTempView ("dim_salesman")


# COMMAND ----------

histOutletMap = "/mnt/adls/EDGE_Analytics/Datalake/Transformed/Dimensions/Hist_Outlet_Map"

hom_schema = types.StructType([
  types.StructField("date",types.StringType()),
  types.StructField("old_outlet_code",types.StringType()),
  types.StructField("master_outlet_code",types.StringType()),
  types.StructField("master_distributor_code",types.StringType()),
  types.StructField("master_site_code",types.StringType())
])

dataHOM= spark.read.option("header","true").schema(hom_schema).csv(histOutletMap)
dataHOM.createOrReplaceTempView ("hist_outlet_map")



# COMMAND ----------

# MAGIC %sql
# MAGIC /* CREATE BELOW TEMPORARY TABLE TO GET THE SET OF EXPECTED SPGs POSSIBLE FOR A PARTICULAR STANDARD SPG */
# MAGIC 
# MAGIC create or replace temporary view vw_expected_spg_for_each_product_group as
# MAGIC select 
# MAGIC salesman_product_group_code,
# MAGIC standardised_salesman_product_group,
# MAGIC num_slsp,
# MAGIC trim(expected_spg) expected_spg
# MAGIC from (
# MAGIC select distinct 
# MAGIC salesman_product_group_code,
# MAGIC  standardised_salesman_product_group,
# MAGIC  expected_spg,
# MAGIC  no_of_salespersons_serving_outlet_in_this_spg as num_slsp
# MAGIC from dim_salesman 
# MAGIC --where no_of_salespersons_serving_outlet_in_this_spg > 1
# MAGIC ) q;

# COMMAND ----------

path= "/mnt/adls/EDGE_Analytics/Datalake/Staging/Historical/Transaction/Daily_SPG_Outlet/"

# COMMAND ----------

om_schema = types.StructType([
  types.StructField("site_code",types.StringType()),
  types.StructField("outlet_code",types.StringType()),
  types.StructField("dt",types.StringType()),
  types.StructField("salesman_code",types.StringType()),
  types.StructField("spg",types.StringType()),
  types.StructField("outlet_status",types.StringType()),
  types.StructField("gsv",types.StringType())
])



# COMMAND ----------

from pyspark.sql.functions import input_file_name, col, when, coalesce, to_date,translate,date_format

df= spark.read.csv(path,header=True,recursiveFileLookup=True,schema=om_schema).withColumn("file_name",input_file_name())

df2=df.select("site_code","outlet_code","salesman_code","spg","outlet_status",date_format(to_date(col("dt"),'dd.MM.yyyy'),'yyyyMMdd').cast("int").alias("time_key") , translate(col("gsv"),',','').cast("float").alias("gsv"))

df2.createOrReplaceTempView ("map")


# COMMAND ----------

df1=spark.sql("""

select 
     coalesce(c.master_site_code,site_code) as site_code,
     site_code as orig_site_code,
     -- lpad(outlet_code,10,'0') as outlet_code,
      coalesce(lpad(c.master_outlet_code,10,'0'),lpad(outlet_code,10,'0')) as outlet_code,
      lpad(outlet_code,10,'0') as orig_outlet_code,
      salesman_code,
      spg ,
      time_key,
      row_number() over(partition by coalesce(c.master_site_code,site_code) , coalesce(lpad(c.master_outlet_code,10,'0'),lpad(outlet_code,10,'0')) order by time_key desc) as rnk

,b.standardised_salesman_product_group
,trim(case when expected_spg is null then 'dummy' else expected_spg end) expected_spg
,num_slsp
 ,expected_spg as orig
 
      from map a 
      left join vw_expected_spg_for_each_product_group b 
      on trim(a.spg)=trim(b.salesman_product_group_code)
      
      left join hist_outlet_map c
on lpad(a.outlet_code,10,'0') = lpad(c.old_outlet_code,10,'0')

      where spg not in ('V30') 
   --   and outlet_code='2132720'
  """)      


# COMMAND ----------

dbutils.fs.rm("/mnt/adls/EDGE_Analytics/Datalake/temp/temp_daily_outlet_spg/",True)

# COMMAND ----------

df1.repartition(30).write.mode("overwrite").option("header", "true")\
.option("emptyValue", None)\
.option("nullValue", None)\
.parquet("/mnt/adls/EDGE_Analytics/Datalake/temp/temp_daily_outlet_spg/")

# COMMAND ----------

df2 = spark.read.parquet("/mnt/adls/EDGE_Analytics/Datalake/temp/temp_daily_outlet_spg/")

# COMMAND ----------

df2.createOrReplaceTempView('all_data')

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view rank_one as
# MAGIC select  
# MAGIC site_code,
# MAGIC outlet_code,
# MAGIC salesman_code,
# MAGIC spg,time_key,
# MAGIC rnk,
# MAGIC standardised_salesman_product_group,
# MAGIC expected_spg,
# MAGIC num_slsp ,
# MAGIC split(case when expected_spg is null then 'dummy' else expected_spg end,';') as next_possible_spg,
# MAGIC expected_spg as orig
# MAGIC from all_data where rnk=1

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view rankmore as
# MAGIC select  
# MAGIC site_code,
# MAGIC outlet_code,
# MAGIC salesman_code,
# MAGIC spg,time_key,
# MAGIC rnk,
# MAGIC standardised_salesman_product_group,
# MAGIC expected_spg,
# MAGIC num_slsp,
# MAGIC expected_spg as orig
# MAGIC from all_data where rnk>1

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view get_all_other_division
# MAGIC as
# MAGIC select *, array_contains(next_possible_spg,standardised_salesman_product_group) as flag 
# MAGIC 
# MAGIC from (
# MAGIC select 
# MAGIC a.site_code,
# MAGIC a.outlet_code,
# MAGIC a.spg,
# MAGIC a.salesman_code,
# MAGIC a.time_key,
# MAGIC b.num_slsp,
# MAGIC a.rnk,
# MAGIC a.standardised_salesman_product_group,
# MAGIC b.next_possible_spg,
# MAGIC trim(b.next_possible_spg[0]) as potential_standardised_salesman_product_group,
# MAGIC a.orig,
# MAGIC row_number() over(partition by b.site_code,b.outlet_code order by a.rnk) as new_rank
# MAGIC from rankmore a inner join rank_one b 
# MAGIC on a.site_code = b.site_code
# MAGIC and a.outlet_code = b.outlet_code
# MAGIC and trim(b.standardised_salesman_product_group)<>trim(a.standardised_salesman_product_group)
# MAGIC where b.num_slsp > 1
# MAGIC ) 
# MAGIC 
# MAGIC where new_rank=1
# MAGIC --and outlet_code='0000348103'

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view get_matching_divisions
# MAGIC as
# MAGIC select  
# MAGIC site_code,
# MAGIC outlet_code,
# MAGIC salesman_code,
# MAGIC spg,
# MAGIC time_key,
# MAGIC num_slsp,
# MAGIC orig
# MAGIC from get_all_other_division where flag=True

# COMMAND ----------

fmt_blob="/mnt/adls/EDGE_Analytics/Datalake/Processed/FMT/"

ol_index_yr = str(max([i.name.replace('/','') for i in dbutils.fs.ls (fmt_blob)])).zfill(0)
ol_index_mon = str(max([i.name.replace('/','') for i in dbutils.fs.ls (fmt_blob +"/" +str(ol_index_yr))])).zfill(0)
ol_index_day  = str(max([i.name.replace('/','') for i in dbutils.fs.ls (fmt_blob +"/"+str(ol_index_yr)+"/"+str(ol_index_mon))])).zfill(0)
                     
path_oli = fmt_blob+ol_index_yr+"/"+ol_index_mon+"/"+ol_index_day + "/VN_SPG_MAP.csv"

df_OLI= spark.read.csv(path_oli , header='true').withColumnRenamed("Salesman Product Group Code","spg").withColumnRenamed("Standardised Salesperson Product Group","spg_name")

display(df_OLI)

df_OLI.createOrReplaceTempView('spg_def')

# COMMAND ----------

spgToPHMap    = "/mnt/adls/EDGE_Analytics/Datalake/Transformed/Dimensions/SPG_TO_PH_MAP"

yearPH = str(max([i.name.replace('/','') for i in dbutils.fs.ls (spgToPHMap)]))
monthPH= str(max([i.name.replace('/','') for i in dbutils.fs.ls (spgToPHMap +"/" +str(yearPH))]))
dayPH  = str(max([i.name.replace('/','') for i in dbutils.fs.ls (spgToPHMap +"/"+str(yearPH)+"/"+str(monthPH))]))


dataPH= spark.read.option("header","true").csv(spgToPHMap+"/"+yearPH+"/"+monthPH+"/"+dayPH)
dataPH.select("standardised_spg","product_hierarchy").distinct().createOrReplaceTempView ("spg_to_ph_map")

# --inner join spg_to_ph_map map on q.standard_spg= map.standardised_spg;

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view get_non_matching_divisions
# MAGIC as
# MAGIC select  
# MAGIC site_code,
# MAGIC outlet_code,
# MAGIC null as salesman_code,
# MAGIC b.spg,
# MAGIC null as time_key,
# MAGIC num_slsp,
# MAGIC orig
# MAGIC from get_all_other_division a
# MAGIC 
# MAGIC left join (  
# MAGIC 
# MAGIC 
# MAGIC select spg,spg_name from (select  d.spg,
# MAGIC row_number() over (partition by spg_name order by d.spg) as rnk,
# MAGIC d.spg_name 
# MAGIC from 
# MAGIC spg_def  as d
# MAGIC ) where rnk=1
# MAGIC 
# MAGIC ) b
# MAGIC on trim(a.potential_standardised_salesman_product_group)=trim(b.spg_name)
# MAGIC 
# MAGIC where flag=False

# COMMAND ----------

df_sql = spark.sql("""

select site_code,outlet_code,salesman_code,spg,time_key,num_slsp,orig 
from all_data where rnk=1

union 

select site_code,outlet_code,salesman_code,spg,time_key,num_slsp,orig 
from get_matching_divisions

union 

select site_code,outlet_code,salesman_code,spg,time_key,num_slsp,orig 
from get_non_matching_divisions

""")

# COMMAND ----------

df_sql.createOrReplaceTempView('new_coll')

#display(df_sql)

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC create or replace temp view new_coll2
# MAGIC as
# MAGIC select 
# MAGIC q.*,
# MAGIC map.product_hierarchy as division 
# MAGIC from  new_coll q
# MAGIC left join spg_def d on trim(q.spg)=trim(d.spg)
# MAGIC left join spg_to_ph_map map on nvl(trim(d.spg_name),'dummy')= trim(map.standardised_spg)

# COMMAND ----------

dbutils.fs.rm("/mnt/adls/EDGE_Analytics/Datalake/temp/spg_hist_map/ref_daily_spg_outlet_map/",True)

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC  drop table if  exists ref_daily_spg_outlet_map;
# MAGIC 
# MAGIC  create table if not exists ref_daily_spg_outlet_map
# MAGIC  (
# MAGIC  site_code string,
# MAGIC  master_outlet_code string,
# MAGIC  transactional_salesman_code string,
# MAGIC  salesman_product_group_code string,
# MAGIC  time_key int,
# MAGIC  num_slsp int,
# MAGIC  orig string,
# MAGIC   division  string
# MAGIC  )
# MAGIC using delta
# MAGIC location "/mnt/adls/EDGE_Analytics/Datalake/temp/spg_hist_map/ref_daily_spg_outlet_map/"

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC insert into ref_daily_spg_outlet_map
# MAGIC select 
# MAGIC site_code,
# MAGIC outlet_code,
# MAGIC salesman_code,
# MAGIC spg ,
# MAGIC time_key,
# MAGIC num_slsp,
# MAGIC orig,
# MAGIC division
# MAGIC from 
# MAGIC new_coll2 

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC select * from all_data where outlet_code in ('0003790966')

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC select * from ref_daily_spg_outlet_map where master_outlet_code='0000744418'

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC select * from ref_latest_master_outlet where master_outlet_code='0000744418'
# MAGIC --transactional_salesman_code='5920'

# COMMAND ----------

dailyOutletSPG     = "/mnt/adls/EDGE_Analytics/Datalake/Transformed/Dimensions/ref_daily_spg_outlet_map"

# COMMAND ----------

dbutils.fs.rm(dailyOutletSPG,True)

# COMMAND ----------

hist_spg_master= spark.sql("select * from ref_daily_spg_outlet_map")
hist_spg_master.coalesce(1) \
               .write \
.format ("parquet")\
               .mode("overwrite") \
               .save (dailyOutletSPG ,header = 'true')



# COMMAND ----------

hist_spg_master.count()

# COMMAND ----------

# REMOVING NON PART FILES BEFORE INITIATING COPY ACTIVITY USING POLYBASE
fileInfo= dbutils.fs.ls(dailyOutletSPG)
fileList= [str(i.name) for i in fileInfo]

def filterNonPartFiles (fileName):
  if 'part' in fileName:
    return False
  else:
    return True

nonPartFiles = list(filter(filterNonPartFiles, fileList))

for file in nonPartFiles:
  dbutils.fs.rm(dailyOutletSPG+"/{}".format(file))

# COMMAND ----------

from datetime import datetime, timezone

utc_dt = datetime.now(timezone.utc) # UTC time

import pytz

tz = pytz.timezone('Asia/Bangkok')
vn_now = datetime.now(tz)

print(vn_now)

# COMMAND ----------

