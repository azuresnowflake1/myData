# Databricks notebook source
from datetime import datetime, timezone

utc_dt = datetime.now(timezone.utc) # UTC time

import pytz

tz = pytz.timezone('Asia/Bangkok')
vn_now = datetime.now(tz)

print(vn_now)

# COMMAND ----------

from pyspark.sql.functions import *

# COMMAND ----------

dbutils.widgets.text("IP_Category_Product", "","")
dbutils.widgets.text("OP_Category_product", "","")
dbutils.widgets.text("IP_Distributor_Site", "","")
dbutils.widgets.text("OP_Distributor_Site", "","")
dbutils.widgets.text("IP_Product_cat_core", "","")
dbutils.widgets.text("OP_Product_cat_core", "","")
dbutils.widgets.text("IP_unique_sf", "","")
dbutils.widgets.text("OP_unique_sf", "","")
Input_Category_Product= dbutils.widgets.get("IP_Category_Product")
Output_Category_Product = dbutils.widgets.get("OP_Category_product")
Input_Distributor_Site= dbutils.widgets.get("IP_Distributor_Site")
Output_Distributor_Site = dbutils.widgets.get("OP_Distributor_Site")
Input_Product_cat_core= dbutils.widgets.get("IP_Product_cat_core")
Output_Product_cat_core = dbutils.widgets.get("OP_Product_cat_core")
Input_unique_sf= dbutils.widgets.get("IP_unique_sf")
Output_unique_sf = dbutils.widgets.get("OP_unique_sf")

print(Input_Category_Product)
print(Input_Distributor_Site)
print(Input_Product_cat_core)
print(Input_unique_sf)
print("---------")
print(Output_Category_Product)
print(Output_Distributor_Site)
print(Output_Product_cat_core)
print(Output_unique_sf)

# COMMAND ----------

prod_year = dbutils.fs.ls(Input_Category_Product)
#prod_year = dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/Transformed/Masters/Product/")
prod_month = dbutils.fs.ls(prod_year[-1][0])
prod_date = dbutils.fs.ls(prod_month[-1][0])
prod_file = dbutils.fs.ls(prod_date[-1][0])
path_prod = prod_file[-1][0]

dis_year = dbutils.fs.ls(Input_Distributor_Site)
#dis_year = dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/Transformed/Masters/Distributor/")
dis_month = dbutils.fs.ls(dis_year[-1][0])
dis_date = dbutils.fs.ls(dis_month[-1][0])
dis_file = dbutils.fs.ls(dis_date[-1][0])
path_dis = dis_file[-1][0]

sm_year = dbutils.fs.ls(Input_unique_sf)
#sm_year = dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/Transformed/Masters/Salesman/")
sm_month = dbutils.fs.ls(sm_year[-1][0])
sm_date = dbutils.fs.ls(sm_month[-1][0])
sm_file = dbutils.fs.ls(sm_date[-1][0])
path_sm = sm_file[-1][0]

# COMMAND ----------

prod = spark.read.csv(path_prod , header='true')
dis = spark.read.csv(path_dis , header='true')
sm = spark.read.csv(path_sm , header='true')

# COMMAND ----------

cat_prod = prod.select(col("sorting_index"), col("category_code")).distinct()

# COMMAND ----------

dis_site = dis.select(col("distributor_code"), col("site_code")).distinct()

# COMMAND ----------

cat_prod_core = prod.select(col("sorting_index"), col("brand"), col("category_code"), col("category").alias("category_name"), col("cotc"), concat(col("brand"), lit("_"),col("Category_code"), lit("_"), col("cotc")).alias("brand_cat_core")).distinct()

# COMMAND ----------

sm_sf_mid = sm.select(col("salesman_code"), col("salesforce")).distinct()
sm_sf = sm_sf_mid.select(col("salesforce")).distinct()

# COMMAND ----------

#file=("/mnt/adls/EDGE_Analytics/Datalake/Transformed/Masters/Category_product/"+update_dt)
cat_prod.coalesce(1).write.mode("overwrite").option("header", "true")\
.option("emptyValue", None)\
.option("nullValue", None).csv(Output_Category_Product)

dis_site.coalesce(1).write.mode("overwrite").option("header", "true")\
.option("emptyValue", None)\
.option("nullValue", None).csv(Output_Distributor_Site)

cat_prod_core.coalesce(1).write.mode("overwrite").option("header", "true")\
.option("emptyValue", None)\
.option("nullValue", None).csv(Output_Product_cat_core)

sm_sf.coalesce(1).write.mode("overwrite").option("header", "true")\
.option("emptyValue", None)\
.option("nullValue", None).csv(Output_unique_sf)

# COMMAND ----------

from datetime import datetime, timezone

utc_dt = datetime.now(timezone.utc) # UTC time

import pytz

tz = pytz.timezone('Asia/Bangkok')
vn_now = datetime.now(tz)

print(vn_now)