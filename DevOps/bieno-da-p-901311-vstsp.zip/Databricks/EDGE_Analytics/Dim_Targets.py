# Databricks notebook source
from pyspark.sql.functions import *
from datetime import datetime
from dateutil.relativedelta import *
from pyspark.sql import Window
from pyspark.sql.functions import col


'''path_dss = []
for i in range(1,4):
  files = (dbutils.fs.ls(("/mnt/adls/EDGE_Analytics/Datalake/Transformed/Transactional/DSS/")+(datetime.today() - relativedelta(months=i)).strftime('%Y/%m/')))
  for j in files:
    path_dss.append(j[0])'''

'''path_dss2 = ("/mnt/adls/EDGE_Analytics/Datalake/Transformed/Transactional/DSS/")+((datetime.today() - relativedelta(months=2)).strftime('%Y/%m/')+"*/*.csv")

path_dss3 = ("/mnt/adls/EDGE_Analytics/Datalake/Transformed/Transactional/DSS/")+((datetime.today() - relativedelta(months=3)).strftime('%Y/%m/')+"*/*.csv")
'''

tgt_year = dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/Transformed/Target/Distributor_Site_Category_Sales/")
tgt_month = dbutils.fs.ls(tgt_year[-1][0])
tgt_date = dbutils.fs.ls(tgt_month[-1][0])
tgt_file = dbutils.fs.ls(tgt_date[-1][0])
path_tgt = tgt_file[-1][0]

sm_year = dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/Transformed/Masters/Salesman/")
sm_month = dbutils.fs.ls(sm_year[-1][0])
sm_date = dbutils.fs.ls(sm_month[-1][0])
sm_file = dbutils.fs.ls(sm_date[-1][0])
path_sm = sm_file[-1][0]


prod_year = dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/Transformed/Masters/Product/")
prod_month = dbutils.fs.ls(prod_year[-1][0])
prod_date = dbutils.fs.ls(prod_month[-1][0])
prod_file = dbutils.fs.ls(prod_date[-1][0])
path_prod = prod_file[-1][0]


# COMMAND ----------


tgt = spark.read.csv(path_tgt , header='true')

'''dss= spark.read.csv(path_dss[0]+'*.csv' , header='true')
for i in path_dss[1:]:
  dss = dss.unionAll(spark.read.option("header",True).csv(i+'*.csv'))'''

dss = spark.read.csv("/mnt/adls/EDGE_Analytics/Datalake/Transaction/DSS/Historical/2020/10/22/*csv",header = 'true').filter((substring(col("invoice_date"),1,6)).isin(["202009","202008","202007"]))

sm = spark.read.csv(path_sm , header='true')

prod = spark.read.csv(path_prod , header='true')

for col in tgt.columns:
  tgt = tgt.withColumnRenamed(col,col.replace(" ",""))
  

# COMMAND ----------

dss.show()

# COMMAND ----------

from pyspark.sql import Window
from pyspark.sql.functions import col
tgt_dist = tgt.groupBy(["year", "month", "year_month", "distributor_code", "site_code"]).agg( sum(coalesce("target",lit(0))).alias("target"))
tgt_dist.show()


# COMMAND ----------

dss_df = dss.select(col("master_site_code").alias("site_code"), col("master_salesman_code").alias("salesman_code"), col("invoice_date"), col("GrossSalesValue").cast("int"))
dss_agg = dss_df.groupBy(["site_code", "salesman_code", "invoice_date"]).agg(sum(coalesce("GrossSalesValue",lit(0))).alias("gsv"))
dss_agg.show()

# COMMAND ----------

dss_sf = dss_agg.join(sm.select(col("salesman_code"), col("salesforce")).distinct(),dss_agg.salesman_code == sm.salesman_code, how = "left").select(col("site_code"), col("salesforce"), col("gsv")).groupBy(["site_code","salesforce"]).agg(sum("gsv").alias("gsv_sf"))
dss_sf.show()

# COMMAND ----------

dss1 = dss_sf.withColumn("gsv_site", sum(col("gsv_sf")).over(Window.partitionBy(col("site_code"))))
tgt_sf = tgt_dist.join(dss1, dss1.site_code == tgt_dist.site_code , how = 'left').select(col("year"), col("month"), tgt.year_month,col("distributor_code"), tgt.site_code, col("salesforce"),  (col("target")*(col("gsv_sf")/col("gsv_site"))).alias("target_sf"))
tgt_sf.show(1000)

# COMMAND ----------

dss_prod = dss.select(col("master_site_code").alias("site_code"), col("product_code"), col("GrossSalesValue").cast("int"))
dss_prod_agg = dss_prod.groupBy(["site_code", "product_code"]).agg(sum(coalesce("GrossSalesValue",lit(0))).alias("gsv"))
dss_prod_agg.show()

# COMMAND ----------

dss_prod_join = dss_prod_agg.join(prod.select(col("product_code"), col("cotc"), col("brand"), col("category_code")).distinct(),dss_prod_agg.product_code == prod.product_code, how = "left").select(col("site_code"), col("category_code"),col("brand"), col("cotc"), col("gsv")).groupBy(["site_code", "category_code", "brand", "cotc"]).agg(sum("gsv").alias("gsv_brand_core"))
dss_prod_join.show()

# COMMAND ----------

dss_prod1 = dss_prod_join.withColumn("gsv_cat", sum(col("gsv_brand_core")).over(Window.partitionBy(col("site_code"), col("category_code"))))
dss_prod1.show()

# COMMAND ----------

tgt_prod = tgt.join(dss_prod1, (dss_prod1.site_code == tgt.site_code) & (dss_prod1.category_code == tgt.master_product_Category_code) , how = 'left').select(col("year"), col("month"), tgt.year_month, col("distributor_code"), tgt.site_code, col("master_product_Category_code"), col("brand"), col("cotc"),  (col("target")*(col("gsv_brand_core")/col("gsv_cat"))).alias("target_prod")).withColumn("brand_cat_core", concat(col("brand"), lit("_"),col("master_product_Category_code"), lit("_"), col("cotc")))
tgt_prod.show(1000)

# COMMAND ----------

update_dt = datetime.today().strftime('%Y/%m/%d/')
update_dt
file=("/mnt/adls/EDGE_Analytics/Datalake/Transformed/Target/Distributor_tgt/"+update_dt)
tgt_dist.coalesce(1).write.mode("overwrite").option("header", "true")\
.option("emptyValue", None)\
.option("nullValue", None).csv(file)

file=("/mnt/adls/EDGE_Analytics/Datalake/Transformed/Target/Salesforce_tgt/"+update_dt)
tgt_sf.coalesce(1).write.mode("overwrite").option("header", "true")\
.option("emptyValue", None)\
.option("nullValue", None).csv(file)

file=("/mnt/adls/EDGE_Analytics/Datalake/Transformed/Target/Product_tgt/"+update_dt)
tgt_prod.coalesce(1).write.mode("overwrite").option("header", "true")\
.option("emptyValue", None)\
.option("nullValue", None).csv(file)


# COMMAND ----------

