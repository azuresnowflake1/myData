# Databricks notebook source
# MAGIC %run "/Shared/EDGE_Analytics/DSS - Transformed"

# COMMAND ----------

dbutils.widgets.text("OP_Distributor_Site_Category_Brand_Core", "","")

OP_Distributor_Site_Category_Brand_Core = dbutils.widgets.get("OP_Distributor_Site_Category_Brand_Core")

print(OP_Distributor_Site_Category_Brand_Core)

# COMMAND ----------

from pyspark.sql import types

prodPath      = "/mnt/adls/EDGE_Analytics/Datalake/Transformed/Dimensions/Product/"
timePath      = "/mnt/adls/EDGE_Analytics/Datalake/Transformed/Dimensions/Time/"
#tsdscPath       = "/mnt/adls/EDGE_Analytics/Datalake/Transformed/Facts/Targets/Distributor_Site_Category_Sales/"
salesmanMaster= "/mnt/adls/EDGE_Analytics/Datalake/Transformed/Dimensions/Salesman/"

# COMMAND ----------

yearPD = str(max([i.name.replace('/','') for i in dbutils.fs.ls (prodPath)]))
monthPD= str(max([i.name.replace('/','') for i in dbutils.fs.ls (prodPath +"/" +str(yearPD))]))
dayPD  = str(max([i.name.replace('/','') for i in dbutils.fs.ls (prodPath +"/"+str(yearPD)+"/"+str(monthPD))]))

yearTD = str(max([i.name.replace('/','') for i in dbutils.fs.ls (timePath)]))
monthTD= str(max([i.name.replace('/','') for i in dbutils.fs.ls (timePath +"/" +str(yearTD))]))
dayTD  = str(max([i.name.replace('/','') for i in dbutils.fs.ls (timePath +"/"+str(yearTD)+"/"+str(monthTD))]))

dataPD= spark.read.option("header","true").csv(prodPath+yearPD+"/"+monthPD+"/"+dayPD)
dataPD.createOrReplaceTempView ("dim_product")

dataTD= spark.read.option("header","true").csv(timePath+yearTD+"/"+monthTD+"/"+dayTD)
dataTD.createOrReplaceTempView ("dim_time")

dataSM= spark.read.option("header","true").csv(salesmanMaster+yearSM+"/"+monthSM+"/"+daySM)
dataSM.createOrReplaceTempView ("dim_salesman")

dataTSDC= spark.table("ref_dist_site_cat_sales")
dataTSDC.createOrReplaceTempView ("tgt_distributor_site_category")

# COMMAND ----------

print("Product dim row count is : ")
dataPD.count()

# COMMAND ----------

print("Time dim row count is : ")
dataTD.count()

# COMMAND ----------

print("Salesman dim row count is : ")
dataSM.count()

# COMMAND ----------

print("Target data row count is : ")
dataTSDC.count()

# COMMAND ----------

# MAGIC %sql
# MAGIC --drop table if exists tgt_distributor_site_product;
# MAGIC create table if not exists tgt_distributor_site_product
# MAGIC   (
# MAGIC   year integer,
# MAGIC   month integer,
# MAGIC   year_month integer,
# MAGIC   brand_cat_core string,
# MAGIC   distributor_code string,
# MAGIC   site_code string,
# MAGIC   master_product_Category_code string,
# MAGIC   brand string,
# MAGIC   cotc string,
# MAGIC   before_target_prod double,
# MAGIC   after_target_prod double
# MAGIC   )
# MAGIC   using delta
# MAGIC   location "/mnt/adls/EDGE_Analytics/Datalake/Transformed/Facts/Targets/Distributor_Site_Category_Brand_Core/delta/"

# COMMAND ----------

spark.sql("""
SELECT t.year_month,transactional_site_code , ds.category_code, ds.brand, cotc,  sum(gross_sales_val * 1.0)  as transactional_brand_cotc_GSV
,min(FirstDayofPrev3Month) as 3_mon_start
,max(LastDayofPrevMonth) as 3_mon_end
  FROM fact_daily_sales as ds
  left JOIN dim_time t
on t.Dt_og = ds.invoice_date
left JOIN dim_product p
on p.product_code = ds.product_code
--where transactional_site_code='3002'
group by t.year_month,transactional_site_code , ds.category_code, ds.brand, cotc 
""").createOrReplaceTempView("transactional_gsv_site_cat_brand_cotc_dtl")

# COMMAND ----------

spark.sql("""
select *,sum(transactional_brand_cotc_GSV) over(partition by  cotc ,category_code,transactional_site_code ,brand order by year_month   rows between  3 preceding and  1  preceding) as tot_last_3_months from transactional_gsv_site_cat_brand_cotc_dtl
""").createOrReplaceTempView("transactional_gsv_site_cat_brand_cotc")

# COMMAND ----------

spark.sql("""
SELECT t.year_month,master_site_code , ds.category_code, ds.brand, cotc,  sum(gross_sales_val * 1.0) as master_brand_cotc_GSV
,min(FirstDayofPrev3Month)
,max(LastDayofPrevMonth)
  FROM view_fact_daily_sales as ds
 
  left JOIN dim_time t
on t.Dt_og = ds.invoice_date
left JOIN dim_product p
on p.product_code = ds.product_code
--where master_site_code='3002'
group by t.year_month,master_site_code , ds.category_code, ds.brand, cotc 
""").createOrReplaceTempView("master_gsv_site_cat_brand_cotc_dtl")

# COMMAND ----------

spark.sql("""
select *,sum(master_brand_cotc_GSV) over(partition by  cotc ,category_code,master_site_code ,brand order by year_month rows between 3 preceding and 1 preceding ) as tot_last_3_months from master_gsv_site_cat_brand_cotc_dtl
""").createOrReplaceTempView("master_gsv_site_cat_brand_cotc")

# COMMAND ----------

spark.sql("""
SELECT year_month,transactional_site_code , category_code , sum(tot_last_3_months) as transactional_site_cat_gsv
FROM transactional_gsv_site_cat_brand_cotc
group by year_month,transactional_site_code , category_code 
""").createOrReplaceTempView("transactional_site_cat_gsv")

# COMMAND ----------

spark.sql("""
SELECT year_month,master_site_code , category_code , sum(tot_last_3_months) as master_site_cat_gsv
FROM master_gsv_site_cat_brand_cotc
group by year_month,master_site_code , category_code 
""").createOrReplaceTempView("master_site_cat_gsv")

# COMMAND ----------

spark.sql("""
SELECT year,
month,
year_month,
distributor_code, 
site_code, 
master_prod_cat_code as master_product_Category_code,
before_transition_target, 
after_transition_target
FROM tgt_distributor_site_category
""").createOrReplaceTempView("tgt_distributor_site_cat")

# COMMAND ----------

spark.sql("""

select 


substring(tgscbc.year_month,1,4) as year,substring(tgscbc.year_month,5,2) as month ,
tgscbc.year_month as year_month,

concat(tgscbc.brand,'_',tgscbc.category_code,'_',tgscbc.cotc) as brand_cat_core,
distributor_code,
site_code ,
tgscbc.category_code as master_product_category_code,
tgscbc.brand,
tgscbc.cotc, 
(before_transition_target * tgscbc.tot_last_3_months)/(transactional_site_cat_GSV) as before_transition_target,
(after_transition_target * mgscbc.tot_last_3_months)/(master_site_cat_GSV) as after_transition_target

FROM 

transactional_gsv_site_cat_brand_cotc tgscbc
left join master_gsv_site_cat_brand_cotc mgscbc
on mgscbc.year_month = tgscbc.year_month and 
mgscbc.master_site_code = tgscbc.transactional_site_code and mgscbc.category_code = tgscbc.category_code and mgscbc.brand = tgscbc.brand and mgscbc.cotc = tgscbc.cotc

LEFT join
tgt_distributor_site_cat tgt
on tgt.year_month = tgscbc.year_month and
tgt.site_code = tgscbc.transactional_site_code and tgt.master_product_Category_code = tgscbc.category_code


left join transactional_site_cat_gsv tscg
on tscg.year_month = tgt.year_month and 
tscg.transactional_site_code = tgt.site_code and tscg.category_code = tgt.master_product_Category_code


left join master_site_cat_gsv mscg
on mgscbc.year_month = mscg.year_month and
mgscbc.master_site_code = mscg.master_site_code and mgscbc.category_code = mscg.category_code

""").createOrReplaceTempView("derived")

# COMMAND ----------

# MAGIC %md
# MAGIC #########################################
# MAGIC spark.sql("""
# MAGIC select substring(mgscbc.year_month,1,4) as year,substring(mgscbc.year_month,5,2) as month ,mgscbc.year_month as year_month,
# MAGIC 
# MAGIC concat(mgscbc.brand,'_',master_product_category_code,'_',mgscbc.cotc) as brand_cat_core,
# MAGIC distributor_code,
# MAGIC site_code ,
# MAGIC master_product_category_code,
# MAGIC mgscbc.brand,
# MAGIC mgscbc.cotc, 
# MAGIC (before_transition_target * tgscbc.tot_last_3_months)/(transactional_site_cat_GSV) as before_transition_target,
# MAGIC (after_transition_target * mgscbc.tot_last_3_months)/(master_site_cat_GSV) as after_transition_target
# MAGIC 
# MAGIC FROM master_gsv_site_cat_brand_cotc mgscbc
# MAGIC left join master_site_cat_gsv mscg
# MAGIC on mgscbc.year_month = mscg.year_month and
# MAGIC mgscbc.master_site_code = mscg.master_site_code and mgscbc.category_code = mscg.category_code
# MAGIC 
# MAGIC LEFT join
# MAGIC tgt_distributor_site_cat tgt
# MAGIC on tgt.year_month = mgscbc.year_month and
# MAGIC tgt.site_code = mgscbc.master_site_code and tgt.master_product_Category_code = mgscbc.category_code
# MAGIC 
# MAGIC left join transactional_gsv_site_cat_brand_cotc tgscbc
# MAGIC on mgscbc.year_month = tgscbc.year_month and 
# MAGIC mgscbc.master_site_code = tgscbc.transactional_site_code and mgscbc.category_code = tgscbc.category_code and mgscbc.brand = tgscbc.brand and mgscbc.cotc = tgscbc.cotc
# MAGIC left join transactional_site_cat_gsv tscg
# MAGIC on tscg.year_month = tgt.year_month and 
# MAGIC tscg.transactional_site_code = tgt.site_code and tscg.category_code = tgt.master_product_Category_code
# MAGIC """).createOrReplaceTempView("derived")

# COMMAND ----------

print("performing cleanup") 

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC vacuum tgt_distributor_site_product retain 168 hours;
# MAGIC 
# MAGIC truncate table tgt_distributor_site_product;

# COMMAND ----------

print("performing merge")
  
spark.sql("""
  merge into tgt_distributor_site_product tgt
  using derived as src
  on 1=2
/*on tgt.year = src.year
  and tgt.month = src.month
  and tgt.year_month = src.year_month
  and tgt.brand_cat_core = src.brand_cat_core
  and tgt.distributor_code = src.distributor_code
  and tgt.site_code = src.site_code
  and tgt.master_product_Category_code = src.master_product_Category_code
  and tgt.brand = src.brand
  and tgt.cotc = src.cotc
  when matched then update
  set 
  tgt.before_target_prod=src.before_transition_target,
  tgt.after_target_prod=src.after_transition_target
*/  
  when not matched then insert
  (
  year,
  month,
  year_month,
  brand_cat_core,
  distributor_code,
  site_code,
  master_product_Category_code,
  brand,
  cotc,
  before_target_prod,
  after_target_prod
  )
  values
  (
  src.year,
  src.month,
  src.year_month,
  src.brand_cat_core,
  src.distributor_code,
  src.site_code,
  src.master_product_Category_code,
  src.brand,
  src.cotc,
  src.before_transition_target,
  src.after_transition_target
  )
  """)

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC select count(1) from tgt_distributor_site_product

# COMMAND ----------

df_csv_builder=spark.table("tgt_distributor_site_product")

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql import functions as f
from datetime import datetime

# COMMAND ----------

#/mnt/adls/EDGE_Analytics/Datalake/Transformed/Facts/Targets/Distributor_Site_Category_Brand_Core/

update_dt = datetime.today().strftime('%Y/%m/%d')
file_dt=(OP_Distributor_Site_Category_Brand_Core+update_dt)
df_csv_builder.coalesce(1).write.mode("overwrite").option("header", "true")\
.option("emptyValue", None)\
.option("nullValue", None).csv(file_dt)

# COMMAND ----------

