# Databricks notebook source
dbutils.widgets.text("IP_path", "","")
IP_path = dbutils.widgets.get("IP_path")

dbutils.widgets.text("OP_path", "","")
OP_path = dbutils.widgets.get("OP_path")

#/mnt/adls/EDGE_Analytics/Datalake/Staging/Incremental/FMT/
#/mnt/adls/EDGE_Analytics/Datalake/Processed/FMT/

print(IP_path)
print(OP_path)

# COMMAND ----------

from pyspark.sql.functions import *
from datetime import datetime
from pyspark.sql import Window
import re

month_map=dict(
  JAN='01',
  FEB='02',
  MAR='03',
  APR='04',
  MAY='05',
  JUN='06',
  JUL='07',
  AUG='08',
  SEP='09',
  OCT='10',
  NOV='11',
  DEC='12'
)
#print(month_map)   

cm=[]
a=[]
month_no = None

"""
cm_year = dbutils.fs.ls(IP_path)

print(cm_year)

lst=[]
for ab in cm_year:
  lst.append(ab.name)
print(lst)

cm_file = dbutils.fs.ls(cm_year[-1][0])

print(cm_file)

for i in cm_file:
  for j in dbutils.fs.ls(i[0]):
    for k in dbutils.fs.ls(j[0]):
      for l in dbutils.fs.ls(k[0]):
        cm.append(l[0]) 

"""

for m in dbutils.fs.ls(IP_path):
  cm_file = dbutils.fs.ls(m[0])
  for i in cm_file:
    for j in dbutils.fs.ls(i[0]):
      for k in dbutils.fs.ls(j[0]):
        for l in dbutils.fs.ls(k[0]):
          cm.append(l[0]) 

#print(cm)
for i in cm:
  year=str(i.split('/')[-4])
  month=str(month_map[i.split('/')[-3].upper()])
  day=str(i.split('/')[-2])
  filename=str(i.split('/')[-1])
  
  tmp = [i,year + month + day , filename]
  #print(tmp)
  #print("")
  a.append(tmp)
  
#print(a)

import databricks.koalas as pd
df=pd.DataFrame(a,columns=['filepath','filercvddate','filename']).to_spark()

df.createOrReplaceTempView('latest')

dfout=spark.sql("""select *,
                year(current_timestamp()) as yr,
                lpad(month(current_timestamp()),2,'0') as mo,
                lpad(day(current_timestamp()),2,'0') as dt 
                from (select row_number() over (partition by filename order by cast(filercvddate as int) desc) as rnk, * from latest) where rnk=1""")

dfout.show(50)

lst=dfout.collect()

# COMMAND ----------

for i in lst:
  print(i['filepath'])
  yrmodt=str(i['yr']) + '/'+ str(i['mo']) + '/' + str(i['dt']) 
  final_path=OP_path +  yrmodt + '/' + str(i['filename'])
  #print(final_path)
  
  dbutils.fs.cp(i['filepath'],final_path)



# COMMAND ----------

