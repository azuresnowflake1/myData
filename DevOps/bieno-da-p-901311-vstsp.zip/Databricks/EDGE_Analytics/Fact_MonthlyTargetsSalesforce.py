# Databricks notebook source
# MAGIC %run "/Shared/EDGE_Analytics/DSS - Transformed"

# COMMAND ----------

dbutils.widgets.text("OP_Distributor_Site_Salesforce", "","")

OP_Distributor_Site_Salesforce = dbutils.widgets.get("OP_Distributor_Site_Salesforce")

print(OP_Distributor_Site_Salesforce)

# COMMAND ----------

from pyspark.sql import types

prodPath      = "/mnt/adls/EDGE_Analytics/Datalake/Transformed/Dimensions/Product/"
timePath      = "/mnt/adls/EDGE_Analytics/Datalake/Transformed/Dimensions/Time/"
#tsdscPath       = "/mnt/adls/EDGE_Analytics/Datalake/Transformed/Facts/Distributor_Site_Category_Sales_Monthly_Targets/"
salesmanMaster= "/mnt/adls/EDGE_Analytics/Datalake/Transformed/Dimensions/Salesman/"

# COMMAND ----------

yearPD = str(max([i.name.replace('/','') for i in dbutils.fs.ls (prodPath)]))
monthPD= str(max([i.name.replace('/','') for i in dbutils.fs.ls (prodPath +"/" +str(yearPD))]))
dayPD  = str(max([i.name.replace('/','') for i in dbutils.fs.ls (prodPath +"/"+str(yearPD)+"/"+str(monthPD))]))

yearTD = str(max([i.name.replace('/','') for i in dbutils.fs.ls (timePath)]))
monthTD= str(max([i.name.replace('/','') for i in dbutils.fs.ls (timePath +"/" +str(yearTD))]))
dayTD  = str(max([i.name.replace('/','') for i in dbutils.fs.ls (timePath +"/"+str(yearTD)+"/"+str(monthTD))]))


dataPD= spark.read.option("header","true").csv(prodPath+yearPD+"/"+monthPD+"/"+dayPD)
dataPD.createOrReplaceTempView ("dim_product")

dataTD= spark.read.option("header","true").csv(timePath+yearTD+"/"+monthTD+"/"+dayTD)
dataTD.createOrReplaceTempView ("dim_time")

dataSM= spark.read.option("header","true").csv(salesmanMaster+yearSM+"/"+monthSM+"/"+daySM)
dataSM.createOrReplaceTempView ("dim_salesman")

dataTSDC= spark.table("ref_dist_site_cat_sales")
dataTSDC.createOrReplaceTempView ("tgt_distributor_site_category")

# COMMAND ----------

print("Product dim row count is : ")
dataPD.count()

# COMMAND ----------

print("Time dim row count is : ")
dataTD.count()

# COMMAND ----------

print("Salesman dim row count is : ")
dataSM.count()

# COMMAND ----------

print("Target data row count is : ")
dataTSDC.count()

# COMMAND ----------

# MAGIC %sql
# MAGIC --drop table if  exists tgt_distributor_site_salesforce;
# MAGIC create table if not exists tgt_distributor_site_salesforce
# MAGIC   (
# MAGIC   year integer,
# MAGIC   month integer,
# MAGIC   year_month integer,
# MAGIC   distributor_code string,
# MAGIC   site_code string,
# MAGIC   salesforce string,
# MAGIC   before_transition_target_sf double,
# MAGIC   after_transition_target_sf double
# MAGIC   )
# MAGIC   using delta
# MAGIC   location "/mnt/adls/EDGE_Analytics/Datalake/Transformed/Facts/Targets/Distributor_Site_Salesforce/delta/"

# COMMAND ----------

spark.sql("""
SELECT t.year_month,transactional_site_code , ds.salesforce,   sum(gross_sales_val * 1.0) as transactional_site_sf_GSV
,min(FirstDayofPrev3Month) as 3_mon_start
,max(LastDayofPrevMonth) as 3_mon_end

  FROM view_fact_daily_sales as ds
left  JOIN dim_time t
on t.Dt_og = ds.invoice_date
left JOIN dim_salesman s
on s.salesman_code = ds.master_salesman_code 
--where transactional_site_code='3002'
group by t.year_month,transactional_site_code , ds.salesforce 
""").createOrReplaceTempView("transactional_gsv_site_salesforce_dtl")

# COMMAND ----------

spark.sql("""
select *,sum(transactional_site_sf_GSV) over(partition by  salesforce ,transactional_site_code  order by year_month   rows between  3 preceding and  1  preceding) as tot_last_3_months 
from transactional_gsv_site_salesforce_dtl
""").createOrReplaceTempView("transactional_gsv_site_salesforce")

# COMMAND ----------

spark.sql("""
SELECT year_month,transactional_site_code ,3_mon_start,3_mon_end , sum(tot_last_3_months) as transactional_site_GSV
  FROM transactional_gsv_site_salesforce
group by year_month,transactional_site_code ,3_mon_start,3_mon_end 
""").createOrReplaceTempView("transactional_gsv_site")

# COMMAND ----------

spark.sql("""
SELECT t.year_month,master_site_code , ds.salesforce,  sum(gross_sales_val * 1.0) as master_site_sf_GSV
,min(FirstDayofPrev3Month) as 3_mon_start
,max(LastDayofPrevMonth) as 3_mon_end

  FROM view_fact_daily_sales as ds
left  JOIN dim_time t
on t.Dt_og = ds.invoice_date
left JOIN dim_salesman s
on s.salesman_code = ds.master_salesman_code 
--where master_site_code='3002'
group by t.year_month,master_site_code , ds.salesforce 
""").createOrReplaceTempView("master_gsv_site_salesforce_dtl")

# COMMAND ----------

spark.sql("""
select *,sum(master_site_sf_GSV) over(partition by  salesforce ,master_site_code  order by year_month   rows between  3 preceding and  1  preceding) as tot_last_3_months 
from master_gsv_site_salesforce_dtl
""").createOrReplaceTempView("master_gsv_site_salesforce")

# COMMAND ----------

spark.sql("""
SELECT year_month,master_site_code ,3_mon_start,3_mon_end ,  sum(tot_last_3_months) as master_site_GSV
  FROM master_gsv_site_salesforce
group by year_month,master_site_code ,3_mon_start,3_mon_end 
""").createOrReplaceTempView("master_gsv_site")

# COMMAND ----------

spark.sql("""
SELECT year_month,distributor_code, site_code, sum (before_transition_target) as before_transition_target , sum(after_transition_target) as after_transition_target
FROM tgt_distributor_site_category

group by year_month,distributor_code ,site_code
""").createOrReplaceTempView("tgt_distributor_site")

# COMMAND ----------

spark.sql("""
  select   
  substring(tsf.year_month,1,4) as year,
  substring(tsf.year_month,5,2) as month ,
  tsf.year_month as year_month,
  distributor_code,
  site_code , 
  tsf.salesforce , 
   
  (before_transition_target * tsf.tot_last_3_months)/(ts.transactional_site_GSV) as before_transition_target_sf,
  (after_transition_target * msf.tot_last_3_months)/(ms.master_site_GSV) as after_transition_target_sf
  
  FROM transactional_gsv_site_salesforce tsf
  
  LEFT join  master_gsv_site_salesforce msf
  on   msf.year_month=tsf.year_month and  
  msf.master_site_code = tsf.transactional_site_code and msf.salesforce = tsf.salesforce
  
  left join transactional_gsv_site ts
  on   ts.year_month=tsf.year_month and 
  ts.transactional_site_code = tsf.transactional_site_code
  
    LEFT join   tgt_distributor_site tgt
  on   tgt.year_month=tsf.year_month and 
  tgt.site_code = tsf.transactional_site_code


  left join master_gsv_site ms
  on   msf.year_month=ms.year_month and  
  msf.master_site_code = ms.master_site_code
  

  """).createOrReplaceTempView("derivative")

# COMMAND ----------

print("performing cleanup") 

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC vacuum tgt_distributor_site_salesforce retain 168 hours;
# MAGIC 
# MAGIC truncate table tgt_distributor_site_salesforce;

# COMMAND ----------

print("performing merge")
  
spark.sql("""
  merge into tgt_distributor_site_salesforce tgt
  using derivative as src
  
  on 1=2
  
 /* 
 on tgt.year = src.year
  and tgt.month = src.month
  and tgt.year_month = src.year_month
  and tgt.distributor_code = src.distributor_code
  and tgt.site_code = src.site_code
  and tgt.salesforce = src.salesforce
  when matched then update
  set 
  tgt.before_transition_target_sf=src.before_transition_target_sf,
  tgt.after_transition_target_sf=src.after_transition_target_sf
 */
 
  when not matched then insert
  (
  year,
  month,
  year_month,
  distributor_code,
  site_code,
  salesforce,
  before_transition_target_sf,
  after_transition_target_sf
  )
  values
  (
  src.year,
  src.month,
  src.year_month,
  src.distributor_code,
  src.site_code,
  src.salesforce,
  src.before_transition_target_sf,
  src.after_transition_target_sf
  )
  """)
  



# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC select count(1) from tgt_distributor_site_salesforce

# COMMAND ----------

df_csv_builder=spark.table("tgt_distributor_site_salesforce")

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql import functions as f
from datetime import datetime

# COMMAND ----------

#/mnt/adls/EDGE_Analytics/Datalake/Transformed/Facts/Targets/Distributor_Site_Salesforce/

update_dt = datetime.today().strftime('%Y/%m/%d')
file_dt=(OP_Distributor_Site_Salesforce+update_dt)
df_csv_builder.coalesce(1).write.mode("overwrite").option("header", "true")\
.option("emptyValue", None)\
.option("nullValue", None).csv(file_dt)

# COMMAND ----------

