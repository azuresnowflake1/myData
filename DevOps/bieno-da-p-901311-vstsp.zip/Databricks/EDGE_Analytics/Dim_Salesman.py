# Databricks notebook source
dbutils.widgets.text("Salesman_SPG_Mapping", "","")
dbutils.widgets.text("Salesman_PH_Group_Mapping", "","")
dbutils.widgets.text("Salesforce_Hierarchy", "","")
dbutils.widgets.text("Salesman", "","")

IP_Salesman_SPG_Mapping = dbutils.widgets.get("Salesman_SPG_Mapping")
IP_Salesman_PH_Group_Mapping = dbutils.widgets.get("Salesman_PH_Group_Mapping")
IP_Salesforce_Hierarchy = dbutils.widgets.get("Salesforce_Hierarchy")
OP_Salesman = dbutils.widgets.get("Salesman")
#new: /mnt/adls/EDGE_Analytics/Datalake/Processed/FMT/
#old: /mnt/adls/EDGE_Analytics/Datalake/Staging/Incremental/Masters/Salesman_Product_group_Mapping/

print(IP_Salesman_SPG_Mapping)
print(IP_Salesman_PH_Group_Mapping)
print(IP_Salesforce_Hierarchy)
print(OP_Salesman)


# COMMAND ----------

from pyspark.sql.types import *

# COMMAND ----------

spg_year = dbutils.fs.ls(IP_Salesman_SPG_Mapping)
#spg_year = dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/Staging/Incremental/Masters/Salesman_SPG_Mapping/")
spg_month = dbutils.fs.ls(spg_year[-1][0])
spg_date = dbutils.fs.ls(spg_month[-1][0])
spg_file = dbutils.fs.ls(spg_date[-1][0])
path_spg = spg_file[-1][0]

"""
sgm_year = dbutils.fs.ls(IP_Salesman_PH_Group_Mapping)
#sgm_year = dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/Staging/Incremental/Masters/Salesman_Product_group_Mapping/")
sgm_month = dbutils.fs.ls(sgm_year[-1][0])
sgm_date = dbutils.fs.ls(sgm_month[-1][0])
sgm_file = dbutils.fs.ls(sgm_date[-1][0])
path_sgm = sgm_file[-1][0]
print(sgm_date)
"""

sgm_year = str(max([i.name.replace('/','') for i in dbutils.fs.ls (IP_Salesman_PH_Group_Mapping)]))
sgm_month= str(max([i.name.replace('/','') for i in dbutils.fs.ls (IP_Salesman_PH_Group_Mapping +"/" +str(sgm_year))]))
sgm_date  = str(max([i.name.replace('/','') for i in dbutils.fs.ls (IP_Salesman_PH_Group_Mapping +"/"+str(sgm_year)+"/"+str(sgm_month))]))
sgm_file="VN_SPG_MAP.csv"
path_sgm=IP_Salesman_PH_Group_Mapping+sgm_year+"/"+sgm_month+"/"+sgm_date+"/"+sgm_file
print(path_sgm)


salesforce_hierarchy_year = dbutils.fs.ls(IP_Salesforce_Hierarchy)
#salesforce_hierarchy_year = dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/Staging/Incremental/Masters/Salesforce_Hierarchy/")
salesforce_hierarchy_month = dbutils.fs.ls(salesforce_hierarchy_year[-1][0])
salesforce_hierarchy_date = dbutils.fs.ls(salesforce_hierarchy_month[-1][0])
salesforce_hierarchy_file = dbutils.fs.ls(salesforce_hierarchy_date[-1][0])
path_salesforce_hierarchy = salesforce_hierarchy_file[-1][0]

fcs_year = dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/Staging/Incremental/Transaction/FCS_Salesperson/")
fcs_month = dbutils.fs.ls(fcs_year[-1][0])
fcs_date = dbutils.fs.ls(fcs_month[-1][0])
fcs_files = fcs_date[-1][0]

print(fcs_files)

# COMMAND ----------

from pyspark.sql.functions import *

# COMMAND ----------

df_fcs1 = spark.read.csv(fcs_files+"/*/*.csv" , header='true')

# COMMAND ----------

"""
df_fcs = df_fcs1.select(concat(substring(col("calender_month"),-4,4),substring(col("calender_month"),1,2)).alias("cal_month"), col("salesman_code"), col("salesman").alias("salesman_name")).withColumn("max_cal_month", expr("max(cal_month) over(partition by salesman_code order by calender_month)")).filter(expr("cal_month == max_cal_month"))\
.distinct().orderBy("cal_month","salesman_code")
"""

# COMMAND ----------

df_fcs = df_fcs1.select(
  concat(substring(col("calender_month"),-4,4),substring(col("calender_month"),1,2)).alias("cal_month"), 
  col("salesman_code"), 
  col("salesman").alias("salesman_name")).withColumn("rownum", expr("row_number() over(partition by salesman_code order by cast(cal_month as int) desc)")).where(col("rownum") == 1).distinct().orderBy("cal_month","salesman_code")

# COMMAND ----------

df_fcs.createOrReplaceTempView('tmp_fcs')

# COMMAND ----------

df_fcs.count()

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC select salesman_code,count(1) from tmp_fcs
# MAGIC group by salesman_code
# MAGIC having count(1) > 1

# COMMAND ----------

from pyspark.sql import functions as f
from datetime import datetime
df_SPG = spark.read.csv(path_spg , header='true')
df_SGM = spark.read.csv(path_sgm , header='true')
df_salesforce_hierarchy = spark.read.csv(path_salesforce_hierarchy, header='true')

# COMMAND ----------

df_SPG.count()

# COMMAND ----------

df_SGM.count()

# COMMAND ----------

df_salesforce_hierarchy.count()

# COMMAND ----------

df_salesforce_hierarchy_columns_renamed = df_salesforce_hierarchy.select(col("Site"),col("Role"),col("Role Name").alias("role_name"),col("Role business scope assignment").alias("role_business_scope_assignment"))
display(df_salesforce_hierarchy_columns_renamed)

# COMMAND ----------

df_salesforce_hierarchy_columns_renamed.count()

# COMMAND ----------

df_sf_ASM = df_salesforce_hierarchy_columns_renamed.filter(col("Role") == 'ASM')\
.select(col("Role"),col("Site"),col("role_name").alias("ASM"),col("role_business_scope_assignment")).withColumn("rownum", expr("row_number() over(partition by Site, Role,role_business_scope_assignment order by 1)")).where(col("rownum") == 1)


df_sf_BM = df_salesforce_hierarchy_columns_renamed.filter(col("Role") == 'BM')\
.select(col("Role"),col("Site"),col("role_name").alias("BM"),col("role_business_scope_assignment")).withColumn("rownum", expr("row_number() over(partition by Site, Role,role_business_scope_assignment order by 1)")).where(col("rownum") == 1)


df_sf_Supervisor = df_salesforce_hierarchy_columns_renamed.filter(col("Role") == 'Supervisor')\
.select(col("Role"),col("Site"),col("role_name").alias("Supervisor"),col("role_business_scope_assignment")).withColumn("rownum", expr("row_number() over(partition by Site, Role,role_business_scope_assignment order by 1)")).where(col("rownum") == 1)




# COMMAND ----------

df_sf_ASM.count()


# COMMAND ----------

df_sf_BM.count()


# COMMAND ----------


df_sf_Supervisor.count()

# COMMAND ----------

salesforce_hierarchy_final = df_sf_ASM.join(df_sf_BM,["Site","role_business_scope_assignment"])\
.join(df_sf_Supervisor,["Site","role_business_scope_assignment"])


# COMMAND ----------

salesforce_hierarchy_final.count()

# COMMAND ----------


df_SGM=df_SGM.select(col("Salesman Product Group Code").alias("Salesman_Product_Group_Code"),col("Salesman Product Group").alias("Salesman_Product_Group"),col("Standardised Salesperson Product Group").alias("Standardised_Salesman_Product_Group"),col("Salesforce").alias("Salesforce"),col("KPI In Scope").alias("KPI_In_Scope"),col("Role Business Scope Assignment").alias("Role_Business_Scope_Assignment"),col("No of Salespersons Serving Outlet in this SPG").alias("No_of_Salespersons_Serving_Outlet_in_this_SPG"),col("Expected SPG").alias("Expected_SPG")).distinct()

# COMMAND ----------

df_SPG_join_SGM = df_SPG.join(df_SGM,df_SPG.VKGRP ==df_SGM.Salesman_Product_Group_Code,how='left').select(df_SPG["PERNR"],df_SPG["VKGRP"],df_SPG["VKORG"],df_SGM["*"]) .distinct()

# COMMAND ----------

df1=df_SPG_join_SGM.select(col("PERNR").cast("int").alias("salesman_code"),col("VKORG").alias("site_code"),col("salesman_product_group_code"),col("salesman_product_group"),col("standardised_salesman_product_group"),col("salesforce"),col("kpi_in_scope"),col("role_business_scope_assignment"),col("no_of_salespersons_serving_outlet_in_this_spg"),col("expected_spg")).distinct()

df2 = df1.join(salesforce_hierarchy_final, (df1.site_code == salesforce_hierarchy_final.Site) & (df1.role_business_scope_assignment == salesforce_hierarchy_final.role_business_scope_assignment),how = 'left').select(df1["*"],col("BM"),col("ASM"),col("Supervisor")).join(df_fcs.select(["salesman_code","salesman_name"]).distinct(),["salesman_code"],"left")

# COMMAND ----------

update_dt = datetime.today().strftime('%Y/%m/%d/')
file_dt=(OP_Salesman+update_dt)
#file=("/mnt/adls/EDGE_Analytics/Datalake/Transformed/Masters/Salesman/"+update_dt)
df2.coalesce(1).write.mode("overwrite").option("header", "true")\
.option("emptyValue", None)\
.option("nullValue", None).csv(file_dt)


# COMMAND ----------

df2.createOrReplaceTempView('cnt_chk')

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC select count(salesman_code ),count(distinct salesman_code ) from cnt_chk

# COMMAND ----------

# MAGIC %sql
# MAGIC select salesman_code, count(1) from cnt_chk
# MAGIC group by salesman_code
# MAGIC having count(1) >1

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC select * from cnt_chk where salesman_code in (
# MAGIC select salesman_code from cnt_chk
# MAGIC group by salesman_code
# MAGIC having count(1) >1)

# COMMAND ----------

