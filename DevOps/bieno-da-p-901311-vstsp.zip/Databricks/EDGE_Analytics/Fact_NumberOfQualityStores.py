# Databricks notebook source
# MAGIC %sql
# MAGIC 
# MAGIC select current_timestamp()

# COMMAND ----------

# MAGIC %run "/Shared/EDGE_Analytics/DSS - Transformed"

# COMMAND ----------

dbutils.widgets.text("OP_qualitystores", "","")

OP_qualitystores = dbutils.widgets.get("OP_qualitystores")

print(OP_qualitystores)

# COMMAND ----------

from pyspark.sql import types

timePath      = "/mnt/adls/EDGE_Analytics/Datalake/Transformed/Dimensions/Time/"


# COMMAND ----------

yearTD = str(max([i.name.replace('/','') for i in dbutils.fs.ls (timePath)]))
monthTD= str(max([i.name.replace('/','') for i in dbutils.fs.ls (timePath +"/" +str(yearTD))]))
dayTD  = str(max([i.name.replace('/','') for i in dbutils.fs.ls (timePath +"/"+str(yearTD)+"/"+str(monthTD))]))


dataTD= spark.read.option("header","true").csv(timePath+yearTD+"/"+monthTD+"/"+dayTD)
dataTD.createOrReplaceTempView ("dim_time")

# COMMAND ----------

# MAGIC %sql
# MAGIC -- drop table if exists fact_qualitystores ;
# MAGIC create table if not exists fact_qualitystores
# MAGIC   (
# MAGIC   distributor_code string,
# MAGIC   year integer,
# MAGIC   month integer,
# MAGIC   wk_no integer,
# MAGIC   total_month_flag string,
# MAGIC   transactional_quality_stores integer,
# MAGIC   master_quality_stores integer,
# MAGIC   transactional_active_stores integer,
# MAGIC   master_active_stores integer
# MAGIC   )
# MAGIC   using delta
# MAGIC   location "/mnt/adls/EDGE_Analytics/Datalake/Transformed/Facts/qualitystores/delta/"

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC drop table if exists master_monthly_sales;
# MAGIC 
# MAGIC create table master_monthly_sales
# MAGIC as
# MAGIC SELECT master_distributor_code , master_outlet_code , sum(Gross_Sales_Val * 1.0) as sales,
# MAGIC T.year_month
# MAGIC FROM	view_fact_daily_sales S
# MAGIC 			left	Join
# MAGIC 				dim_time T
# MAGIC 				ON S.invoice_date = T.Dt_og
# MAGIC                 
# MAGIC                 left join dim_salesman sm
# MAGIC                 on s.transactional_salesman_code=sm.salesman_code
# MAGIC                 where sm.salesforce <> 'Others - Out of Scope'
# MAGIC                 
# MAGIC 				GROUP BY S.master_distributor_code , S.master_outlet_code,T.year_month

# COMMAND ----------

spark.sql("""
(select  distinct master_distributor_code , master_outlet_code,null as sales, t2.year_month from master_monthly_sales
join (select distinct year_month from dim_time) t2 on 1=1
)

except

select distinct master_distributor_code , master_outlet_code,null as sales,year_month from master_monthly_sales   """).createOrReplaceTempView("master_monthly_none_sales") 



# COMMAND ----------

spark.sql("""
select  * from master_monthly_sales 
union
select  * from master_monthly_none_sales 
 """).createOrReplaceTempView("master_monthly_all_none_sales") 



# COMMAND ----------

spark.sql("""
SELECT *, sum(sales) over (partition by master_distributor_code, master_outlet_code order by year_month 
rows between 2 preceding and current row) as sales_3_months
FROM master_monthly_all_none_sales""").createOrReplaceTempView("master_monthly_3mon_sales")

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC drop table if exists trans_monthly_sales;
# MAGIC 
# MAGIC create table trans_monthly_sales
# MAGIC as
# MAGIC SELECT transactional_distributor_code , transactional_outlet_code , sum(Gross_Sales_Val * 1.0) as sales,
# MAGIC T.year_month
# MAGIC FROM	view_fact_daily_sales S
# MAGIC 			left	Join
# MAGIC 				dim_time T
# MAGIC 				ON S.invoice_date = T.Dt_og
# MAGIC                                 
# MAGIC                 left join dim_salesman sm
# MAGIC                 on s.transactional_salesman_code=sm.salesman_code
# MAGIC                 where sm.salesforce <> 'Others - Out of Scope'
# MAGIC                 
# MAGIC 				GROUP BY S.transactional_distributor_code , S.transactional_outlet_code,T.year_month   

# COMMAND ----------

spark.sql("""
(select  distinct transactional_distributor_code , transactional_outlet_code,null as sales, t2.year_month from trans_monthly_sales
join (select distinct year_month from dim_time) t2 on 1=1
)

except

select distinct transactional_distributor_code , transactional_outlet_code,null as sales,year_month from trans_monthly_sales   """).createOrReplaceTempView("trans_monthly_none_sales") 



# COMMAND ----------

spark.sql("""
select  * from trans_monthly_sales
union
select  * from trans_monthly_none_sales
 """).createOrReplaceTempView("trans_monthly_all_none_sales") 



# COMMAND ----------

spark.sql("""
SELECT *, sum(sales) over (partition by transactional_distributor_code, transactional_outlet_code order by year_month 
rows between 2 preceding and current row) as sales_3_months
FROM	trans_monthly_all_none_sales""").createOrReplaceTempView("trans_monthly_3mon_sales")

# COMMAND ----------

spark.sql("""
 select 
 distinct 
 year,
 cast(year_month as int) as year_month,
  month_no,
  cast(wk as int) as wk,
  concat(cast(year as int),lpad(cast(wk as int),2,'0')) as year_wk,

/* 
    case 
    when (cast(wk as int) -13 >0 )
    then concat(cast(year as int),lpad(cast(wk as int)-13,2,'0') )
    else   
    concat(cast(year-1 as int),lpad((b.last_yr_max_wk + wk -13) ,2,'0') ) 

    end   as last_13_year_wk,
*/
  
-- b.last_yr_max_wk

 concat(split(past13week,'_')[1],lpad(split(past13week,'_')[0] , 2,'0')) as last_13_year_wk
 
 
 from dim_time  a

/*

    left join 
    (select  year as yr,max(cast(wk as int)) as last_yr_max_wk from dim_time group by year) as b
    on a.year=(b.yr + 1)

*/
 """).createOrReplaceTempView("week_diff_calculation")

# COMMAND ----------

spark.sql("""

select a.year_month as yrmo,
a.wk as week,
a.year_wk,
count(b.year_wk) as cnt ,
min(b.year_wk),
max(b.year_wk)

from 
week_diff_calculation a  
join week_diff_calculation b 

on  1=1
where 
b.year_wk >= a.last_13_year_wk and  b.year_wk <= a.year_wk

-- b.year_wk > a.last_13_year_wk and  b.year_wk <= a.year_wk

and cast(a.year_month as int)  >= cast(b.year_month as int)

group by a.year_month,a.wk,a.year_wk

--order by a.year_month,cast(a.wk as int)

""").createOrReplaceTempView("week_row_cnt") 

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC select * from week_row_cnt

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC drop table if exists master_weekly_sales;
# MAGIC 
# MAGIC create table master_weekly_sales
# MAGIC as
# MAGIC SELECT master_distributor_code , master_outlet_code , sum(Gross_Sales_Val * 1.0) as sales,
# MAGIC t.wk,T.year_month
# MAGIC FROM	view_fact_daily_sales S
# MAGIC 			left	Join
# MAGIC 				dim_time T
# MAGIC 				ON S.invoice_date = T.Dt_og
# MAGIC                                 
# MAGIC                 left join dim_salesman sm
# MAGIC                 on s.transactional_salesman_code=sm.salesman_code
# MAGIC                 where sm.salesforce <> 'Others - Out of Scope'
# MAGIC                 
# MAGIC 				GROUP BY S.master_distributor_code , S.master_outlet_code,t.wk,T.year_month 

# COMMAND ----------

spark.sql("""
(select  distinct master_distributor_code , master_outlet_code,null as sales, t2.wk,t2.year_month from master_weekly_sales
join (select distinct cast(week as int) as wk,cast(yrmo as int) as year_month from week_row_cnt) t2 on 1=1
)

except

select distinct master_distributor_code , master_outlet_code,null as sales,cast(wk as int) as wk,cast(year_month as int) as year_month from master_weekly_sales   """).createOrReplaceTempView("master_weekly_none_sales") 



# COMMAND ----------

spark.sql("""
select  * from master_weekly_sales
union
select  * from master_weekly_none_sales
 """).createOrReplaceTempView("master_weekly_all_none_sales") 



# COMMAND ----------

spark.sql("""
SELECT * 
, case when b.cnt=17 then
sum(sales) over (partition by master_distributor_code, master_outlet_code order by cast(year_month as int),cast(wk as int)
rows between 16 preceding and current row)

when b.cnt=16 then
sum(sales) over (partition by master_distributor_code, master_outlet_code order by cast(year_month as int),cast(wk as int)
rows between 15 preceding and current row) 

 when b.cnt=15 then
 sum(sales) over (partition by master_distributor_code, master_outlet_code order by cast(year_month as int),cast(wk as int)
rows between 14 preceding and current row) 

 when b.cnt=14 then
 sum(sales) over (partition by master_distributor_code, master_outlet_code order by cast(year_month as int),cast(wk as int)
rows between 13 preceding and current row) 

 when b.cnt=13 then
 sum(sales) over (partition by master_distributor_code, master_outlet_code order by cast(year_month as int),cast(wk as int)
rows between 12 preceding and current row) 

end
as sales_13_weeks 
FROM	master_weekly_all_none_sales a left join  week_row_cnt b on a.year_month=b.yrmo and a.wk=b.week

""").createOrReplaceTempView("master_weekly_13wk_sales")

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC drop table if exists trans_weekly_sales;
# MAGIC 
# MAGIC create table trans_weekly_sales
# MAGIC as
# MAGIC SELECT transactional_distributor_code , transactional_outlet_code , sum(Gross_Sales_Val * 1.0) as sales,
# MAGIC t.wk,T.year_month
# MAGIC FROM	view_fact_daily_sales S
# MAGIC 			left	Join
# MAGIC 				dim_time T
# MAGIC 				ON S.invoice_date = T.Dt_og
# MAGIC                                 
# MAGIC                 left join dim_salesman sm
# MAGIC                 on s.transactional_salesman_code=sm.salesman_code
# MAGIC                 where sm.salesforce <> 'Others - Out of Scope'
# MAGIC                 
# MAGIC 				GROUP BY S.transactional_distributor_code , S.transactional_outlet_code,t.wk,T.year_month  

# COMMAND ----------

spark.sql("""
(select  distinct transactional_distributor_code , transactional_outlet_code,null as sales, t2.wk,t2.year_month from trans_weekly_sales
join (select distinct cast(wk as int) as wk,cast(year_month as int) as year_month  from dim_time) t2 on 1=1
)

except

select distinct transactional_distributor_code , transactional_outlet_code,null as sales,cast(wk as int) as wk,cast(year_month as int) as year_month from trans_weekly_sales   """).createOrReplaceTempView("trans_weekly_none_sales") 



# COMMAND ----------

spark.sql("""
select  * from trans_weekly_sales
union
select  * from trans_weekly_none_sales
 """).createOrReplaceTempView("trans_weekly_all_none_sales") 



# COMMAND ----------

spark.sql("""

SELECT * 
, case when b.cnt=17 then
sum(sales) over (partition by transactional_distributor_code, transactional_outlet_code order by cast(year_month as int),cast(wk as int)
rows between 16 preceding and current row) 

when b.cnt=16 then
sum(sales) over (partition by transactional_distributor_code, transactional_outlet_code order by cast(year_month as int),cast(wk as int)
rows between 15 preceding and current row)

 when b.cnt=15 then
 sum(sales) over (partition by transactional_distributor_code, transactional_outlet_code order by cast(year_month as int),cast(wk as int)
rows between 14 preceding and current row) 

 when b.cnt=14 then
 sum(sales) over (partition by transactional_distributor_code, transactional_outlet_code order by cast(year_month as int),cast(wk as int)
rows between 13 preceding and current row) 

 when b.cnt=13 then
 sum(sales) over (partition by transactional_distributor_code, transactional_outlet_code order by cast(year_month as int),cast(wk as int)
rows between 12 preceding and current row) 

end
as sales_13_weeks 
FROM	trans_weekly_all_none_sales a left join  week_row_cnt b on a.year_month=b.yrmo and a.wk=b.week

""").createOrReplaceTempView("trans_weekly_13wk_sales")

# COMMAND ----------

spark.sql("""

select year_month,master_distributor_code,count(distinct case when sales_3_months > 0 then master_outlet_code else null end)  as activestores
,count(distinct case when sales_3_months/3 > 500000 then master_outlet_code else null end) as qualitystores
from master_monthly_3mon_sales 
group by year_month,master_distributor_code
""").createOrReplaceTempView("master_monthly")

# COMMAND ----------

spark.sql("""

select year_month,transactional_distributor_code,count(distinct case when sales_3_months > 0 then transactional_outlet_code else null end)  as activestores 
,count(distinct case when sales_3_months/3 > 500000 then transactional_outlet_code else null end)  as qualitystores
from trans_monthly_3mon_sales 
group by year_month,transactional_distributor_code
""").createOrReplaceTempView("trans_monthly")

# COMMAND ----------

spark.sql("""

select year_month,master_distributor_code,wk,count(distinct case when sales_13_weeks > 0 then master_outlet_code else null end)  as activestores
,count(distinct case when sales_13_weeks/3 > 500000 then master_outlet_code else null end) as qualitystores
from master_weekly_13wk_sales 
group by year_month,master_distributor_code,wk
""").createOrReplaceTempView("master_weekly")

# COMMAND ----------

spark.sql("""

select year_month,transactional_distributor_code,wk,count(distinct case when sales_13_weeks > 0 then transactional_outlet_code else null end)  as activestores 
,count(distinct case when sales_13_weeks/3 > 500000 then transactional_outlet_code else null end)  as qualitystores
from trans_weekly_13wk_sales 
group by year_month,transactional_distributor_code,wk
""").createOrReplaceTempView("trans_weekly")

# COMMAND ----------

spark.sql("""

SELECT 
A.master_distributor_code,
substring(a.year_month,1,4) as year,
substring(a.year_month,5,2) as month,
null as wk,
'Y' as flag,
B.QualityStores as trans_quality_stores, 
A.QualityStores  as master_quality_stores,
B.ActiveStores as trans_Active_Stores, 
A.ActiveStores as master_active_stores
FROM master_monthly as A
left join  trans_monthly as B ON A.master_distributor_code = B.transactional_distributor_code and A.year_month=b.year_month

union all

SELECT 
A.master_distributor_code,
substring(a.year_month,1,4) as year,
substring(a.year_month,5,2) as month,
a.wk as wk,
'N' as flag,
B.QualityStores as trans_quality_stores, 
A.QualityStores  as master_quality_stores,
B.ActiveStores as trans_Active_Stores, 
A.ActiveStores as master_active_stores 
FROM master_weekly as A
left join  trans_weekly as B ON A.master_distributor_code = B.transactional_distributor_code and A.year_month=b.year_month and a.wk=b.wk

""").createOrReplaceTempView("overall")

# COMMAND ----------

  print("performing cleanup")

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC vacuum fact_qualitystores retain 168 hours;
# MAGIC 
# MAGIC truncate table fact_qualitystores;

# COMMAND ----------


 
  print("performing fresh load")
  
  spark.sql("""
  Insert into fact_qualitystores

SELECT 
master_distributor_code,
year,
month,
wk ,
flag,
trans_quality_stores, 
master_quality_stores,
trans_Active_Stores, 
master_active_stores
FROM overall
""")


# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC select current_timestamp()

# COMMAND ----------

df_csv_builder=spark.table("fact_qualitystores")

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql import functions as f
from datetime import datetime

# COMMAND ----------

#/mnt/adls/EDGE_Analytics/Datalake/Transformed/Facts/qualitystores/

update_dt = datetime.today().strftime('%Y/%m/%d')
file_dt=(OP_qualitystores+update_dt)
df_csv_builder.coalesce(1).write.mode("overwrite").option("header", "true")\
.option("emptyValue", None)\
.option("nullValue", None).csv(file_dt)

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC select count(1) from fact_qualitystores