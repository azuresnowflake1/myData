# Databricks notebook source
from pyspark.sql import functions as f
from datetime import datetime
from pyspark.sql.functions import col,substring,when,isnull,expr
from pyspark.sql import types

# COMMAND ----------

dbutils.widgets.text("IP_Path", "","")
# /mnt/adls/EDGE_Analytics/Datalake/Processed/FMT/
dbutils.widgets.text("OP_Path", "","")
# /mnt/adls/EDGE_Analytics/Datalake/Transformed/Transactional/dss_aggregate
dbutils.widgets.text("TimeKeyST", "","")

IP_Path= dbutils.widgets.get("IP_Path")
OP_Path = dbutils.widgets.get("OP_Path")
TimeKeyST = dbutils.widgets.get("TimeKeyST")

print(IP_Path)
print(OP_Path)
print(TimeKeyST)


# COMMAND ----------

salesmanMaster="/mnt/adls/EDGE_Analytics/Datalake/Transformed/Dimensions/Salesman/"

yearSM = str(max([i.name.replace('/','') for i in dbutils.fs.ls (salesmanMaster)]))
monthSM= str(max([i.name.replace('/','') for i in dbutils.fs.ls (salesmanMaster +"/" +str(yearSM))])).zfill(0)
daySM  = str(max([i.name.replace('/','') for i in dbutils.fs.ls (salesmanMaster +"/"+str(yearSM)+"/"+str(monthSM))])).zfill(0)


dataSM= spark.read.option("header","true").csv(salesmanMaster+yearSM+"/"+monthSM+"/"+daySM)
dataSM.createOrReplaceTempView ("dim_salesman")


# COMMAND ----------

ol_index_yr = str(max([i.name.replace('/','') for i in dbutils.fs.ls (IP_Path)])).zfill(0)
ol_index_mon = str(max([i.name.replace('/','') for i in dbutils.fs.ls (IP_Path +"/" +str(ol_index_yr))])).zfill(0)
ol_index_day  = str(max([i.name.replace('/','') for i in dbutils.fs.ls (IP_Path +"/"+str(ol_index_yr)+"/"+str(ol_index_mon))])).zfill(0)
                     
path_oli = IP_Path+ol_index_yr+"/"+ol_index_mon+"/"+ol_index_day + "/VN_INVOICE_RANGE_MAP.csv"
                   
print(path_oli)

# COMMAND ----------

df_OLI= spark.read.csv(path_oli , header='true').withColumn("map_index",expr("row_number() over (order by cast(min as int))"))

# COMMAND ----------

display(df_OLI)

# COMMAND ----------

spark.sql("drop TABLE if exists map")
dbutils.fs.rm("/mnt/adls/EDGE_Analytics/Datalake/Staging/temp/dss_aggr_map/",True)

# COMMAND ----------

df_OLI.write.format("delta").save("/mnt/adls/EDGE_Analytics/Datalake/Staging/temp/dss_aggr_map")
spark.sql("CREATE TABLE map USING DELTA LOCATION '/mnt/adls/EDGE_Analytics/Datalake/Staging/temp/dss_aggr_map'")

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC spark.sql("""
# MAGIC 
# MAGIC create or replace temp view dss_aggr_inc
# MAGIC as
# MAGIC select
# MAGIC   count(distinct case when gross_sales_val > 0 then  product_code else null end) total_sku_lines,
# MAGIC   count(distinct case when gross_sales_val > 0 then  invoice_number else null end) as non_zero_amount_bill_count,
# MAGIC    count(distinct invoice_number) as total_bill_count,
# MAGIC   transactional_distributor_code,
# MAGIC   transactional_site_code,
# MAGIC   transactional_outlet_code,
# MAGIC   invoice_date,
# MAGIC   transactional_salesman_code,
# MAGIC   sm.salesman_product_group_code,
# MAGIC   sm.standardised_salesman_product_group transactional_spg,
# MAGIC   sum(gross_sales_val) as gsv,
# MAGIC   sum(net_invoice_val) as net_invoice,
# MAGIC   dss.salesforce,
# MAGIC   year_id,
# MAGIC   month_id,
# MAGIC   time_key
# MAGIC from
# MAGIC   fact_daily_sales dss
# MAGIC   left outer join dim_salesman sm on dss.transactional_salesman_code = sm.salesman_code
# MAGIC where
# MAGIC   country_code = 'VN'
# MAGIC   and time_key >={}
# MAGIC group by
# MAGIC   transactional_distributor_code,
# MAGIC   transactional_site_code,
# MAGIC   transactional_outlet_code,
# MAGIC   invoice_date,
# MAGIC   transactional_salesman_code,
# MAGIC   sm.salesman_product_group_code,
# MAGIC   sm.standardised_salesman_product_group ,
# MAGIC   dss.salesforce,
# MAGIC   year_id,
# MAGIC   month_id,
# MAGIC   time_key
# MAGIC   """.format(TimeKeyST))

# COMMAND ----------

spark.sql("""

create or replace temp view dss_aggr_inc
as
select
  sum( case when gsv > 0 then  total_sku_lines else 0 end) as total_sku_lines,
  sum( case when gsv > 0 then  non_zero_amount_bill_count else 0 end) as non_zero_amount_bill_count,
  count(distinct case when gsv > 0 and non_zero_amount_bill_count > 0 then 1 else 0 end) as total_bill_count,
  transactional_distributor_code,
  transactional_site_code,
  transactional_outlet_code,
  invoice_date,
  transactional_salesman_code,
  sm.salesman_product_group_code,
  sm.standardised_salesman_product_group transactional_spg,
  sum(gsv) as gsv,
  sum(net_invoice) as net_invoice,
  dss.salesforce,
  year_id,
  month_id,
  time_key
from
( 
select
  count(distinct case when gross_sales_val > 0 then  product_code else null end) as total_sku_lines,
  count(distinct case when gross_sales_val > 0 then  invoice_number else null end) as non_zero_amount_bill_count,
  transactional_distributor_code,
  transactional_site_code,
  transactional_outlet_code,
  invoice_date,
  transactional_salesman_code,
  sum(gross_sales_val) as gsv,
  sum(net_invoice_val) as net_invoice,
  salesforce,
  year_id,
  month_id,
  time_key
from fact_daily_sales
where country_code = 'VN'
  and time_key >={}
group by 
    transactional_distributor_code,
  transactional_site_code,
  transactional_outlet_code,
  invoice_date,
  transactional_salesman_code,
  salesforce,
  year_id,
  month_id,
  time_key
)  dss
  left outer join dim_salesman sm on dss.transactional_salesman_code = sm.salesman_code
group by
  transactional_distributor_code,
  transactional_site_code,
  transactional_outlet_code,
  invoice_date,
  transactional_salesman_code,
  sm.salesman_product_group_code,
  sm.standardised_salesman_product_group ,
  dss.salesforce,
  year_id,
  month_id,
  time_key
  """.format(TimeKeyST))

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC create or replace  temp view dss_aggregate_inc
# MAGIC as
# MAGIC select /*+ SHUFFLE_REPLICATE_NL(b) */  a.*,
# MAGIC b.range as invoice_range,
# MAGIC current_date as insert_ts,
# MAGIC current_date as update_ts,
# MAGIC b.map_index as map_index
# MAGIC 
# MAGIC from dss_aggr_inc a 
# MAGIC inner join map  b on 1=1
# MAGIC and  gsv>=min and gsv < nvl(max,1000000000000)
# MAGIC where 1=1
# MAGIC 
# MAGIC -- and invoice_date between '2020-10-01' and '2020-10-31'
# MAGIC --and transactional_distributor_code='3002'
# MAGIC --and transactional_outlet_code=''
# MAGIC --and invoice_Date='2020-10-07'
# MAGIC --and transactional_salesman_code='2015'

# COMMAND ----------

spark.sql("""
delete from dss_aggregate where time_key >={}
  """.format(TimeKeyST))

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC insert into  dss_aggregate 
# MAGIC select 
# MAGIC total_sku_lines ,
# MAGIC non_zero_amount_bill_count ,
# MAGIC total_bill_count ,
# MAGIC transactional_distributor_code ,
# MAGIC transactional_site_code ,
# MAGIC transactional_outlet_code ,
# MAGIC invoice_date date,
# MAGIC transactional_salesman_code ,
# MAGIC salesman_product_group_code ,
# MAGIC transactional_spg ,
# MAGIC gsv ,
# MAGIC net_invoice ,
# MAGIC salesforce ,
# MAGIC year_id ,
# MAGIC month_id ,
# MAGIC time_key ,
# MAGIC invoice_range ,
# MAGIC insert_ts ,
# MAGIC update_ts,
# MAGIC map_index
# MAGIC from
# MAGIC dss_aggregate_inc 

# COMMAND ----------

stg_path="/mnt/adls/EDGE_Analytics/Datalake/temp/inc_dss_agg/temp"

# COMMAND ----------

dbutils.fs.rm(stg_path,True)

# COMMAND ----------

(spark.sql("""select * from dss_aggregate where time_key >={}""".format(TimeKeyST))
      .repartition(30)
      .write
      .mode("overwrite")
      .parquet (stg_path)
)

# REMOVING NON PART FILES BEFORE INITIATING COPY ACTIVITY USING POLYBASE
fileInfo= dbutils.fs.ls(stg_path)
fileList= [str(i.name) for i in fileInfo]

def filterNonPartFiles (fileName):
  if 'part' in fileName:
    return False
  else:
    return True

nonPartFiles = list(filter(filterNonPartFiles, fileList))

for file in nonPartFiles:
  dbutils.fs.rm(stg_path+"/{}".format(file))

# COMMAND ----------

