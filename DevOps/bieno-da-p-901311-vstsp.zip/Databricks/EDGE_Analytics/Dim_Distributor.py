# Databricks notebook source
dbutils.widgets.text("IP_Distributor", "","")
dbutils.widgets.text("IP_U2K2_NGDMS_Mapping", "","")
dbutils.widgets.text("IP_Customer", "","")
dbutils.widgets.text("OP_Distributor", "","")

Input_Distributor= dbutils.widgets.get("IP_Distributor")
Input_U2K2_NGDMS_Mapping = dbutils.widgets.get("IP_U2K2_NGDMS_Mapping")
Input_Customer = dbutils.widgets.get("IP_Customer")
Output_Distributor = dbutils.widgets.get("OP_Distributor")

print(Input_Distributor)
print(Input_U2K2_NGDMS_Mapping)
print(Input_Customer)
print(Output_Distributor)


# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql import functions as f
from datetime import datetime

# COMMAND ----------

dml_year = dbutils.fs.ls(Input_Distributor)
#dml_year = dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/Staging/Incremental/Masters/Distributor/")
dml_month = dbutils.fs.ls(dml_year[-1][0])
dml_date = dbutils.fs.ls(dml_month[-1][0])
dml_file = dbutils.fs.ls(dml_date[-1][0])
path_dm = dml_file[-1][0]


u2k_year = dbutils.fs.ls(Input_U2K2_NGDMS_Mapping)
#u2k_year = dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/Staging/Incremental/Masters/U2K2_NGDMS_Mapping/")
u2k_month = dbutils.fs.ls(u2k_year[-1][0])
u2k_date = dbutils.fs.ls(u2k_month[-1][0])
u2k_file = dbutils.fs.ls(u2k_date[-1][0])
path_u2k = u2k_file[-1][0]


cx_year = dbutils.fs.ls(Input_Customer)
#cx_year = dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/Staging/Incremental/Masters/Customer/")
cx_month = dbutils.fs.ls(cx_year[-1][0])
cx_date = dbutils.fs.ls(cx_month[-1][0])
cx_file = dbutils.fs.ls(cx_date[-1][0])
path_cx = cx_file[-1][0]

print("year: "  + str(cx_year))
print("---------")
print("month: "  + str(cx_month))
print("---------")
print("date: "  + str(cx_date))
print("---------")
print("filename: "  + str(cx_file))



# COMMAND ----------

df_U2k = spark.read.csv(path_u2k , header='true').where("ZU2K2_SALORG='V001'")
df_CX  = spark.read.csv(path_cx , header='true').where("salesorg = 'V001'")
df_DM = spark.read.csv(path_dm, header='true')

# COMMAND ----------

df_U2k.count()

# COMMAND ----------

df_CX.count()

# COMMAND ----------

df_DM.count()

# COMMAND ----------

df_U2k.createOrReplaceTempView('u2k')
df_CX.createOrReplaceTempView('cx')
df_DM.createOrReplaceTempView('dm')

# COMMAND ----------

"""
df_DM_join_U2k = df_DM.join(df_U2k,df_DM.WERKS ==df_U2k.ZNGDMS_SITE,how='left').select(df_DM["FABKL"],df_DM["WERKS"],
                                                                                       df_DM["NAME1"],df_DM["ZZDISTRIB_TYP"],df_U2k["ZNGDMS_SITE"],
                                                                                       df_U2k["ZNGDMS_COCDE"],df_U2k["ZU2K2_SOLDP"]) 
"""

# COMMAND ----------

df_DM_join_U2k = spark.sql("""
select 
distinct
a.FABKL,a.WERKS,

a.NAME1,a.ZZDISTRIB_TYP,b.ZNGDMS_SITE,b.ZNGDMS_COCDE,b.ZU2K2_SOLDP
from dm  a 
left join u2k b on a.WERKS =b.ZNGDMS_SITE
where a.FABKL='VN'
and b.ZNGDMS_SITE is not null
""")

# COMMAND ----------

df_DM_join_U2k.count()

# COMMAND ----------

""" 
df_DM_join_U2k_CX= df_DM_join_U2k.join(df_CX  ,df_CX.CUST_SALES == df_DM_join_U2k.ZU2K2_SOLDP,how='left').select(df_DM_join_U2k["*"], df_CX["CUST_SALES"],df_CX["ZCUSTNAME"],df_CX["ZCUSTNAME16"],df_CX["ZCUSTNAME17"],df_CX["ZCUSTNAME18"],df_CX["SALESORG"]).distinct()
"""


# COMMAND ----------

df_DM_join_U2k_CX= spark.sql("""

select distinct 
a.FABKL,
a.WERKS,
a.NAME1,
a.ZZDISTRIB_TYP,

b.ZNGDMS_SITE,
b.ZNGDMS_COCDE,
b.ZU2K2_SOLDP,

c.CUST_SALES,
case when c.ZCUSTNAME is null then 'UNASG' else c.ZCUSTNAME end AS ZCUSTNAME,
case when c.ZCUSTNAME16 is null then 'UNASG' else c.ZCUSTNAME16 end AS ZCUSTNAME16,
case when c.ZCUSTNAME17 is null then 'UNASG' else c.ZCUSTNAME17 end AS ZCUSTNAME17,
case when c.ZCUSTNAME18 is null then 'UNASG' else c.ZCUSTNAME18 end AS ZCUSTNAME18,
case when c.salesorg is null then 'UNASG' else c.salesorg end AS SALESORG

from dm  a 
left join u2k b on a.WERKS =b.ZNGDMS_SITE
left join cx c on c.CUST_SALES = b.ZU2K2_SOLDP
where a.FABKL='VN'
and b.ZNGDMS_SITE is not null

""")

# COMMAND ----------

df_DM_join_U2k_CX.count()

# COMMAND ----------

  #df1=df_DM_join_U2k_CX.selectExpr(cast("FABKL as Country_Code") asgooggoo int)
df1=df_DM_join_U2k_CX.select(col("FABKL").alias("country_code"),col("WERKS").alias("site_code"),col("NAME1").alias("site_name"),col("ZNGDMS_COCDE").cast("int").alias("distributor_code"),col("ZZDISTRIB_TYP").alias("distributor_type"), col("ZCUSTNAME").alias("distributor_name"),col("ZCUSTNAME16").alias("dt_region"),col("ZCUSTNAME17").alias("dt_area"),col("ZCUSTNAME18").alias("dt_district"),col("SALESORG").alias("salesorg")).distinct()
#df1.show()

# COMMAND ----------

df1.count()

# COMMAND ----------

update_dt = datetime.today().strftime('%Y/%m/%d/')
file_dt=(Output_Distributor+update_dt)
#file=("/mnt/adls/EDGE_Analytics/Datalake/Transformed/Dimensions/Distributor/"+update_dt)
df1.coalesce(1).write.mode("overwrite").option("header", "true")\
.option("emptyValue", None)\
.option("nullValue", None).csv(file_dt)

# COMMAND ----------

