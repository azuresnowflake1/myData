# Databricks notebook source
year_id      =dbutils.widgets.get("year_id")
month_id_st  =dbutils.widgets.get("month_id_st")
month_id_ed  =dbutils.widgets.get("month_id_ed")

stg_path="/mnt/adls/EDGE_Analytics/Datalake/temp/hist_dss/temp"

# COMMAND ----------

dbutils.fs.rm("/mnt/adls/EDGE_Analytics/Datalake/temp/hist_dss/temp/",True)

# COMMAND ----------

dss_delta= spark.sql("select * from fact_daily_sales where year_id={} and month_id between {} and {}".format(year_id, month_id_st, month_id_ed))
dss_delta.repartition(20) \
         .write \
         .mode("overwrite") \
         .parquet (stg_path)

# COMMAND ----------

fileInfo= dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/temp/hist_dss/temp")
fileList= [str(i.name) for i in fileInfo]

def filterNonPartFiles (fileName):
  if 'part' in fileName:
    return False
  else:
    return True

nonPartFiles = list(filter(filterNonPartFiles, fileList))

for file in nonPartFiles:
  dbutils.fs.rm("/mnt/adls/EDGE_Analytics/Datalake/temp/hist_dss/temp/{}".format(file))

# COMMAND ----------

dbutils.notebook.exit(value="Write completed successfully")