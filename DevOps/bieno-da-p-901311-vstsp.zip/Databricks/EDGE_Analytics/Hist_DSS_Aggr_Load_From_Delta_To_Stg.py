# Databricks notebook source
from datetime import datetime, timezone

utc_dt = datetime.now(timezone.utc) # UTC time

import pytz

tz = pytz.timezone('Asia/Bangkok')
vn_now = datetime.now(tz)

print(vn_now)

# COMMAND ----------

dbutils.widgets.text("year_id", "","")

year_id= dbutils.widgets.get("year_id")

print(year_id)


# COMMAND ----------

stg_path="/mnt/adls/EDGE_Analytics/Datalake/temp/hist_dss_agg/temp"

# COMMAND ----------

dbutils.fs.rm("/mnt/adls/EDGE_Analytics/Datalake/temp/hist_dss_agg/temp/",True)

# COMMAND ----------

dss_delta= spark.sql("select * from dss_aggregate where year_id={} ".format(year_id))
dss_delta.repartition(20) \
         .write \
         .mode("overwrite") \
         .parquet (stg_path)

# COMMAND ----------

fileInfo= dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/temp/hist_dss_agg/temp")
fileList= [str(i.name) for i in fileInfo]

def filterNonPartFiles (fileName):
  if 'part' in fileName:
    return False
  else:
    return True

nonPartFiles = list(filter(filterNonPartFiles, fileList))

for file in nonPartFiles:
  dbutils.fs.rm("/mnt/adls/EDGE_Analytics/Datalake/temp/hist_dss_agg/temp/{}".format(file))

# COMMAND ----------

dbutils.notebook.exit(value="Write completed successfully")

# COMMAND ----------

from datetime import datetime, timezone

utc_dt = datetime.now(timezone.utc) # UTC time

import pytz

tz = pytz.timezone('Asia/Bangkok')
vn_now = datetime.now(tz)

print(vn_now)