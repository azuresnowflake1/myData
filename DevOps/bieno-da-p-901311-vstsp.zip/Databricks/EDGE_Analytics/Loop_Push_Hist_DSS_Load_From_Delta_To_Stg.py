# Databricks notebook source
from pyspark.sql.functions import col, date_format, unix_timestamp, from_unixtime, date_sub

# COMMAND ----------

from pyspark.sql.functions import sequence, to_date, explode, col

df=spark.sql("SELECT sequence(to_date('2018-01-01'), cast(current_timestamp() as date), interval 1 month) as date").withColumn("date", explode(col("date")))

# COMMAND ----------

df.createOrReplaceTempView('myTemp2')

# COMMAND ----------

lst= spark.sql(""" select distinct year(date) as year_id, min(concat(year(date),lpad(month(date),2,'0'))) as month_id_st, max(concat(year(date),lpad(month(date),2,'0'))) as month_id_ed from myTemp2 group by 1  order by 1,2,3""").collect()

# COMMAND ----------

print(lst)

# COMMAND ----------

for a in lst:
  year_id=a.year_id
  month_id_st=a.month_id_st
  month_id_ed=a.month_id_ed
  
  print("running now for year " + str(a.year_id) + " and start_year_month " + str(a.month_id_st) + " and end_year_month " + str(a.month_id_ed))
  
  dbutils.notebook.run(path="/Shared/EDGE_Analytics/Hist_DSS_Load_From_Delta_To_Stg", timeout_seconds=3600, arguments={"year_id":year_id, "month_id_st":month_id_st,"month_id_ed":month_id_ed})
  
  print("run complete now for year " + str(a.year_id) + " and start_year_month " + str(a.month_id_st) + " and end_year_month " + str(a.month_id_ed))
  

# COMMAND ----------

dbutils.notebook.exit(value="completed successfully")