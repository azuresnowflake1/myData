# Databricks notebook source
from datetime import datetime, timezone

utc_dt = datetime.now(timezone.utc) # UTC time

import pytz

tz = pytz.timezone('Asia/Bangkok')
vn_now = datetime.now(tz)

print(vn_now)

# COMMAND ----------

dbutils.widgets.text("IP_Annual_Target", "","")
#old: /mnt/adls/EDGE_Analytics/Datalake/Staging/Incremental/Targets/Distributor_Yearly_Sales_Growth&Others/
dbutils.widgets.text("OP_Annual_Target", "","")
Input_Annual_Target= dbutils.widgets.get("IP_Annual_Target")
Output_Annual_Target = dbutils.widgets.get("OP_Annual_Target")

print(Input_Annual_Target)
print(Output_Annual_Target)


# COMMAND ----------

from datetime import datetime
from pyspark.sql.functions import col,concat,lit,translate

# COMMAND ----------


"""
l_year = dbutils.fs.ls(Input_Annual_Target)
#l_year = dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/Staging/Incremental/Targets/Distributor_Yearly_Sales_Growth&Others/")
l_month = dbutils.fs.ls(l_year[-1][0])
l_date = dbutils.fs.ls(l_month[-1][0])
l_file = dbutils.fs.ls(l_date[-1][0])
path = l_file[0][0]
"""

l_year = str(max([i.name.replace('/','') for i in dbutils.fs.ls (Input_Annual_Target)]))
l_month= str(max([i.name.replace('/','') for i in dbutils.fs.ls (Input_Annual_Target +"/" +str(l_year))]))
l_date  = str(max([i.name.replace('/','') for i in dbutils.fs.ls (Input_Annual_Target +"/"+str(l_year)+"/"+str(l_month))]))
l_file="VN_YEARLY_TARGET.csv"
path=Input_Annual_Target+l_year+"/"+l_month+"/"+l_date+"/"+l_file
print(path)

# COMMAND ----------

df1 = spark.read.option("inferSchema", "true").option("delimiter", ",").csv(path , header='true')

# COMMAND ----------


df_at = df1.select(col("Year"), col("Site Code").cast("string").alias("site_code"), 
                   concat(col("Site Code"),lit("_"),col("year")).alias("site_code_year"),
                   translate(col("Original Annual Sales Growth Target"),"%","").cast("float").alias("original_annual_growth_target"), 
                   translate(col("Quality Stores Absolute Target"), ",", "").cast("int").alias("quality_stores_abs_target"), 
                   col("Distributor Commentary").alias("dist_comment")
                  )

# COMMAND ----------

update_dt = datetime.today().strftime('%Y/')
file_path = Output_Annual_Target+update_dt
df_at.coalesce(1).write.mode("overwrite").option("header", "true").csv(file_path)

# COMMAND ----------

from datetime import datetime, timezone

utc_dt = datetime.now(timezone.utc) # UTC time

import pytz

tz = pytz.timezone('Asia/Bangkok')
vn_now = datetime.now(tz)

print(vn_now)