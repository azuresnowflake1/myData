# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *
from datetime import datetime
from dateutil.relativedelta import *
from pyspark.sql import Window

# COMMAND ----------


filepath = ("/mnt/adls/EDGE_Analytics/Datalake/Staging/Historical/Transaction/DSS/")


# COMMAND ----------

distributor_year = dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/Transformed/Dimensions/Distributor/")
distributor_month = dbutils.fs.ls(distributor_year[-1][0])
distributor_date = dbutils.fs.ls(distributor_month[-1][0])
distributor_file = dbutils.fs.ls(distributor_date[-1][0])
path_dis = distributor_file[-1][0]

sm_year = dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/Transformed/Dimensions/Salesman/")
sm_month = dbutils.fs.ls(sm_year[-1][0])
sm_date = dbutils.fs.ls(sm_month[-1][0])
sm_file = dbutils.fs.ls(sm_date[-1][0])
path_sm = sm_file[-1][0]


prod_year = dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/Transformed/Dimensions/Product/")
prod_month = dbutils.fs.ls(prod_year[-1][0])
prod_date = dbutils.fs.ls(prod_month[-1][0])
prod_file = dbutils.fs.ls(prod_date[-1][0])
path_prod = prod_file[-1][0]

# COMMAND ----------

hist_dss = spark.read.csv("/mnt/adls/EDGE_Analytics/Datalake/Staging/Historical/Transaction/DSS/2020/*/*/*.parquet", header="true")

# COMMAND ----------

hist_dss.display()

# COMMAND ----------

hist_dss = spark.read.parquet("/mnt/adls/EDGE_Analytics/Datalake/Staging/Historical/Transaction/DSS/2020/*/*/*.parquet")
  
sm = spark.read.csv(path_sm , header='true')

prod = spark.read.csv(path_prod , header='true')

dis = spark.read.csv(path_dis , header='true')

# COMMAND ----------

dss = hist_dss.filter(col("CountryCode")=="VN").withColumn("GrossSalesValue",hist_dss["GrossSalesValue"].cast(IntegerType())).withColumn('InvoiceDate', to_date(col('InvoiceDate')))

# COMMAND ----------

dss.agg(sum(col('GrossSalesValue'))).display()

# COMMAND ----------

dss.filter(col("SalesmanCode")=="NA").agg(sum(col('GrossSalesValue'))).display()

# COMMAND ----------

dss.filter(col("SalesmanCode")=="NA").select(col("SalesmanName")).distinct().count()

# COMMAND ----------

'''to be removed while moving to production'''
dss = hist_dss.filter((col("CountryCode")=="VN") & ~(col("SalesmanCode")=="NA") ).withColumn("GrossSalesValue",hist_dss["GrossSalesValue"].cast(IntegerType()))
dss = dss.withColumn('InvoiceDate', to_date(col('InvoiceDate')))

# COMMAND ----------

dss_distributor = dss.join(dis,dss.SiteCode == dis.site_code, how = 'left' )

# COMMAND ----------

dss1 = dss_distributor.select(substring(col("ArticleCode"),-8,8).alias("product_code")
                ,col("InvoiceNumber")
                ,concat(col("SiteCode"),lit("_"),date_format(col("InvoiceDate"),"yyyy")).alias("site_code_year")
                ,col("distributor_code").alias("transactional_distributor_code")
                ,col("distributor_code").alias("master_distributor_code")
                ,col("SiteCode").alias("transactional_site_code")
                ,col("SiteCode").alias("master_site_code")
                ,col("OutletCode").alias("transactional_outlet_code")
                ,col("OutletCode").alias("master_outlet_code")
                ,date_format(col("InvoiceDate"),"yyyyMMdd").cast("String").alias("invoice_date")
                ,col("SalesmanCode").alias("transactional_salesman_code")
                ,col("SalesmanCode").alias("master_salesman_code")
                ,col("invoicetype")
                ,col("customerZRSSFlag")
                ,col("SalesReturnReferenceInvoiceNumber")
                ,(col("GrossSalesValue")*100).alias("GrossSalesValue")
                ,(col("GrossSalesValue")/1000000).alias("gsv_million")
                ,col("NetInvoiceValue")
                ,col("GrossSalesWithReturnValue").alias("gross_sales_with_return_val")
                ,col("SalesReturnValue").alias("sales_return_val")
                ,col("OnInvoiceDiscountValue").alias("on_inv_discount_val")
                ,col("NetInvoiceValue").alias("net_invoice_val")
                ,col("ValueAddedTax").alias("ValueAddedTax")
                ,col("OffInvoiceDiscountValue").alias("off_inv_discount_val")
                ,col("TurnoverValue").alias("turn_over_value")
                ,col("SalesWithReturnPCQuantity").alias("sales_with_return_pc_qty")
                ,col("SalesReturnPCQuantity").alias("sales_return_pc_qty")
                ,col("SalesCSVolume").alias("sales_cs_vol")
                ,col("SalesKGVolume").alias("sales_kg_vol")
                ,col("SalesLTVolume").alias("sales_lt_vol")
                ,col("FreePCQuantity").alias("sales_pc_vol")                                                        ).withColumn("last_inserted_datetime",current_timestamp()).withColumn("last_modified_datetime",current_timestamp()).withColumn("dist_site_year", concat(col("master_distributor_code"), lit("_"), col("master_site_code"), lit("_"), substring(col("invoice_date"),1,4)))


# COMMAND ----------

sm_sf_mid = sm.select(col("salesman_code"), col("salesforce")).distinct()

df1 = dss1.join(sm_sf_mid,col('master_salesman_code')== col('salesman_code'), how = 'left')


# COMMAND ----------

cat_prod_mid = prod.select(col("product_code"), col("brand"), col("category_code"), col("cotc"), concat(col("brand"), lit("_"),col("Category_code"), lit("_"), col("cotc")).alias("brand_cat_core")).distinct()

df = df1.join(cat_prod_mid.select(col("product_code"), col("brand_cat_core"), col("category_code")), on = "product_code", how = "left")


# COMMAND ----------

sm_sf = sm_sf_mid.select(col("salesforce")).distinct()

cat_prod_core = cat_prod_mid.select(col("brand"), col("category_code"), col("cotc"), col("brand_cat_core")).distinct()

cat_prod = cat_prod_mid.select(col("product_code"), col("category_code")).distinct()

dis_site = dis.select(col("distributor_code"), col("site_code")).distinct()

# COMMAND ----------

update_dt = datetime.today().strftime('%Y/%m/%d/')
update_dt
file=("/mnt/adls/EDGE_Analytics/Datalake/Transformed/Transactional/DSS/"+update_dt)
df.write.mode("overwrite").option("header", "true")\
.option("emptyValue", None)\
.option("nullValue", None).parquet(file)

# COMMAND ----------

'''
file=("/mnt/adls/EDGE_Analytics/Datalake/Transformed/Masters/Distributor_site/"+update_dt)
dis_site.coalesce(1).write.mode("overwrite").option("header", "true")\
.option("emptyValue", None)\
.option("nullValue", None).csv(file)

file=("/mnt/adls/EDGE_Analytics/Datalake/Transformed/Masters/unique_sf/"+update_dt)
sm_sf.coalesce(1).write.mode("overwrite").option("header", "true")\
.option("emptyValue", None)\
.option("nullValue", None).csv(file)

file=("/mnt/adls/EDGE_Analytics/Datalake/Transformed/Masters/Product_cat_core/"+update_dt)
cat_prod_core.coalesce(1).write.mode("overwrite").option("header", "true")\
.option("emptyValue", None)\
.option("nullValue", None).csv(file)

file=("/mnt/adls/EDGE_Analytics/Datalake/Transformed/Masters/Category_product/"+update_dt)
cat_prod.coalesce(1).write.mode("overwrite").option("header", "true")\
.option("emptyValue", None)\
.option("nullValue", None).csv(file)
'''

# COMMAND ----------

