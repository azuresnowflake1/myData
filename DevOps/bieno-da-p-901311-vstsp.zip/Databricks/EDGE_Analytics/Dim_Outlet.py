# Databricks notebook source
from datetime import datetime, timezone

utc_dt = datetime.now(timezone.utc) # UTC time

import pytz

tz = pytz.timezone('Asia/Bangkok')
vn_now = datetime.now(tz)

print(vn_now)

# COMMAND ----------

from pyspark.sql import functions as f
from datetime import datetime
from pyspark.sql.functions import col,substring,when,isnull
from pyspark.sql import types

# COMMAND ----------


dbutils.widgets.text("Channel", "","")
dbutils.widgets.text("Outlet", "","")
dbutils.widgets.text("Output_outlet", "","")

dbutils.widgets.text("Channel_IDX", "","")
#/mnt/adls/EDGE_Analytics/Datalake/Processed/FMT/

Channel= dbutils.widgets.get("Channel")
Channel_IDX= dbutils.widgets.get("Channel_IDX")
Online_outlet = dbutils.widgets.get("Outlet")
OP_outlet = dbutils.widgets.get("Output_outlet")

print(Channel)
print(Channel_IDX)
print(Online_outlet)
print(OP_outlet)

#/mnt/adls/EDGE_Analytics/Datalake/Staging/Incremental/Masters/Online_Outlet/

# COMMAND ----------

oc_year = dbutils.fs.ls(Channel)
#oc_year = dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/Staging/Incremental/Masters/Channel_Mapping/")
oc_month = dbutils.fs.ls(oc_year[-1][0])
oc_date = dbutils.fs.ls(oc_month[-1][0])
oc_file = dbutils.fs.ls(oc_date[-1][0])
path_oc = oc_file[0][0]

"""
om_year = dbutils.fs.ls(Online_outlet)
#om_year = dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/Staging/Incremental/Masters/Online_Outlet/")
om_month = dbutils.fs.ls(om_year[-1][0])
om_date = dbutils.fs.ls(om_month[-1][0])
om_file = dbutils.fs.ls(om_date[-1][0])
path_om = om_file[0][0]
"""

# COMMAND ----------

ol_index_yr = str(max([i.name.replace('/','') for i in dbutils.fs.ls (Channel_IDX)])).zfill(0)
ol_index_mon = str(max([i.name.replace('/','') for i in dbutils.fs.ls (Channel_IDX +"/" +str(ol_index_yr))])).zfill(0)
ol_index_day  = str(max([i.name.replace('/','') for i in dbutils.fs.ls (Channel_IDX +"/"+str(ol_index_yr)+"/"+str(ol_index_mon))])).zfill(0)
                     
path_oli = Channel_IDX+ol_index_yr+"/"+ol_index_mon+"/"+ol_index_day + "/VN_OL_CHANNEL_INDEX.csv"

#path_oli = "dbfs:/mnt/adls/EDGE_Analytics/Datalake/Processed/FMT/2021/01/05/VN_OL_CHANNEL_INDEX.csv"
                   
print(path_oli)

# COMMAND ----------

df_OLI= spark.read.csv(path_oli , header='true')

df_oli = df_OLI.select(col("Channel"),col("Index").alias("sorting_index"))

# COMMAND ----------

from pyspark.sql import functions as f
from datetime import datetime
df_OC= spark.read.csv(path_oc , header='true')

#df_OM = spark.read.csv(path_om , header='true').filter(col("OutletSubTypeCode").isNotNull())

# directly reading BDL data instead of copying it over

bdlDeltaPathIncr="/mnt/adls/BDL_Gen2/BusinessDataLake/CD/SecSales/Global/Online_Countries/Reference/OnlineOutletMaster/OnlineOutletMaster_Processed/"

#df_OM = spark.table('src_online_outlet').filter(col("OutletSubTypeCode").isNotNull())
df_OM = spark.read.format("delta").load(bdlDeltaPathIncr).filter(col("OutletSubTypeCode").isNotNull())


# COMMAND ----------

df_OM.createOrReplaceTempView('OM')

# COMMAND ----------

df_OC.createOrReplaceTempView('OC')

# COMMAND ----------

df_oli.createOrReplaceTempView('OLI')

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC select count(1) from OM

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC select count(1) from OC

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC select count(1) from OLI

# COMMAND ----------

"""

df_OM_join_OC = df_OM.join(df_OC,df_OM.OutletSubTypeCode ==df_OC.COC5,how='left').select(df_OC["*"],df_OM["CountryCode"],df_OM["OutletCode"],df_OM["OutletGroupCode"],df_OM["OutletName"],df_OM["OutletStatusCode"],df_OM["OutletSubTypeCode"],df_OM["OutletTypeCode"],df_OM["DistrictName"],df_OM["LatitudeValue"],df_OM["LongitudeValue"],df_OM["DistributorCode"],df_OM["SiteCode"],df_OM["PerfectStoreAuditTypeCode"],df_OM["B2BFlag"],df_OM["PerfectStoreCategoryCode"], when(df_OM["PerfectStoreCategoryCode"]==22,"Y").otherwise("N").alias("perfect_store")).filter(col("CountryCode") == 'VN').distinct()

"""

# COMMAND ----------

#df_OM_join_OC.count()

# COMMAND ----------

"""
df1=df_OM_join_OC.select(col("OutletCode").alias("outlet_code"),col("COC5").alias("outletsubtypecode"),col("outletstatuscode"),col("CHANNEL").alias("channel"), col("perfect_store"),col("OutletName").alias("Outlet_Name")).distinct()
"""

# COMMAND ----------

#df1.count()

# COMMAND ----------

"""
df_out = df1.join(df_oli,df1.channel == df_oli.Channel,how='left').select(df1["*"],when(isnull(df_oli["sorting_index"] ),9999).otherwise(df_oli["sorting_index"]).alias("sorting_index")) 
"""

# COMMAND ----------

#df_out.select(col("sorting_index")).distinct().show()

# COMMAND ----------

#df_out.count()

# COMMAND ----------

df2= spark.sql("""
select distinct

OM.OutletCode as outlet_code,
coalesce(OC.COC5,'UNASG') as outletsubtypecode,
OM.OutletStatusCode,
coalesce(OC.CHANNEL,'UNASG') as channel,
case when OM.PerfectStoreCategoryCode =22 then 'Y' else 'N' end as perfect_store,
OM.OutletName as Outlet_Name,
case when OLI.sorting_index is null then 9999 else OLI.sorting_index end as sorting_index,
coalesce(OC.LOCATION,'UNASG') as LOCATION,
OM.GeoCityCode as geo_city_code

--OC.COC4,
--OC.[COC4 DESCRIPTION],
--OC.[COC5 DESCRIPTION],
--OC.[GROUP CHANNEL],

--OM.OutletGroupCode,

--OM.OutletSubTypeCode,
--OM.OutletTypeCode,
--OM.DistrictName,
--OM.LatitudeValue,
--OM.LongitudeValue,
--OM.DistributorCode,
--OM.SiteCode,
--OM.PerfectStoreAuditTypeCode,
--OM.B2BFlag,
--OM.PerfectStoreCategoryCode,


from OM 
left join OC on OM.OutletSubTypeCode = OC.COC5
left join OLI on OC.CHANNEL = OLI.Channel

where OM.CountryCode = 'VN'

""")

# COMMAND ----------

display(df2.where("channel='UNASG'"))

# COMMAND ----------

df2.count()

# COMMAND ----------

df2.coalesce(1).write.mode("overwrite").option("header", "true")\
.option("emptyValue", None)\
.option("nullValue", None).csv(OP_outlet)

# COMMAND ----------

from datetime import datetime, timezone

utc_dt = datetime.now(timezone.utc) # UTC time

import pytz

tz = pytz.timezone('Asia/Bangkok')
vn_now = datetime.now(tz)

print(vn_now)