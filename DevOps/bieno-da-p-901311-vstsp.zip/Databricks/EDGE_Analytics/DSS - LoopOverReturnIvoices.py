# Databricks notebook source
from datetime import datetime, timezone

utc_dt = datetime.now(timezone.utc) # UTC time

import pytz

tz = pytz.timezone('Asia/Bangkok')
vn_now = datetime.now(tz)

print(vn_now)

# COMMAND ----------

from pyspark.sql.functions import col, date_format, unix_timestamp, from_unixtime, date_sub

# COMMAND ----------

from pyspark.sql.functions import sequence, to_date, explode, col

df=spark.sql("SELECT sequence(to_date('2018-02-01'), cast(current_timestamp() as date), interval 1 month) as date").withColumn("date", explode(col("date")))

# COMMAND ----------

df.createOrReplaceTempView('myTemp')

# COMMAND ----------

lst= spark.sql(""" select distinct year(date) as yr, concat(year(date),lpad(month(date),2,'0')) as yrmo,lpad(month(date),2,'0') as mo from myTemp  order by 1,2""").collect()

# COMMAND ----------

print(lst)

# COMMAND ----------

for a in lst:
  yr=a.yr
  yrmo=a.mo
  
  print("running now for year " + str(a.yr) + " and year_month " + str(a.yrmo))
  
  dbutils.notebook.run(path="/Shared/EDGE_Analytics/DSS - MergeReturnInvoiceHistorical", timeout_seconds=3600, arguments={"ProcessingYear":yr, "ProcessingMonth":yrmo})
  
  print("run complete now for year " + str(a.yr) + " and year_month " + str(a.yrmo))
  

# COMMAND ----------

dbutils.notebook.exit(value="completed successfully")

# COMMAND ----------

from datetime import datetime, timezone

utc_dt = datetime.now(timezone.utc) # UTC time

import pytz

tz = pytz.timezone('Asia/Bangkok')
vn_now = datetime.now(tz)

print(vn_now)