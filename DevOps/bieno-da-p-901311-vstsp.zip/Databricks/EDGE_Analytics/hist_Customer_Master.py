# Databricks notebook source
dbutils.widgets.text("IP_Customer", "","")
dbutils.widgets.text("OP_Customer", "","")
Input_Pre_Customer = dbutils.widgets.get("IP_Customer")
Output_Customer = dbutils.widgets.get("OP_Customer")

print(Input_Pre_Customer)
print(Output_Customer)

# COMMAND ----------

from pyspark.sql.functions import *
from datetime import datetime
from pyspark.sql import Window

cm=[]
cm_year = dbutils.fs.ls(Input_Pre_Customer)
#cm_year = dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/Staging/Historical/Masters/Pre_Customer/")
cm_file = dbutils.fs.ls(cm_year[-1][0])
for i in cm_file:
  for j in dbutils.fs.ls(i[0]):
    for k in dbutils.fs.ls(j[0]):
      for l in dbutils.fs.ls(k[0]):
        cm.append(l[0])



# COMMAND ----------


df_CM_unfiltered = spark.read.csv(cm[0], header='true').withColumn("load_dt", lit(int(cm[0][89:93]+cm[0][97:99]+cm[0][103:105])))

#looping to read and assign dates in column from address
for i in range(len(cm)-1):
  df_CM_unfiltered = df_CM_unfiltered.unionAll(spark.read.csv(cm[i+1], header='true').withColumn("load_dt", lit(int(cm[0][89:93]+cm[0][97:99]+cm[0][103:105]))))

# COMMAND ----------

df_CM_unfiltered = df_CM_unfiltered.distinct()
df_cm_row = df_CM_unfiltered.withColumn("row_num", row_number().over(Window.partitionBy( col("SALESORG"), col("CUST_SALES"), col("DIVISION"), col("DISTR_CHAN")).orderBy(col("load_dt").desc()))).filter(col("COUNTRY")=="VN").filter(col("row_num") == 1)

# COMMAND ----------

df_cm = df_cm_row.drop('row_num')

# COMMAND ----------

update_dt = datetime.today().strftime('%Y/%m/%d/')
file_cm=(Output_Customer+update_dt)
#file_cm=("/mnt/adls/EDGE_Analytics/Datalake/Staging/Incremental/Masters/Customer/"+update_dt)
df_cm.coalesce(1).write.mode("overwrite").option("header", "true")\
.option("emptyValue", None)\
.option("nullValue", None).csv(file_cm)

# COMMAND ----------

update_dt

# COMMAND ----------

