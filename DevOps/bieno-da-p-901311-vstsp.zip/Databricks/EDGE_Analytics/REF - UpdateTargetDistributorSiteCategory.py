# Databricks notebook source
dbutils.widgets.text("ProcessingYear", "","")

processingYear = dbutils.widgets.get("ProcessingYear")

print(processingYear)

# COMMAND ----------

from pyspark.sql import types
from pyspark.sql.functions import regexp_replace, concat, col, date_format, to_date, substring
from datetime import datetime

spark.conf.set("spark.sql.sources.partitionOverwriteMode","dynamic")

# dbutils.widgets.text("ProcessingYear", "2020")
#processingYear = dbutils.widgets.get("ProcessingYear")

# COMMAND ----------

#DSCStgPath="/mnt/adls/EDGE_Analytics/Datalake/Staging/Incremental/Targets/Distributor_Site_Category_Sales"
DSCStgPath="/mnt/adls/EDGE_Analytics/Datalake/Processed/FMT/"
DSCTrnPath="/mnt/adls/EDGE_Analytics/Datalake/Transformed/Facts/Targets/Distributor_Site_Category_Sales"
DSCTempPath="/mnt/adls/EDGE_Analytics/Datalake/temp/temp_ref_dist_site_cat_sales"

# COMMAND ----------

# READING MONTHLY PROVIDED DISTRIBUTOR CATEGORY SALES TARGET YTD FILE 

yearDSC = str(max([i.name.replace('/','') for i in dbutils.fs.ls (DSCStgPath)]))
monthDSC= str(max([i.name.replace('/','') for i in dbutils.fs.ls (DSCStgPath +"/" +str(yearDSC))])).zfill(2)
dayDSC  = str(max([i.name.replace('/','') for i in dbutils.fs.ls (DSCStgPath +"/"+str(yearDSC)+"/"+str(monthDSC))])).zfill(2)

DSCfile="VN_MONTHLY_SALES_TARGET.csv"

path_DSC=DSCStgPath+yearDSC+"/"+monthDSC+"/"+dayDSC+"/"+DSCfile

print(path_DSC)

dataDSC= spark.read.option("header","true").csv(path_DSC)


for col in dataDSC.columns:
  dataDSC = dataDSC.withColumnRenamed(col,col.replace(" ",""))
  
dataDSC.createOrReplaceTempView ("dist_site_cat_sales")

# COMMAND ----------

dataDSC_t1= spark.sql(
"select "+
"cast(year as int) year, "+
"month, "+
"cast(date_format(to_date(concat('01','-',substring(month,1,3),'-',year),'dd-MMM-yyyy'),'yyyyMM') as int) year_month, "+
"distributor_code, "+
"site_code, "+
"master_prod_cat_code, "+
"(nvl(cast(target as float),0) * 1000000) before_transition_target, "+
"(nvl(cast(target as float),0) * 1000000) after_transition_target, "+
"current_timestamp() insert_ts, "+
"current_timestamp() update_ts "+
"from "+
"(select "+
"  year, "+
"  DistributorCode as distributor_code, "+
"  SiteCode as site_code, "+
"  MasterProductCategoryCode as master_prod_cat_code, "+
"  stack(12,'January',January, "+
"           'February',February, "+
"           'March',March, "+
"           'April',April, "+
"           'May',May, "+
"           'June',June, "+
"           'July',July, "+
"           'August',August, "+
"           'September',September, "+
"           'October',October, "+
"           'November',November, "+
"           'December',December) as (month, target) "+
"  from dist_site_cat_sales "+
")q"
)
display(dataDSC_t1)

# COMMAND ----------

spark.conf.set("spark.databricks.delta.properties.defaults.autoOptimize.optimizeWrite", "true")
spark.conf.set("spark.databricks.delta.properties.defaults.autoOptimize.autoCompact","true")
dataDSC_t1.write \
          .format("delta") \
          .partitionBy("year") \
          .mode("overwrite") \
          .save(DSCTrnPath)

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table if exists ref_dist_site_cat_sales;
# MAGIC CREATE TABLE ref_dist_site_cat_sales
# MAGIC (year int,
# MAGIC month string,
# MAGIC year_month int,
# MAGIC distributor_code string,
# MAGIC site_code string,
# MAGIC master_prod_cat_code string,
# MAGIC before_transition_target float,
# MAGIC after_transition_target float,
# MAGIC insert_ts timestamp,
# MAGIC update_ts timestamp
# MAGIC )
# MAGIC USING DELTA 
# MAGIC PARTITIONED BY (year)
# MAGIC LOCATION "/mnt/adls/EDGE_Analytics/Datalake/Transformed/Facts/Targets/Distributor_Site_Category_Sales";
# MAGIC 
# MAGIC ALTER TABLE ref_dist_site_cat_sales
# MAGIC SET TBLPROPERTIES (delta.autoOptimize.optimizeWrite = true, delta.autoOptimize.autoCompact = true);

# COMMAND ----------

# MAGIC %md ##### run daily sales transformed

# COMMAND ----------

# MAGIC %run "./DSS - Transformed"

# COMMAND ----------

# MAGIC %sql
# MAGIC merge into ref_dist_site_cat_sales tgt
# MAGIC using 
# MAGIC (select 
# MAGIC   dss.year_id as year,
# MAGIC   dss.month_id as year_month,
# MAGIC   dss.transactional_site_code as site_code,
# MAGIC   dss.category_code as master_prod_cat_code,
# MAGIC   nvl(ref.before_transition_target,0) as before_transition_target,
# MAGIC   nvl(dss.gross_sales_val,0) gross_gsv,
# MAGIC   (nvl(cast(ref.after_transition_target as double),0) - nvl(cast(dss.gross_sales_val as double),0)) after_transition_target
# MAGIC   from ref_dist_site_cat_sales ref
# MAGIC   right outer join (
# MAGIC    select 
# MAGIC     dss.year_id,
# MAGIC     dss.month_id,
# MAGIC     dss.transactional_site_code,
# MAGIC     dss.category_code,
# MAGIC     sum(dss.gross_sales_val) gross_sales_val
# MAGIC     from view_fact_daily_sales dss
# MAGIC     inner join dim_product pd on pd.product_code = dss.product_code
# MAGIC     where dss.year_id=cast($ProcessingYear as int)
# MAGIC     and ((dss.transactional_outlet_code != dss.master_outlet_code)  or (dss.master_site_code != dss.transactional_site_code)  )
# MAGIC     group by dss.year_id, dss.month_id, dss.transactional_site_code, dss.category_code
# MAGIC    ) dss
# MAGIC    on ref.year= dss.year_id
# MAGIC    and ref.year_month= dss.month_id
# MAGIC    and ref.site_code = dss.transactional_site_code
# MAGIC    and ref.master_prod_cat_code= dss.category_code
# MAGIC ) src
# MAGIC on (tgt.year= src.year
# MAGIC and tgt.year_month= src.year_month
# MAGIC and tgt.site_code= src.site_code
# MAGIC and tgt.master_prod_cat_code= src.master_prod_cat_code)
# MAGIC when matched then update set tgt.after_transition_target= src.after_transition_target,
# MAGIC                              tgt.update_ts= current_timestamp();

# COMMAND ----------

# MAGIC %sql
# MAGIC merge into ref_dist_site_cat_sales tgt
# MAGIC using 
# MAGIC (select 
# MAGIC   dss.year_id as year,
# MAGIC   dss.month_id as year_month,
# MAGIC   dss.master_site_code as site_code,
# MAGIC   dss.category_code as master_prod_cat_code,
# MAGIC   nvl(ref.before_transition_target,0) as before_transition_target,
# MAGIC   nvl(dss.gross_sales_val,0) gross_gsv,
# MAGIC   (nvl(cast(ref.after_transition_target as double),0) + nvl(cast(dss.gross_sales_val as double),0)) after_transition_target
# MAGIC   from ref_dist_site_cat_sales ref
# MAGIC   right outer join (
# MAGIC    select 
# MAGIC     dss.year_id,
# MAGIC     dss.month_id,
# MAGIC     dss.master_site_code,
# MAGIC     dss.category_code,
# MAGIC     sum(dss.gross_sales_val) gross_sales_val
# MAGIC     from view_fact_daily_sales dss
# MAGIC     inner join dim_product pd on pd.product_code = dss.product_code
# MAGIC     where dss.year_id=cast($ProcessingYear as int)
# MAGIC     and ((dss.transactional_outlet_code != dss.master_outlet_code)  or (dss.master_site_code != dss.transactional_site_code)  )
# MAGIC     group by dss.year_id, dss.month_id, dss.master_site_code, dss.category_code
# MAGIC    ) dss
# MAGIC    on ref.year= dss.year_id
# MAGIC    and ref.year_month= dss.month_id
# MAGIC    and ref.site_code = dss.master_site_code
# MAGIC    and ref.master_prod_cat_code= dss.category_code
# MAGIC ) src
# MAGIC on (tgt.year= src.year
# MAGIC and tgt.year_month= src.year_month
# MAGIC and tgt.site_code= src.site_code
# MAGIC and tgt.master_prod_cat_code= src.master_prod_cat_code)
# MAGIC when matched then update set tgt.after_transition_target= src.after_transition_target,
# MAGIC                              tgt.update_ts= current_timestamp();

# COMMAND ----------

# MAGIC %sql
# MAGIC analyze table ref_dist_site_cat_sales compute statistics;
# MAGIC optimize ref_dist_site_cat_sales;

# COMMAND ----------

# WRITE THE DATA FROM DELTA TABLE TO TEMP LOCATION
(
spark.sql("select * from ref_dist_site_cat_sales where year={}".format(processingYear))
     .repartition(1)
     .write
     .mode("overwrite")
     .parquet(DSCTempPath)
)