# Databricks notebook source
dbutils.notebook.run(path="./00_INSTALL_CHROME_DRIVER",timeout_seconds=600)

# COMMAND ----------

pip install selenium

# COMMAND ----------

import time
import json
# from common import wait_for_element_located, wait_for_invisible, wait_for_visible, wait_for_visible_by_css, wait_for_iframe
import pandas as pd
import logging
# import sub_code
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities


import os
import pandas as pd
import re
import datetime
import time 
import shutil
import chardet

# COMMAND ----------

from pyspark.sql.functions import concat
from pyspark.sql.functions import substring
from pyspark.sql.functions import col
from pyspark.sql.functions import lit
from pyspark.sql.types import StructType,StructField, StringType

# COMMAND ----------

arr=[
  ["V08" , "3BA1;3136;3AK1;3AI1;3218;3108;3138;3174;3070;3055;3227;3526;3937;3517;3930;3926"],
  ["V09" , "3107;3AB1;3044;3094;3251;3220;3047;3AK2;3102;3226;3208;3907;3512;3124;3924;3539"],
  ["V10" , "3037;3165;3010;3066;3049;3194;3052;3071;3157;3204;3529;3945;3540;3538;3260;3900"],
  ["V11" , "3077;3059;3239;3045;3053;3068;3254;3222;3258;3084;3531;3507;3021;3905;3927;3903"],
  ["V12" , "3249;3133;3025;3106;3145;3168;3169;3040;3902;3901;3913;3933;3514;3943;3179;3AE1"],
  ["V13" , "3058;3008;3245;3123;3192;3243;3210;3198;3092;3242;3236;3906;3921;3533;3518;3909"],
  ["V14" , "3255;3011;3072;3057;3252;3041;3075;3139;3162;3178;3063;3508;3519;3536;3535;3912"],
  ["V15" , "3004;3AC2;3146;3024;3233;3234;3026;3035;3199;3158;3919;3528;3542;3515;3006;3914"] 
]

# COMMAND ----------

end_date = spark.sql(" select date_format(current_date-1, 'ddMMyyyy')").collect()[0][0]
start_date = spark.sql(" select date_format(current_date-6, 'ddMMyyyy')").collect()[0][0]

period = start_date + " - " + end_date

file_unique_id="LE VN DSS"

print("start date is " + start_date )
print("end date is " + end_date )
print("period date is " + period )

lst=[]
for i in arr:
  file_nm = file_unique_id + " " + period + " " + i[0]
  lst.append([i[1],period , file_nm])

print(lst)

# COMMAND ----------

credentials = {
  "username": "NW_IT_27",
  "pass_1": "GHIghi$$78",
  "pass_2": "Lambo#912"
}

# COMMAND ----------

path="/mnt/adls/EDGE_Analytics/Datalake/Staging/Incremental/Transaction/DSS_Aggregate/"

# COMMAND ----------

#filepath = path + 'schedule/EXTR_SCHEDULE - VN_DAILY_SALES.csv'

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC filepath = '/mnt/blob_901480/bot_extractions/leveredge/schedule/EXTR_SCHEDULE - VN_DAILY_SALES.csv'
# MAGIC df_schedule = spark.read.format("csv").options(delimiter=",", header="True").load(filepath)
# MAGIC df_schedule = df_schedule.withColumn('period', concat(substring(concat(lit('00'), col('from_date')), -2, 2), substring(concat(lit('00'), col('from_month')), -2, 2), substring(concat(lit('0000'), col('from_year')), -4, 4), lit(' - '), 
# MAGIC                                                       substring(concat(lit('00'), col('to_date')), -2, 2), substring(concat(lit('00'), col('to_month')), -2, 2), substring(concat(lit('0000'), col('to_year')), -4, 4)))
# MAGIC rcd = df_schedule.count()
# MAGIC tmp_link = df_schedule.select('template_link').collect()[0].template_link
# MAGIC keys = df_schedule.select('site_code', 'period', 'file_name')

# COMMAND ----------

#display(df_schedule)

# COMMAND ----------

emptyRDD = spark.sparkContext.emptyRDD()

schema = StructType([StructField('file_name', StringType(), True),
                     StructField('download_time', StringType(), True),
                     StructField('download_status', StringType(), True)])
df_download = spark.createDataFrame(emptyRDD,schema)

# COMMAND ----------

logging.basicConfig(level=logging.INFO,
                    filename="error.log",
                    format='%(asctime)s %(message)s')

# COMMAND ----------

def login_ISR(driver, timeout, credentials):
    check = None
    while check is None:
        try:
            WebDriverWait(driver,timeout).until(EC.presence_of_element_located((By.NAME, 'j_username')))
            driver.find_element_by_name('j_username').clear()
            driver.find_element_by_name('j_username').send_keys(credentials['username'])
            driver.find_element_by_name('j_password').clear()
            driver.find_element_by_name('j_password').send_keys(credentials['pass_1'])
            driver.find_element_by_xpath("//*[@name='uidPasswordLogon']").click()
            check = 'Sucessfully login 1'
            print(check)
        except: pass
    
    check = None
    while check is None:
        try:
            WebDriverWait(driver,timeout).until(EC.presence_of_element_located((By.XPATH, """//*[@lsdata="{3:'HEADER1',4:'PARAGRAPH',5:'MARKED1'}"]""")))
            driver.find_element_by_xpath("//input[@type='password']").clear()
            driver.find_element_by_xpath("//input[@type='password']").send_keys(credentials['pass_2'])
            token = driver.find_element_by_xpath("""//*[@lsdata="{3:'HEADER1',4:'PARAGRAPH',5:'MARKED1'}"]""").text
            driver.find_element_by_xpath("//*[@title='Type Here']").clear()
            driver.find_element_by_xpath("//*[@title='Type Here']").send_keys(token)
            driver.find_element_by_xpath("//*[@title='Login ']").click()
            check = 'Sucessfully login 2'
            print(check)
        except: pass

# COMMAND ----------

def snake_name(name):
    return re.sub('[^A-Za-z0-9]+','_',name.strip().replace(' ','_').lower())

# COMMAND ----------

def file_exists(path):
  try:
    dbutils.fs.ls(path)
    return True
  except Exception as e:
    if 'java.io.FileNotFoundException' in str(e):
      return False
    else:
      raise

# COMMAND ----------

chrome_options = webdriver.ChromeOptions()
chrome_options.add_argument('--no-sandbox')
chrome_options.add_argument('--headless')
chrome_options.add_argument('--disable-dev-shm-usage')
prefs = {
  "download.prompt_for_download": False,
  "download.default_directory": "/tmp/",
  "download.directory_upgrade": True,
  "safebrowsing.enabled": False,
  "safebrowsing.disable_download_protection": True
}

chrome_options.add_experimental_option("prefs", prefs)
print(chrome_options.experimental_options)
chrome_driver = "/tmp/chromedriver/chromedriver"


browser = webdriver.Chrome(executable_path=chrome_driver, options=chrome_options)
browser.maximize_window()
url = r'https://www.dms.unilever.com/irj/portal'
timeout = 10
browser.get(url)
# login
login_ISR(browser, timeout, credentials)

# COMMAND ----------

# url = r'https://bw.dms.unilever.com/irj/servlet/prt/portal/prtroot/pcd%213aportal_content%212fcom.sap.pct%212fplatform_add_ons%212fcom.sap.ip.bi%212fiViews%212fcom.sap.ip.bi.bex?INITIAL_STATE=VIEW&INITIAL_STATE-VIEW=ZZ_LODR_DSS_VN_LATEST'

#url = tmp_link

################################## Code added by Pulkit manually ############################################
url="https://bw.dms.unilever.com/irj/servlet/prt/portal/prtroot/pcd%213aportal_content%212fcom.sap.pct%212fplatform_add_ons%212fcom.sap.ip.bi%212fiViews%212fcom.sap.ip.bi.bex?INITIAL_STATE=VIEW&INITIAL_STATE-VIEW=ZZ_LODR_DSS_VN_LATEST"

schema = StructType([StructField('site_code', StringType(), True),
                     StructField('period', StringType(), True),
                     StructField('file_name', StringType(), True)])

df_dd=spark.createDataFrame(lst,schema)

#df_dd=spark.sql("select '3002;3257' as site_code, '01052021 - 05052021'  as period, 'acde' as file_name")

keys = df_dd.select('site_code', 'period', 'file_name')
################################## Code added by Pulkit manually ############################################

display(keys)

# COMMAND ----------

rcd=len(lst)

file_name_fix = "0ANALYSIS_PATTERN.csv"
tmp_download_status = ""

# '_'.join('LE VN NRM DSS G1', [(datetime.date.today() - datetime.timedelta(days=1)).strftime('%Y%m'), 'coupon.csv'])
src_data = "file:/tmp/"
src_file = "file:/tmp/0ANALYSIS_PATTERN.csv"

print('initiating extraction process...')

start_time_1 = time.time()

from datetime import datetime
dt_folder = datetime.today().strftime('%Y/%m/%d/')


for i in range(rcd):
  
  no_data = False
  site_codes = str(keys.collect()[i].site_code)
  period = str(keys.collect()[i].period)
  file_name = str(keys.collect()[i].file_name)

  print("site_codes " + site_codes)
  print("period " + period)
  print("file_name " + file_name)
  
  start_time_2 = time.time()  
  # file_name = 'test'
  # no_data = False
  tgr_file = path + "daily_sales_summary/"+ dt_folder +"{}.csv".format(file_name)
  
  if (file_exists(src_file)):
    dbutils.fs.rm(src_file)

  while not file_exists(src_file) and no_data == False:
      try:
          # connect
          print(' - '.join(['Loop ' + str(i), file_name, 'Starting extraction', str(rcd - i) + ' files left']))
          
          browser.switch_to.window(browser.window_handles[0])
          browser.find_element_by_id("navNodeAnchor_1_0").click()

          browser.execute_script("window.open('" + url + "');")
          browser.switch_to.window(browser.window_handles[-1])

          WebDriverWait(browser, timeout).until(EC.presence_of_element_located((By.XPATH, r"//*[@title='BEx\x20Web']")))
          browser.switch_to.frame(browser.find_element_by_xpath(r"//*[@title='BEx\x20Web']"))

          WebDriverWait(browser, timeout * 20).until(EC.presence_of_element_located((By.XPATH, r"//*[@id='DLG_VARIABLE_dlgBase_BTNOK']")))
          browser.find_element_by_id('DLG_VARIABLE_vsc_cvl_VAR_1_INPUT_inp').clear()
          browser.find_element_by_id('DLG_VARIABLE_vsc_cvl_VAR_1_INPUT_inp').send_keys('VN')

          browser.find_element_by_id('DLG_VARIABLE_vsc_cvl_VAR_2_INPUT_inp').clear()
          browser.find_element_by_id('DLG_VARIABLE_vsc_cvl_VAR_2_INPUT_inp').send_keys('3*')

          browser.find_element_by_id('DLG_VARIABLE_vsc_cvl_VAR_3_INPUT_inp').clear()
          #browser.find_element_by_id('DLG_VARIABLE_vsc_cvl_VAR_3_INPUT_inp').send_keys('3054;3058;3AA1;3140;3066;3144;3220;3222;3203;3230;3172;3221')
          # browser.find_element_by_id('DLG_VARIABLE_vsc_cvl_VAR_3_INPUT_inp').send_keys('3002')
          browser.find_element_by_id('DLG_VARIABLE_vsc_cvl_VAR_3_INPUT_inp').send_keys(site_codes)

          browser.find_element_by_id('DLG_VARIABLE_vsc_cvl_VAR_4_INPUT_inp').clear()
          # browser.find_element_by_id('DLG_VARIABLE_vsc_cvl_VAR_4_INPUT_inp').send_keys((datetime.date.today() - datetime.timedelta(days=1)).strftime('%m.%Y'))
          # browser.find_element_by_id('DLG_VARIABLE_vsc_cvl_VAR_4_INPUT_inp').send_keys('01012020 - 31122020')
          browser.find_element_by_id('DLG_VARIABLE_vsc_cvl_VAR_4_INPUT_inp').send_keys(period)

          browser.find_element_by_id('DLG_VARIABLE_dlgBase_BTNOK').click()

          # print(' - '.join([file_name, 'Query sent...']))

          browser.switch_to.window(browser.window_handles[-1])
          WebDriverWait(browser, timeout * 20).until(EC.presence_of_element_located((By.XPATH, r"//*[@title='BEx\x20Web']")))
          browser.switch_to.frame(browser.find_element_by_xpath(r"//*[@title='BEx\x20Web']"))

          WebDriverWait(browser, timeout * 20).until(EC.presence_of_element_located((By.XPATH, r"//*[@title='Export to CSV File']")))

          print(' - '.join(['Loop ' + str(i), file_name, 'Report loaded']))

          try:
              browser.find_element_by_id('tblInnerCnt')
          except:
              try:
                  tmp_download_status = browser.find_element_by_id('ANALYSIS_ITEM_1_ia_msg_unid5').text
                  print(' - '.join(['Loop ' + str(i), file_name, tmp_download_status]))
                  no_data = True
                  with open(tgr_file, "w") as empty_file:
                      pass  # or write something to it already
                  break
              except:
                  print(' - '.join(['Loop ' + str(i), file_name, 'Downloading report']))
                  WebDriverWait(browser, timeout * 10).until(EC.presence_of_element_located((By.XPATH, r"//*[@title='Export to CSV File']")))
                  browser.find_element_by_xpath(r"//*[@title='Export to CSV File']").click()
                  
                  while not file_exists(src_data + file_name_fix):
                    time.sleep(5)
                  
                  dbutils.fs.mv(src_data + file_name_fix, tgr_file)
                  tmp_download_status = 'Data extraction successful'
                  print(' - '.join(['Loop ' + str(i), file_name, tmp_download_status]))
                  break
      
      except Exception as e:
          print(e)
          # pass
  
  tmp_time_taken = str(round((time.time() - start_time_2) / 60, 2)) + ' min(s)'
  tmp_list = [[file_name, tmp_time_taken, tmp_download_status]]
  tmp_df = spark.createDataFrame(tmp_list)
  df_download = df_download.union(tmp_df)
  
  print(' - '.join(['Loop ' + str(i), file_name, 'Extraction took ' + tmp_time_taken]))
  
  for j in range(1,len(browser.window_handles)):
    browser.switch_to.window(browser.window_handles[-1])
    browser.close()
  browser.switch_to.window(browser.window_handles[0])
  
  
browser.close()  
browser.quit()

tmp_time_taken = str(round((time.time() - start_time_1) / 60, 2)) + ' min(s)'
print(' - '.join(['Total time Taken', tmp_time_taken]))

# COMMAND ----------

path_new = path + "daily_sales_summary/"

year=dbutils.fs.ls(path_new)[-1][0]
mon=dbutils.fs.ls(year)[-1][0]
dt=dbutils.fs.ls(mon)[-1][0]

dt

# COMMAND ----------

import os

bs= "/dbfs" + path+"daily_sales_summary/"

yr=os.listdir(bs)[-1]
mon=os.listdir(bs + yr)[-1]
dt=os.listdir(bs + yr + "/" + mon)[-1]

path2=bs + yr +  "/"+ mon + "/" + dt

path2

# COMMAND ----------

import pandas as pd

df_pd = pd.read_csv(path2 + "/*.csv" ,header=0,skiprows=6,engine="python",sep=";")

# COMMAND ----------

df2=spark.createDataFrame(df_pd)

# COMMAND ----------

print(df2.count())

# COMMAND ----------

display(df2)

# COMMAND ----------

