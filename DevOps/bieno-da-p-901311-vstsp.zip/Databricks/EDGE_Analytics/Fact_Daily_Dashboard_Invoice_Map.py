# Databricks notebook source
from pyspark.sql import functions as f
from datetime import datetime
from pyspark.sql.functions import col,substring,when,isnull
from pyspark.sql import types

# COMMAND ----------

dbutils.widgets.text("IP_Invoice_Map", "","")
# /mnt/adls/EDGE_Analytics/Datalake/Processed/FMT/
dbutils.widgets.text("OP_Invoice_Map", "","")
# /mnt/adls/EDGE_Analytics/Datalake/Transformed/Facts/Invoice_Map/

IP_Invoice_Map= dbutils.widgets.get("IP_Invoice_Map")
OP_Invoice_Map = dbutils.widgets.get("OP_Invoice_Map")

print(IP_Invoice_Map)
print(OP_Invoice_Map)


# COMMAND ----------

salesmanMaster="/mnt/adls/EDGE_Analytics/Datalake/Transformed/Dimensions/Salesman/"

yearSM = str(max([i.name.replace('/','') for i in dbutils.fs.ls (salesmanMaster)]))
monthSM= str(max([i.name.replace('/','') for i in dbutils.fs.ls (salesmanMaster +"/" +str(yearSM))])).zfill(0)
daySM  = str(max([i.name.replace('/','') for i in dbutils.fs.ls (salesmanMaster +"/"+str(yearSM)+"/"+str(monthSM))])).zfill(0)


dataSM= spark.read.option("header","true").csv(salesmanMaster+yearSM+"/"+monthSM+"/"+daySM)
dataSM.createOrReplaceTempView ("dim_salesman")


# COMMAND ----------

ol_index_yr = str(max([i.name.replace('/','') for i in dbutils.fs.ls (IP_Invoice_Map)])).zfill(0)
ol_index_mon = str(max([i.name.replace('/','') for i in dbutils.fs.ls (IP_Invoice_Map +"/" +str(ol_index_yr))])).zfill(0)
ol_index_day  = str(max([i.name.replace('/','') for i in dbutils.fs.ls (IP_Invoice_Map +"/"+str(ol_index_yr)+"/"+str(ol_index_mon))])).zfill(0)
                     
path_oli = IP_Invoice_Map+ol_index_yr+"/"+ol_index_mon+"/"+ol_index_day + "/VN_INVOICE_RANGE_MAP.csv"
                   
print(path_oli)

# COMMAND ----------

df_OLI= spark.read.csv(path_oli , header='true')

# COMMAND ----------

df_OLI.show()

# COMMAND ----------

spark.sql("drop TABLE if exists map")
dbutils.fs.rm("/mnt/adls/EDGE_Analytics/Datalake/Staging/temp/dss_aggr_map/")

# COMMAND ----------

df_OLI.write.format("delta").save("/mnt/adls/EDGE_Analytics/Datalake/Staging/temp/dss_aggr_map")
spark.sql("CREATE TABLE map USING DELTA LOCATION '/mnt/adls/EDGE_Analytics/Datalake/Staging/temp/dss_aggr_map'")

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view dss_aggr
# MAGIC as
# MAGIC select
# MAGIC   count(distinct case when gross_sales_val > 0 then  product_code else null end) total_sku_lines,
# MAGIC   count(distinct case when gross_sales_val > 0 then  invoice_number else null end) as non_zero_amount_bill_count,
# MAGIC    count(distinct invoice_number) as total_bill_count,
# MAGIC   transactional_distributor_code,
# MAGIC   transactional_site_code,
# MAGIC   transactional_outlet_code,
# MAGIC   invoice_date,
# MAGIC   transactional_salesman_code,
# MAGIC   sm.salesman_product_group_code,
# MAGIC   sm.standardised_salesman_product_group transactional_spg,
# MAGIC   sum(gross_sales_val) as gsv,
# MAGIC   sum(net_invoice_val) as net_invoice,
# MAGIC   dss.salesforce,
# MAGIC   year_id,
# MAGIC   month_id,
# MAGIC   time_key
# MAGIC from
# MAGIC   fact_daily_sales dss
# MAGIC   left outer join dim_salesman sm on dss.transactional_salesman_code = sm.salesman_code
# MAGIC where
# MAGIC   country_code = 'VN'
# MAGIC group by
# MAGIC   transactional_distributor_code,
# MAGIC   transactional_site_code,
# MAGIC   transactional_outlet_code,
# MAGIC   invoice_date,
# MAGIC   transactional_salesman_code,
# MAGIC   sm.salesman_product_group_code,
# MAGIC   sm.standardised_salesman_product_group ,
# MAGIC   dss.salesforce,
# MAGIC   year_id,
# MAGIC   month_id,
# MAGIC   time_key

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC select a.* from   fact_daily_sales  a 
# MAGIC where 1=1
# MAGIC -- and invoice_date between '2020-10-01' and '2020-10-31'
# MAGIC and transactional_distributor_code='3002'
# MAGIC and transactional_outlet_code='0000346696'
# MAGIC and invoice_Date='2020-10-07'
# MAGIC and transactional_salesman_code='2015'

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC select /*+ BROADCAST(b) */ a.*,b.range from dss_aggr a 
# MAGIC inner join map  b on 1=1
# MAGIC and  gsv>=min and gsv < nvl(max,100 500 000 000)
# MAGIC where 1=1
# MAGIC -- and invoice_date between '2020-10-01' and '2020-10-31'
# MAGIC and transactional_distributor_code='3002'
# MAGIC --and transactional_outlet_code=''
# MAGIC and invoice_Date='2020-10-07'
# MAGIC and transactional_salesman_code='2015'

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC select /*+ SHUFFLE_REPLICATE_NL(b) */  a.*,b.range from dss_aggr a 
# MAGIC inner join map  b on 1=1
# MAGIC and  gsv>=min and gsv < nvl(max,100 500 000 000)
# MAGIC where 1=1
# MAGIC -- and invoice_date between '2020-10-01' and '2020-10-31'
# MAGIC and transactional_distributor_code='3002'
# MAGIC --and transactional_outlet_code=''
# MAGIC and invoice_Date='2020-10-07'
# MAGIC and transactional_salesman_code='2015'

# COMMAND ----------

df_OLI.coalesce(1).write.mode("overwrite").option("header", "true")\
.option("emptyValue", None)\
.option("nullValue", None).csv(OP_Invoice_Map)

# COMMAND ----------

