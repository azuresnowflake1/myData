# Databricks notebook source
dbutils.widgets.text("IP_Hist_Outlet_Mapping", "","")
dbutils.widgets.text("OP_Hist_Outlet_Mapping", "","")
Input_Hist_Outlet_Map = dbutils.widgets.get("IP_Hist_Outlet_Mapping")
Output_Hist_Outlet_Map = dbutils.widgets.get("OP_Hist_Outlet_Mapping")

print(Input_Hist_Outlet_Map)
print(Output_Hist_Outlet_Map)

# COMMAND ----------

"""
ol_year = dbutils.fs.ls(Input_Hist_Outlet_Map)
#ol_year = dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/Staging/Incremental/Masters/Historical_Outlet_Mapping/")
ol_month = dbutils.fs.ls(ol_year[-1][0])
ol_date = dbutils.fs.ls(ol_month[-1][0])
ol_file = dbutils.fs.ls(ol_date[-1][0])
path_ol = ol_file[0][0]
"""

ol_year = str(max([i.name.replace('/','') for i in dbutils.fs.ls (Input_Hist_Outlet_Map)])).zfill(0)
ol_month = str(max([i.name.replace('/','') for i in dbutils.fs.ls (Input_Hist_Outlet_Map +"/" +str(ol_year))])).zfill(0)
ol_date  = str(max([i.name.replace('/','') for i in dbutils.fs.ls (Input_Hist_Outlet_Map +"/"+str(ol_year)+"/"+str(ol_month))])).zfill(0)
                     
path_ol = Input_Hist_Outlet_Map+ol_year+"/"+ol_month+"/"+ol_date + "/VN_HISTORICAL_OL_MAP.csv"

#path_phi = "dbfs:/mnt/adls/EDGE_Analytics/Datalake/Processed/FMT/2021/01/05/VN_LOCAL_PH_INDEX.csv"
                   
print(path_ol)

# COMMAND ----------

from pyspark.sql.functions import *
from datetime import *
from pyspark.sql import Window
df1 = spark.read.csv(path_ol , header='true')

# COMMAND ----------

df = df1.select(date_format(to_date(col("Date"), "M/d/yyyy"),"yyyyMMdd").cast("int").alias("dt"), lpad(col("Outlet Code Old"),10,'0').alias("old_outlet_code"), lpad(col("Outlet Code New"),10,'0').alias("new_outlet_code"), col("Distributor Code").cast("int").alias("distributor_code"), col("Site Code").alias("site_code"))

# COMMAND ----------


df.coalesce(1).write.mode("overwrite").option("header", "true")\
.option("emptyValue", None)\
.option("nullValue", None).csv(Output_Hist_Outlet_Map)

# COMMAND ----------

