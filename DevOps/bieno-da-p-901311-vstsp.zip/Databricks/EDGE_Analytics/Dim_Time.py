# Databricks notebook source
dbutils.widgets.text("IP_Trading_Day", "","")
dbutils.widgets.text("OP_Time", "","")
Input_Trading_Day= dbutils.widgets.get("IP_Trading_Day")
Output_Time = dbutils.widgets.get("OP_Time")


# COMMAND ----------

td_year= dbutils.fs.ls(Input_Trading_Day)
#td_year = dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/Staging/Incremental/Masters/Trading_Day/VN_TRADING_DAYS_MAP.csv")
td_month = dbutils.fs.ls(td_year[-1][0])
td_date = dbutils.fs.ls(td_month[-1][0])
td_file = dbutils.fs.ls(td_date[-1][0])
path_td = td_file[0][0]


# COMMAND ----------

from pyspark.sql.functions import *
from datetime import *
from pyspark.sql import Window
df1 = spark.read.option("inferSchema", "true").option("delimiter", ",").csv(path_td , header='true')

# COMMAND ----------

df1.show(10)

# COMMAND ----------

df1.display()

# COMMAND ----------

spark.conf.set("spark.sql.legacy.timeParserPolicy","LEGACY")

# COMMAND ----------

df_td = df1.select(

to_date(col("Date"),'M/d/yyyy').alias("Dt"),col("Month"), 
                 
when( col("Month") =='January' , 1
).when( col("Month") =='February' , 2
).when( col("Month") =='March' , 3
).when( col("Month") =='April' , 4
).when( col("Month") =='May' , 5
).when( col("Month") =='June' , 6
).when( col("Month") =='July' , 7
).when( col("Month") =='August' , 8
).when( col("Month") =='September' , 9
).when( col("Month") =='October' , 10
).when( col("Month") =='November' , 11
).when( col("Month") =='December' , 12).cast("int").alias("month_no"),  
 
col("Trading Day").alias("Trading_day"), 
col("Cumulative_Mth").alias("Cumulatv_trading_day_Mth"), 
col("Day"), 
col("Wk ").alias("Wk"), 
col("Cumulative_Wk").alias("Cumulatv_trading_day_wk"), 
col("No of Working days in a Week").alias("Total_trading_day_wk"), 
col("Total Trading days").alias("Total_trading_day_month"), 
substring(col('Date'),-4,4).cast("int").alias("Year"),
(year(to_date(col("Date"),'M/d/yyyy'))-lit(1)).alias("PY"), 
(weekofyear(add_months(to_date(col("Date"),'M/d/yyyy'),-12))).alias("PY_week")).distinct()

# COMMAND ----------

df_td_fin = df_td.select(
  col("Dt").alias("Dt_og"), 
  date_format(col("Dt"), "yyyyMMdd").cast("int").alias("Dt"),
  date_format(col("Dt"), "yyyyMM").cast("int").alias("year_month"),
  col("Month"), 
  col("month_no"),
  col("Day"), 
  col("Wk"),
  col("Year"),
  last_day(add_months(col("Dt"),-1)).alias("LastDayofPrevMonth"),
  date_add(last_day(add_months(col("Dt"),-4)),1).alias("FirstDayofPrev3Month"),
  concat(col("Wk"),lit("_"), col("Year")).alias("Wk_year"), 
  col("Trading_day"), 
  col("Cumulatv_trading_day_wk"), 
  col("Cumulatv_trading_day_Mth"), 
  col("Total_trading_day_wk"), 
  col("Total_trading_day_month"), 
  min(col("Dt")).over(Window.partitionBy(col("Month"),col("Wk"),col("Year"))).alias("startofweekCY"),
  max(col("Dt")).over(Window.partitionBy(col("Month"),col("Wk"),col("Year"))).alias("endofweekCY"),
  min(add_months(col("Dt"),-12)).over(Window.partitionBy(col("Month"),col("PY_week"),(col("PY")))).alias("startofweekPY"),
  max(add_months(col("Dt"),-12)).over(Window.partitionBy(col("Month"),col("PY_week"),(col("PY")))).alias("endofweekPY"),
  min(col("Dt")).over(Window.partitionBy(col("Month"),col("Year"))).alias("startofmonthCY"),
  min(add_months(col("Dt"),-12)).over(Window.partitionBy(col("Month"),(col("PY")))).alias("startofmonthPY"),
  concat(weekofyear(date_add(col("Dt"),-91)),lit("_"), year(date_add(col("Dt"),-91))).alias("past13week"),
  concat(weekofyear(date_add(col("Dt"),-56)),lit("_"), year(date_add(col("Dt"),-56))).alias("past8week"),
  concat(weekofyear(date_add(col("Dt"),-28)),lit("_"), year(date_add(col("Dt"),-28))).alias("past4week")).distinct()

# COMMAND ----------

df_td_fin.createOrReplaceTempView("cal")


# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC select * from cal where dt_og> '2018-12-22' order by dt_og

# COMMAND ----------

update_dt = datetime.today().strftime('%Y/%m/%d/')
df_td_fin.coalesce(1).write.mode("overwrite").option("header", "true")\
.option("emptyValue", None)\
.option("nullValue", None).csv(Output_Time+update_dt)

# COMMAND ----------

