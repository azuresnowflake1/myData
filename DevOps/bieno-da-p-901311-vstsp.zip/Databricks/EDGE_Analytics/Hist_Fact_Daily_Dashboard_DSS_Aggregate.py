# Databricks notebook source
from datetime import datetime, timezone

utc_dt = datetime.now(timezone.utc) # UTC time

import pytz

tz = pytz.timezone('Asia/Bangkok')
vn_now = datetime.now(tz)

print(vn_now)

# COMMAND ----------

from pyspark.sql import functions as f
from datetime import datetime
from pyspark.sql.functions import col,substring,when,isnull,expr
from pyspark.sql import types

# COMMAND ----------

dbutils.widgets.text("IP_Path", "","")
# /mnt/adls/EDGE_Analytics/Datalake/Processed/FMT/
dbutils.widgets.text("OP_Path", "","")
# /mnt/adls/EDGE_Analytics/Datalake/Transformed/Transactional/dss_aggregate

IP_Path= dbutils.widgets.get("IP_Path")
OP_Path = dbutils.widgets.get("OP_Path")

print(IP_Path)
print(OP_Path)


# COMMAND ----------

salesmanMaster="/mnt/adls/EDGE_Analytics/Datalake/Transformed/Dimensions/Salesman/"

yearSM = str(max([i.name.replace('/','') for i in dbutils.fs.ls (salesmanMaster)]))
monthSM= str(max([i.name.replace('/','') for i in dbutils.fs.ls (salesmanMaster +"/" +str(yearSM))])).zfill(0)
daySM  = str(max([i.name.replace('/','') for i in dbutils.fs.ls (salesmanMaster +"/"+str(yearSM)+"/"+str(monthSM))])).zfill(0)


dataSM= spark.read.option("header","true").csv(salesmanMaster+yearSM+"/"+monthSM+"/"+daySM)
dataSM.createOrReplaceTempView ("dim_salesman")


# COMMAND ----------

ol_index_yr = str(max([i.name.replace('/','') for i in dbutils.fs.ls (IP_Path)])).zfill(0)
ol_index_mon = str(max([i.name.replace('/','') for i in dbutils.fs.ls (IP_Path +"/" +str(ol_index_yr))])).zfill(0)
ol_index_day  = str(max([i.name.replace('/','') for i in dbutils.fs.ls (IP_Path +"/"+str(ol_index_yr)+"/"+str(ol_index_mon))])).zfill(0)
                     
path_oli = IP_Path+ol_index_yr+"/"+ol_index_mon+"/"+ol_index_day + "/VN_INVOICE_RANGE_MAP.csv"
                   
print(path_oli)

# COMMAND ----------

df_OLI= spark.read.csv(path_oli , header='true').withColumn("map_index",expr("row_number() over (order by cast(min as int))"))

# COMMAND ----------

display(df_OLI)

# COMMAND ----------

spark.sql("drop TABLE if exists map")
dbutils.fs.rm("/mnt/adls/EDGE_Analytics/Datalake/Staging/temp/dss_aggr_map/",True)

# COMMAND ----------

df_OLI.write.format("delta").save("/mnt/adls/EDGE_Analytics/Datalake/Staging/temp/dss_aggr_map")
spark.sql("CREATE TABLE map USING DELTA LOCATION '/mnt/adls/EDGE_Analytics/Datalake/Staging/temp/dss_aggr_map'")

# COMMAND ----------

dbutils.fs.rm("/mnt/adls/EDGE_Analytics/Datalake/Transformed/Transactional/dss_aggregate/",True)

# COMMAND ----------

# MAGIC %sql 
# MAGIC drop table if exists dss_aggregate;
# MAGIC 
# MAGIC CREATE TABLE IF NOT EXISTS dss_aggregate (
# MAGIC   total_sku_lines bigint,
# MAGIC   non_zero_amount_bill_count bigint,
# MAGIC   total_bill_count bigint,
# MAGIC   transactional_distributor_code string,
# MAGIC   transactional_site_code string,
# MAGIC   transactional_outlet_code string,
# MAGIC   invoice_date date,
# MAGIC   transactional_salesman_code string,
# MAGIC   salesman_product_group_code string,
# MAGIC   transactional_spg string,
# MAGIC   gsv double,
# MAGIC   net_invoice double,
# MAGIC   salesforce string,
# MAGIC   year_id int,
# MAGIC   month_id int,
# MAGIC   time_key int,
# MAGIC   invoice_range string,
# MAGIC   insert_ts timestamp,
# MAGIC   update_ts timestamp,
# MAGIC   map_index int
# MAGIC ) USING DELTA PARTITIONED BY (year_id, month_id, time_key) LOCATION "/mnt/adls/EDGE_Analytics/Datalake/Transformed/Transactional/dss_aggregate";
# MAGIC 
# MAGIC ALTER TABLE
# MAGIC   fact_daily_sales
# MAGIC SET
# MAGIC   TBLPROPERTIES (
# MAGIC     delta.autoOptimize.optimizeWrite = true,
# MAGIC     delta.autoOptimize.autoCompact = true
# MAGIC   );

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC create or replace temp view vw_tmp_bill_count
# MAGIC as
# MAGIC select
# MAGIC   count(distinct case when sales_ret_ref_invoice_number= 0 then  invoice_number end) as total_bill_count,
# MAGIC   transactional_distributor_code,
# MAGIC   transactional_site_code,
# MAGIC   transactional_outlet_code,
# MAGIC   invoice_date,
# MAGIC   transactional_salesman_code,
# MAGIC   salesforce,
# MAGIC   year_id,
# MAGIC   month_id,
# MAGIC   time_key
# MAGIC from fact_daily_sales
# MAGIC where country_code = 'VN'
# MAGIC   group by 
# MAGIC     transactional_distributor_code,
# MAGIC   transactional_site_code,
# MAGIC   transactional_outlet_code,
# MAGIC   invoice_date,
# MAGIC   transactional_salesman_code,
# MAGIC   salesforce,
# MAGIC   year_id,
# MAGIC   month_id,
# MAGIC   time_key
# MAGIC   
# MAGIC   

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC create or replace temp view vw_tmp_sls_line_count
# MAGIC as
# MAGIC select 
# MAGIC 
# MAGIC count(distinct case when gsv>0 then  product_code else null end) as sku_lines,
# MAGIC   transactional_distributor_code,
# MAGIC   transactional_site_code,
# MAGIC   transactional_outlet_code,
# MAGIC   invoice_date,
# MAGIC   transactional_salesman_code,
# MAGIC   salesforce,
# MAGIC   year_id,
# MAGIC   month_id,
# MAGIC   time_key,
# MAGIC    sum(gsv) as gsv,
# MAGIC   sum(net_invoice) as net_invoice
# MAGIC   from (
# MAGIC select
# MAGIC   product_code,
# MAGIC   transactional_distributor_code,
# MAGIC   transactional_site_code,
# MAGIC   transactional_outlet_code,
# MAGIC   invoice_date,
# MAGIC   transactional_salesman_code,
# MAGIC   salesforce,
# MAGIC   year_id,
# MAGIC   month_id,
# MAGIC   time_key,
# MAGIC    sum(gross_sales_val) as gsv,
# MAGIC   sum(net_invoice_val) as net_invoice
# MAGIC   
# MAGIC from fact_daily_sales
# MAGIC where country_code = 'VN'
# MAGIC   group by 
# MAGIC     transactional_distributor_code,
# MAGIC   transactional_site_code,
# MAGIC   transactional_outlet_code,
# MAGIC   invoice_date,
# MAGIC   transactional_salesman_code,
# MAGIC   salesforce,
# MAGIC   year_id,
# MAGIC   month_id,
# MAGIC   time_key,
# MAGIC   product_code
# MAGIC   
# MAGIC   )
# MAGIC   group by
# MAGIC   
# MAGIC   transactional_distributor_code,
# MAGIC   transactional_site_code,
# MAGIC   transactional_outlet_code,
# MAGIC   invoice_date,
# MAGIC   transactional_salesman_code,
# MAGIC   salesforce,
# MAGIC   year_id,
# MAGIC   month_id,
# MAGIC   time_key

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view dss_aggr
# MAGIC as
# MAGIC select
# MAGIC   
# MAGIC   a.sku_lines as total_sku_lines,
# MAGIC   b.total_bill_count as total_bill_count,
# MAGIC   cast(case when a.gsv > 0 and b.total_bill_count > 0 then 1 else 0 end as bigint) as non_zero_amount_bill_count,
# MAGIC   
# MAGIC   a.transactional_distributor_code,
# MAGIC   a.transactional_site_code,
# MAGIC   a.transactional_outlet_code,
# MAGIC   a.invoice_date,
# MAGIC   a.transactional_salesman_code,
# MAGIC   sm.salesman_product_group_code,
# MAGIC   sm.standardised_salesman_product_group transactional_spg,
# MAGIC   a.gsv,
# MAGIC   a.net_invoice,
# MAGIC   a.salesforce,
# MAGIC   a.year_id,
# MAGIC   a.month_id,
# MAGIC   a.time_key
# MAGIC from
# MAGIC vw_tmp_sls_line_count a
# MAGIC inner join vw_tmp_bill_count b
# MAGIC on 	
# MAGIC 
# MAGIC a.transactional_distributor_code 	=	b.transactional_distributor_code 
# MAGIC and	  a.transactional_site_code	=	  b.transactional_site_code
# MAGIC and	  a.transactional_outlet_code	=	  b.transactional_outlet_code
# MAGIC and	  a.invoice_date	=	  b.invoice_date
# MAGIC and	  a.transactional_salesman_code	=	  b.transactional_salesman_code
# MAGIC and	  a.salesforce	=	  b.salesforce
# MAGIC and	  a.year_id	=	  b.year_id
# MAGIC and	  a.month_id	=	  b.month_id
# MAGIC and	  a.time_key	=	  b.time_key
# MAGIC 
# MAGIC left outer join dim_salesman sm on a.transactional_salesman_code = sm.salesman_code

# COMMAND ----------

df_out = spark.sql("""

select /*+ SHUFFLE_REPLICATE_NL(b) */  a.*,
b.range as invoice_range,
current_timestamp as insert_ts,
current_timestamp as update_ts,
b.map_index as map_index

from dss_aggr a 
inner join map  b on 1=1
--and  gsv>=min and gsv < nvl(max,1000000000000)
and  gsv >= nvl(min,-10000000000) and gsv < nvl(max,10000000000)
where 1=1

-- and invoice_date between '2020-10-01' and '2020-10-31'
--and transactional_distributor_code='3002'
--and transactional_outlet_code=''
--and invoice_Date='2020-10-07'
--and transactional_salesman_code='2015'

""")

# COMMAND ----------

df_out.filter(col("year_id")=="2018") \
             .write \
             .format("delta") \
             .mode("append") \
             .partitionBy("year_id", "month_id", "time_key") \
             .save(OP_Path)

# COMMAND ----------

df_out.filter(col("year_id")=="2019") \
             .write \
             .format("delta") \
             .mode("append") \
             .partitionBy("year_id", "month_id", "time_key") \
             .save(OP_Path)

# COMMAND ----------

df_out.filter(col("year_id")=="2020") \
             .write \
             .format("delta") \
             .mode("append") \
             .partitionBy("year_id", "month_id", "time_key") \
             .save(OP_Path)

# COMMAND ----------

df_out.filter(col("year_id")=="2021") \
             .write \
             .format("delta") \
             .mode("append") \
             .partitionBy("year_id", "month_id", "time_key") \
             .save(OP_Path)

# COMMAND ----------

from datetime import datetime, timezone

utc_dt = datetime.now(timezone.utc) # UTC time

import pytz

tz = pytz.timezone('Asia/Bangkok')
vn_now = datetime.now(tz)

print(vn_now)