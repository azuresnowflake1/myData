# Databricks notebook source
from pyspark.sql import functions as f
from datetime import datetime
from pyspark.sql.functions import col,substring,when,isnull
from pyspark.sql import types

# COMMAND ----------

dbutils.widgets.text("IP_Monthly_SM_Target", "","")
# /mnt/adls/EDGE_Analytics/Datalake/Processed/FMT/
dbutils.widgets.text("OP_Monthly_SM_Target", "","")
# /mnt/adls/EDGE_Analytics/Datalake/Transformed/Facts/Targets/Salesman_Monthly_Targets/

IP_Monthly_SM_Target= dbutils.widgets.get("IP_Monthly_SM_Target")
OP_Monthly_SM_Target = dbutils.widgets.get("OP_Monthly_SM_Target")

print(IP_Monthly_SM_Target)
print(OP_Monthly_SM_Target)


# COMMAND ----------

ol_index_yr = str(max([i.name.replace('/','') for i in dbutils.fs.ls (IP_Monthly_SM_Target)])).zfill(0)
ol_index_mon = str(max([i.name.replace('/','') for i in dbutils.fs.ls (IP_Monthly_SM_Target +"/" +str(ol_index_yr))])).zfill(0)
ol_index_day  = str(max([i.name.replace('/','') for i in dbutils.fs.ls (IP_Monthly_SM_Target +"/"+str(ol_index_yr)+"/"+str(ol_index_mon))])).zfill(0)
                     
path_oli = IP_Monthly_SM_Target+ol_index_yr+"/"+ol_index_mon+"/"+ol_index_day + "/VN_NUMBER_SM_TARGET.csv"

#path_oli = "dbfs:/mnt/adls/EDGE_Analytics/Datalake/Processed/FMT/2021/01/05/VN_OL_CHANNEL_INDEX.csv"
                   
print(path_oli)

# COMMAND ----------

df_OLI= spark.read.csv(path_oli , header='true')

for col in df_OLI.columns:
  df_OLI = df_OLI.withColumnRenamed(col,col.replace(" ","_"))

# COMMAND ----------

df_OLI.show()

# COMMAND ----------

df_OLI.createOrReplaceTempView('OLI')

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC select * from OLI

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC select count(1) from OLI

# COMMAND ----------

df2= spark.sql(
"""
select 
cast(year as int) year, 
Standardised_Salesperson_Product_Group as SPG,
concat(year,month) as year_month, 
site_code, 
 stack(12,'01',January, 
          '02',February, 
          '03',March, 
          '04',April, 
           '05',May, 
           '06',June, 
           '07',July, 
           '08',August, 
           '09',September, 
           '10',October, 
           '11',November, 
           '12',December) as (month, target) 
  from OLI 
"""
)
display(df2)

# COMMAND ----------

df2.count()

# COMMAND ----------

df2.coalesce(1).write.mode("overwrite").option("header", "true")\
.option("emptyValue", None)\
.option("nullValue", None).csv(OP_Monthly_SM_Target)

# COMMAND ----------

