# Databricks notebook source
from datetime import datetime, timezone

utc_dt = datetime.now(timezone.utc) # UTC time

import pytz

tz = pytz.timezone('Asia/Bangkok')
vn_now = datetime.now(tz)

print(vn_now)

# COMMAND ----------

from datetime import datetime
from pyspark.sql.functions import col,substring,when,isnull,trim
from pyspark.sql.types import *

# COMMAND ----------

dbutils.widgets.text("IP_Monthly_SM_Target", "","")
# /mnt/adls/EDGE_Analytics/Datalake/Processed/FMT/
dbutils.widgets.text("OP_Monthly_SM_Target", "","")
# /mnt/adls/EDGE_Analytics/Datalake/Transformed/Facts/Targets/Salesman_Monthly_Targets/
dbutils.widgets.text("OP_Monthly_SPG_Target", "","")
# /mnt/adls/EDGE_Analytics/Datalake/Transformed/Facts/Targets/SPG_Monthly_Targets/
dbutils.widgets.text("OP_Monthly_KPI_Target", "","")
# /mnt/adls/EDGE_Analytics/Datalake/Transformed/Facts/Targets/KPI_Monthly_Targets/

IP_Monthly_SM_Target= dbutils.widgets.get("IP_Monthly_SM_Target")
OP_Monthly_SM_Target = dbutils.widgets.get("OP_Monthly_SM_Target")
OP_Monthly_SPG_Target = dbutils.widgets.get("OP_Monthly_SPG_Target")
OP_Monthly_KPI_Target = dbutils.widgets.get("OP_Monthly_KPI_Target")

print(IP_Monthly_SM_Target)
print(OP_Monthly_SM_Target)
print(OP_Monthly_SPG_Target)
print(OP_Monthly_KPI_Target)


# COMMAND ----------

ol_index_yr = str(max([i.name.replace('/','') for i in dbutils.fs.ls (IP_Monthly_SM_Target)])).zfill(0)
ol_index_mon = str(max([i.name.replace('/','') for i in dbutils.fs.ls (IP_Monthly_SM_Target +"/" +str(ol_index_yr))])).zfill(0)
ol_index_day  = str(max([i.name.replace('/','') for i in dbutils.fs.ls (IP_Monthly_SM_Target +"/"+str(ol_index_yr)+"/"+str(ol_index_mon))])).zfill(0)
                     
path_oli = IP_Monthly_SM_Target+ol_index_yr+"/"+ol_index_mon+"/"+ol_index_day + "/VN_NUMBER_SM_TARGET.csv"

#path_oli = "dbfs:/mnt/adls/EDGE_Analytics/Datalake/Processed/FMT/2021/01/05/VN_OL_CHANNEL_INDEX.csv"
                   
print(path_oli)

# COMMAND ----------

kpi_index_yr = str(max([i.name.replace('/','') for i in dbutils.fs.ls (IP_Monthly_SM_Target)])).zfill(0)
kpi_index_mon = str(max([i.name.replace('/','') for i in dbutils.fs.ls (IP_Monthly_SM_Target +"/" +str(kpi_index_yr))])).zfill(0)
kpi_index_day  = str(max([i.name.replace('/','') for i in dbutils.fs.ls (IP_Monthly_SM_Target +"/"+str(kpi_index_yr)+"/"+str(kpi_index_mon))])).zfill(0)
                     
path_kpi = IP_Monthly_SM_Target+kpi_index_yr+"/"+kpi_index_mon+"/"+kpi_index_day + "/VN_KPI_TARGET.csv"
                  
print(path_kpi)

# COMMAND ----------

df_OLI= spark.read.csv(path_oli , header='true')

for col in df_OLI.columns:
  df_OLI = df_OLI.withColumnRenamed(col,col.replace(" ","_"))

# COMMAND ----------

df_KPI= spark.read.csv(path_kpi , header='true')

for col in df_KPI.columns:
  df_KPI = df_KPI.withColumnRenamed(col,col.replace(" ",""))

# COMMAND ----------

df_OLI.show()

# COMMAND ----------

df_KPI.show()

# COMMAND ----------

df_OLI.createOrReplaceTempView('OLI')

# COMMAND ----------

df_KPI.createOrReplaceTempView('KPI')

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC select * from OLI

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC select * from KPI

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC select count(1) from OLI

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC select count(1) from KPI

# COMMAND ----------

df2= spark.sql(
"""
select 
cast(year as int) year, 
Standardised_Salesperson_Product_Group as SPG,
concat(year,month) as year_month, 
site_code, 
 stack(12,'01',January, 
          '02',February, 
          '03',March, 
          '04',April, 
           '05',May, 
           '06',June, 
           '07',July, 
           '08',August, 
           '09',September, 
           '10',October, 
           '11',November, 
           '12',December) as (month, target) 
  from OLI 
"""
)
display(df2)

# COMMAND ----------

df3= spark.sql(
"""
select 
cast(year as int) year, 
StandardisedSalespersonProductGroup as SPG,
concat(year,month) as year_month, 
KPI, 
 stack(12,'01',January, 
          '02',February, 
          '03',March, 
          '04',April, 
           '05',May, 
           '06',June, 
           '07',July, 
           '08',August, 
           '09',September, 
           '10',October, 
           '11',November, 
           '12',December) as (month, target) 
  from KPI 
"""
)
display(df3)

# COMMAND ----------

df2.count()

# COMMAND ----------

df3.count()

# COMMAND ----------

dbutils.fs.rm(OP_Monthly_SM_Target,True)

# COMMAND ----------

df2.coalesce(1).write.mode("overwrite").option("header", "true")\
.option("emptyValue", None)\
.option("nullValue", None).csv(OP_Monthly_SM_Target)

# COMMAND ----------

dbutils.fs.rm(OP_Monthly_KPI_Target,True)

# COMMAND ----------

df3.coalesce(1).write.mode("overwrite").option("header", "true")\
.option("emptyValue", None)\
.option("nullValue", None).csv(OP_Monthly_KPI_Target)

# COMMAND ----------

spr_year = dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/Staging/Historical/Transaction/Sales_Period_Report/")
spr_files = spr_year[-1][0]

# COMMAND ----------

df_SPR1 = spark.read.csv(spr_files+"*/*.csv", header='true')

# COMMAND ----------

df_SPR1.createOrReplaceTempView('SPR')

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view
# MAGIC final_spg_from_spr
# MAGIC as
# MAGIC select distinct 
# MAGIC distributor_code,
# MAGIC site_code,
# MAGIC salesman_code,
# MAGIC --salesman_product_group as original_spg,
# MAGIC --to_date(cast(dt as varchar(8)),'yyyyMMdd')  as date,
# MAGIC 
# MAGIC substring(date_format(to_date(calender_day, 'dd.MM.yyyy'),'yyyyMMdd') ,1,6) as yrmo,
# MAGIC 
# MAGIC first(salesman_product_group) over(partition by distributor_code,salesman_code ,substring(date_format(to_date(calender_day, 'dd.MM.yyyy'),'yyyyMMdd') ,1,6) 
# MAGIC --order by substring(dt ,1,6) 
# MAGIC order by to_date(date_format(to_date(calender_day, 'dd.MM.yyyy'),'yyyyMMdd'),'yyyyMMdd') desc
# MAGIC ) as final_spg
# MAGIC from SPR where country='VN'
# MAGIC --and  (to_date(cast(dt as varchar(8)),'yyyyMMdd')=last_day(to_date(cast(dt as varchar(8)),'yyyyMMdd')))
# MAGIC --order by to_date(cast(dt as varchar(8)),'yyyyMMdd') 

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC select * from final_spg_from_spr

# COMMAND ----------

import numpy
from pyspark.sql.functions import *

fcs_spg_year = dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/Staging/Historical/Transaction/FCS_SalespersonbySPG_hist/")
path_fcs_spg = fcs_spg_year[-1][0]

fcs_spg_year_inc = dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/Staging/Historical/Transaction/FCS_SalespersonbySPG/")
fcs_spg_folders_inc = dbutils.fs.ls(fcs_spg_year_inc[-1][0])
fcs_spg_files_inc = []

for i in fcs_spg_folders_inc:
  fcs_spg_files_inc.append([i[0][-31:-25],i[0]])
  
fcs_spg_select = spark.createDataFrame(fcs_spg_files_inc, ["data_month","path"])
path_fcs_spg_inc = list(fcs_spg_select.groupBy(["data_month"]).agg(max(col("path")).alias("path")).select(col("path")).toPandas()["path"])


# COMMAND ----------

df_fcs_spg1 = spark.read.csv(path_fcs_spg+'*/*.csv' , header='true').distinct()

df_fcs_spg1_inc = spark.read.csv(path_fcs_spg_inc[0]+'*.csv', header='true')
for i in path_fcs_spg_inc[1:]:
  df_fcs_spg1_inc = df_fcs_spg1_inc.unionAll(spark.read.csv(i+'*.csv' , header='true'))

# COMMAND ----------

df_fcs_spg_ini = df_fcs_spg1.union(df_fcs_spg1_inc)

# COMMAND ----------

df_fcs_spg_ini.createOrReplaceTempView('fcs_spg')

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC select date_format(to_date('01.'||cal_month, 'dd.MM.yyyy'),'yyyyMM'),
# MAGIC distributor_code,
# MAGIC salesman_code,
# MAGIC count(distinct salesman_product_group)
# MAGIC from fcs_spg
# MAGIC group by date_format(to_date('01.'||cal_month, 'dd.MM.yyyy'),'yyyyMM'),distributor_code,
# MAGIC salesman_code
# MAGIC having count(distinct salesman_product_group) > 1

# COMMAND ----------

df_SPG_out = spark.sql("""

select 
a.yrmo,
a.distributor_code,
a.salesman_code,
a.final_spg as salesman_product_group,
 cast(translate(b.sales_target,',','') as float) as sales_target
from
final_spg_from_spr a
inner join fcs_spg b
on a.distributor_code=b.distributor_code
and a.salesman_code=b.salesman_code
and a.site_code=b.site_code
and a.final_spg=b.salesman_product_group
and a.yrmo=date_format(to_date('01.'||b.cal_month, 'dd.MM.yyyy'),'yyyyMM')

""")




# COMMAND ----------

dbutils.fs.rm(OP_Monthly_SPG_Target,True)

# COMMAND ----------

df_SPG_out.coalesce(1).write.mode("overwrite").option("header", "true")\
.option("emptyValue", None)\
.option("nullValue", None).csv(OP_Monthly_SPG_Target)

# COMMAND ----------

from datetime import datetime, timezone

utc_dt = datetime.now(timezone.utc) # UTC time

import pytz

tz = pytz.timezone('Asia/Bangkok')
vn_now = datetime.now(tz)

print(vn_now)