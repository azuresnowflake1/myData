# Databricks notebook source
# MAGIC %sql
# MAGIC 
# MAGIC select current_timestamp()

# COMMAND ----------

spg_year = dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/Staging/Incremental/Masters/Salesman_SPG_Mapping/")
spg_month = dbutils.fs.ls(spg_year[-1][0])
spg_date = dbutils.fs.ls(spg_month[-1][0])
path_spg = spg_date[-1][0]

sm_year = dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/Transformed/Dimensions/Salesman/")
sm_month = dbutils.fs.ls(sm_year[-1][0])
sm_date = dbutils.fs.ls(sm_month[-1][0])
path_sm = sm_date[-1][0]

"""
td_year = dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/Staging/Incremental/Masters/Trading_Day/")
path_td = td_year[-1][0]
"""

time_path="/mnt/adls/EDGE_Analytics/Datalake/Staging/Incremental/Masters/Trading_Day/"
td_year = str(max([i.name.replace('/','') for i in dbutils.fs.ls (time_path)]))
td_month= str(max([i.name.replace('/','') for i in dbutils.fs.ls (time_path +"/" +str(td_year))]))
td_date  = str(max([i.name.replace('/','') for i in dbutils.fs.ls (time_path +"/"+str(td_year)+"/"+str(td_month))]))
time_file="VN_TRADING_DAYS_MAP.csv"
path_td=time_path+td_year+"/"+td_month+"/"+td_date+"/"+time_file
print(path_td)


spr_year = dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/Staging/Historical/Transaction/Sales_Period_Report/")
path_spr = spr_year[-1][0]

#list of paths to extract dates from the same
path_efos=[]
efos_year = dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/Staging/Historical/Transaction/EFOS_Outlet_Daily/")
for yr in efos_year:
  for file in dbutils.fs.ls(yr[0]):
    path_efos.append(file[0])



IP_FMT_Blob='/mnt/adls/EDGE_Analytics/Datalake/Processed/FMT/'
fmt_year = str(max([i.name.replace('/','') for i in dbutils.fs.ls (IP_FMT_Blob)]))
fmt_month= str(max([i.name.replace('/','') for i in dbutils.fs.ls (IP_FMT_Blob +"/" +str(fmt_year))]))
fmt_date  = str(max([i.name.replace('/','') for i in dbutils.fs.ls (IP_FMT_Blob +"/"+str(fmt_year)+"/"+str(fmt_month))]))

"""
ktgt_year = dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/Staging/Historical/Targets/KPI_Target/")
path_ktgt = ktgt_year[-1][0]
"""
kpi_file="VN_KPI_TARGET.csv"
path_ktgt=IP_FMT_Blob+fmt_year+"/"+fmt_month+"/"+fmt_date+"/"+kpi_file
print(path_ktgt)


sgm_file="VN_SPG_MAP.csv"
path_sgm=IP_FMT_Blob+fmt_year+"/"+fmt_month+"/"+fmt_date+"/"+sgm_file
print(path_sgm)

eot_file="VN_EOT_FILTER.csv"
path_eot=IP_FMT_Blob+fmt_year+"/"+fmt_month+"/"+fmt_date+"/"+eot_file
print(path_eot)



# COMMAND ----------

import numpy
from pyspark.sql.functions import *

t4p_year = dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/Staging/Historical/Transaction/4P_Salesman_View_hist/")
path_4p = t4p_year[-1][0]

t4p_year_inc = dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/Staging/Historical/Transaction/4P_Salesman_View/")
t4p_files_inc = dbutils.fs.ls(t4p_year_inc[-1][0])
path_4p_list = []
for i in t4p_files_inc:
  for j in dbutils.fs.ls(i[0]):
    path_4p_list.append([j[0],j[0][-38:-32],j[0][-16:-8]])

    
path_4p_select = spark.createDataFrame(path_4p_list, ["path","data_month","extracted_on"])

#selecting overflow month data and marking the last week we recieved data for overflow
path_4p_select_multiple = path_4p_select.filter(expr("substring(extracted_on,1,6)>data_month")).withColumn("max_extracted_on", expr("max(extracted_on) over(partition by data_month)"))

df_4p_last_dt = path_4p_select.filter(expr("substring(extracted_on,1,6)>data_month")).withColumn("max_extracted_on", expr("date_format(date_sub(to_date(concat(substring(extracted_on,1,6),'01'),'yyyyMMdd'),1),'yyyyMMdd' )") ).select(["data_month","max_extracted_on"]).distinct()

path_4p_select.createOrReplaceTempView("t_path_4p_select_fin")

path_4p_select_multiple.createOrReplaceTempView("t_path_4p_select")

#removing all the addresses present in the overflow table, but not removing the last week data
path_4p_inc1 = spark.sql("select * from t_path_4p_select_fin where path not in (select distinct path from t_path_4p_select where data_month in (select data_month from t_path_4p_select group by data_month having count(distinct extracted_on)>1) and extracted_on!=max_extracted_on)")

path_4p_inc = list(path_4p_inc1.toPandas()["path"])



# COMMAND ----------

"""
fcs_spg_year_inc = dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/Staging/Historical/Transaction/FCS_SalespersonbySPG/")
path_fcs_spg_inc = fcs_spg_year_inc[-1][0]
"""

fcs_spg_year = dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/Staging/Historical/Transaction/FCS_SalespersonbySPG_hist/")
path_fcs_spg = fcs_spg_year[-1][0]

fcs_spg_year_inc = dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/Staging/Historical/Transaction/FCS_SalespersonbySPG/")
fcs_spg_folders_inc = dbutils.fs.ls(fcs_spg_year_inc[-1][0])
fcs_spg_files_inc = []

for i in fcs_spg_folders_inc:
  fcs_spg_files_inc.append([i[0][-31:-25],i[0]])
  
fcs_spg_select = spark.createDataFrame(fcs_spg_files_inc, ["data_month","path"])
path_fcs_spg_inc = list(fcs_spg_select.groupBy(["data_month"]).agg(max(col("path")).alias("path")).select(col("path")).toPandas()["path"])



"""
eot_year = dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/Staging/Historical/Targets/EOT_Benchmark_Filters/")
path_eot = eot_year[-1][0]

sgm_year = dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/Staging/Incremental/Masters/Salesman_Product_group_Mapping/")
sgm_month = dbutils.fs.ls(sgm_year[-1][0])
sgm_date = dbutils.fs.ls(sgm_month[-1][0])
path_sgm = sgm_date[-1][0]
"""

# COMMAND ----------

fcs_year = dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/Staging/Historical/Transaction/FCS_Salesperson_hist/")
path_fcs = fcs_year[-1][0]

fcs_year_inc = dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/Staging/Historical/Transaction/FCS_Salesperson/")
fcs_files_inc = dbutils.fs.ls(fcs_year_inc[-1][0])
path_fcs_list = []
for i in fcs_files_inc:
  for j in dbutils.fs.ls(i[0]):
    path_fcs_list.append([j[0],j[0][-38:-32],j[0][-16:-8]])
    
    
path_fcs_select = spark.createDataFrame(path_fcs_list, ["path","data_month","extracted_on"])

#selecting overflow month data and marking the last week we recieved data for overflow
path_fcs_select_multiple = path_fcs_select.filter(expr("substring(extracted_on,1,6)>data_month")).withColumn("max_extracted_on", expr("max(extracted_on) over(partition by data_month)"))

fcs_last_dt = path_fcs_select.filter(expr("substring(extracted_on,1,6)>data_month")).withColumn("max_extracted_on", expr("date_format(date_sub(to_date(concat(substring(extracted_on,1,6),'01'),'yyyyMMdd'),1),'yyyyMMdd' )") ).select(["data_month","max_extracted_on"]).distinct()

path_fcs_select.createOrReplaceTempView("t_path_fcs_select_fin")

path_fcs_select_multiple.createOrReplaceTempView("t_path_fcs_select")

#removing all the addresses present in the overflow table, but not removing the last week data
path_fcs_inc1 = spark.sql("select * from t_path_fcs_select_fin where path not in (select distinct path from t_path_fcs_select where data_month in (select data_month from t_path_fcs_select group by data_month having count(distinct extracted_on)>1) and extracted_on!=max_extracted_on)")

path_fcs_inc = list(path_fcs_inc1.toPandas()["path"])

# COMMAND ----------

pa_year = dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/Staging/Historical/Transaction/PA_Salesman_View/")
pa_files = dbutils.fs.ls(pa_year[-1][0])
pa_files_list = []
for i in pa_files:
  for j in dbutils.fs.ls(i[0]):
    pa_files_list.append([j[0],j[0][-38:-32],j[0][-16:-8]])
    
    
pa_files_select = spark.createDataFrame(pa_files_list, ["path","data_month","extracted_on"])

pa_last_dt = pa_files_select.filter(expr("substring(extracted_on,1,6)==data_month")).withColumn("max_extracted_on", expr("max(extracted_on) over(partition by data_month)")).select(["data_month","max_extracted_on"]).distinct()

#selecting overflow month data and marking the last week we recieved data for overflow
pa_files_select_multiple = pa_files_select.filter(expr("substring(extracted_on,1,6)>data_month")).withColumn("max_extracted_on", expr("max(extracted_on) over(partition by data_month)"))

pa_files_select.createOrReplaceTempView("t_pa_files_select_fin")

pa_files_select_multiple.createOrReplaceTempView("t_pa_files_select")

#removing all the addresses present in the overflow table, but not removing the last week data
path_pa1 = spark.sql("select * from t_pa_files_select_fin where path not in (select distinct path from t_pa_files_select where data_month in (select data_month from t_pa_files_select group by data_month having count(distinct extracted_on)>1) and extracted_on!=max_extracted_on)")

path_pa = list(path_pa1.toPandas()["path"])

# COMMAND ----------

spr_year = dbutils.fs.ls("/mnt/adls/EDGE_Analytics/Datalake/Staging/Historical/Transaction/Sales_Period_Report/")
spr_files = spr_year[-1][0]

# COMMAND ----------

from datetime import *
from pyspark.sql.types import *
from pyspark.sql import Window

# COMMAND ----------

#reading all files
df_SPG1 = spark.read.csv(path_spg , header='true').distinct()

print("SPG count is " + str(df_SPG1.count()))

df_SM1 = spark.read.csv(path_sm , header='true').distinct()

print("SM count is " + str(df_SM1.count()))

df_td1 = spark.read.option("inferSchema", "true").option("delimiter", ",").csv(path_td, header='true').distinct()

print("TD count is " + str(df_td1.count()))

df_SPR1 = spark.read.csv(spr_files, header='true',recursiveFileLookup=True)

print("SPR count is " + str(df_SPR1.count()))

df_eot1 = spark.read.csv(path_eot , header='true').distinct()

print("EOT count is " + str(df_eot1.count()))

df_SGM1 = spark.read.csv(path_sgm , header='true').distinct()

print("SGM count is " + str(df_SGM1.count()))

df_kpi_tgt1 = spark.read.csv(path_ktgt , header='true').distinct()

print("KPI TGT count is " + str(df_kpi_tgt1.count()))

# COMMAND ----------

 #reading all files

"""
df_efos1 = spark.read.csv(path_efos[0]+"*.csv" , header='true')

for i in range(len(path_efos)-1):
  df_efos1 = df_efos1.unionAll(spark.read.csv(path_efos[i+1]+"*.csv" , header='true'))
"""

df_efos1_write = spark.read.csv(path_efos , header='true',recursiveFileLookup=True).distinct()

# COMMAND ----------

dbutils.fs.rm("/mnt/adls/EDGE_Analytics/Datalake/temp/temp_KPI/temp_efos11/",True)

df_efos1_write.repartition(30).write.mode("overwrite").option("header", "true")\
.option("emptyValue", None)\
.option("nullValue", None).parquet("/mnt/adls/EDGE_Analytics/Datalake/temp/temp_KPI/temp_efos11/")

df_efos1 = spark.read.parquet("/mnt/adls/EDGE_Analytics/Datalake/temp/temp_KPI/temp_efos11/")

# COMMAND ----------

df_4p1 = spark.read.csv(path_4p , header='true',recursiveFileLookup=True).withColumn("t_flag", lit(2)).distinct()

"""
df_4p1_inc = spark.read.csv(path_4p_inc[0], header='true').withColumn("t_wk", lit(path_4p_inc[0][-16:-8])).withColumn("data_month", lit(path_4p_inc[0][-38:-32]))
for i in path_4p_inc[1:]:
  df_4p1_inc = df_4p1_inc.unionAll(spark.read.csv(i , header='true').withColumn("t_wk", lit(i[-16:-8])).withColumn("data_month", lit(i[-38:-32])))
 """

df_4p1_inc = spark.read.csv(path_4p_inc, header='true',recursiveFileLookup=True).withColumn("filename",  regexp_replace(lit(input_file_name()),'%20',' ')).withColumn("data_month",  substring(col("filename"),-38,6)).withColumn("t_wk",  substring(col("filename"),-16,8))

df_4p1_inc = df_4p1_inc.join(df_4p_last_dt,["data_month"],"left").withColumn("t_wk", when(substring(col("t_wk"),1,6)>col("data_month") , col("max_extracted_on")).otherwise(col("t_wk")) ).drop("data_month")

df_4p1_inc.count()

# COMMAND ----------

df_fcs1 = spark.read.csv(path_fcs , header='true',recursiveFileLookup=True).withColumn("t_flag", lit(2)).distinct()

"""
df_fcs1_inc = spark.read.csv(path_fcs_inc[0], header='true').withColumn("t_wk", lit(path_fcs_inc[0][-16:-8])).withColumn("data_month", lit(path_fcs_inc[0][-38:-32]))
for i in path_fcs_inc[1:]:
  df_fcs1_inc = df_fcs1_inc.unionAll(spark.read.csv(i , header='true').withColumn("t_wk", lit(i[-16:-8])).withColumn("data_month", lit(i[-38:-32])) )
 """

df_fcs1_inc = spark.read.csv(path_fcs_inc, header='true',recursiveFileLookup=True).withColumn("filename",  regexp_replace(lit(input_file_name()),'%20',' ')).withColumn("data_month",  substring(col("filename"),-38,6)).withColumn("t_wk",  substring(col("filename"),-16,8))

df_fcs1_inc = df_fcs1_inc.join(fcs_last_dt,["data_month"],"left").withColumn("t_wk", when(substring(col("t_wk"),1,6)>col("data_month") , col("max_extracted_on")).otherwise(col("t_wk")) ).drop("data_month")


df_fcs1_inc.count()

# COMMAND ----------

df_fcs_spg1 = spark.read.csv(path_fcs_spg , header='true',recursiveFileLookup=True).distinct()

"""

df_fcs_spg1_inc = spark.read.csv(path_fcs_spg_inc[0]+'*.csv', header='true')
for i in path_fcs_spg_inc[1:]:
  df_fcs_spg1_inc = df_fcs_spg1_inc.unionAll(spark.read.csv(i+'*.csv' , header='true'))
"""

df_fcs_spg1_inc = spark.read.csv(path_fcs_spg_inc, header='true',recursiveFileLookup=True)

df_fcs_spg1_inc.count()

# COMMAND ----------


"""
df_pa1 = spark.read.csv(path_pa[0] , header='true').withColumn("t_wk", lit(path_pa[0][-16:-8])).withColumn("data_month", lit(path_pa[0][-38:-32]))
for i in path_pa[1:]:
  df_pa1 = df_pa1.unionAll(spark.read.csv(i , header='true').withColumn("t_wk", lit(i[-16:-8])).withColumn("data_month", lit(i[-38:-32])) )
 
 """
df_pa1 = spark.read.csv(path_pa, header='true',recursiveFileLookup=True).withColumn("filename",  regexp_replace(lit(input_file_name()),'%20',' ')).withColumn("data_month",  substring(col("filename"),-38,6)).withColumn("t_wk",  substring(col("filename"),-16,8))


#df_pa1 = df_pa1.join(pa_last_dt,["data_month"],"left").withColumn("t_wk", when(substring(col("t_wk"),1,6)>col("data_month") , col("max_extracted_on")).otherwise(col("t_wk")) ).drop("data_month")

df_pa1.count()

# COMMAND ----------

#setting parameter for time dimension transformation
spark.conf.set("spark.sql.legacy.timeParserPolicy","LEGACY")

# COMMAND ----------

df_SPG = df_SPG1.select(col("PERNR").cast("int").alias("salesman_code")).distinct()

df_SM = df_SM1.select(col("Salesman_Product_Group_Code").alias("salesman_product_group"), col("Role_Business_Scope_Assignment")).distinct()

df_td2 = df_td1.select(date_format(to_date(col("Date"),'M/d/yyyy'), "yyyyMMdd").cast("int").alias("dt"), substring(col('Date'),-4,4).cast("int").alias("year"), col("Month").alias("month"), col("Wk ").cast("int").alias("wk"), col("Trading Day").cast("int").alias("trading_day"), col("Total Trading days").cast("int").alias("trading_days_month")).filter(to_date(col("Dt").cast("string"),'yyyyMMdd')<= date.today()).withColumn('cum_days', expr('sum(trading_day) over (partition by month,year order by dt)')).withColumn('cum_days_week', expr('max(cum_days) over (partition by wk,month,year )')).withColumn('trading_days_remaining', col("trading_days_month")-col("cum_days_week")).withColumn('wk_td', expr('sum(trading_day) over (partition by wk,month,year )')).withColumn('wk_wt', expr('wk_td/trading_days_month')).drop("wk_td")

df_td = df_td2.join(df_td2.select(col("wk"),col("month"), col("year"), col("wk_wt")).distinct().withColumn("cum_wk_wt", expr("sum(wk_wt) over(partition by year,month order by wk)")).drop("wk_wt").distinct(), ["wk","month","year"], how="left")

df_SGM=df_SGM1.select(col("Salesman Product Group Code").alias("Salesman_Product_Group"), col("Standardised Salesperson Product Group").alias("std_Salesman_Product_Group"), col("Salesforce").alias("Salesforce"), col("KPI In Scope").alias("kpi_in_scope")).distinct()

# COMMAND ----------

#pre-processing the tables like marking week, aggregating weekly MTD, removing commas

"""
df_SPR = df_SPR1.select(col("country"), date_format(to_date(col("calender_day"), "dd.MM.yyyy"),'yyyyMMdd').cast("int").alias("dt"),  col("distributor_code"), col("site_code"), col("salesman_code"),  col("salesman_product_group")).join(df_td2.select(["dt","wk","year"]).distinct(), ["dt"], "left").drop("dt").distinct().join(df_td2.select(["dt","wk","year"]).distinct(), ["wk","year"], "left").distinct().withColumn("salesman_product_group", expr("last(salesman_product_group) over (partition by distributor_code, site_code, salesman_code, wk,year order by dt )")).drop("year")
"""

df_efos2 = df_efos1.withColumn("month", date_format(to_date(col("Dt"),'dd.MM.yyyy'),"M")).withColumn("year", substring(col("Dt"),-4,4).cast("int")).select(date_format(to_date(col("Dt"),'dd.MM.yyyy'),'yyyyMMdd').cast("int").alias("dt"), \
                           col("month").cast("int").alias("month_num"), col("year").cast("int"), col("salesman_code"), col("distributor_code"), col("site_code"), \
                           coalesce(col("actual_outlet_time").cast("int"),lit(0)).alias("actual_outlet_time"),\
                           col("effective_outlet_time").cast("int").alias("effective_outlet_time"),\
                           coalesce(col("geo_complied_calls").cast("int"),lit(0)).alias("geo_complied_calls"), \
                           coalesce(col("pjp_complied_calls").cast("int"),lit(0)).alias("pjp_complied_calls"),\
                           coalesce(col("planned_calls").cast("int"),lit(0)).alias("planned_calls"),\
                           coalesce(col("sku_order").cast("int"),lit(0)).alias("sku_order"),\
                          coalesce(translate(col("total_sales_return"),",","").cast("int"),lit(0)).alias("total_sales_return"))\
.join(df_td2.select(["dt","wk"]).distinct(), ["dt"], "left")\
.withColumn("actual_calls", expr("if(effective_outlet_time='' or effective_outlet_time is null, 0, 1 )") )\
.withColumn("effective_outlet_time", coalesce(col("effective_outlet_time"),lit(0)))\
.join(df_td2.select(["dt","trading_day"]).distinct(), ["dt"], "left")\




# COMMAND ----------

df_efos3 = df_td2.select(col("dt"),col("wk"),substring(col("dt"),5,2).alias("month_num"),col("year")).distinct().crossJoin(df_efos2.select(["salesman_code","distributor_code","site_code"]).distinct()).join(df_efos2.select(["salesman_code","distributor_code","site_code","month_num","year"]).distinct(), ["salesman_code","distributor_code","site_code","month_num","year"],"inner").join(df_efos2, ["salesman_code","distributor_code","site_code","month_num","dt","wk","year"],"left")




# COMMAND ----------

df_efos_write = df_efos3.withColumn("actual_outlet_time", expr("sum(coalesce(actual_outlet_time,0)) over(partition by year,month_num,distributor_code,site_code,salesman_code order by wk)"))\
.withColumn("effective_outlet_time", expr("sum(coalesce(effective_outlet_time,0)) over(partition by year,month_num,distributor_code,site_code,salesman_code order by wk)")/60)\
.withColumn("geo_complied_calls_weekly", expr("sum(coalesce(geo_complied_calls,0)) over(partition by year,wk,month_num,distributor_code,site_code,salesman_code)"))\
.withColumn("pjp_complied_calls_weekly", expr("sum(coalesce(pjp_complied_calls,0)) over(partition by year,wk,month_num,distributor_code,site_code,salesman_code)"))\
.withColumn("geo_complied_calls", expr("sum(coalesce(geo_complied_calls,0)) over(partition by year,month_num,distributor_code,site_code,salesman_code order by wk)"))\
.withColumn("pjp_complied_calls", expr("sum(coalesce(pjp_complied_calls,0)) over(partition by year,month_num,distributor_code,site_code,salesman_code order by wk)"))\
.withColumn("planned_calls_weekly", expr("sum(case when trading_day=0 then null else coalesce(planned_calls,0) end) over(partition by year,wk,month_num,distributor_code,site_code,salesman_code)"))\
.withColumn("planned_calls", expr("sum(case when trading_day=0 then null else coalesce(planned_calls,0) end) over(partition by year,month_num,distributor_code,site_code,salesman_code order by wk)"))\
.withColumn("total_sales_return", expr("sum(coalesce(total_sales_return,0)) over(partition by year,month_num,distributor_code,site_code,salesman_code order by wk)"))\
.withColumn("sku_order", expr("sum(coalesce(sku_order,0)) over(partition by year,month_num,distributor_code,site_code,salesman_code order by wk)"))\
.withColumn("actual_calls_weekly", expr("sum(coalesce(actual_calls,0)) over(partition by year,wk,month_num,distributor_code,site_code,salesman_code)"))\
.withColumn("actual_calls", expr("sum(coalesce(actual_calls,0)) over(partition by year,month_num,distributor_code,site_code,salesman_code order by wk)") ).drop("dt").drop("trading_day").distinct()

# COMMAND ----------

dbutils.fs.rm("/mnt/adls/EDGE_Analytics/Datalake/temp/temp_KPI/temp_efos/",True)

df_efos_write.repartition(30).write.mode("overwrite").option("header", "true")\
.option("emptyValue", None)\
.option("nullValue", None).parquet("/mnt/adls/EDGE_Analytics/Datalake/temp/temp_KPI/temp_efos/")

df_efos = spark.read.parquet("/mnt/adls/EDGE_Analytics/Datalake/temp/temp_KPI/temp_efos/")

# COMMAND ----------

dbutils.fs.rm("/mnt/adls/EDGE_Analytics/Datalake/temp/temp_KPI/temp_SPR/",True)

# COMMAND ----------

df_SPR1.select(col("distributor_code"), col("site_code"), col("salesman_code"),  col("salesman_product_group"),col("country")
 ,date_format(to_date(col("calender_day"), "dd.MM.yyyy"),'yyyyMMdd').cast("int").alias("dt")
                                                                                           ).distinct().createOrReplaceTempView('SPR3')

df_td2.select(col("dt"),col("wk"),col("year")).distinct().createOrReplaceTempView('td2')

df_td2.select(col("dt")).distinct().createOrReplaceTempView('td3')

spark.sql("""
create or replace temp view spr3_min_max
as
select distributor_code,site_code,salesman_code,min(dt) as min_dt,max(dt) as max_dt from SPR3
-- where distributor_code='3002' and salesman_code='2012'
group by distributor_code,site_code,salesman_code
""")

spark.sql("""
create or replace temp view spr21 as 
select  distinct distributor_code,site_code,salesman_code,dt, salesman_product_group,country
from SPR3 
-- where distributor_code='3002' and salesman_code='2012'

union
(
(
select distinct a.distributor_code,a.site_code,a.salesman_code,b.dt,null as salesman_product_group,country from SPR3 a 
join td3 b
 on 1=1
-- and distributor_code='3002' and salesman_code='2012'

)
except
(
select distinct a.distributor_code,a.site_code,a.salesman_code,dt,null as salesman_product_group,country from SPR3 a
-- where a.distributor_code='3002' and a.salesman_code='2012'
)
)
"""
 )

df_SPR2_write= spark.sql("""
select  distinct a.distributor_code,a.site_code,a.salesman_code,a.dt, a.salesman_product_group,a.country
from spr21 a
join spr3_min_max c
on a.distributor_code=c.distributor_code
and a.site_code=c.site_code
and a.salesman_code=c.salesman_code
and to_date(cast(dt as varchar(8)),'yyyyMMdd') between to_date(cast(c.min_dt as varchar(8)),'yyyyMMdd') 
and last_day(to_date(cast(c.max_dt as varchar(8)),'yyyyMMdd'))

""")


df_SPR2_write.repartition(30).write.mode("overwrite").option("header", "true")\
.option("emptyValue", None)\
.option("nullValue", None).parquet("/mnt/adls/EDGE_Analytics/Datalake/temp/temp_KPI/temp_SPR/")

df_SPR2 = spark.read.parquet("/mnt/adls/EDGE_Analytics/Datalake/temp/temp_KPI/temp_SPR/")

# COMMAND ----------

df_SPR2.createOrReplaceTempView('vw_SPR')

df_SPR = spark.sql("""
select 
a.dt,
wk,
latest_spg as spg_prev,
distributor_code,
site_code,
salesman_code,
country,
split(latest_spg,",")[1] as salesman_product_group 
from (
select *,max(dt || ',' || salesman_product_group) over(partition by distributor_code,site_code,salesman_code order by dt rows between unbounded preceding and current row) as latest_spg from vw_SPR 
-- where salesman_code='2030' and distributor_code='3002' order by dt
) a join td2 b on a.dt=b.dt
""")




# COMMAND ----------

df_4p_ini = df_4p1.select(col("salesman_code"), col("salesman_product_group"), col("distributor_code"), col("site_code"),\
                      translate(col("total_outlet_count"),",","").cast("int").alias("total_outlet_count"), \
                      translate(col("4P_compliance_outlet"),",","").cast("int").alias("FourP_compliance_outlet"), \
                      translate(col("EB_target"),",","").cast("int").alias("EB_target_abs"), \
                      translate(col("EB_actual"),",","").cast("int").alias("EB_actual"), \
                      translate(col("redline_target"),",","").cast("int").alias("RL_target_abs"), \
                      translate(col("redline_actual"),",","").cast("int").alias("RL_actual"), \
                      translate(col("WP_target"),",","").cast("int").alias("WP_target_abs"), \
                      translate(col("WP_actual"),",","").cast("int").alias("WP_actual"), \
                      translate(col("COTC_target"),",","").cast("int").alias("COTC_target_abs"), \
                      translate(col("COTC_actual"),",","").cast("int").alias("COTC_actual"), \
                      translate(col("NPD_target"),",","").cast("int").alias("NPD_target_abs"), \
                      translate(col("NPD_actual"),",","").cast("int").alias("NPD_actual"), \
                      substring(col("calender_month"),4,4).cast("int").alias("year"),\
                      substring(col("calender_month"),1,2).cast("int").alias("month_num"),\
                      concat(substring(col("calender_month"),4,4),substring(col("calender_month"),1,2)).cast("int").alias("dt"),\
                      lit('hist').alias('flagsh')).distinct()\
.join(df_td.select(substring(col("dt"),1,6).alias("dt"), col("year"), col("wk"), col("cum_wk_wt")).distinct(), ["dt","year"], how = "left")\
.withColumn("FourP_compliance_outlet", col("FourP_compliance_outlet")*col("cum_wk_wt"))\
.withColumn("EB_actual", col("EB_actual")*col("cum_wk_wt"))\
.withColumn("RL_actual", col("RL_actual")*col("cum_wk_wt"))\
.withColumn("WP_actual", col("WP_actual")*col("cum_wk_wt"))\
.withColumn("COTC_actual", col("COTC_actual")*col("cum_wk_wt"))\
.withColumn("NPD_actual", col("NPD_actual")*col("cum_wk_wt")).drop("dt").drop("cum_wk_wt")

df_4p1_inc=df_4p1_inc.where((substring(col("calender_month"),4,4).cast("int")>=2020) & (substring(col("calender_month"),1,2).cast("int")>=8))

df_4p_inc = df_4p1_inc.select(substring(col("calender_month"),4,4).cast("int").alias("year"),\
                              col("salesman_code"),\
                              col("salesman_product_group"),\
                              col("distributor_code"),\
                              col("site_code"),\
                              translate(col("total_outlet_count"),",","").cast("int").alias("total_outlet_count"), \
                              translate(col("4P_compliance_outlet"),",","").cast("int").alias("FourP_compliance_outlet"), \
                              translate(col("EB_target"),",","").cast("int").alias("EB_target_abs"), \
                              translate(col("EB_actual"),",","").cast("int").alias("EB_actual"), \
                              translate(col("redline_target"),",","").cast("int").alias("RL_target_abs"), \
                              translate(col("redline_actual"),",","").cast("int").alias("RL_actual"), \
                              translate(col("WP_target"),",","").cast("int").alias("WP_target_abs"), \
                              translate(col("WP_actual"),",","").cast("int").alias("WP_actual"), \
                              translate(col("COTC_target"),",","").cast("int").alias("COTC_target_abs"), \
                              translate(col("COTC_actual"),",","").cast("int").alias("COTC_actual"), \
                              translate(col("NPD_target"),",","").cast("int").alias("NPD_target_abs"), \
                              translate(col("NPD_actual"),",","").cast("int").alias("NPD_actual"), \
                              substring(col("calender_month"),1,2).cast("int").alias("month_num"),\
                              col("t_wk"),\
                              lit('inc').alias('flagsh')).join(df_td2.select(["dt","wk"]).distinct(), df_td2.dt==df_4p1_inc.t_wk, "left").drop("dt")\
.withColumn("row_num", expr("row_number() over(partition by year, month_num, wk, salesman_code, salesman_product_group, distributor_code, site_code order by t_wk desc)")).filter(col("row_num")==1).drop("row_num").distinct().drop("t_wk")

df_4p = df_4p_ini.unionAll(df_4p_inc)

# COMMAND ----------

df_fcs_ini = df_fcs1.select(col("distributor_code"), col("site_code"), col("salesman_code"),\
                        translate(col("active_shop_in_pjp"),",","").cast("int").alias("active_shop_in_pjp"),\
                        translate(col("eco_actual"),",","").cast("int").alias("eco_actual"),\
                        translate(col("calls_to_be_visited"),",","").cast("int").alias("calls_to_be_visited"),\
                        translate(col("gsv"),",","").cast("bigint").alias("sales_actual"),\
                        translate(col("PC_total_number_of_invoices"),",","").cast("int").alias("PC"), \
                        translate(col("total_sku_line"),",","").cast("int").alias("total_sku_line"), \
                        substring(col("calender_month"),4,4).cast("int").alias("year"),\
                        substring(col("calender_month"),1,2).cast("int").alias("month_num"),\
                        concat(substring(col("calender_month"),4,4),substring(col("calender_month"),1,2)).cast("int").alias("dt"),\
                        lit('hist').alias("flag_fcs"))\
.join(df_td.select(substring(col("dt"),1,6).alias("dt"), col("year"), col("wk"), col("cum_wk_wt")).distinct(), ["dt","year"], how = "left")\
.withColumn("eco_actual", col("eco_actual")*col("cum_wk_wt"))\
.withColumn("calls_to_be_visited", col("calls_to_be_visited")*col("cum_wk_wt"))\
.withColumn("sales_actual", col("sales_actual")*col("cum_wk_wt"))\
.withColumn("PC", col("PC")*col("cum_wk_wt"))\
.withColumn("total_sku_line", col("total_sku_line")*col("cum_wk_wt"))\
.withColumn("lppc", (col("total_sku_line")/col("PC"))).drop("dt").drop("cum_wk_wt").distinct()

df_fcs1_inc=df_fcs1_inc.where((substring(col("calender_month"),4,4).cast("int")>=2020) & (substring(col("calender_month"),1,2).cast("int")>=8))


df_fcs_inc = df_fcs1_inc.join(df_td2.select(["dt","wk"]).distinct(), df_td2.dt==df_fcs1_inc.t_wk, "left").drop("dt").select(substring(col("calender_month"),4,4).cast("int").alias("year"),\
                                col("distributor_code"), col("site_code"), col("salesman_code"),col("t_wk"),\
                                translate(col("active_shop_in_pjp"),",","").cast("int").alias("active_shop_in_pjp"),\
                                translate(col("eco_actual"),",","").cast("int").alias("eco_actual"),\
                                translate(col("calls_to_be_visited"),",","").cast("int").alias("calls_to_be_visited"),\
                                translate(col("gsv"),",","").cast("bigint").alias("sales_actual"),\
                                translate(col("PC_total_number_of_invoices"),",","").cast("int").alias("PC"), \
                                translate(col("total_sku_line"),",","").cast("int").alias("total_sku_line"), \
                                substring(col("calender_month"),1,2).cast("int").alias("month_num"),\
                                lit('inc').alias("flag_fcs"),\
                                col("wk")
                                )\
.withColumn("row_num", expr("row_number() over(partition by year, month_num, wk, salesman_code, distributor_code, site_code order by t_wk desc)")).filter(col("row_num")==1).drop("row_num").drop("t_wk")\
.withColumn("lppc", (col("total_sku_line")/col("PC"))).distinct()\

df_fcs = df_fcs_ini.unionAll(df_fcs_inc)

# COMMAND ----------

df_eot = df_eot1.filter(col("Minimum_Maximum")==lit("Minimum")).select(col("salesforce"), col("Geo Complied Calls").cast("int").alias("geo_complied_calls_min"), col("Total Sales_Returns").alias("total sales_returns").cast("int").alias("total_sales_return_min"), col("Actual Outlet Time").cast("int").alias("actual_outlet_time_min"), col("SKUs Order").cast("int").alias("skus_order_min") ,(col("rolling weeks").cast("int")-1).alias("rolling_weeks"))\
.join(df_eot1.filter(col("Minimum_Maximum")==lit("Maximum") ).select(col("salesforce"), col("Geo Complied Calls").cast("int").alias("geo_complied_calls_max"), col("Total Sales_Returns").cast("int").alias("total_sales_return_max"), col("Actual Outlet Time").cast("int").alias("actual_outlet_time_max"), col("SKUs Order").cast("int").alias("skus_order_max")), ["salesforce"], how = "left")

df_pa_temp1 = df_pa1.drop("t_wk").drop("dt").distinct().filter(col("cal_month")=="07.2020")\
.crossJoin(df_td.filter(col("month")=="July").filter(col("year")=="2020").select(["wk","cum_wk_wt"]).distinct()).select(col("distributor_code"), col("site_code"), col("salesman_code"), col("salesman_product_group"),\
                      col("assortment_target_abs"),\
                      (col("assortment_achieved")*col("cum_wk_wt")).alias("assortment_achieved"), \
                      col("wk"),\
                      substring(col("cal_month"),4,4).cast("int").alias("year"),\
                      substring(col("cal_month"),1,2).cast("int").alias("month_num")).distinct()

df_pa = df_pa1.filter(expr("cal_month!='07.2020'"))\
.join(df_td2.select(["dt","wk"]).distinct(), df_td2.dt==df_pa1.t_wk, "left").drop("t_wk").drop("dt").distinct().select(col("distributor_code"), col("site_code"), col("salesman_code"), col("salesman_product_group"),\
                      col("assortment_target_abs"),\
                      col("assortment_achieved"), \
                      col("wk"),\
                      substring(col("cal_month"),4,4).cast("int").alias("year"),\
                      substring(col("cal_month"),1,2).cast("int").alias("month_num")).distinct().union(df_pa_temp1)

# COMMAND ----------

kpi_tgt = df_kpi_tgt1.withColumnRenamed("January ", "January").withColumnRenamed("Standardised Salesperson Product Group", "salesman_product_group")\
.selectExpr("Year","salesman_product_group","KPI","stack(12,'January', January, 'February',February,'March',March,'April',April,'May',May,'June',June,'July',July,'August',August,'September',September,'October',October,'November',November,'December',December)").withColumnRenamed("col0", "month").withColumnRenamed("col1","target").withColumnRenamed("Year","year")\
.join(df_td.select(col("month"), col("wk"), col("year"), col("cum_wk_wt")).distinct(), ["year","month"], how = "left").distinct()

df_kpi_tgt_map = kpi_tgt.select(col("year"), col("salesman_product_group"), col("month"), col("wk"), col("target").alias("ECO_target")).filter(col("KPI")=="ECO Percent")\
.join(kpi_tgt.select(col("year"), col("salesman_product_group"), col("month"), col("wk"), col("target").alias("PC_target")).filter(col("KPI")=="Productive Calls per Day"), ["year","salesman_product_group","month","wk"], "left")\
.join(kpi_tgt.select(col("year"), col("salesman_product_group"), col("month"), col("wk"), (col("target")*col("cum_wk_wt")).alias("EB_target")).filter(col("KPI")=="EB Percent"), ["year","salesman_product_group","month","wk"], "left")\
.join(kpi_tgt.select(col("year"), col("salesman_product_group"), col("month"), col("wk"), (col("target")*col("cum_wk_wt")).alias("assortment_target")).filter(col("KPI")=="Assortment Percent"), ["year","salesman_product_group","month","wk"], "left")\
.join(kpi_tgt.select(col("year"), col("salesman_product_group"), col("month"), col("wk"), col("target").alias("total_lines_target")).filter(col("KPI")=="Total Lines per Day"), ["year","salesman_product_group","month","wk"], "left")\
.join(kpi_tgt.select(col("year"), col("salesman_product_group"), col("month"), col("wk"), (col("target")*col("cum_wk_wt")).alias("4P_target")).filter(col("KPI")=="4P Compliance"), ["year","salesman_product_group","month","wk"], "left")\
.join(kpi_tgt.select(col("year"), col("salesman_product_group"), col("month"), col("wk"), (col("target")*col("cum_wk_wt")).alias("cotc_target")).filter(col("KPI")=="CotC Percent"), ["year","salesman_product_group","month","wk"], "left")\
.join(kpi_tgt.select(col("year"), col("salesman_product_group"), col("month"), col("wk"), (col("target")*col("cum_wk_wt")).alias("wp_target")).filter(col("KPI")=="WP Percent"), ["year","salesman_product_group","month","wk"], "left")\
.join(kpi_tgt.select(col("year"), col("salesman_product_group"), col("month"), col("wk"), col("target").cast("int").alias("geo_target")).filter(col("KPI")=="Geo Compliance"), ["year","salesman_product_group","month","wk"], "left")\
.join(kpi_tgt.select(col("year"), col("salesman_product_group"), col("month"), col("wk"), col("target").alias("non_pc_above_eot_target")).filter(col("KPI")=="Percent of Non PC Above EOT Benchmark "), ["year","salesman_product_group","month","wk"], "left")\
.join(kpi_tgt.select(col("year"), col("salesman_product_group"), col("month"), col("wk"), col("target").alias("pjp_target")).filter(col("KPI")=="PJP Compliance"), ["year","salesman_product_group","month","wk"], "left")\
.join(kpi_tgt.select(col("year"), col("salesman_product_group"), col("month"), col("wk"), (col("target")*col("cum_wk_wt")).alias("rl_target")).filter(col("KPI")=="RL Percent"), ["year","salesman_product_group","month","wk"], "left")\
.join(kpi_tgt.select(col("year"), col("salesman_product_group"), col("month"), col("wk"), (col("target")*col("cum_wk_wt")).alias("NPD_target")).filter(col("KPI")=="NPD Percent"), ["year","salesman_product_group","month","wk"], "left")\
.join(kpi_tgt.select(col("year"), col("salesman_product_group"), col("month"), col("wk"), col("target").alias("avg_time_spent_target")).filter(col("KPI")=="Average Time Spent (In Hrs) per day"), ["year","salesman_product_group","month","wk"], "left").drop("cum_wk_wt")\
.join(kpi_tgt.select(col("year"), col("salesman_product_group"), col("month"), col("wk"), (col("target")).alias("rl_target_monthly")).filter(col("KPI")=="RL Percent"), ["year","salesman_product_group","month","wk"], "left")\
.join(kpi_tgt.select(col("year"), col("salesman_product_group"), col("month"), col("wk"), (col("target")).alias("EB_target_monthly")).filter(col("KPI")=="EB Percent"), ["year","salesman_product_group","month","wk"], "left")\
.join(kpi_tgt.select(col("year"), col("salesman_product_group"), col("month"), col("wk"), (col("target")).alias("cotc_target_monthly")).filter(col("KPI")=="CotC Percent"), ["year","salesman_product_group","month","wk"], "left")\
.join(kpi_tgt.select(col("year"), col("salesman_product_group"), col("month"), col("wk"), (col("target")).alias("wp_target_monthly")).filter(col("KPI")=="WP Percent"), ["year","salesman_product_group","month","wk"], "left")\
.join(kpi_tgt.select(col("year"), col("salesman_product_group"), col("month"), col("wk"), (col("target")*col("cum_wk_wt")).alias("NPD_target_monthly")).filter(col("KPI")=="NPD Percent"), ["year","salesman_product_group","month","wk"], "left")\
.distinct().withColumnRenamed("salesman_product_group", "std_Salesman_Product_Group")


# COMMAND ----------

df_fcs_spg_ini = df_fcs_spg1.union(df_fcs_spg1_inc)

df_fcs_spg = df_fcs_spg_ini.select(col("salesman_code"), col("salesman_product_group"), col("distributor_code"), col("site_code"),\
                                translate(col("sales_target"),",","").cast("bigint").alias("sales_target"),\
                                substring(col("cal_month"),4,4).cast("int").alias("year"),\
                                substring(col("cal_month"),1,2).cast("int").alias("month_num"))\
.withColumn("salesperson_with_target", expr("if(sales_target!=0 or sales_target is not null, 'YES', 'NO')")).distinct()\
.join(df_SPR1.withColumn("month_num", date_format(to_date(col("calender_day"), "dd.MM.yyyy"),'M'))\
      .withColumn("year", substring(col("calender_day"),-4,4))\
      .withColumn("dt", date_format(to_date(col("calender_day"), "dd.MM.yyyy"),'yyyyMMdd'))\
      .withColumn("month_end_dt", expr("max(dt) over(partition by salesman_code, distributor_code, site_code,year,month_num)"))\
      .filter(col("dt")==col("month_end_dt"))\
      .select(["salesman_code", "distributor_code", "site_code","year","month_num","salesman_product_group"]).distinct(),["salesman_code", "distributor_code", "site_code","year","month_num","salesman_product_group"] , "inner")\
#.filter(col("salesman_product_group")==col("month_end_spg")).drop("salesman_product_group").withColumnRenamed("month_end_spg","salesman_product_group")\

# COMMAND ----------

###############################################################

#changed on march 19th 
df_SPGx = df_fcs_spg.select("salesman_code").union(df_efos.select("salesman_code")).distinct()
###############################################################

# COMMAND ----------

###############################################################

#changed on march 19th 
#df_sm_td = df_SPGx.crossJoin(df_td)
df_sm_td = df_SPGx.crossJoin(df_td)

###############################################################
df_sm_spg = df_sm_td.join(df_SPR, on = ["salesman_code","dt","wk"], how = "left")

df_sm_sf = df_sm_spg.join(df_SGM, ["salesman_product_group"], how = "left").filter(expr("salesman_product_group is not null"))

df_kpi_tgt_weekend = df_sm_sf.join(df_kpi_tgt_map, ["year","std_Salesman_Product_Group","month","wk"], "left")\
.withColumn("max_dt", expr("max(dt) over( partition by year,month,wk, salesman_code)")).filter(col("dt")==col("max_dt"))\
.withColumnRenamed("PC_target","weekend_target_PC").withColumnRenamed("total_lines_target","weekend_target_total_lines")\
.select(["weekend_target_PC","weekend_target_total_lines","salesman_code","wk","month","year"]).drop("std_Salesman_Product_Group").distinct()

df_kpi_tgt_join = df_sm_sf.join(df_kpi_tgt_map, ["year","std_Salesman_Product_Group","month","wk"], "left").drop("std_Salesman_Product_Group")\
.withColumn('total_lines_target', col("total_lines_target")*col("trading_days_month"))\
.join(df_kpi_tgt_weekend, ["salesman_code","wk","month","year"])

df_kpi_calc1 = df_kpi_tgt_join.withColumn("PC_target", col("PC_target")*col("trading_day")).withColumn("remaining_target_PC", col("PC_target")*col("trading_days_remaining")).withColumn("weekly_cumulative_PC_target", expr('sum(PC_target) over( partition by salesman_code,month,year order by wk)')).withColumn("PC_target_monthly", col("weekly_cumulative_PC_target")+col("remaining_target_PC")).orderBy("dt")

W1 = Window.partitionBy(["wk", "month", "year", "salesman_code", "country", "salesforce", "distributor_code", "site_code"]).orderBy('dt')

df_kpi_calc1 = df_kpi_calc1.withColumn("dt", min("dt").over(W1))

df_kpi_calc = df_kpi_calc1.withColumn("salesman_product_group", last("salesman_product_group").over(W1))

W = Window.partitionBy(["wk", "month", "year", "salesman_code", "salesman_product_group", "country", "salesforce", "distributor_code", "site_code"]).orderBy('dt')

df_kpi_agg_write = df_kpi_calc\
.withColumn("ECO_target", last("ECO_target").over(W))\
.withColumn("EB_target", last("EB_target").over(W))\
.withColumn("assortment_target", last("assortment_target").over(W))\
.withColumn("4P_target", last("4P_target").over(W))\
.withColumn("wp_target", last("wp_target").over(W))\
.withColumn("geo_target", last("geo_target").over(W))\
.withColumn("non_pc_above_eot_target", last("non_pc_above_eot_target").over(W))\
.withColumn("pjp_target", last("pjp_target").over(W))\
.withColumn("rl_target", last("rl_target").over(W))\
.withColumn("NPD_target", last("NPD_target").over(W))\
.withColumn("rl_target_monthly", last("rl_target_monthly").over(W))\
.withColumn("EB_target_monthly", last("EB_target_monthly").over(W))\
.withColumn("COTC_target_monthly", last("COTC_target_monthly").over(W))\
.withColumn("wp_target_monthly", last("wp_target_monthly").over(W))\
.withColumn("npd_target_monthly", last("npd_target_monthly").over(W))\
.groupBy(["wk", "month", "year", "salesman_code", "salesman_product_group", "country", "salesforce", "distributor_code", "site_code"])\
.agg(min("dt").alias("dt"), \
     sum("trading_day").alias("trading_day"), \
     max("trading_days_month").alias("trading_days_month"), \
     max("cum_days").alias("trading_days_passed"), \
     max("wk_wt").alias("wk_wt"),\
     sum("PC_target").alias("PC_target"),\
     max("kpi_in_scope").alias("kpi_in_scope"),\
     max("trading_days_remaining").alias("trading_days_remaining"), \
     max("ECO_target").alias("ECO_target"), \
     max("EB_target").alias("EB_target"), \
     max("total_lines_target").alias("total_lines_target"), \
     max("assortment_target").alias("assortment_target"), \
     max("4P_target").alias("FourP_target"), \
     max("cotc_target").alias("cotc_target"), \
     max("wp_target").alias("wp_target"), \
     max("geo_target").alias("geo_target"), \
     max("non_pc_above_eot_target").alias("non_pc_above_eot_target"), \
     max("pjp_target").alias("pjp_target"), \
     max("rl_target").alias("RL_target"), \
     max("NPD_target").alias("NPD_target"), \
     max("rl_target_monthly").alias("rl_target_monthly"), \
     max("EB_target_monthly").alias("EB_target_monthly"), \
     max("wp_target_monthly").alias("wp_target_monthly"), \
     max("cotc_target_monthly").alias("cotc_target_monthly"), \
     max("npd_target_monthly").alias("npd_target_monthly"), \
     max("avg_time_spent_target").alias("avg_time_spent_target"), \
     max("weekend_target_PC").alias("weekend_target_PC"), \
     max("remaining_target_PC").alias("remaining_target_PC"), \
     max("weekly_cumulative_PC_target").alias("weekly_cumulative_PC_target"), \
     max("PC_target_monthly").alias("PC_target_monthly")  )\
.withColumn('month_num', date_format(to_date(col('month'), 'MMMMM'), 'MM').cast('int'))

# COMMAND ----------

dbutils.fs.rm("/mnt/adls/EDGE_Analytics/Datalake/temp/temp_KPI/temp_KPI_agg/",True)

# COMMAND ----------

df_kpi_agg_write.repartition(30).write.mode("overwrite").option("header", "true")\
.option("emptyValue", None)\
.option("nullValue", None).parquet("/mnt/adls/EDGE_Analytics/Datalake/temp/temp_KPI/temp_KPI_agg/")

# COMMAND ----------

df_kpi_agg = spark.read.parquet("/mnt/adls/EDGE_Analytics/Datalake/temp/temp_KPI/temp_KPI_agg/")

# COMMAND ----------

df_kpi1 = df_kpi_agg.join(df_efos, ["salesman_code","wk", "month_num", "year", "distributor_code", "site_code"], "left").withColumn("pjp_complied_calls", when(col("trading_day")==0, 0).otherwise(col("pjp_complied_calls")))

df_kpi2 = df_kpi1.join(df_4p, ["salesman_code","distributor_code","site_code","salesman_product_group","year","month_num","wk"], "left")

df_kpi3 = df_kpi2.join(df_fcs, ["salesman_code","distributor_code","site_code","year","wk","month_num"], "left").join(df_SM,["salesman_product_group"],"left").withColumn("key_col", concat(col("site_code"),lit("_"),col("Role_Business_Scope_Assignment")))

df_kpi4 = df_kpi3.join(df_fcs_spg.drop("salesman_product_group"), ["salesman_code","distributor_code","site_code","year","month_num"], "left")

df_kpi5 = df_kpi4.join(df_pa, ["salesman_code","distributor_code","site_code","salesman_product_group","year","wk","month_num"], "left")

df_eot_filter = df_efos2.join(df_kpi_agg.select(col("salesman_code"),col("wk"), col("salesman_product_group"), col("month_num"), col("year"), col("distributor_code"), col("site_code"),col("salesforce"),col("kpi_in_scope")).distinct(), ["salesman_code","wk", "month_num", "year", "distributor_code", "site_code"], "left")\
.join(df_eot, ["salesforce"], how = "left")\
.filter((col("geo_complied_calls")>=col("geo_complied_calls_min"))\
        & (col("geo_complied_calls")<=col("geo_complied_calls_max"))\
        & (col("total_sales_return")>=col("total_sales_return_min"))\
        & (col("total_sales_return")<=col("total_sales_return_max"))\
        & (col("actual_outlet_time")>=col("actual_outlet_time_min"))\
        & (col("actual_outlet_time")<=col("actual_outlet_time_max"))\
        & (col("sku_order")>=col("skus_order_min"))\
        & (col("sku_order")<=col("skus_order_max"))\
        & (col("pjp_complied_calls")==1)\
        & (col("total_sales_return")>0)\
        & (col("kpi_in_scope")=='Y'))

df_eot_roll1 = df_eot_filter.select(["dt", "salesforce", "salesman_product_group", "year","wk","month_num", "rolling_weeks", "actual_outlet_time"]).orderBy( col("salesman_code"), col("salesman_product_group"), col("salesforce"), col("dt"))



# COMMAND ----------

#listing all rolling weeks

rl_wk1 = list(df_eot1.select('rolling weeks').distinct().toPandas()['rolling weeks'])

rl_wk = []

for i in rl_wk1:
  rl_wk.append(i)
  
rl_wk

# COMMAND ----------

#creating a matrix for all dates on all sf, salesman and spg
df_eot_roll_cross = df_td.select(col("dt"), col("wk").cast("int"), col("year")).distinct().crossJoin(df_kpi_agg.select(["salesforce","salesman_product_group"]).distinct()).withColumn("month_num",  substring(col("dt"),-4,2).cast("int")).drop("dt").distinct()

df_eot_roll_cross = df_eot_roll_cross.withColumn("rolling_weeks", lit(rl_wk[0]).cast("int"))
for i in rl_wk[1:]:
  df_eot_roll_cross = df_eot_roll_cross.unionAll(df_eot_roll_cross.withColumn("rolling_weeks", lit(i).cast("int")))


# COMMAND ----------


df_eot_roll = df_eot_roll1.join(df_eot_roll_cross, ["wk","month_num","year","salesforce","salesman_product_group","rolling_weeks"], "full" ).filter(expr("dt is not null")).join(df_td.withColumn("max_wk_last_yr", expr("max(wk) over(partition by year)"))\
.select((col("year")+1).alias("year"), col("max_wk_last_yr")).distinct(), ["year"], "left").withColumn("rolled_weeks", when((col("wk")-col("rolling_weeks"))>0, (col("wk")-col("rolling_weeks"))).otherwise(col("max_wk_last_yr") + (col("wk")-col("rolling_weeks")))).withColumn("rolled_year", when((col("wk")-col("rolling_weeks"))>0, col("year")).otherwise(col("year")-1)).withColumn("yrwk", concat(col("year"),col("wk"))).withColumn("rolled_yrwk", concat(col("year"),col("wk")))


# COMMAND ----------

df_eot_roll_pd = df_eot_roll.select(["wk","year", "salesforce", "salesman_product_group","month_num","yrwk","rolled_yrwk"]).distinct()

# COMMAND ----------

df_eot_roll.createOrReplaceTempView ("t_df_eot_roll")
df_eot_roll_pd.createOrReplaceTempView ("t_df_eot_roll_pd")

# COMMAND ----------


#calculating EOT benchmark

df_eot_fin = spark.sql("select * from (select q2.year, q2.wk, q2.month_num, q2.salesforce, q2.salesman_product_group, percentile_approx(q1.actual_outlet_time, 0.5) EOT_benchmark from t_df_eot_roll q1 join t_df_eot_roll_pd q2  on q1.yrwk <= q2.yrwk  and q1.salesforce = q2.salesforce and q1.salesman_product_group = q2.salesman_product_group and q1.yrwk >= q2.rolled_yrwk group by q2.year, q2.wk, q2.month_num, q2.salesforce, q2.salesman_product_group)")

# COMMAND ----------

df_np_matrix = df_efos2.join(df_sm_sf, ["dt","wk","year","salesman_code","distributor_code","site_code"], "left")

df_np_pjp = df_np_matrix.select(["wk", "month_num", "year", "salesman_code", "pjp_complied_calls", "total_sales_return", "distributor_code", "salesforce","salesman_product_group"]).filter(col("total_sales_return")<=0).drop("total_sales_return").select(["wk", "month_num", "year", "salesman_code", "distributor_code", "salesforce","salesman_product_group","pjp_complied_calls"]).withColumn( "Non_prod_pjp", expr("sum(pjp_complied_calls) over(partition by month_num, year, salesman_code, distributor_code, salesforce,salesman_product_group order by wk)")).drop("pjp_complied_calls").distinct()

df_np_pjp_above_eot = df_np_matrix\
.select(["wk", "month_num", "year", "salesman_code", "total_sales_return", "effective_outlet_time", "distributor_code", "pjp_complied_calls", "salesforce","salesman_product_group"])\
.join(df_eot_fin.select(["wk", "month_num", "year", "salesforce","salesman_product_group", "eot_benchmark"]), ["wk", "month_num", "year", "salesforce","salesman_product_group"], "left")\
.filter((col("total_sales_return")<=0) & (col("effective_outlet_time")>=col("eot_benchmark")))\
.select(["wk", "month_num", "year", "salesman_code", "pjp_complied_calls", "distributor_code", "salesforce","salesman_product_group"]).groupBy(["wk", "month_num", "year", "salesman_code", "distributor_code", "salesforce", "salesman_product_group"]).agg(sum("pjp_complied_calls").alias("Non_prod_pjp_above_eot")).withColumn("Non_prod_pjp_above_eot", expr("sum(Non_prod_pjp_above_eot) over(partition by month_num, year, salesman_code, distributor_code, salesforce, salesman_product_group order by wk)"))

df_kpi_eot_write = df_kpi5.join(df_eot_fin.select(["wk","month_num","salesforce","salesman_product_group","year","EOT_benchmark"]).distinct(), ["wk","month_num","salesforce","salesman_product_group","year"], "left" ).withColumn("EOT_benchmark", when(expr("EOT_benchmark is null"),expr("min(EOT_benchmark) over (partition by wk, month, salesforce, year) ")).otherwise(col("EOT_benchmark")) ).distinct().filter(expr("salesforce is not null"))\
.join(df_np_pjp, ["wk", "month_num", "year", "salesman_code", "distributor_code", "salesforce","salesman_product_group"], "left").join(df_np_pjp_above_eot, ["wk", "month_num", "year", "salesman_code", "distributor_code", "salesforce","salesman_product_group"], "left").withColumn("EOT_benchmark", expr("min(EOT_benchmark) over(partition by year, month_num,wk,salesforce)")).distinct()

# COMMAND ----------

dbutils.fs.rm("/mnt/adls/EDGE_Analytics/Datalake/temp/temp_KPI/temp_KPI_eot/",True)

# COMMAND ----------

df_kpi_eot_write.repartition(30).write.mode("overwrite").option("header", "true")\
.option("emptyValue", None)\
.option("nullValue", None)\
.parquet("/mnt/adls/EDGE_Analytics/Datalake/temp/temp_KPI/temp_KPI_eot/")

# COMMAND ----------

df_kpi_eot = spark.read.parquet("/mnt/adls/EDGE_Analytics/Datalake/temp/temp_KPI/temp_KPI_eot/")

# COMMAND ----------

#adding calculated columns
df_kpi_calc = df_kpi_eot\
.withColumn("week_flag", when(col("wk")==(expr("max(wk) over (partition by month,year)")), lit(1)).otherwise(lit(0)))\
.withColumn("cum_wk_wt", expr("sum(wk_wt) over(partition by month, year, salesman_code, salesman_product_group, country, distributor_code, site_code order by wk)"))\
.withColumn("sales_perc", (col("sales_actual")/col("sales_target"))*100)\
.withColumn("sales_balance_to_hit", col("sales_target")-col("sales_actual"))\
.withColumn("sales_balance_to_hit_daily", col("sales_balance_to_hit")/col("trading_days_remaining"))\
.withColumn("PC_target_month", col("PC")-col("trading_days_month"))\
.withColumn("PC_per_salesperson", col("PC")/col("trading_days_passed"))\
.withColumn("PC_balance_to_hit", col("PC_target_monthly")-col("PC"))\
.withColumn("PC_balance_to_hit_daily", col("PC_balance_to_hit")/col("trading_days_remaining"))\
.withColumn("PJP_compliance", when(col("trading_day")==0,0).otherwise((col("PJP_complied_calls")/col("planned_calls"))*100) )\
.withColumn("geo_compliance", (col("geo_complied_calls")/col("actual_calls"))*100)\
.withColumn("avg_time_spent_daily", (col("effective_outlet_time")/col("trading_days_passed")))\
.withColumn("ECO_perc", (col("eco_actual")/col("active_shop_in_pjp"))*100)\
.withColumn("ECO_balance_to_hit", ((col("ECO_target")/100)*col("active_shop_in_pjp"))-col("eco_actual"))\
.withColumn("total_lines_perc", ((col("total_sku_line")/col("total_lines_target")))*100)\
.withColumn("total_lines_balance_to_hit_month", (col("total_lines_target")-col("total_sku_line")))\
.withColumn("total_lines_balance_to_hit_daily", (col("total_lines_balance_to_hit_month")/col("trading_days_remaining")))\
.withColumn("RL_perc", (col("RL_actual")/col("RL_target_abs"))*100)\
.withColumn("PC_perc", (col("PC")/col("PC_target_monthly"))*100)\
.withColumn("EB_perc", (col("EB_actual")/col("EB_target_abs"))*100)\
.withColumn("WP_perc", (col("WP_actual")/col("WP_target_abs"))*100)\
.withColumn("COTC_perc", (col("COTC_actual")/col("COTC_target_abs"))*100)\
.withColumn("NPD_perc", (col("NPD_actual")/col("NPD_target_abs"))*100)\
.withColumn("FourP_perc", (col("FourP_compliance_outlet")/col("total_outlet_count"))*100)\
.withColumn("Assortment_perc", (col("assortment_achieved")/col("assortment_target_abs"))*100)\
.withColumn("Non_pc_above_eot_perc", (col("Non_prod_pjp_above_eot")/col("Non_prod_pjp"))*100)

# COMMAND ----------

#adding statuses
df_kpi_mid = df_kpi_calc\
.withColumn("PC_balance_to_hit", when(col("PC_balance_to_hit")<0,0)\
            .otherwise(col("PC_balance_to_hit")))\
.withColumn("PC_balance_to_hit_daily", when(col("PC_balance_to_hit_daily")<0,0)\
            .otherwise(col("PC_balance_to_hit_daily")))\
.withColumn("ECO_balance_to_hit", when(col("ECO_balance_to_hit")<0,0)\
            .otherwise(col("ECO_balance_to_hit")))\
.withColumn("total_lines_balance_to_hit_month", when(col("total_lines_balance_to_hit_month")<0,0)\
            .otherwise(col("total_lines_balance_to_hit_month")))\
.withColumn("total_lines_balance_to_hit_daily", when(col("total_lines_balance_to_hit_daily")<0,0)\
            .otherwise(col("total_lines_balance_to_hit_daily")))\
.withColumn("sales_balance_to_hit", when(col("sales_balance_to_hit")<0,0)\
            .otherwise(col("sales_balance_to_hit")))\
.withColumn("sales_balance_to_hit_daily", when(col("sales_balance_to_hit_daily")<0,0)\
            .otherwise(col("sales_balance_to_hit_daily")))\
.withColumn("sales_status", when(col("sales_perc")>=100, lit("Delivered"))\
            .when(col("sales_perc")>=100*col("cum_wk_wt"), lit("On Track")).otherwise(lit("Behind")))\
.withColumn("PC_status", when((col("week_flag")==1) & (col("PC_perc")>=(100*col("cum_wk_wt"))), lit("Delivered"))\
            .otherwise(when(col("PC_perc")>=(100*col("cum_wk_wt")), lit("On Track"))\
            .otherwise(lit("Behind"))))\
.withColumn("PJP_status", when(((col("week_flag")==1) & (col("PJP_compliance")>=col("PJP_target"))), lit("Delivered"))\
            .otherwise(when(col("PJP_compliance")>=col("PJP_target"), lit("On Track"))\
            .otherwise(when((col("PJP_compliance")>=(0.9*col("PJP_target"))) & (col("PJP_compliance")>=col("PJP_target")) ,lit("Temp"))\
            .otherwise("Behind"))))\
.withColumn("Geo_status", when((col("week_flag")==1) & (col("geo_compliance")>=col("geo_target")), lit("Delivered"))\
            .otherwise(when(col("geo_compliance")>=(col("geo_target")), lit("On Track"))\
            .otherwise(lit("Behind"))))\
.withColumn("RL_status", when(col("RL_target_abs")==0, lit("Delivered"))\
            .otherwise(when(col("RL_perc")>=(col("RL_target_monthly")), lit("Delivered"))\
            .otherwise(when(col("RL_perc")>=(col("RL_target")), lit("On Track"))\
            .otherwise(lit("Behind")))))\
.withColumn("avg_time_spent_status", when((col("week_flag")==1) & (col("avg_time_spent_daily")>=col("avg_time_spent_target")), lit("Delivered"))\
            .otherwise(when((col("avg_time_spent_daily")>=(col("avg_time_spent_target"))), lit("On Track"))\
            .otherwise(when((col("avg_time_spent_daily")>=(0.9*col("avg_time_spent_target"))) & (col("avg_time_spent_daily")>=col("avg_time_spent_target")) ,lit("Temp"))\
            .otherwise(lit("Behind")))))\
.withColumn("EB_status", when(col("EB_target_abs")==0, lit("Delivered"))\
            .otherwise(when(col("EB_perc")>=(col("EB_target_monthly")), lit("Delivered"))\
            .otherwise(when(col("EB_perc")>=(col("EB_target")), lit("On Track"))\
            .otherwise(lit("Behind")))))\
.withColumn("WP_status", when(col("WP_target_abs")==0, lit("Delivered"))\
            .otherwise(when(col("WP_perc")>=(col("WP_target_monthly")), lit("Delivered"))\
            .otherwise(when(col("WP_perc")>=(col("WP_target")), lit("On Track"))\
            .otherwise(lit("Behind")))))\
.withColumn("total_lines_status", when((col("week_flag")==1) & (col("total_lines_perc")>=(100*col("cum_wk_wt"))), lit("Delivered"))\
            .otherwise(when(col("total_lines_perc")>=(100*col("cum_wk_wt")), lit("On Track"))\
            .otherwise(lit("Behind"))))\
.withColumn("NPD_status", when(col("NPD_target_abs")==0, lit("Delivered"))\
            .otherwise(when(col("NPD_perc")>=(col("NPD_target_monthly")), lit("Delivered"))\
            .otherwise(when(col("NPD_perc")>=(col("NPD_target")), lit("On Track"))\
            .otherwise(lit("Behind")))))\
.withColumn("Assortment_status", when(col("Assortment_perc")>=col("Assortment_target"), lit("Delivered"))\
            .otherwise(lit("Behind")))\
.withColumn("COTC_status", when(col("COTC_perc")>=(col("COTC_target_monthly")), lit("Delivered"))\
            .otherwise(when(col("COTC_perc")>=(col("COTC_target")), lit("On Track"))\
            .otherwise(lit("Behind"))))\
.withColumn("FourP_status", when(col("FourP_perc")>=col("FourP_target"), lit("Delivered"))\
            .otherwise("Behind"))\
.withColumn("ECO_status", when(col("ECO_perc")>=col("ECO_target"), lit("Delivered"))\
            .otherwise("Behind"))\
.withColumn("non_PC_above_eot_status",when((col("week_flag")==1) & (col("Non_pc_above_eot_perc")>=col("non_pc_above_eot_target")), lit("Delivered"))\
            .otherwise(when(col("Non_pc_above_eot_perc")>=(col("non_pc_above_eot_target")), lit("On Track"))\
            .otherwise(lit("Behind"))))\
.drop("month_num")\
.drop("RL_target_monthly")\
.drop("eb_target_monthly")\
.drop("wp_target_monthly")\
.drop("cotc_target_monthly")\
.drop("npd_target_monthly")

# COMMAND ----------

df_kpi = df_kpi_mid.withColumn("recommendation_id", expr("if(Sales_Status in ('On Track','Delivered'),\
                               if(ECO_status in ('On Track','Delivered') and\
                                        PC_Status in ('On Track','Delivered') and\
                                        RL_Status in ('On Track','Delivered') and\
                                        EB_Status in ('On Track','Delivered') and\
                                        FourP_status in ('On Track','Delivered') and\
                                        Geo_Status in ('On Track','Delivered'),1\
                                      ,2),\
                               if(PC_Status in ('On Track','Delivered'),\
                                      if(total_lines_status in ('On Track','Delivered'),\
                                             8,\
                                             if((RL_Status  in ('On Track','Delivered') and EB_Status  in ('On Track','Delivered')),\
                                                    if(WP_Status in ('On Track','Delivered'),\
                                                           if(NPD_Status in ('On Track','Delivered'),14,13),12),\
                                                    if((RL_Status  in ('Behind') and EB_Status  in ('Behind')),11,\
                                                           if(RL_Status  in ('Behind'),9,10)))),\
                                      if(PJP_Status in ('On Track','Delivered','temp'),\
                                             if(avg_time_spent_status in ('On Track','Delivered','Temp'),\
                                                    if(Geo_Status in ('On Track','Delivered'),\
                                                           if(non_pc_above_eot_perc in ('On Track','Delivered'),7,6),\
                                                           5),\
                                                    4),\
                                             3)\
                               )\
                        )"))\
.withColumn("issue_type", expr("if(Recommendation_Id = 1 ,'No Issue',\
                                           if(Recommendation_Id in (3,4,5,6),'Disciplinary',\
                                                  if(Recommendation_Id in (7,8),'Capability',\
                                                         if(Recommendation_Id in (9,10,11,12,13),'IQ','Planning'))))"))\
.withColumn("performance", expr("if(sales_target > 0 and Sales_Status in ('On Track','Delivered'),'Top',\
                                             if((Sales_Target <= 0 or Sales_Target is null) and\
                                                      PC_Status  in ('On Track','Delivered'),'Top','Bottom'))"))\
.withColumn("PJP_status", when(col("PJP_status")=="Temp","Behind").otherwise(col("PJP_status")))\
.withColumn("avg_time_spent_status", when(col("avg_time_spent_status")=="Temp","Behind").otherwise(col("avg_time_spent_status")))

# COMMAND ----------

from datetime import datetime
update_dt = datetime.today().strftime('%Y/%m/%d/')

# COMMAND ----------

dbutils.fs.rm("/mnt/adls/EDGE_Analytics/Datalake/Transformed/Transactional/Fact_KPI/",True)

# COMMAND ----------


update_dt
file=("/mnt/adls/EDGE_Analytics/Datalake/Transformed/Transactional/Fact_KPI/"+update_dt)
df_kpi.write.mode("overwrite").option("header", "true")\
.option("emptyValue", None)\
.option("nullValue", None).csv(file)

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC select current_timestamp()

# COMMAND ----------

df_output=spark.read.csv(file,header=True)

# COMMAND ----------

df_output.createOrReplaceTempView('kpi_tbl')

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC select count(1) from kpi_tbl