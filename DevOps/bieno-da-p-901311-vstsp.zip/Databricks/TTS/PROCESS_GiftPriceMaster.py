# Databricks notebook source
import pandas as pd
import numpy as np
from pyspark.sql import types
from pyspark.sql.functions import col

pathGiftPriceMaster="dbfs:/mnt/adls/TTS/raw/monthly/gift_price_master/"
pathPRCGiftPriceMaster='dbfs:/mnt/adls/TTS/processed/references/ref_gift_price_master'

#reading the latest gift price master from the raw layer in adls
yearGPM = str(max([int(i.name.replace('/','')) for i in dbutils.fs.ls(pathGiftPriceMaster)]))
monthGPM= str(max([int(i.name.replace('/','')) for i in dbutils.fs.ls(pathGiftPriceMaster +"/" +str(yearGPM))])).zfill(2)

# fileName=dbutils.fs.ls(pathGiftPriceMaster+"/"+"2020"+"/"+"12"+"/")[0].name

# COMMAND ----------

gift_price_master= spark.read.option("header", True).option("inferSchema",True).csv(pathGiftPriceMaster+yearGPM+"/"+monthGPM+"/")
gift_price_master.createOrReplaceTempView("gift_price_master")

gift_price_masterDF=spark.sql("""select 
                                  scheme_id,
                                  name,
                                  item_code,
                                  item_name,
                                  cast(replace(`PRICE (VND)`,',','') as double) price_vnd
                                 from gift_price_master
                              """)
# for j in range(1,12):
#   monthGPM_dummy= str(max([int(i.name.replace('/','')) for i in dbutils.fs.ls(pathGiftPriceMaster +"/" +str(yearGPM))])-j).zfill(2)
#   gift_price_masterDF.write.mode("overwrite").parquet(pathPRCGiftPriceMaster+"/"+yearGPM+"/"+monthGPM_dummy+"/")

gift_price_masterDF.write.mode("overwrite").parquet(pathPRCGiftPriceMaster+"/"+yearGPM+"/"+monthGPM+"/")

# COMMAND ----------

