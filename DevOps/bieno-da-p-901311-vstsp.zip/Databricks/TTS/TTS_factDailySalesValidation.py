# Databricks notebook source
from pyspark.sql.functions \
import col, date_format, unix_timestamp, from_unixtime, date_sub

# COMMAND ----------

yearID= int(dbutils.widgets.get("ProcessingYear"))
monthID= int(str(yearID) +dbutils.widgets.get("ProcessingMonth"))

# COMMAND ----------

deltaMthlyAggPath   = "/mnt/adls/TTS/transformed/aggregates/fact_monthly_sales_agg"
deltaPath    = "/mnt/adls/EDGE_Analytics/Datalake/Transformed/Transactional/fact_daily_sales/"

# COMMAND ----------

# MAGIC %run /Shared/TTS/GET_SiteAndDistributorDT

# COMMAND ----------

DSSdata=spark.read.format('delta').load(deltaPath)
DSSdata.createOrReplaceTempView("fact_daily_sales")

dssRawDFDT = spark.sql("select dss.* "+
                       "from fact_daily_sales dss "+
                       "inner join list_site dt "+
                       "on dss.transactional_site_code = dt.site_code where product_code not like '75%' ")
dssRawDFDT.createOrReplaceTempView('daily_sales')


# reading the dss agg data for the processing month
DSSdataAgg=spark.read.format('delta').load(deltaMthlyAggPath)
DSSdataAgg.createOrReplaceTempView('dss_monthly_agg')

# COMMAND ----------

ExceptionDSSAgg=spark.sql("""select 
                              trn.transactional_outlet_code,
                              trn.transactional_site_code,
                              trn.transactional_distributor_code,
                              trn.product_code,
                              (nvl(agg.gross_sales_val,0)-nvl(trn.gross_sales_val,0)) delta_gross_sales_val,
                              (nvl(agg.gross_sales_val_mn,0)-nvl(trn.gross_sales_val_mn,0)) delta_gross_sales_val_mn,
                              (nvl(agg.net_invoice_val,0)-nvl(trn.net_invoice_val,0)) delta_net_invoice_val,
                              (nvl(agg.gross_sales_return_val,0)-nvl(trn.gross_sales_return_val,0)) delta_gross_sales_return_val,
                              (nvl(agg.sales_return_val,0)-nvl(trn.sales_return_val,0)) delta_sales_return_val,
                              (nvl(agg.on_invoice_discount_val,0)-nvl(trn.on_invoice_discount_val,0)) delta_on_invoice_discount_val,
                              (nvl(agg.value_added_tax,0)-nvl(trn.value_added_tax,0)) delta_value_added_tax,
                              (nvl(agg.off_inv_discount_val,0)-nvl(trn.off_inv_discount_val,0)) delta_off_inv_discount_val,
                              (nvl(agg.turn_over_val,0)-nvl(trn.turn_over_val,0)) delta_turn_over_val,
                              (nvl(agg.sales_with_return_pc_qty,0)-nvl(trn.sales_with_return_pc_qty,0)) delta_sales_with_return_pc_qty,
                              (nvl(agg.sales_return_pc_qty,0)-nvl(trn.sales_return_pc_qty,0)) delta_sales_return_pc_qty,
                              (nvl(agg.sales_pc_qty,0)-nvl(trn.sales_pc_qty,0)) delta_sales_pc_qty,
                              (nvl(agg.sales_cs_vol,0)-nvl(trn.sales_cs_vol,0)) delta_sales_cs_vol,
                              (nvl(agg.sales_lt_vol,0)-nvl(trn.sales_lt_vol,0)) delta_sales_lt_vol,
                              (nvl(agg.sales_kg_vol,0)-nvl(trn.sales_kg_vol,0)) delta_sales_kg_vol,
                              (nvl(agg.free_pc_qty,0)-nvl(trn.free_pc_qty,0)) delta_free_pc_qty
                              from 
                              (select 
                              transactional_outlet_code,
                              transactional_site_code,
                              transactional_distributor_code,
                              product_code,
                              round(sum(gross_sales_val),3) as gross_sales_val,
                              round(sum(gross_sales_val_mn),3) as gross_sales_val_mn,
                              round(sum(net_invoice_val),3) as net_invoice_val,
                              round(sum(gross_sales_return_val),3) as gross_sales_return_val,
                              round(sum(sales_return_val),3) as sales_return_val,
                              round(sum(on_invoice_discount_val),3) as on_invoice_discount_val,
                              round(sum(value_added_tax),3) as value_added_tax,
                              round(sum(off_inv_discount_val),3) as off_inv_discount_val,
                              round(sum(turn_over_val),3) as turn_over_val,
                              sum(sales_with_return_pc_qty) as sales_with_return_pc_qty,
                              sum(sales_return_pc_qty) as sales_return_pc_qty,
                              sum(sales_pc_qty) as sales_pc_qty,
                              round(sum(sales_cs_vol),3) as sales_cs_vol,
                              round(sum(sales_kg_vol),3) as sales_kg_vol,
                              round(sum(sales_lt_vol),3) as sales_lt_vol,
                              sum(free_pc_qty) as free_pc_qty
                              from dss_monthly_agg where month_id={} and year_id={} group by
                              transactional_outlet_code,
                              transactional_site_code,
                              transactional_distributor_code,
                              product_code) agg
                              full outer join
                              (select 
                              transactional_outlet_code,
                              transactional_site_code,
                              transactional_distributor_code,
                              product_code,
                              round(sum(gross_sales_val),3) as gross_sales_val,
                              round(sum(gross_sales_val_mn),3) as gross_sales_val_mn,
                              round(sum(net_invoice_val),3) as net_invoice_val,
                              round(sum(gross_sales_return_val),3) as gross_sales_return_val,
                              round(sum(sales_return_val),3) as sales_return_val,
                              round(sum(on_invoice_discount_val),3) as on_invoice_discount_val,
                              round(sum(value_added_tax),3) as value_added_tax,
                              round(sum(off_inv_discount_val),3) as off_inv_discount_val,
                              round(sum(turn_over_val),3) as turn_over_val,
                              sum(sales_with_return_pc_qty) as sales_with_return_pc_qty,
                              sum(sales_return_pc_qty) as sales_return_pc_qty,
                              sum(sales_pc_qty) as sales_pc_qty,
                              round(sum(sales_cs_vol),3) as sales_cs_vol,
                              round(sum(sales_kg_vol),3) as sales_kg_vol,
                              round(sum(sales_lt_vol),3) as sales_lt_vol,
                              sum(free_pc_qty) as free_pc_qty
                              from daily_sales where month_id={} and year_id={} group by 
                              transactional_outlet_code,
                              transactional_site_code,
                              transactional_distributor_code,
                              product_code) trn
                              on agg.transactional_outlet_code=trn.transactional_outlet_code
                              and agg.transactional_site_code=trn.transactional_site_code
                              and agg.transactional_distributor_code=trn.transactional_distributor_code
                              and agg.product_code=trn.product_code""".format(monthID,yearID,monthID,yearID))
ExceptionDSSAgg.createOrReplaceTempView("exception_dss_agg")

# COMMAND ----------

exceptionDSSAggVal=spark.sql("""select * from exception_dss_agg
                                where    ( abs(delta_gross_sales_val)>1 or
                                              abs(delta_gross_sales_val_mn)>1 or
                                              abs(delta_net_invoice_val)>1 or
                                              abs(delta_gross_sales_return_val)>1 or
                                              abs(delta_sales_return_val)>1 or
                                              abs(delta_on_invoice_discount_val)>1 or
                                              abs(delta_value_added_tax)>1 or
                                              abs(delta_off_inv_discount_val)>1 or
                                              abs(delta_turn_over_val)>1 or
                                              abs(delta_sales_with_return_pc_qty)>1 or
                                              abs(delta_sales_return_pc_qty)>1 or
                                              abs(delta_sales_pc_qty)>1 or
                                              abs(delta_sales_cs_vol)>1 or
                                              abs(delta_sales_lt_vol)>1 or
                                              abs(delta_sales_kg_vol)>1 or
                                              abs(delta_free_pc_qty)>1)""")

if(exceptionDSSAggVal.count()>0):
  raise Exception ("Exception: DSS daily not matching with DSS monthly aggregate")
else :
  print("DSS daily matching with DSS monthly aggregate")

# COMMAND ----------

