-- Databricks notebook source
CREATE DATABASE IF NOT EXISTS edge LOCATION '/mnt/adls/EDGEDB';