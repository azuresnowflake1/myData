Use this folder to add a triggers.csv file that lists the triggers you want to stop before an ADF deployment and start after an ADF deployment.
File must be named triggers.csv