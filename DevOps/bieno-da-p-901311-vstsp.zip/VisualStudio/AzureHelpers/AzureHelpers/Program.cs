﻿using com.unilever.ina;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AzureHelpers
{
    class Program
    {
        static int Main(string[] args)
        {
            var helper = new KeyVaultHelper();
            // Get the clientId from the parameter file so we can look up the client secret
            String clientId = helper.ParameterFile.parameters.adApplicationName.value;

            Task.Run(async () =>
            {
                string secret = await helper.RetrieveSecretAsync(clientId);
                Console.WriteLine(secret);
            
            }).GetAwaiter().GetResult();

            Console.WriteLine("Execute custom activity complete.");
            //Console.ReadLine();
            return 0;
        }
    }
}
