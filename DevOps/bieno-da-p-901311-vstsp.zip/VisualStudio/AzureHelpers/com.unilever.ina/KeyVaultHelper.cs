﻿using Microsoft.Azure.KeyVault;
using Microsoft.Azure.KeyVault.Models;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace com.unilever.ina
{
    /// <summary>
    /// Access keyvault using your application SPN credential
    /// </summary>
    /// <remarks>For this to work the SPN self signed certificate must be installed in your batch pool in cert store "My" and location "currentuser".
    /// The standard CI pipeline does this when the batch account is provisioned</remarks>
    public class KeyVaultHelper
    {
        /// <summary>
        /// You must deploy the correct parameter file with your custom activity.  Rename it to parameters.json.
        /// </summary>
        private string _parameterFileName = "parameters.json";
        private string _thumbPrint = "";
        private string _clientId = "";
        private string _akvBaseUrl = "";
        dynamic _params;
        private X509Certificate2 _cert;

        public KeyVaultHelper()
        {
            _params = GetParameterFile();
            _clientId = _params.parameters.applicationId.value;
            _thumbPrint = _params.parameters.applicationCertThumprint.value;
            _akvBaseUrl = string.Format("https://{0}.vault.azure.net/", _params.parameters.keyVaultName.value);
            _cert = FindCertificateByThumbprint(_thumbPrint);
        }

        /// <summary>
        /// The name of the environment parameter file.  Defaults to parameters.json.
        /// </summary>
        /// <remarks>You must deploy the correct parameter file from \DevOps\Projects folder and rename to the value specified here. </remarks>
        public string ParameterFileName
        {
            get { return _parameterFileName; }
        }
        /// <summary>
        /// Get the parameter file as a dynamic in memory object. You can access parameter values like this: {variable}.parameters.subscriptionId.value (i.e. for subscriptionId);
        /// </summary>
        public dynamic ParameterFile { 
            get {
                if (_params == null)
                {
                    _params = GetParameterFile();
                    _clientId = _params.parameters.applicationId.value;
                    _thumbPrint = _params.parameters.applicationCertThumprint.value;
                }
                return _params;
            }
        }
        /// <summary>
        /// Load the json parameter file into memory.  
        /// </summary>
        /// <returns></returns>
        private dynamic GetParameterFile()
        {
            dynamic paramFile = JValue.Parse(File.ReadAllText(_parameterFileName));
            return paramFile;
        }
        /// <summary>
        /// Retreive a secret from key vault
        /// </summary>
        /// <param name="secretName"></param>
        /// <returns></returns>
        public async Task<string> RetrieveSecretAsync(string secretName)
        {
            
            var assertionCert = new ClientAssertionCertificate(_clientId, _cert);
            var kvClient = new KeyVaultClient(new KeyVaultClient.AuthenticationCallback(async (authority, resource, scope) =>
            {
                var context = new AuthenticationContext(authority, TokenCache.DefaultShared);

                var result = await context.AcquireTokenAsync(resource, assertionCert);
                return result.AccessToken;
            }));
            
            SecretBundle secretBundle = await kvClient.GetSecretAsync(_akvBaseUrl, secretName);
            return secretBundle != null ? secretBundle.Value : null;
        }
        /// <summary>
        /// Look in the certificate store My CurrentUser for the specified thumprint.
        /// </summary>
        /// <param name="thumbprint"></param>
        /// <returns></returns>
        private static X509Certificate2 FindCertificateByThumbprint(string thumbprint)
        {
            X509Store store = null;
            try
            {
                store = new X509Store(StoreName.My, StoreLocation.CurrentUser);
                store.Open(OpenFlags.ReadOnly);
                X509Certificate2Collection certCollection = store.Certificates.Find(X509FindType.FindByThumbprint, thumbprint, false);

                if (certCollection == null || certCollection.Count == 0)
                {
                    Console.WriteLine("The certificate with thrumprint: {0} was not found in the certificate store.", thumbprint ?? "null");
                    Console.Error.WriteLine("The certificate with thrumprint: {0} was not found in the certificate store.", thumbprint ?? "null");
                    return null;
                } else
                      return certCollection[0];
            }
            finally
            {
                if (store != null)
                {
                    store.Close();
                }
            }
        }
    }
}
