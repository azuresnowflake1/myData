using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Azure.Services.AppAuthentication;
using Microsoft.Azure.KeyVault;
using Microsoft.AnalysisServices.Tabular;
using System;
using Newtonsoft.Json;
using System.Text;
using Microsoft.Extensions.Configuration;

namespace ProcessTabularModel
{
    public static class ProcessModel
    {
        [FunctionName("ProcessModel")]
        public static async Task<HttpResponseMessage> Run([HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = null)]HttpRequestMessage req, TraceWriter log, ExecutionContext context)
        {
            log.Info("HTTP trigger function called to ProcessModel.");

            string appId, appKey, connectionString = null;
            Microsoft.AnalysisServices.Tabular.Server asSrv;
            Microsoft.AnalysisServices.Tabular.Database db;
            Model model;

            /************** parse query parameter *******************/
            string name = req.GetQueryNameValuePairs().FirstOrDefault(q => string.Compare(q.Key, "name", true) == 0).Value;

            if (name == null)
            {
                // Get request body
                dynamic data = await req.Content.ReadAsAsync<object>();
                name = data?.name;
            }

            /************** Using ConfigurationBuilder for Azure Functions v2 runtime *******************/
            var config = new ConfigurationBuilder()
             .SetBasePath(context.FunctionAppDirectory)
             .AddJsonFile("parameters.json", optional: true, reloadOnChange: true)
             .AddEnvironmentVariables()
             .Build();

            /************** Get parameter values *******************/
            ProcessModelParameters processModelParameters = new ProcessModelParameters
            {
                analysisServicesUrl = config["parameters:analysisServicesUrl:value"],
                keyVaultUrl = config["parameters:keyVaultURL:value"],
                appKeySecret = config["parameters:appKeySecret:value"],
                tabularModelName = name
            };
            appId = config["parameters:appId:value"];

            /************** Read the secret value from KeyVault 
            var azureServiceTokenProvider = new AzureServiceTokenProvider();
            var keyVaultClient = new KeyVaultClient(new KeyVaultClient.AuthenticationCallback(azureServiceTokenProvider.KeyVaultTokenCallback));

            var secretBundle = await keyVaultClient.GetSecretAsync(processModelParameters.keyVaultUrl + "secrets/" + processModelParameters.appKeySecret).ConfigureAwait(false);
            appKey = secretBundle.Value;

            connectionString = "Provider=MSOLAP;Data Source=" + processModelParameters.analysisServicesUrl + "; User ID=app:" + appId + "; Password=" + appKey;*******************/

            /*************** Process the model
            try
            {
                asSrv = new Microsoft.AnalysisServices.Tabular.Server();
                asSrv.Connect(connectionString);
                db = asSrv.Databases[name];
                model = db.Model;

                //db.Model.Tables["Table"].RequestRefresh(RefreshType.Full);//mark one table to refresh
                //db.Model.Tables["Table"].Partitions["Bucket1"].RequestRefresh(RefreshType.Full);//mark one partitions to refresh
                db.Model.RequestRefresh(RefreshType.Full);//mark the model to refresh
                db.Model.SaveChanges();//commit  which will execute the refresh
                asSrv.Disconnect();
            }
            catch (Exception e)
            {
                log.Info($"Exception: {e.ToString()}");
                processModelParameters.errorMessage = e.ToString();
            } ***************/

            var json = JsonConvert.SerializeObject(processModelParameters, Formatting.Indented);

            return processModelParameters.errorMessage == null
                ? new HttpResponseMessage(HttpStatusCode.OK)
                {
                    Content = new StringContent(json, Encoding.UTF8, "application/json")
                }
                : new HttpResponseMessage(HttpStatusCode.BadRequest)
                {
                    Content = new StringContent(json, Encoding.UTF8, "application/json")
                };
        }
    }
}

public class ProcessModelParameters
{
    public string analysisServicesUrl { get; set; }
    public string tabularModelName { get; set; }
    public string keyVaultUrl { get; set; }
    public string appKeySecret { get; set; }
    public string errorMessage { get; set; }
}