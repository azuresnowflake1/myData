Param
(
    [Parameter(Mandatory = $True, HelpMessage = 'Specify the parameter file')]
    [String]$parameterFile,

    [Parameter(HelpMessage = 'Specify to configue the Azure Data Lake store')]
    [Switch]$ADLStore
)
# Used to create a linked service that uses the deployment SPN credentials.
# Required so that ADF can spin up components on demand
$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

$subscriptionId = $parameters.parameters.subscriptionId.value

Function New-TemporaryFile() {
    return [System.IO.Path]::GetTempFileName()
}


Function CreateAdlsLinkedService {
    $adlStoreResourceGroupName = $parameters.parameters.adlStoreResourceGroupName.value 
    $adlStoreName = $parameters.parameters.adlStoreName.value

    $sourcePath = "$devOpsProjectFolder\DataFactoryV2\adlstore.json"
    $adlsLinkedService = Get-Content -Path $sourcePath -Raw | ConvertFrom-JSON

    $dataLakeStoreUri = "adl://{0}.azuredatalakestore.net/" -f $adlStoreName    
    $tenantDomainName = $parameters.parameters.tenantDomainName.value

    $appApplicationId = $parameters.parameters.deploymentApplicationId.value
    $linkServiceName = $parameters.parameters.dataLakeStoreLinkedServiceName.value + "Deploy"
    $appServicePrincipalId = $parameters.parameters.deploymentServicePrincipalId.value
    $keyVaultName = $parameters.parameters.keyVaultName.value
    $secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $appApplicationId
    $appClientSecretText = $secret.SecretValueText
    $adlStoreResourceGroupName = $parameters.parameters.adlStoreResourceGroupName.value
    $adlsLinkedService.name = $linkServiceName
    $adlsLinkedService.properties.typeProperties.dataLakeStoreUri = $dataLakeStoreUri
    $adlsLinkedService.properties.typeProperties.servicePrincipalId = $appApplicationId
    $adlsLinkedService.properties.typeProperties.servicePrincipalKey.value = $appClientSecretText 
    $adlsLinkedService.properties.typeProperties.tenant = $tenantDomainName
    $adlsLinkedService.properties.typeProperties.subscriptionId = $subscriptionId
    $adlsLinkedService.properties.typeProperties.resourceGroupName = $adlStoreResourceGroupName

    $destinationPath = New-TemporaryFile
    Write-Verbose "Writing $destinationPath with link service details"

    $adlsLinkedService | ConvertTo-JSON -Depth 10 | Out-File -filepath $destinationPath -Force
    return $destinationPath
}

# Create Linked Services
$dataFactoryResourceGroupName = $parameters.parameters.dataFactoryResourceGroupName.value 
$dataFactoryName = $parameters.parameters.dataFactoryName.value

$df = Get-AzDataFactoryV2 -ResourceGroupName $dataFactoryResourceGroupName -Name $dataFactoryName -ErrorAction SilentlyContinue
if ($df -eq $null) {
    throw "Data Factory does not exist. Please create it first."
}

if ($ADLStore) {
    Write-Verbose $dataFactoryName
    Write-Verbose "Generating Azure Data Lake Store linked service configuration"
    $tempAdlsConfigFile = CreateAdlsLinkedService
    Write-Verbose "Creating Data Lake Store linked service configuration"    
    $depl = Set-AzDataFactoryV2LinkedService -ResourceGroupName  $dataFactoryResourceGroupName `
    -DataFactoryName $dataFactoryName -Name "AzureDataLakeStoreDeploy" -DefinitionFile $tempAdlsConfigFile -Force
}

