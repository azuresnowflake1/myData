Param 
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$parameterFile,
    
    [Parameter(Mandatory = $False, HelpMessage='Optional.  Specify this if you want to disable the firewall')]
    [switch]$Disable,

    [Parameter(Mandatory = $False, HelpMessage='Optional.  Specify this if you want to disable access from PBI.com')]
    [switch]$DisablePowerBI

)
# Enable or disable the SSAS firewall.

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

& "$utilitiesFolder\Test-Login.ps1"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile
$resourceGroupName = $parameters.parameters.analysisServicesResourceGroupName.value
$analysisServicesName = $parameters.parameters.analysisServicesName.value
$storageAccountName = $parameters.parameters.storageAccountName.value
$storageResourceGroupName = $parameters.parameters.storageAccountResourceGroupName.value

# Get the AnalysisServices resource properties
$resource = Get-AzResource `
    -ResourceGroupName $resourceGroupName `
    -ResourceType "Microsoft.AnalysisServices/servers" `
    -ResourceName $analysisServicesName

$props = $resource.Properties

$keys = Get-AzStorageAccountKey `
-StorageAccountName $storageAccountName `
-ResourceGroupName $storageResourceGroupName

# Use first key.
$key = $keys[0].Value

# Create an Azure Storage Context for the storage account.
$context = New-AzStorageContext -StorageAccountName $storageAccountName -StorageAccountKey $key
$starTime = (Get-Date).AddMinutes(-5)
$sasToken = New-AzStorageContainerSASToken `
    -Name $analysisServicesName `
    -Context $context `
    -ExpiryTime $starTime.AddYears(2) `
    -Permission rwdlac `
    -Protocol HttpsOnly `
    -StartTime $starTime
    
    
$backupBlobContainerUri = $props.backupBlobContainerUri
$backupBlobContainerUri = $backupBlobContainerUri + $sasToken

$props.backupBlobContainerUri = $backupBlobContainerUri

# To turn the firewall on we must add a property called ipV4FirewallSettings
# To turn it off we delete the property.
$firewall = '{"firewallRules": [], "enablePowerBIService": true}'
if ($DisablePowerBI) {
    $firewall = '{"firewallRules": [], "enablePowerBIService": false}'
}
$fireWallProps = ConvertFrom-JSON -InputObject $firewall

if ($Disable)
{
    if (-Not ($props.PSobject.Properties.name -contains "ipV4FirewallSettings"))
    { 
        Write-Output "Analysis services firewall on $analysisServicesName is already disabled."
        return
    }
    else {
        Write-Output "Disabling analysis services firewall on $analysisServicesName"
        $props.psobject.properties.remove('ipV4FirewallSettings')
    }
    
}
else {
    if ($props.PSobject.Properties.name -contains "ipV4FirewallSettings")
    { 
        Write-Output "Analysis services firewall on $analysisServicesName is already enabled."
        return
    } else {
        Write-Output "Enabling analysis services firewall on $analysisServicesName"
        $props | Add-Member -NotePropertyName "ipV4FirewallSettings" -NotePropertyValue $fireWallProps
    }
    
}
Set-AzResource `
    -PropertyObject $props `
    -ResourceGroupName $resourceGroupName `
    -ResourceType "Microsoft.AnalysisServices/servers" `
    -ResourceName $analysisServicesName `
    -Force