Param
(
    [Parameter(Mandatory = $True, HelpMessage = 'Specify the parameter file')]
    [String]$parameterFile,

    [Parameter(HelpMessage = 'Specify to configue the storage account')]
    [Switch]$Storage,

    [Parameter(HelpMessage = 'Specify to configue the shared UDL storage account')]
    [Switch]$Sharedstorage,

    [Parameter(HelpMessage = 'Specify to configue the sql database')]
    [Switch]$SqlDb,

    [Parameter(HelpMessage = 'Specify to configue the sql data warehouse')]
    [Switch]$SqlDW,

    [Parameter(HelpMessage = 'Specify to configue the batch account')]
    [Switch]$Batch,

    [Parameter(HelpMessage = 'Specify to configure SSIS')]
    [Switch]$SSIS,

    [Parameter(HelpMessage = 'Specify to configue the Azure Data Lake store gen2')]
    [Switch]$ADLStore,

    [Parameter(HelpMessage = 'Specify to configue the Azure Data Lake store gen1')]
    [Switch]$ADLStoreGen1,

    [Parameter(HelpMessage = 'Specify to configue the Product Specific Landing Azure Data Lake store')]
    [Switch]$PSLZADLStore,
    
    [Parameter(HelpMessage = 'Specify to configue the Azure Data Lake store')]
    [Switch]$sharedADLStore,

    [Parameter(HelpMessage='Specify to configure the Azure Data Lake Analytics')]
    [Switch]$ADLAnalytics,

    [Parameter(HelpMessage = 'Specify to configue the on prem file server linked service')]
    [Switch]$OnPremFileServer,

    [Parameter(HelpMessage = 'Specify to configue the on sftp server linked service')]
    [Switch]$Sftp,

    [Parameter(HelpMessage = 'Specify to configue the linked service for keyvault')]
    [Switch]$KeyVault,

    [Parameter(HelpMessage = 'Specify to configue the linked service for FTP')]
    [Switch]$ftp,

    [Parameter(HelpMessage = 'Specify to configue the shared self hosted IR')]
    [Switch]$sharedSelfHostedIR,

    [Parameter(HelpMessage = 'Specify to configue the seed data location')]
    [Switch]$SeedDataStore,

    [Parameter(HelpMessage = 'Specify to configue the storage account using the storage account key')]
    [Switch]$StorageWithKey

)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

$subscriptionId = $parameters.parameters.subscriptionId.value
$tenantId = $parameters.parameters.tenantId.value
$secretExpiryYears = $parameters.parameters.keyVaultSecretExpiryTerm.value
$devBootStrap = Get-BootStrap -SubscriptionNumber $Global:CtxBootStrap.SubscriptionNumberDev

Function New-TemporaryFile() {
    return [System.IO.Path]::GetTempFileName()
}

Function CreateSqlLinkedService {
    param
    (
        # Parameter help description
        [String]$databaseName,
        [String]$type,
        [String]$name
    )
   
    if($type -eq "AzureSqlDatabase") {
        $sourcePath = "$devOpsProjectFolder\DataFactoryV2\sql.json"
    }
    else {
        $sourcePath = "$devOpsProjectFolder\DataFactoryV2\sqlDw.json"
    }
    
    $sinkSqlLinkedService = Get-Content -Path $sourcePath -Raw | ConvertFrom-JSON
    $sqlServerName = $parameters.parameters.sqlServerName.value
    $sqlSelfHostedIRName = $parameters.parameters.sqlSelfHostedIRName.value

    $connectionString = "Data Source=tcp:{0}.database.windows.net,1433;Initial Catalog={1};Integrated Security=False;Encrypt=True;Connect Timeout=30" `
        -f $sqlServerName, $databaseName
    $sinkSqlLinkedService.properties.typeProperties.connectionString = $connectionString
    $sinkSqlLinkedService.name = $name
    $sinkSqlLinkedService.properties.type = $type
    if($type -eq "AzureSqlDatabase") {
            $sinkSqlLinkedService.properties.typeProperties.servicePrincipalId = $parameters.parameters.applicationId.value
            $sinkSqlLinkedService.properties.typeProperties.servicePrincipalKey.store.referenceName = $parameters.parameters.keyVaultLinkedServiceName.value
            $sinkSqlLinkedService.properties.typeProperties.servicePrincipalKey.secretName = $parameters.parameters.adApplicationName.value
    }
    $sinkSqlLinkedService.properties.typeProperties.tenant = $parameters.parameters.tenantId.value

    if ([string]::IsNullOrEmpty($sqlSelfHostedIRName)) {
        # The link must use the default hosted integration runtime.  To do this we must remove the
        # properties.connectVia value from the object.
        $obj1 = $sinkSqlLinkedService.properties | Select-Object type,typeProperties
        $sinkSqlLinkedService.properties = $obj1
    } else {
        $sinkSqlLinkedService.properties.connectVia.referenceName = $sqlSelfHostedIRName
    }
    $destinationPath = New-TemporaryFile
    Write-Verbose "Writing $destinationPath with link service details"
    $sinkSqlLinkedService | ConvertTo-JSON -Depth 10 | Out-File -filepath $destinationPath -Force
    
    return $destinationPath
}

Function CreateStorageLinkedService {
    param
    (
        # Parameter help description
        [String]$storageAccountResourceGroupName,
        [String]$storageAccountName
    )

    $sourcePath = "$devOpsProjectFolder\DataFactoryV2\storage.json"
    $storageLinkedService = Get-Content -Path $sourcePath -Raw | ConvertFrom-JSON

    $connectionString = "https://{0}.blob.core.windows.net" -f $storageAccountName
    $storageLinkedService.properties.typeProperties.serviceEndpoint = $connectionString
    $storageLinkedService.properties.typeProperties.tenant = $tenantId
    $storageLinkedService.properties.typeProperties.servicePrincipalId = $parameters.parameters.applicationId.value
    $storageLinkedService.properties.typeProperties.servicePrincipalKey.secretName = $parameters.parameters.adApplicationName.value
    $storageLinkedService.name = $parameters.parameters.storageAccountLinkedServiceName.value
    
    $destinationPath = New-TemporaryFile
    Write-Verbose "Writing $destinationPath with link service details"

    $storageLinkedService | ConvertTo-JSON -Depth 10| Out-File -filepath $destinationPath -Force
    return $destinationPath
}
# Use a SAS token to authenticate to azure storage
Function CreateStorageLinkedServiceWithSAS {
    param
    (
        # Parameter help description
        [string]$storageAccountName,
        [String]$containerName,
        [String]$secretName,
        [String]$description
    )
    # This is actually a work around.  At the time of writing the powershell commandlet don't support SAS credentials
    # properly.  Should be able to store just the SAS token in key vault as implied by the GUI.
    # Workaround here is to store the entire SAS URI in key vault
    $sourcePath = "$devOpsProjectFolder\DataFactoryV2\storage.sas.json"
    $storageLinkedService = Get-Content -Path $sourcePath -Raw | ConvertFrom-JSON

    $storageLinkedService.properties.description = $description
    $storageLinkedService.properties.typeProperties.sasUri.secretName = $secretName
    
    $destinationPath = New-TemporaryFile
    Write-Verbose "Writing $destinationPath with link service details"
    $storageLinkedService | ConvertTo-JSON -Depth 10| Out-File -filepath $destinationPath -Force
    return $destinationPath
}
Function CreateStorageLinkedServiceWithKey {
    param
    (
        # Parameter help description
        [String]$storageAccountResourceGroupName,
        [String]$storageAccountName
    )
    $sourcePath = "$devOpsProjectFolder\DataFactoryV2\storage.key.json"
    $storageLinkedService = Get-Content -Path $sourcePath -Raw | ConvertFrom-JSON

    $storageLinkedService.properties.typeProperties.connectionString.store.referenceName = $parameters.parameters.keyVaultLinkedServiceName.value
    $storageLinkedService.properties.typeProperties.connectionString.secretName = $parameters.parameters.storageAccountConnectionSecretName.value
    
    $destinationPath = New-TemporaryFile
    Write-Verbose "Writing $destinationPath with link service details"
    $storageLinkedService | ConvertTo-JSON -Depth 10| Out-File -filepath $destinationPath -Force
    return $destinationPath
}
Function CreateAdlsLinkedService {
    param
    (
        # Parameter help description
        [String]$adlStoreResourceGroupName,
        [String]$adlStoreName,
        [String]$adlsSubscriptionId
    )
    $sourcePath = "$devOpsProjectFolder\DataFactoryV2\adlstore.json"
    $adlsLinkedService = Get-Content -Path $sourcePath -Raw | ConvertFrom-JSON

    $dataLakeStoreUri = "adl://{0}.azuredatalakestore.net/" -f $adlStoreName
        
    $tenantDomainName = $parameters.parameters.tenantDomainName.value

    $appApplicationId = $parameters.parameters.applicationId.value
    
    $adlsLinkedService.name = $parameters.parameters.dataLakeStoreLinkedServiceName.value
    $adlsLinkedService.properties.typeProperties.dataLakeStoreUri = $dataLakeStoreUri
    $adlsLinkedService.properties.typeProperties.servicePrincipalId = $appApplicationId

    $adlsLinkedService.properties.typeProperties.servicePrincipalKey.store.referenceName = $parameters.parameters.keyVaultLinkedServiceName.value
    $adlsLinkedService.properties.typeProperties.servicePrincipalKey.secretName = $parameters.parameters.adApplicationName.value
    $adlsLinkedService.properties.typeProperties.tenant = $tenantDomainName
    $adlsLinkedService.properties.typeProperties.subscriptionId = $subscriptionId
    if (-not ([string]::IsNullOrEmpty($adlsSubscriptionId)))
    {
        $adlsLinkedService.properties.typeProperties.subscriptionId = $adlsSubscriptionId
    }
    $adlsLinkedService.properties.typeProperties.resourceGroupName = $adlStoreResourceGroupName

    $destinationPath = New-TemporaryFile
    Write-Verbose "Writing $destinationPath with link service details"
    $adlsLinkedService | ConvertTo-JSON -Depth 10 | Out-File -filepath $destinationPath -Force
    return $destinationPath
}

Function CreateKeyVaultLinkedService {
    $kvName = $parameters.parameters.keyVaultName.value
    $sourcePath = "$devOpsProjectFolder\DataFactoryV2\keyvault.json"
    $kvLinkedService = Get-Content -Path $sourcePath -Raw | ConvertFrom-JSON
    $kvUri = "https://{0}.vault.azure.net/" -f $kvName    

    $kvLinkedService.name = $lvLinkName
    $kvLinkedService.properties.typeProperties.baseUrl = $kvUri
    
    $destinationPath = New-TemporaryFile
    Write-Verbose "Writing $destinationPath with link service details"

    $kvLinkedService | ConvertTo-JSON -Depth 10 | Out-File -filepath $destinationPath -Force
    return $destinationPath
}

Function CreateAdlaLinkedService {
    $adlAnalyticsResourceGroupName = $parameters.parameters.adlAnalyticsResourceGroupName.value 
    $adlAnalyticsName = $parameters.parameters.adlAnalyticsName.value

    $sourcePath = "$devOpsProjectFolder\DataFactoryV2\adlanalytics.json"
    $adlaLinkedService = Get-Content -Path $sourcePath -Raw | ConvertFrom-JSON

    $dataLakeAnalyticsUri = "adl://{0}.azuredatalakeanalytics.net/" -f $adlAnalyticsName    
    $tenantDomainName = $parameters.parameters.tenantDomainName.value

    $appApplicationId = $parameters.parameters.applicationId.value
    $keyVaultName = $parameters.parameters.keyVaultName.value
    $secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $parameters.parameters.adApplicationName.value
    $appClientSecretText = $secret.SecretValueText

    $adlaLinkedService.name = $parameters.parameters.dataLakeAnalyticsLinkedServiceName.value
    $adlaLinkedService.properties.typeProperties.accountName = $adlAnalyticsName
    $adlaLinkedService.properties.typeProperties.dataLakeAnalyticsUri = $dataLakeAnalyticsUri
    $adlaLinkedService.properties.typeProperties.servicePrincipalId = $appApplicationId
    $adlaLinkedService.properties.typeProperties.servicePrincipalKey.value = $appClientSecretText 
    $adlaLinkedService.properties.typeProperties.tenant = $tenantDomainName
    $adlaLinkedService.properties.typeProperties.subscriptionId = $subscriptionId
    $adlaLinkedService.properties.typeProperties.resourceGroupName = $adlAnalyticsResourceGroupName

    $destinationPath = New-TemporaryFile
    Write-Verbose "Writing $destinationPath with link service details"

    $adlaLinkedService | ConvertTo-JSON -Depth 10 | Out-File -filepath $destinationPath -Force
    return $destinationPath
}
Function CreateAdlsGen2LinkedService {
    param
    (
        # Parameter help description
        [String]$adlStoreResourceGroupName,
        [String]$adlStoreName,
        [String]$adlsSubscriptionId
    )
    $sourcePath = "$devOpsProjectFolder\DataFactoryV2\adlstore2.json"
    $adlsLinkedService = Get-Content -Path $sourcePath -Raw | ConvertFrom-JSON

    if($Global:CtxBootstrap.ProjectEnvironment -eq "r") {
        $dataLakeStoreUri = "https://{0}-secondary.dfs.core.windows.net" -f $adlStoreName
    }else {
        $dataLakeStoreUri = "https://{0}.dfs.core.windows.net" -f $adlStoreName
    }
    $appApplicationId = $parameters.parameters.applicationId.value
    
    $adlsLinkedService.name = $parameters.parameters.dataLakeStoreLinkedServiceName.value
    $adlsLinkedService.properties.typeProperties.Url = $dataLakeStoreUri
    $adlsLinkedService.properties.typeProperties.servicePrincipalId = $appApplicationId

    $adlsLinkedService.properties.typeProperties.servicePrincipalKey.store.referenceName = $parameters.parameters.keyVaultLinkedServiceName.value
    $adlsLinkedService.properties.typeProperties.servicePrincipalKey.secretName = $parameters.parameters.adApplicationName.value
    $adlsLinkedService.properties.typeProperties.subscriptionId = $subscriptionId
    if (-not ([string]::IsNullOrEmpty($adlsSubscriptionId)))
    {
        $adlsLinkedService.properties.typeProperties.subscriptionId = $adlsSubscriptionId
    }
    $adlsLinkedService.properties.typeProperties.resourceGroupName = $adlStoreResourceGroupName

    $destinationPath = New-TemporaryFile
    Write-Verbose "Writing $destinationPath with link service details"
    #$adlsLinkedService | ConvertTo-JSON -Depth 10 | Write-Host
    $adlsLinkedService | ConvertTo-JSON -Depth 10 | Out-File -filepath $destinationPath -Force
    return $destinationPath
}
function CreateOnPremiseLinkedService () {
    $keyVaultName = $parameters.parameters.keyVaultName.value
    $hostname = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $parameters.parameters.OnPremiseFileServerHostName.value -ErrorAction SilentlyContinue
    $userid =  Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $parameters.parameters.OnPremiseFileServerUserName.value -ErrorAction SilentlyContinue
    
    $dataFactoryGatewayName = $parameters.parameters.dataFactoryGatewayName.value;
    $sourcePath = "$devOpsProjectFolder\DataFactoryV2\onpremfileshare.json"
    $OnPremLinkedService = Get-Content -Path $sourcePath -Raw | ConvertFrom-JSON

    $OnPremLinkedService.name = $parameters.parameters.OnPremisesFileServerLinkedServiceName.value
    $OnPremLinkedService.properties.typeProperties.host = $hostname.SecretValueText       
    $OnPremLinkedService.properties.typeProperties.userId = $userid.SecretValueText
    $OnPremLinkedService.properties.typeProperties.password.secretName = $parameters.parameters.OnPremiseFileServerPassword.value
    $OnPremLinkedService.properties.connectVia.referenceName = $dataFactoryGatewayName

    $destinationPath = New-TemporaryFile
    Write-Verbose "Writing $destinationPath with link service details"
    $OnPremLinkedService | ConvertTo-JSON -Depth 10 | Out-File -filepath $destinationPath -Force
    return $destinationPath
}

Function CreateSftpLinkedService {
    $keyVaultName = $parameters.parameters.keyVaultName.value
    $sftpHostnameKeyVaultName = $parameters.parameters.sftpHostSecretName.value
    $sftpUsernameKeyVaultName = $parameters.parameters.sftpUserSecretName.value
    $sftpPrivateKeyContentKeyVaultName = $parameters.parameters.sftpPrivateKeySecretName.value
    $sftpPassPhraseKeyVaultName = $parameters.parameters.sftpPassPhraseSecretName.value
    $sftpPortKeyVaultName = $parameters.parameters.sftpPortSecretName.value
    $port = "22"

    $hostname = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $sftpHostnameKeyVaultName -ErrorAction SilentlyContinue
    $username =  Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $sftpUsernameKeyVaultName  -ErrorAction SilentlyContinue
    if (-not [string]::IsNullOrEmpty($sftpPortKeyVaultName)){
        $portSecret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $sftpPortKeyVaultName -ErrorAction SilentlyContinue
        if ($portSecret) {
            $port = $portSecret.SecretValueText
        }

    }
    
    $dataFactoryGatewayName = $parameters.parameters.sftpSelfHostedIRName.value    
    
    $sourcePath = "$devOpsProjectFolder\DataFactoryV2\sftp.json"
    $sftpLinkedService = Get-Content -Path $sourcePath -Raw | ConvertFrom-JSON

    $sftpLinkedService.name = $parameters.parameters.sftpLinkedServiceName.value
    $sftpLinkedService.properties.typeProperties.host = $hostname.SecretValueText
    $sftpLinkedService.properties.typeProperties.port = $port
    $sftpLinkedService.properties.typeProperties.username = $username.SecretValueText
    
    $sftpLinkedService.properties.typeProperties.privateKeyContent.secretName = $sftpPrivateKeyContentKeyVaultName    
    $sftpLinkedService.properties.typeProperties.passPhrase.secretName = $sftpPassPhraseKeyVaultName

    if ([string]::IsNullOrEmpty($dataFactoryGatewayName)) {
        # The link must use the default integration runtime.  To do this we must remove the
        # properties.connectVia value from the object.
        $obj1 = $sftpLinkedService.properties | Select-Object type,typeProperties
        $sftpLinkedService.properties = $obj1
    } else {
        $sftpLinkedService.properties.connectVia.referenceName = $dataFactoryGatewayName
    }

    $destinationPath = New-TemporaryFile
    Write-Verbose "Writing $destinationPath with link service details"

    $sftpLinkedService | ConvertTo-JSON -Depth 10 | Out-File -filepath $destinationPath -Force
    return $destinationPath
}

Function CreateFtpLinkedService {
    $keyVaultName = $parameters.parameters.keyVaultName.value
    $ftpHostnameKeyVaultName = $parameters.parameters.ftpHostSecretName.value
    $ftpPortKeyVaultName = $parameters.parameters.ftpPortSecretName.value
    $ftpUsernameKeyVaultName = $parameters.parameters.ftpUserNameSecretName.value
    $ftpPasswordKeyContentKeyVaultName = $parameters.parameters.ftpPasswordSecretName.value
    
    $hostname = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $ftpHostnameKeyVaultName -ErrorAction SilentlyContinue
    $username =  Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $ftpUsernameKeyVaultName  -ErrorAction SilentlyContinue
    $port = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $ftpPortKeyVaultName -ErrorAction SilentlyContinue
    $password = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $ftpPasswordKeyContentKeyVaultName -ErrorAction SilentlyContinue
    $dataFactoryGatewayName = $parameters.parameters.ftpSelfHostedIRName.value    
    
    $sourcePath = "$devOpsProjectFolder\DataFactoryV2\ftp.json"
    $ftpLinkedService = Get-Content -Path $sourcePath -Raw | ConvertFrom-JSON

    $ftpLinkedService.name = $parameters.parameters.ftpLinkedServiceName.value
    $ftpLinkedService.properties.typeProperties.host = $hostname.SecretValueText
    $ftpLinkedService.properties.typeProperties.username = $username.SecretValueText
    $ftpLinkedService.properties.typeProperties.port.value = $port.SecretValueText 
    $ftpLinkedService.properties.typeProperties.password.value = $password.SecretValueText

    if ([string]::IsNullOrEmpty($dataFactoryGatewayName)) {
        # The link must use the default integration runtime.  To do this we must remove the
        # properties.connectVia value from the object.
        $obj1 = $ftpLinkedService.properties | Select-Object type,typeProperties
        $ftpLinkedService.properties = $obj1
    } else {
        $ftpLinkedService.properties.connectVia.referenceName = $dataFactoryGatewayName
    }

    $destinationPath = New-TemporaryFile
    Write-Verbose "Writing $destinationPath with link service details"

    $ftpLinkedService | ConvertTo-JSON -Depth 10 | Out-File -filepath $destinationPath -Force
    return $destinationPath
}

Function CreateBatchLinkedService {
    $batchAccountResourceGroupName = $parameters.parameters.batchAccountResourceGroupName.value
    $batchAccountName = $parameters.parameters.batchAccountName.value
    $batchPoolName = $parameters.parameters.batchPoolName.value
    $Context = Get-AzBatchAccountKey -AccountName $batchAccountName -ResourceGroupName $batchAccountResourceGroupName
    
    $batchAccountUri = 'https://' + $Context.AccountEndpoint
    $storageLinkedServiceName = $parameters.parameters.storageAccountLinkedServiceName.value
    $dataFactoryGatewayName = $parameters.parameters.batchSelfHostedIRName.value

    $sourcePath = "$devOpsProjectFolder\DataFactoryV2\batch.json"
    $batchLinkedService = Get-Content -Path $sourcePath -Raw | ConvertFrom-JSON
    
    $batchLinkedService.name = $parameters.parameters.batchAccountLinkedServiceName.value
    $batchLinkedService.properties.typeProperties.accountName = $batchAccountName       
    $batchLinkedService.properties.typeProperties.accessKey.secretName = $batchAccountName
    $batchLinkedService.properties.typeProperties.poolName = $batchPoolName
    $batchLinkedService.properties.typeProperties.linkedServiceName.referenceName = $storageLinkedServiceName
    $batchLinkedService.properties.typeProperties.batchUri = $batchAccountUri

    if ($dataFactoryGatewayName -eq "") {
        # The batch link must use the default integration runtime.  To do this we must remove the
        # properties.connectVia value from the object.
        $obj1 = $batchLinkedService.properties | Select-Object type,typeProperties
        $batchLinkedService.properties = $obj1
    } else {
        $batchLinkedService.properties.connectVia.referenceName = $dataFactoryGatewayName
    }

    $destinationPath = New-TemporaryFile
    Write-Verbose "Writing $destinationPath with link service details"
    $batchLinkedService | ConvertTo-JSON -Depth 4 | Out-File -filepath $destinationPath -Force
    return $destinationPath
}


# Create Linked Services
$dataFactoryResourceGroupName = $parameters.parameters.dataFactoryResourceGroupName.value 
$dataFactoryName = $parameters.parameters.dataFactoryName.value

$df = Get-AzDataFactoryV2 -ResourceGroupName $dataFactoryResourceGroupName -Name $dataFactoryName -ErrorAction SilentlyContinue
if (!$df) {
    throw "Data Factory does not exist. Please create it first."
}
if ($KeyVault) {
    Write-Verbose "Generating Azure key vault linked service configuration"
    $tempConfigFile = CreateKeyVaultLinkedService
    $name = $parameters.parameters.keyVaultLinkedServiceName.value
    Write-Verbose "Creating private key vault linked service configuration"    
    Set-AzDataFactoryV2LinkedService -ResourceGroupName $dataFactoryResourceGroupName `
    -DataFactoryName $dataFactoryName -Name $name -DefinitionFile $tempConfigFile -Force | Out-Null
}

if ($PSLZADLStore) {
    
    Write-Verbose "Generating PSLZ Azure Data Lake Store linked service configuration"
    $pslzStoreResourceGroupName = $parameters.parameters.pslzStoreResourceGroupName.value 
    $pslzStoreName = $parameters.parameters.pslzStoreName.value
    $pslzSubscriptionId = $parameters.parameters.pslzSubscriptionId.value

    if($pslzStoreName -ne "Not Applicable")
    {
        # point to UDL in the prod subscription
        $tempAdlsConfigFile = CreateAdlsLinkedService $pslzStoreResourceGroupName $pslzStoreName $pslzSubscriptionId
        $name = $parameters.parameters.pslzlinkedServiceName.value
        Write-Verbose "Creating PSLZ Data Lake Store linked service configuration $dataFactoryResourceGroupName $name "    
        $depl = Set-AzDataFactoryV2LinkedService -ResourceGroupName  $dataFactoryResourceGroupName `
        -DataFactoryName $dataFactoryName -Name $name -DefinitionFile $tempAdlsConfigFile -Force
      }
}

if ($Storage) {
    Write-Verbose "Generating Storage linked service configuration"
    $storageAccountResourceGroupName = $parameters.parameters.storageAccountResourceGroupName.value
    $storageAccountName = $parameters.parameters.storageAccountName.value
    $tempStorageConfigFile = CreateStorageLinkedService $storageAccountResourceGroupName $storageAccountName
    $name = $parameters.parameters.storageAccountLinkedServiceName.value
    
    Write-Verbose "Creating Storage linked service configuration"
    Set-AzDataFactoryV2LinkedService -ResourceGroupName  $dataFactoryResourceGroupName `
    -DataFactoryName $dataFactoryName -Name $name -DefinitionFile $tempStorageConfigFile -Force | Out-Null
}
if ($StorageWithKey) {
    Write-Verbose "Generating Storage linked service configuration using storage account key"
    $storageAccountResourceGroupName = $parameters.parameters.storageAccountResourceGroupName.value
    $storageAccountName = $parameters.parameters.storageAccountName.value
    $tempStorageConfigFile = CreateStorageLinkedServiceWithKey $storageAccountResourceGroupName $storageAccountName
    $name = $parameters.parameters.storageAccountLinkedServiceName.value
    
    Write-Verbose "Creating Storage linked service configuration"
    Set-AzDataFactoryV2LinkedService -ResourceGroupName  $dataFactoryResourceGroupName `
    -DataFactoryName $dataFactoryName -Name $name -DefinitionFile $tempStorageConfigFile -Force | Out-Null
}
# If you are provisioning this in an ADF that belongs to a BDL or PDL you need to run it as a separate manual step.
# Problem is it requires contributor permissions on the BDL/PDL and the UDL storage resource group.
if ($Sharedstorage) {
    Write-Verbose "Generating UDL Storage linked service configuration"
    $storageAccountResourceGroupName = $parameters.parameters.sharedStorageAccountResourceGroupName.value
    $storageAccountName = $parameters.parameters.sharedStorageAccountName.value
    $tempStorageConfigFile = CreateStorageLinkedService $storageAccountResourceGroupName $storageAccountName

    $name = $parameters.parameters.storageAccountLinkedServiceNameUdl.value
    Write-Verbose "Creating Storage linked service configuration"
    Set-AzDataFactoryV2LinkedService -ResourceGroupName  $dataFactoryResourceGroupName `
    -DataFactoryName $dataFactoryName -Name $name -DefinitionFile $tempStorageConfigFile -Force | Out-Null
}
if ($Batch) {
    $batchAccountResourceGroupName = $parameters.parameters.batchAccountResourceGroupName.value
    $batchAccountName = $parameters.parameters.batchAccountName.value
    $name = $parameters.parameters.batchAccountLinkedServiceName.value
    $batchobj = Get-AzBatchAccount -ResourceGroupName $batchAccountResourceGroupName -AccountName $batchAccountName -ErrorAction SilentlyContinue
    if ($batchobj){
        Write-Verbose "Generating Batch linked service configuration"
        $tempBatchConfigFile = CreateBatchLinkedService
        Write-Verbose "Creating Batch linked service configuration"
        $name = $parameters.parameters.batchAccountLinkedServiceName.value
        Set-AzDataFactoryV2LinkedService -ResourceGroupName  $dataFactoryResourceGroupName `
        -DataFactoryName $dataFactoryName -Name $name -DefinitionFile $tempBatchConfigFile -Force | Out-Null
        }
}

if ($SqlDb) {
    $sqlServerResourceGroupName = $parameters.parameters.sqlServerResourceGroupName.value
    $sqlServerName = $parameters.parameters.sqlServerName.value
    $sqlDatabaseName = $parameters.parameters.sqlDatabaseName.value
    $sqldbObj = Get-AzSqlDatabase -ResourceGroupName $sqlServerResourceGroupName -ServerName $sqlServerName -DatabaseName $sqlDatabaseName -ErrorAction SilentlyContinue
    if ($sqldbObj){
        Write-Verbose "Generating SQL linked service configuration"
        $sqlDatabaseName = $parameters.parameters.sqlDatabaseName.value
        $name = $parameters.parameters.sqlDatabaseLinkedServiceName.value
        $type = "AzureSqlDatabase"
        $tempSqlConfigFile = CreateSqlLinkedService -databaseName $sqlDatabaseName -type $type -name $name
        Write-Verbose "Creating Sql database linked service configuration"
        Set-AzDataFactoryV2LinkedService -ResourceGroupName  $dataFactoryResourceGroupName `
        -DataFactoryName $dataFactoryName -Name $name -DefinitionFile $tempSqlConfigFile -Force | Out-Null
    }
}

if ($SqlDW) {
    $sqlServerResourceGroupName = $parameters.parameters.sqlServerResourceGroupName.value
    $sqlServerName = $parameters.parameters.sqlServerName.value
    $sqlDataWarehouseName = $parameters.parameters.sqlDataWarehouseName.value
    $sqldwobj = Get-AzSqlDatabase -ResourceGroupName $sqlServerResourceGroupName -ServerName $sqlServerName -DatabaseName $sqlDataWarehouseName -ErrorAction SilentlyContinue
    if ($sqldwobj){
        Write-Verbose "Generating SQL DW linked service configuration"
        $sqlDataWarehouseName = $parameters.parameters.sqlDataWarehouseName.value
        $name = $parameters.parameters.sqlDataWarehouseLinkedServiceName.value
        $type = "AzureSqlDW"
        $tempSqlConfigFile = CreateSqlLinkedService -databaseName $sqlDataWarehouseName -type $type -name $name
        Write-Verbose "Creating Sql Data Warehouse linked service configuration"
        Set-AzDataFactoryV2LinkedService -ResourceGroupName $dataFactoryResourceGroupName `
        -DataFactoryName $dataFactoryName -Name $name -DefinitionFile $tempSqlConfigFile -Force | Out-Null
    }
}
if ($ADLStoreGen1) {
    Write-Verbose "Generating private Azure Data Lake Store linked service configuration"
    $adlStoreResourceGroupName = $parameters.parameters.AdlStoreResourceGroupName.value 
    $adlStoreName = $parameters.parameters.adlStoreNameGen1.value
    $tempAdlsConfigFile = CreateAdlsLinkedService $adlStoreResourceGroupName $adlStoreName ""
    $name = $parameters.parameters.dataLakeStoreLinkedServiceName.value
    Write-Verbose "Creating private Data Lake Store linked service configuration"    
    Set-AzDataFactoryV2LinkedService -ResourceGroupName  $dataFactoryResourceGroupName `
    -DataFactoryName $dataFactoryName -Name $name -DefinitionFile $tempAdlsConfigFile -Force | Out-Null
}
if ($ADLStore){
    Write-Verbose "Generating private Azure Data Lake Store Gen2 linked service configuration"
    $adlStoreResourceGroupName = $parameters.parameters.AdlStoreResourceGroupName.value 
    $adlStoreName = $parameters.parameters.adlStoreName.value
    $tempAdlsConfigFile = CreateAdlsGen2LinkedService $adlStoreResourceGroupName $adlStoreName ""
    $name = $parameters.parameters.dataLakeStoreLinkedServiceName.value
    Write-Verbose "Creating private Data Lake Store linked service configuration"    
    $depl = Set-AzDataFactoryV2LinkedService -ResourceGroupName  $dataFactoryResourceGroupName `
    -DataFactoryName $dataFactoryName -Name $name -DefinitionFile $tempAdlsConfigFile -Force
}
if ($sharedADLStore) {
    Write-Verbose "Generating UDL Azure Data Lake Store linked service configuration"
    $adlStoreResourceGroupName = $parameters.parameters.sharedAdlStoreResourceGroupName.value 
    $adlStoreName = $parameters.parameters.sharedAdlStoreName.value

    # point to UDL in the prod subscription
    $tempAdlsConfigFile = CreateAdlsLinkedService $adlStoreResourceGroupName $adlStoreName "50327adb-f8a0-4908-8d31-aa182df19f02"
    $name = $parameters.parameters.dataLakeStoreLinkedServiceNameUdl.value
    Write-Verbose "Creating UDL Data Lake Store linked service configuration $dataFactoryResourceGroupName $name "    
    Set-AzDataFactoryV2LinkedService -ResourceGroupName  $dataFactoryResourceGroupName `
    -DataFactoryName $dataFactoryName -Name $name -DefinitionFile $tempAdlsConfigFile -Force | Out-Null
}

if ($ADLAnalytics) {
    $adlAnalyticsResourceGroupName = $parameters.parameters.adlAnalyticsResourceGroupName.value
    $adlAnalyticsName = $parameters.parameters.adlAnalyticsName.value
    $name = $parameters.parameters.dataLakeAnalyticsLinkedServiceName.value
    $adlaobj = Get-AzDataLakeAnalyticsAccount -ResourceGroupName $adlAnalyticsResourceGroupName -Name $adlAnalyticsName -ErrorAction SilentlyContinue
    if ($adlaobj) {
        Write-Verbose "Generating Azure Data Analytics linked service configuration"
        $tempAdlaConfigFile = CreateAdlaLinkedService
        Write-Verbose "Creating Data Lake Analytics linked service configuration"    
        Set-AzDataFactoryV2LinkedService -ResourceGroupName  $dataFactoryResourceGroupName `
        -DataFactoryName $dataFactoryName -Name $name -DefinitionFile $tempAdlaConfigFile -Force | Out-Null
    }
}

function IsSSISDatabaseInstalled {
    $sqlServerResourceGroupName = $parameters.parameters.sqlServerResourceGroupName.value
    $sqlServerName = $parameters.parameters.sqlServerName.value    
    $sqlDatabaseName = $parameters.parameters.sqlDatabaseName.value    
    
    $resp = Get-AzSqlDatabase -ResourceGroupName $sqlServerResourceGroupName `
    -ServerName $sqlServerName -DatabaseName $sqlDatabaseName -ErrorAction SilentlyContinue

    if (!$resp)
    {
        Write-Verbose "Sql Database is not installed "
        return $false
    }
    else {
        Write-Verbose "Sql Database is installed"
        return $true
    }
}

if ($SSIS) {
    if (-not (IsSSISDatabaseInstalled)) {
        throw "Sql Server not installed. Please install Sql Server using Add-Resources"
    }

    Write-Verbose "Creating SSIS Integration Runtime"
    $sqlServerName = $parameters.parameters.sqlServerName.value
    # Hack : This no longer works.  SqlAdmin credentials is not used anymore.    
    $sqlServerAdminLogin = $parameters.parameters.sqlServerAdminLogin.value
    $keyVaultName = $parameters.parameters.keyVaultName.value
    $secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $sqlServerAdminLogin -ErrorAction SilentlyContinue
    $sqlServerAdminPassword = $secret.SecretValue
    
    $azureSSISResourceGroupName = $parameters.parameters.azureSSISResourceGroupName.value
    $azureSSISName = $parameters.parameters.azureSSISName.value
    $azureSSISLocation = $parameters.parameters.azureSSISLocation.value
    $azureSSISNodeSize = $parameters.parameters.azureSSISNodeSize.value
    $azureSSISNodeNumber = $parameters.parameters.azureSSISNodeNumber.value
    $azureSSISMaxParallelExecutionsPerNode = $parameters.parameters.azureSSISMaxParallelExecutionsPerNode.value
    $azureSSISDBServerEndpoint = $parameters.parameters.azureSSISDBServerEndpoint.value   
    $azureSSISDBPricingTier = $parameters.parameters.azureSSISDBPricingTier.value

    $serverCreds = New-Object System.Management.Automation.PSCredential($sqlServerAdminLogin, $sqlServerAdminPassword)
    Set-AzDataFactoryV2IntegrationRuntime  -ResourceGroupName $azureSSISResourceGroupName `
    -DataFactoryName $dataFactoryName `
    -Name $azureSSISName -Type Managed `
    -CatalogServerEndpoint $azureSSISDBServerEndpoint `
    -CatalogAdminCredential $serverCreds `
    -CatalogPricingTier $azureSSISDBPricingTier `
    -Location $azureSSISLocation `
    -NodeSize $azureSSISNodeSize -NodeCount $azureSSISNodeNumber `
    -MaxParallelExecutionsPerNode $azureSSISMaxParallelExecutionsPerNode -Force | Out-Null

    Write-Verbose "Installed SSIS Integration Runtime (IR) ...starting SSIS IR"
    Start-AzDataFactoryV2IntegrationRuntime -ResourceGroupName $azureSSISResourceGroupName `
                                                 -DataFactoryName $dataFactoryName `
                                                 -Name $azureSSISName `
                                                 -Force
    
    Write-Verbose("SSIS IR started")
}

# Share the master self hosted IR with another data factory
Function ShareSelfHostedIR {
    # param (
    #     OptionalParameters
    # )
    $masterADFResourceGroupName = $parameters.parameters.landscapeDataFactoryResourceGroupName.value
    $masterADFName = $parameters.parameters.landscapeDataFactoryName.value
    $masterIntegrationRuntimeName = $parameters.parameters.landscapeDataFactorySelfHostedIRName.value
    $subscriptionId = $parameters.parameters.subscriptionId.value

    $masterFactory = Get-AzDataFactoryV2 -ResourceGroupName $masterADFResourceGroupName -Name $masterADFName -DefaultProfile $Global:CtxMasterAdf
    if (-not $masterFactory) {
        Write-Error "Unable to share self hosted IR because the master ADF was not found: $masterADFResourceGroupName / $masterADFName"
        return;
    }
    $SharedIR = Get-AzDataFactoryV2IntegrationRuntime -ResourceGroupName $masterADFResourceGroupName -DataFactoryName $masterADFName `
    -Name $masterIntegrationRuntimeName -DefaultProfile $Global:CtxMasterAdf

    $factory = Get-AzDataFactoryV2 -ResourceGroupName $parameters.parameters.dataFactoryResourceGroupName.value -Name $parameters.parameters.dataFactoryName.value
    if (-not $factory) {
        Write-Error "Unable to share self hosted IR because the child ADF was not found: $($parameters.parameters.dataFactoryResourceGroupName.value) / $($parameters.parameters.dataFactoryName.value)"
        return;
    }

    if (-not (Get-AzRoleAssignment -ObjectId $factory.Identity.PrincipalId ` -RoleDefinitionId 'b24988ac-6180-42a0-ab88-20f7382dd24c' -Scope $SharedIR.Id  -DefaultProfile $Global:CtxMasterAdf))
    {
        Write-Host "Granting access to the shared self hosted IR $masterIntegrationRuntimeName in $masterADFName."
        # grant access on the master ADF so it can be shared
        New-AzRoleAssignment -ObjectId $factory.Identity.PrincipalId ` -RoleDefinitionId 'b24988ac-6180-42a0-ab88-20f7382dd24c' -Scope $SharedIR.Id -DefaultProfile $Global:CtxMasterAdf   
    } else {
        Write-Host "Access to the shared self hosted IR $masterIntegrationRuntimeName is already granted."
    }
    Write-Host "Creating the shared self hosted IR $($parameters.parameters.dataFactoryGatewayName.value)"
    Set-AzDataFactoryV2IntegrationRuntime `
    -ResourceGroupName $parameters.parameters.dataFactoryResourceGroupName.value `
    -DataFactoryName $parameters.parameters.dataFactoryName.value `
    -Name $parameters.parameters.dataFactoryGatewayName.value `
    -Type SelfHosted `
    -SharedIntegrationRuntimeResourceId $SharedIR.Id `
    -Description $SharedIR.Description -Force

}

if ($sharedSelfHostedIR)
{
    Write-Host "Attaching shared on-prem IR"
    ShareSelfHostedIR
}

if ($OnPremFileServer) {
    Write-Verbose "Generating On Premise linked service configuration"
    $tempOnPremConfigFile = CreateOnPremiseLinkedService
    $name = $parameters.parameters.OnPremisesFileServerLinkedServiceName.value
    Write-Verbose "Creating On Premise linked service configuration"
    Set-AzDataFactoryV2LinkedService -ResourceGroupName  $dataFactoryResourceGroupName `
    -DataFactoryName $dataFactoryName -Name $name -DefinitionFile $tempOnPremConfigFile -Force | Out-Null
}

if ($Sftp) {
    Write-Verbose "Generating Sftp linked service configuration"
    $name = $parameters.parameters.sftpLinkedServiceName.value
    $tempSftpConfigFile = CreateSftpLinkedService
    Write-Verbose "Creating Sftp linked service configuration"    
    Set-AzDataFactoryV2LinkedService -ResourceGroupName  $dataFactoryResourceGroupName `
    -DataFactoryName $dataFactoryName -Name $name -DefinitionFile $tempSftpConfigFile -Force | Out-Null
}

if ($ftp) {
    Write-Verbose "Generating ftp linked service configuration"
    $name = $parameters.parameters.ftpLinkedServiceName.value
    $tempftpConfigFile = CreateFtpLinkedService
    Write-Verbose "Creating Ftp linked service configuration"    
    Set-AzDataFactoryV2LinkedService -ResourceGroupName  $dataFactoryResourceGroupName `
    -DataFactoryName $dataFactoryName -Name $name -DefinitionFile $tempftpConfigFile -Force | Out-Null 
}

if($SeedDataStore) {
    # Create a container for this ADF to use as temporary storage for initial data loads.  This will live in the 
    # landscape central storage account and be accessed from all environments using a 3 month SAS token
    $dataFactoryResourceGroupName = $parameters.parameters.dataFactoryResourceGroupName.value
    $dataFactoryName = $parameters.parameters.dataFactoryName.value

    # work out the name of the dev storage account and resource group
    $tokens = $parameters.parameters.developerADGroupName.value.Split("-")
    if ($tokens) {
        $devItsg = $tokens[4]
        $devParameterFile = "$($tokens[3]).$devItsg"
        $devParameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $devParameterFile -bootstrap $devBootStrap
        # This logic is not sound.  Will fail if dev RG is full and we have an addition one.
        $resourceGroupName = $devParameters.parameters.storageAccountResourceGroupName.value
        $storageAccountName = $devParameters.parameters.storageAccountName.value
    } else {
        Write-Error "Unable to identify the development storage account for the data seed linked services."
    }
    
    $storageKey = Get-AzStorageAccountKey -ResourceGroupName $resourceGroupName -Name $storageAccountName -DefaultProfile $Global:CtxDev
    $storageaccountContext = New-AzStorageContext -StorageAccountName $storageAccountName -StorageAccountKey $storageKey[0].Value
    $starttime = Get-Date
    $endtime = $starttime.AddMonths(3) 
    $containerName = "dataseed"
    $description = $parameters.parameters.dataSeedLinkedServiceName.metadata.description

    # For dev env allow writes to the container. for all other env it's read only
    $permissions = "rl"
    if ("dx".Contains($parameters.parameters.projectEnvironment.value))
    {
        $permissions = "rwdl"
        $container = Get-AzStorageContainer -Name $containerName -Context $storageaccountContext -ErrorAction SilentlyContinue
        if (-not $container)
        {
            Write-Verbose "ADF initial data load container $containerName does not exist. Creating..."
            $container = New-AzStorageContainer -Name $containerName -Context $storageaccountContext
        }
        else 
        {
            Write-Verbose "ADF initial data load container $containerName already exists"
        }
    }
    $containerSASToken = New-AzStorageAccountSASToken -Context $storageaccountContext -Service Blob -ResourceType Service,Container,Object -Permission $permissions -StartTime $starttime -ExpiryTime $endtime
    $blobEndPoint = "https://{0}.blob.core.windows.net/{1}" -f $storageAccountName, $containerSASToken
    
    $keyName = "DataSeedSASUri"
    $keyValue = ConvertTo-SecureString -AsPlainText $blobEndPoint -Force
    $secretCredential = New-Object System.Management.Automation.PSCredential ($keyName, $keyValue)
    $contentType = "A SAS URI that can access the 'dataseed' container in your dev storage account {0}. Ask landscape to renew as required."
    & "$utilitiesFolder\Set-KeyVaultSecret" -parameterFile $parameterFile -secretCredential $secretCredential -updateSecret $true -secretExpiryTermYears $secretExpiryYears -contentType $contentType
    
    $tempStorageConfigFile = CreateStorageLinkedServiceWithSAS -storageAccountName $storageAccountName -containerName $containerName -secretName $keyName -description $description
    
    $name = $parameters.parameters.dataSeedLinkedServiceName.value
    Write-Verbose "Deploying the ADF data seed linked service"
    Set-AzDataFactoryV2LinkedService -ResourceGroupName  $dataFactoryResourceGroupName `
    -DataFactoryName $dataFactoryName -Name $name -DefinitionFile $tempStorageConfigFile -Force | Out-Null

}