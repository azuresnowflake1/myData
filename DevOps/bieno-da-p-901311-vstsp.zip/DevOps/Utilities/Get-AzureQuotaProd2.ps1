Param
(
    [Parameter(Mandatory = $True, HelpMessage = 'Specify the parameter file')]
    [String]$parameterFile
)
# ADF
# ADLS
# Batch Service
# Blob
# Databricks
# HDI Hive
# HDI Spark
# SQLDW

# A simple script to return the number of Data Factories / Data Lakes , Azure SQL Servers and Azure Batch within a Subscription
# Soft Lmits can be accessed at https://docs.microsoft.com/en-us/azure/azure-subscription-service-limits and the variable updatd to reflect
# This is a very basic script to show how it could be achieved, clearly more advanced scripting would be required if you wished to automate and productionise in some way.

$sub = Select-AzSubscription -SubscriptionName "PROD2" 

# Get the Data Factory Details
$services =  Get-AzDataFactoryV2
$noOf = $services.count
$max = 200;
$percentage = $noOf / $max * 100;
Write-Output "In Subscription $($sub.Subscription.Name) You have a total of $noOf Azure Data Factory V2's out of $max. Percentage used: $percentage%`r`n" 

# Get the Data Lake Details
$services = Get-AzDataLakeStoreAccount
$noOf = $services.count
$max = 120;
$percentage = $noOf / $max * 100;
Write-Output "In Subscription $($sub.Subscription.Name) You have a total of $noOf Azure Data Lake Stores (ADLS) out of $max. Percentage used: $percentage%`r`n" 

# Get the Azure SQL Server Details (note this is servers not databases, also I am not aware of any soft Limits on the number of Azure SQL Servers deployed into a Sub (only the shape and size e.g S1, P1 etc)
$services=Get-AzSQLServer
$noOf = $services.count
$max = 150;
$percentage = $noOf / $max * 100;
Write-Output "In Subscription $($sub.Subscription.Name) You have a total of $noOf Azure SQL Servers out of $max. Percentage used: $percentage%`r`n"  

# Get the Azure Batch Limits
$services =  Get-AzBatchAccount
$noOf = $services.count
$max = 120;
$percentage = $noOf / $max * 100;
Write-Output "In Subscription $($sub.Subscription.Name) You have a total of $noOf Azure Batch out of $max. Percentage used: $percentage%`r`n"

