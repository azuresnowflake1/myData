Param
(
    [Parameter(Mandatory = $True, HelpMessage = 'Specify the parameter file')]
    [String]$parameterFile
)

Write-Verbose "PSScriptRoot is: $PSScriptRoot"
$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"
$managerFolder = "{0}\{1}" -f $devOpsProjectFolder, "LandscapeManager"

# workout if this project uses ADLS Gen1 or Gen2
function Get-AdlsType {
    param([string]$resourceGroupName,[string]$gen1Name, [string]$gen2Name)

    [bool]$gen1Deployed = $false
    [bool]$gen2Deployed = $false
    $resources = Get-AzResource -ResourceGroupName $resourceGroupName
    foreach ($resource in $resources){
        if ($resource.ResourceName -eq $gen1Name) {
            $gen1Deployed = $true
        } elseif ($resource.ResourceName -eq $gen2Name) {
            $gen2Deployed = $true
        }
    }
    if ($gen1Deployed -and $gen2Deployed) {
        Write-Warning "Unable to create external data sources for your local ADLS since Gen1 and Gen2 are deployed."
        return $null
    }
    if (-not ($gen1Deployed -or $gen2Deployed)){
        return $null
    }
    if ($gen1Deployed) {
        return $gen1Name
    } else {
        return $gen2Name
    }
}

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

$tenantId = $parameters.parameters.tenantId.value

$cred = & "$managerFolder\Get-LandscapeServiceAccount" -parameterFile $parameterFile
if ($cred) {
    $sqlUser = $cred.UserName
    $sqlPwd = $cred.Password.SecretValueText
} else {
    Write-Error "The landscape service account credential was not found."
    return
}

$databaseName = $parameters.parameters.sqlDataWarehouseName.value
$serverName = $parameters.parameters.sqlServerName.value
$resourceGroupName = $parameters.parameters.adlStoreResourceGroupName.value
$adlStoreNameGen1 = $parameters.parameters.adlStoreNameGen1.value
$adlStoreName = $parameters.parameters.adlStoreName.value
$masterKeyToken = "{masterKey}"
$masterKeyName = "{0}-MasterKey" -f $serverName

$keyVaultName = $parameters.parameters.keyVaultName.value
$secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $masterKeyName -ErrorAction SilentlyContinue
if (!$secret) {
    Write-Verbose "Sql master key does not exist in key vault"
    $masterKey = & "$utilitiesFolder\New-Password.ps1"
    $masterKeySecure = ConvertTo-SecureString -AsPlainText $masterKey -Force
    $secretCredential = New-Object System.Management.Automation.PSCredential ($masterKeyName, $masterKeySecure)
    #Dont want to secret MasterKey to expire, hence passing 99 years as expiry
    $contentType = "The master key used to encypt credentials stored in SqlDb and SqlDW. Generated during provisioning."
    & "$utilitiesFolder\Set-KeyVaultSecret.ps1" -parameterFile $parameterFile -secretCredential $secretCredential -secretExpiryTermYears 99 -contentType $contentType
    Write-Verbose "Sql master key written to key vault"
    $secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $masterKeyName
    
}else{
    Write-Verbose "SQL master key exists in key vault"
}
$masterKey = $secret.SecretValueText

$credentialNameToken = "{credentialName}"
$credentialName = $parameters.parameters.adApplicationName.value
$tenantIdToken = "{tenantId}"
$tenantId = $parameters.parameters.tenantId.value

$applicationIdToken = "{applicationId}"
$applicationId = $parameters.parameters.applicationId.value

$clientSecretToken = "{clientSecret}"
$secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $parameters.parameters.adApplicationName.value
$clientSecret = $secret.SecretValueText

$dataSourceNameToken = "{dataSourceName}"
$dataSourceName = "adlsLocal"

$adlStoreNameToken = "{dataLakeStoreName}"
$adlStoreName = $parameters.parameters.adlStoreName.value
$adlStoreNameGen1 = $parameters.parameters.adlStoreNameGen1.value

if ($Global:ctxBootstrap.Environment -ne "DR") {
    $adls = Get-AdlsType -resourceGroupName $resourceGroupName -gen1Name $adlStoreNameGen1 -gen2Name $adlStoreName
        if ($adls -eq $adlStoreName -or (-not $adls)) {
            # Gen2 syntax. Assumes a container called unilever
            $adlStoreSyntax = "abfss://unilever@{dataLakeStoreName}.dfs.core.windows.net/"
            } elseif ($adls -eq $adlStoreNameGen1) {
            # Gen1 syntax
            $adlStoreSyntax = "adl://{dataLakeStoreName}.azuredatalakestore.net"
            }
}
else {
    $adlStoreSyntax = "abfss://unilever@{dataLakeStoreName}-secondary.dfs.core.windows.net/"
}

$centralAdlStoreNameToken = "{centralDataLakeStoreName}"
$centralAdlStoreName = $parameters.parameters.sharedAdlStoreName.value;

$pslzAdlStoreNameToken = "{pslzDataLakeStoreName}"
$pslzAdlStoreName = $parameters.parameters.pslzStoreName.value;

$adlFileFormatNameToken = "{adlFileFormatName}"
$adlFileFormatName = "ADLS_DELIMITEDTEXT"

$storageAccountNameToken = "{storageAccountName}"
$storageAccountResourceGroupName = $parameters.parameters.storageAccountResourceGroupName.value
$storageAccountName = $parameters.parameters.storageAccountName.value

$storageAccountKeyToken = "{storageAccountKey}"
$storageAccountKeys = Get-AzStorageAccountKey -ResourceGroupName $storageAccountResourceGroupName -Name $storageAccountName
$storageAccountKey = $storageAccountKeys[0].Value

$containerNameToken = "{containerName}"
$containerName = "{0}-store" -f $databaseName

$storageCredentialNameToken = "{AzureStorageCredential}"
$storageCredentialName = $parameters.parameters.storageAccountName.value

$storageDataSourceNameToken = "{AzureStorage}"
$storageDataSourceName = "localStorage"

$storageContext = New-AzStorageContext -StorageAccountName $storageAccountName -StorageAccountKey $storageAccountKey
$context = Get-AzStorageContainer -Name $containerName -Context $storageContext -ErrorAction SilentlyContinue
if (!$context) {
    #Create a new container in the storage account
    Write-Verbose "Container $containerName does not exist. Creating..."
    New-AzStorageContainer -Name $containerName -Context $storageContext -Permission Off
    Write-Verbose "Container $containerName created."
}

$sqlInput = "IF not exists (select * from sys.symmetric_keys where name like '%DatabaseMasterKey%')
CREATE MASTER KEY  ENCRYPTION BY PASSWORD ='{masterKey}' 


if not exists (SELECT * FROM sys.database_CREDENTIALs where name='{credentialName}')
CREATE DATABASE SCOPED CREDENTIAL [{credentialName}]
WITH
    IDENTITY = '{applicationId}@https://login.microsoftonline.com/{tenantId}/oauth2/token',
    SECRET = '{clientSecret}'; 

if not exists (select * from sys.external_data_sources where name='{dataSourceName}')
CREATE EXTERNAL DATA SOURCE [{dataSourceName}] WITH (TYPE = HADOOP, LOCATION = N'$adlStoreSyntax', CREDENTIAL = [{credentialName}])
    
if not exists (select * from sys.external_data_sources where name='adlsCentral')
CREATE EXTERNAL DATA SOURCE [adlsCentral] WITH (TYPE = HADOOP, LOCATION = N'adl://{centralDataLakeStoreName}.azuredatalakestore.net', CREDENTIAL = [{credentialName}])

if not exists (select * from sys.external_file_formats where name='{adlFileFormatName}')
CREATE EXTERNAL FILE FORMAT [{adlFileFormatName}] WITH (FORMAT_TYPE = DELIMITEDTEXT, FORMAT_OPTIONS (FIELD_TERMINATOR = N',', STRING_DELIMITER = N'""', DATE_FORMAT = N'yyyy-MM-dd HH:mm:ss.fff', USE_TYPE_DEFAULT = False))

if not exists (SELECT * FROM sys.database_CREDENTIALs where name='{AzureStorageCredential}')
CREATE DATABASE SCOPED CREDENTIAL [{AzureStorageCredential}]
WITH
    IDENTITY = 'user',
    SECRET = '{storageAccountKey}';

if not exists (select * from sys.external_data_sources where name='{AzureStorage}')
CREATE EXTERNAL DATA SOURCE [{AzureStorage}]
WITH (
    TYPE = HADOOP,
    LOCATION = 'wasbs://{containerName}@{storageAccountName}.blob.core.windows.net',
    CREDENTIAL = [{AzureStorageCredential}]
)
"
#Do not apply the external data source for PSLZ if not selected
if(-not ([string]::IsNullOrEmpty($pslzAdlStoreName)))
{
$sqlPSLZ = "if not exists (select * from sys.external_data_sources where name='adlsPSLZ')
CREATE EXTERNAL DATA SOURCE [adlsPSLZ] WITH (TYPE = HADOOP, LOCATION = N'adl://{pslzDataLakeStoreName}.azuredatalakestore.net', CREDENTIAL = [{credentialName}]);
"
}

$sqlinput = $sqlinput + $sqlPSLZ


$sqlInput = $sqlInput -replace $masterKeyToken, $masterKey
$sqlInput = $sqlInput -replace $credentialNameToken, $credentialName
$sqlInput = $sqlInput -replace $tenantIdToken, $tenantId
$sqlInput = $sqlInput -replace $applicationIdToken, $applicationId
$sqlInput = $sqlInput -replace $clientSecretToken, $clientSecret
$sqlInput = $sqlInput -replace $dataSourceNameToken, $dataSourceName
$sqlInput = $sqlInput -replace $adlStoreNameToken, $adlStoreName
$sqlInput = $sqlInput -replace $centralAdlStoreNameToken, $centralAdlStoreName
$sqlInput = $sqlInput -replace $pslzAdlStoreNameToken, $pslzAdlStoreName
$sqlInput = $sqlInput -replace $adlFileFormatNameToken, $adlFileFormatName
$sqlInput = $sqlInput -replace $storageAccountKeyToken, $storageAccountKey
$sqlInput = $sqlInput -replace $containerNameToken, $containerName
$sqlInput = $sqlInput -replace $storageAccountNameToken, $storageAccountName
$sqlInput = $sqlInput -replace $storageCredentialNameToken, $storageCredentialName
$sqlInput = $sqlInput -replace $storageDataSourceNameToken, $storageDataSourceName

Get-Module -Name SqlPS | Remove-Module
$a = Get-Module -ListAvailable -Name SqlServer
if (-not $a)
{
	Write-Host "installing SqlServer modules: start"
	Install-Module -Name SqlServer -Force -AllowClobber
	Write-Host "installing modules: end"
}

$sqlCmdConnectString="Server=$serverName.database.windows.net;Initial Catalog=$databaseName;Persist Security Info=False;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Authentication=""Active Directory Password"";User ID={0};Password={1}" -f $sqlUser, $sqlPwd
Invoke-SqlCmd -query $sqlInput -ConnectionString $sqlCmdConnectString
