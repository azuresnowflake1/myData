Param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$parameterFile,

    [Parameter(Mandatory = $False)]
    [byte]$alertSeverity=3,

    [Parameter(Mandatory = $False)]
    [bool]$isEnabled=$False,

    [Parameter(Mandatory = $False)]
    [string]$metricName="PipelineFailedRuns",

    [Parameter(Mandatory = $False)]
    [string]$actionGroup="LandscapeActionGroup"
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"
$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

$dataFactoryResourceGroupName = $parameters.parameters.dataFactoryResourceGroupName.value
$dataFactoryName = $parameters.parameters.dataFactoryName.value
$dfMetricAlertsTemplateFile = "$devOpsProjectFolder\Templates\metric.alert.json"
$alertName = $dataFactoryName + "_" + $metricName 
$actionGroupName = $dataFactoryName + "_notification"
$actionGroupSupportEmail = $parameters.parameters.actionGroupSupportEmail.value


$metricResource = Get-AzResource -ResourceGroupName $dataFactoryResourceGroupName `
                                        -Name $dataFactoryName
$metricResourceId = $metricResource.ResourceId

$actionGroupResource = Get-AzResource -ResourceGroupName $dataFactoryResourceGroupName `
                                    -ResourceType "microsoft.insights/actiongroups" `
                                     -Name $actionGroupName `
                                     -ErrorAction SilentlyContinue

if (([string]::IsNullOrEmpty($actionGroupResource.ResourceId)))
{
    Write-output "No action group exists. Creating $($actionGroupName)"
    $actionGroupTemplateFile = "$devOpsProjectFolder\Templates\actiongroup.json"

    New-AzResourceGroupDeployment -Name ActionGroupDeploy `
                                        -ResourceGroupName $dataFactoryResourceGroupName `
                                        -TemplateFile $actionGroupTemplateFile `
                                        -actionGroupName $actionGroupName `
                                        -actionGroupShortName "EcoTurnAG" `
                                        -actionGroupPrimaryEmail $actionGroupSupportEmail | Out-Null

    $actionGroupResource = Get-AzResource -ResourceGroupName $dataFactoryResourceGroupName `
                                    -ResourceType "microsoft.insights/actiongroups" `
                                     -Name $actionGroupName `
                                     -ErrorAction SilentlyContinue
  

}
                     
$actionGroupId = $actionGroupResource.ResourceId
New-AzResourceGroupDeployment -Name AlertDeployment -ResourceGroupName $dataFactoryResourceGroupName `
              -TemplateFile $dfMetricAlertsTemplateFile `
              -alertName $alertName `
              -alertSeverity $alertSeverity `
              -metricName $metricName `
              -resourceId  $metricResourceId `
              -actionGroupId  $actionGroupId | Out-Null

