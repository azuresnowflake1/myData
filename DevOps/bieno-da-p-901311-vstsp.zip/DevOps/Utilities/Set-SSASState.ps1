param(
    [Parameter(Mandatory=$true)] [string]$parameterFile,
    [switch]$Pause,
    [switch]$Resume
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters.ps1" -parameterFile $parameterFile

$subscriptionId = $parameters.parameters.subscriptionId.value

$status = Get-AzAnalysisServicesServer -Name $parameters.parameters.analysisServicesName.value

if($Pause)
{
    Write-Host "Pause, Initiated."
    	
    if($status.state -ne 'Paused')
    {
		Suspend-AzAnalysisServicesServer -Name $parameters.parameters.analysisServicesName.value`
											  -ResourceGroupName $parameters.parameters.analysisServicesResourceGroupName.value
        Write-Host "Azure Analysis Service `"$($parameters.parameters.analysisServicesName.value)`" paused for today."
    }
    else 
    {
         Write-Host "$($parameters.parameters.analysisServicesName.value) is already in `"Pause`" state."
    }
}

if($Resume)
{
    Write-Host "Resume, Initiated."
	
    if($status.state -ne 'Succeeded')
    {
		Resume-AzAnalysisServicesServer -Name $parameters.parameters.analysisServicesName.value`
											  -ResourceGroupName $parameters.parameters.analysisServicesResourceGroupName.value
        Write-Host "Azure Analysis Service `"$($parameters.parameters.analysisServicesName.value)`" resumed for successfuly."
    }
    else 
    {
        Write-Host "$($parameters.parameters.analysisServicesName.value) is already in `"Online`" state."
    }
}