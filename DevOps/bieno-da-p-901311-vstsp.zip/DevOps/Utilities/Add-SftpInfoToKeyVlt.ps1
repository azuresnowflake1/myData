Param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$parameterFile,
    
    [Parameter(Mandatory = $True, HelpMessage='The sftp server host name')]
    [String]$sftpHostName,
    
    [Parameter(Mandatory = $False, HelpMessage='The sftp server host name')]
    [String]$sftpPort=22,

    [Parameter(Mandatory = $True, HelpMessage='The sftp user name')]
    [String]$sftpUsername,

    [Parameter(Mandatory = $True, HelpMessage='The sftp private key file path')]
    [String]$sftpPrivateKeyFilePath,

    [Parameter(Mandatory = $False, HelpMessage='The sftp private key pass phrase')]
    [String]$sftpPassPhrase
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

& "$utilitiesFolder\Test-Login.ps1"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

$sftpHostnameKeyVaultName = $parameters.parameters.sftpHostSecretName.value
$sftpUsernameKeyVaultName = $parameters.parameters.sftpUserSecretName.value
$sftpPrivateKeyContentKeyVaultName = $parameters.parameters.sftpPrivateKeySecretName.value
$sftpPassPhraseKeyVaultName = $parameters.parameters.sftpPassPhraseSecretName.value
$sftpPortKeyVaultName = $parameters.parameters.sftpPortSecretName.value
$secretExpiryYears = $parameters.parameters.keyVaultSecretExpiryTerm.value

if (-not [string]::IsNullOrEmpty($sftpPortKeyVaultName))
{   
    $secureSecret = ConvertTo-SecureString -AsPlainText $sftpPort -Force
    $secretCredential = New-Object System.Management.Automation.PSCredential ($sftpPortKeyVaultName, $secureSecret)
    $contentType = "The port number of an SFTP data source.  Used in an ADF linked service."
    & "$utilitiesFolder\Set-KeyVaultSecret.ps1" -parameterFile $parameterFile -secretCredential $secretCredential -secretExpiryTermYears $secretExpiryYears
}

$secureSecret = ConvertTo-SecureString -AsPlainText $sftpHostName -Force
$secretCredential = New-Object System.Management.Automation.PSCredential ($sftpHostnameKeyVaultName, $secureSecret)
$contentType = "The host name of an SFTP data source.  Used in an ADF linked service."
& "$utilitiesFolder\Set-KeyVaultSecret.ps1" -parameterFile $parameterFile -secretCredential $secretCredential -secretExpiryTermYears $secretExpiryYears -contentType $contentType

$secureSecret = ConvertTo-SecureString -AsPlainText $sftpUsername -Force
$secretCredential = New-Object System.Management.Automation.PSCredential ($sftpUsernameKeyVaultName, $secureSecret)
$contentType = "The user name for accesing an SFTP data source.  Used in an ADF linked service."
& "$utilitiesFolder\Set-KeyVaultSecret.ps1" -parameterFile $parameterFile -secretCredential $secretCredential -secretExpiryTermYears $secretExpiryYears -contentType $contentType

$sftpPrivateKeyContent = [System.Convert]::ToBase64String((Get-Content $sftpPrivateKeyFilePath -Encoding Byte))
$secureSecret = ConvertTo-SecureString -AsPlainText $sftpPrivateKeyContent -Force
$secretCredential = New-Object System.Management.Automation.PSCredential ($sftpPrivateKeyContentKeyVaultName, $secureSecret)
$contentType = "The SFTP private key for accesing an SFTP data source.  Used in an ADF linked service."
& "$utilitiesFolder\Set-KeyVaultSecret.ps1" -parameterFile $parameterFile -secretCredential $secretCredential -secretExpiryTermYears $secretExpiryYears -contentType $contentType

if ($sftpPassPhrase -eq "")
{
    Write-Error "Unilver doesn't support certificate authetnication without a passphrase.  Create a new certificate."
    return
}
$secureSecret = ConvertTo-SecureString -AsPlainText $sftpPassPhrase -Force
$secretCredential = New-Object System.Management.Automation.PSCredential ($sftpPassPhraseKeyVaultName, $secureSecret)
$contentType = "The pass phrase for an SFTP private key.  Used in an ADF linked service."
& "$utilitiesFolder\Set-KeyVaultSecret.ps1" -parameterFile $parameterFile -secretCredential $secretCredential -secretExpiryTermYears $secretExpiryYears -contentType $contentType
