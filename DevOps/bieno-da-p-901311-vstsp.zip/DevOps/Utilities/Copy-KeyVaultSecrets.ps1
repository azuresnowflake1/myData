param(
    [Parameter(Mandatory=$true)] [string]$parameterFile,
    [Parameter(Mandatory=$true)] [string]$parameterFileTarget,
	[Parameter(Mandatory=$false)] [switch]$excludeCert,
	[Parameter(Mandatory=$false)] [switch]$excludeAppSPN,
	[Parameter(Mandatory=$false)] [switch]$excludeDeploySPN,
	[Parameter(Mandatory=$false)] [switch]$excludeSqlServer,
	[Parameter(Mandatory=$false)] [switch]$excludeHDI
)
# Copy the secrets from one key vault to another
# This script supports two scenarios:
#  - DR: Here we want to copy all keys to a new target environment that will function as if it is an identical copy of the source environment
#  - Replicate: Here we are aiming to provide a way to pull prod setting into a lower testing environment like PPD or UAT.  
# 	 In this scenario we need to exclude all environment specific credentials from the source key vault because we need to 
# 	 retain the environment specific credentials that have permissions in the target environment. E.g. SPN, sqladmin, clsadmin etc.
#
# ################# Usage #######################################################
#  DR: Create a DR keyvault for UDL prod in UDL PPD
#  Call like this: .\DevOps\Utilities\Copy-KeyVaultSecrets.ps1 -parameterFile parameters.p.80010.json -parameterFileTarget parameters.u.80016.json
#################################################################################
# Replicate: Sync UDL Prod into UDL UAT
# Call like this: .\DevOps\Utilities\Copy-KeyVaultSecrets.ps1 -parameterFile parameters.p.80010.json -parameterFileTarget parameters.u.80016.json -excludeCert -excludeAppSPN -excludeDeploySPN -excludeSqlServer -excludeHDI -Verbose

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

if ($parameterFile -eq $parameterFileTarget)
{
	Write-Error "You cannot copy secrets to and from the same key vault."
	return
}

$parameters = & "$utilitiesFolder\Get-Parameters.ps1" -parameterFile $parameterFile
$parametersT = & "$utilitiesFolder\Get-Parameters.ps1" -parameterFile $parameterFileTarget

[System.Collections.ArrayList]$exclude = @("DatabricksAccessToken","mcsConnectionString")
$tokenSecretName = $parameters.parameters.databricksTokenSecretName.value
if ($tokenSecretName -and $tokenSecretName -ne "DatabricksAccessToken")
{
    $i=$exclude.Add($tokenSecretName)
}
if ($excludeCert)
{
	$i=$exclude.Add($parameters.parameters.applicationIdentityCertificateName.value);
	$applicationIdentityCertificatePassword = "{0}-Password" -f $parameters.parameters.applicationIdentityCertificateName.value
	$i=$exclude.Add($applicationIdentityCertificatePassword)
}
if ($excludeSqlServer)
{
	$databaseServerName = $parameters.parameters.sqlServerName.value;

	$masterKeyName = "{0}-MasterKey" -f $databaseServerName
	$i=$exclude.Add($masterKeyName);
}
if ($excludeAppSPN)
{
	$i=$exclude.Add($parameters.parameters.applicationId.value);
	$i=$exclude.Add($parameters.parameters.adApplicationName.value);
}
if ($excludeDeploySPN)
{
	$i=$exclude.Add($parameters.parameters.deploymentApplicationId.value);
}
if ($excludeHDI)
{
	$i=$exclude.Add($parameters.parameters.clusterAdminLogin.value);
	$i=$exclude.Add($parameters.parameters.clusterSSHUserName.value);
}


$rgName = $parameters.parameters.keyVaultResourceGroupName.value;
$kvName = $parameters.parameters.keyVaultName.value;

$rgNameT = $parametersT.parameters.keyVaultResourceGroupName.value;
$kvNameT = $parametersT.parameters.keyVaultName.value;

$secrets = Get-AzKeyVaultSecret -VaultName $kvName
foreach($secret in $secrets)
{
	$secret = Get-AzKeyVaultSecret -VaultName $kvName -Name $secret.Name
	$keyName = $secret.name
	#$keyValue = ConvertTo-SecureString -AsPlainText $secret.SecretValueText -Force
	$keyValue = $secret.SecretValue
	if (-not $exclude.Contains($keyName)) {
		Write-Host "Adding secret $keyName to $kvNameT"
		$secretCredential = New-Object System.Management.Automation.PSCredential ($keyName, $keyValue)
		if ($secret.Expires) {
			& "$utilitiesFolder\Set-KeyVaultSecret.ps1" -parameterFile $parameterFileTarget -secretCredential $secretCredential -updateSecret $true -secretExpiryDate $secret.Expires -contentType $secret.ContentType
		} else {
			& "$utilitiesFolder\Set-KeyVaultSecret.ps1" -parameterFile $parameterFileTarget -secretCredential $secretCredential -updateSecret $true -secretExpiryTermYears 2 -contentType $secret.ContentType
		}
	}
	else {
		Write-Host "Skipping secret $keyName"
	}
	
}
Write-Host "Secret copy is completed."