Param
(
    [Parameter(Mandatory = $True, HelpMessage = 'Specify the parameter file')]
    [String]$parameterFile,

    [Parameter(Mandatory = $True, HelpMessage = 'Specify to override file for the MCS installation in the UDL')]
    [String]$overrideParameterFile,

    [Parameter(Mandatory = $False, HelpMessage = 'Specify to container name for the MCS custom activity installation in the local batch')]
    [String]$containerName = "azurebatch"

)

# Install ADF linked services for the MCS framework hosted in the UDL resource groups
Write-Verbose "PSScriptRoot is: $PSScriptRoot"
$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
Write-Verbose "DevOps Project Folder: $devOpsProjectFolder"
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"
$mcsFolder = "{0}\{1}" -f $devOpsProjectFolder, "Mcs"

$targetParameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile
$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile -overrideFile $overrideParameterFile
$parameterFileName = & "$utilitiesFolder\Get-ParametersFileName" -parameterFile $parameterFile -overrideFile $overrideParameterFile

$subscriptionId = $parameters.parameters.subscriptionId.value
$tenantId = $parameters.parameters.tenantId.value
$applicationId = $parameters.parameters.deploymentApplicationId.value

# Can't call Set-DataFactory here because the ADF might be in a different subscription to the MCS UDL components
Function CreateSqlLinkedService {
    param
    (
        # Parameter help description
        [String]$databaseName,
        [String]$type,
        [String]$name
    )

    $sourcePath = "$devOpsProjectFolder\DataFactoryV2\sql.json"
    $sinkSqlLinkedService = Get-Content -Path $sourcePath -Raw | ConvertFrom-JSON
    
    $sqlServerName = $parameters.parameters.sqlServerName.value    
    $sqlServerUserLogin = "sqldfuser"
    
    $keyVaultName = $parameters.parameters.keyVaultName.value
    $secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $sqlServerUserLogin
    $sqlServerUserPassword = $secret.SecretValueText
    
    $connectionString = "Data Source=tcp:{0}.database.windows.net,1433;Initial Catalog={1};User ID={2};Password={3};Integrated Security=False;Encrypt=True;Connect Timeout=30" `
        -f $sqlServerName, $databaseName, $sqlServerUserLogin, $sqlServerUserPassword
    
    # Add the password to the target env key fault
    $targetKeyVaultName = $targetParameters.parameters.keyVaultName.value
    $keyValue = ConvertTo-SecureString -AsPlainText $connectionString -Force
    $keyVaultSecretExpiryTerm = $parameters.parameters.keyVaultSecretExpiryTerm.value
    $keyVaultSecretExpiry = (Get-Date).AddYears($keyVaultSecretExpiryTerm)
    $secretCredential = New-Object System.Management.Automation.PSCredential ("mcsConnectionString", $keyValue)
    $contentType = "The SQL connection string that connects to the MCS Azure SqlDB."
    $kyvlt = Set-AzKeyVaultSecret -VaultName $targetKeyVaultName -Name $secretCredential.UserName -SecretValue $secretCredential.Password -Expires $keyVaultSecretExpiry -contentType $contentType
    
    $sinkSqlLinkedService.properties.typeProperties.connectionString.value = $connectionString
    $sinkSqlLinkedService.name = $name
    $sinkSqlLinkedService.properties.type = $type

    $destinationPath = New-TemporaryFile
    Write-Verbose "Writing $destinationPath with link service details"

    $sinkSqlLinkedService | ConvertTo-JSON -Depth 10 | Out-File -filepath $destinationPath -Force

    return $destinationPath
}

$sub = Select-AzSubscription -SubscriptionId $subscriptionId
Write-Verbose "Subscription Id: $($sub.Subscription.SubscriptionId)"
Write-Verbose "TenantId Id: $($sub.Subscription.TenantId)"
Write-Verbose "Account Id: $($sub.Account.Id)"

$dataFactoryResourceGroupName = $parameters.parameters.dataFactoryResourceGroupName.value 
$dataFactoryName = $parameters.parameters.dataFactoryName.value
$storageAccountName = $parameters.parameters.storageAccountName.value
$storageAccountResourceGroupName = $parameters.parameters.storageAccountResourceGroupName.value

$batchAccountResourceGroupName = $parameters.parameters.batchAccountResourceGroupName.value
$batchAccountName = $parameters.parameters.batchAccountName.value
$name = $parameters.parameters.batchAccountLinkedServiceName.value

 Write-Output "Creating ADF linked service to MCS SQLDb"
 Write-Verbose "Generating SQL linked service configuration"
 $sqlDatabaseName = $parameters.parameters.sqlDatabaseName.value
 $name = $parameters.parameters.sqlDatabaseLinkedServiceName.value
 $type = "AzureSqlDatabase"
 $tempSqlConfigFile = CreateSqlLinkedService -databaseName $sqlDatabaseName -type $type -name $name
 Write-Verbose "Creating Sql database linked service configuration"
 $depl = Set-AzDataFactoryV2LinkedService -ResourceGroupName  $dataFactoryResourceGroupName `
 -DataFactoryName $dataFactoryName -Name $name -DefinitionFile $tempSqlConfigFile -Force

 if (-not (Get-AzBatchAccount -AccountName $batchAccountName -ResourceGroupName $batchAccountResourceGroupName -ErrorAction SilentlyContinue))
 {
    Write-Output "Creating the Batch Account"
    & "$utilitiesFolder\New-Resources.ps1" -parameterFile $parameterFile -Batch
 }
Write-Output "Creating ADF linked service to the local batch account"
& "$utilitiesFolder\Set-DataFactory.ps1" -parameterFile $parameterFile -Batch

Write-Verbose "Deploying the MCS custom activity"
Write-Output "Deploying the MCS custom activity"

& "$utilitiesFolder\Deploy-McsToStorageContainer" -parameterFile $parameterFile -containerName $containerName

Remove-Item (Join-Path -Path $devOpsProjectFolder -ChildPath $parameterFileName) -Force -ErrorAction SilentlyContinue
Write-Output "MCS framework installation complete"