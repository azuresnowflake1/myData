param
(
    [Parameter(Mandatory = $True, HelpMessage = 'Specify the parameter file')]
    [String]$parameterFile,

    [Parameter(Mandatory = $True, HelpMessage = 'The personal access token used to authorize vsts requests')]
    [String]$personalAccessToken
)

$teamProjectProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $teamProjectProjectFolder, "Utilities"
$parameters = & "$utilitiesFolder\Get-Parameters.ps1" -parameterFile $parameterFile

$vstsAccountName = $parameters.parameters.vstsAccountName.value
$vstsTeamProjectName = $parameters.parameters.vstsTeamProjectName.value

$patString = "{0}:{1}" -f "", $personalAccessToken
$base64PatString = [System.Convert]::ToBase64String([System.Text.Encoding]::ASCII.GetBytes($patString))
try {
    $vstsURL = "https://{0}.visualstudio.com/DefaultCollection/{1}/_apis/distributedtask/queues?api-version=3.0-preview.1" -f $vstsAccountName, $vstsTeamProjectName
    $params = @{    
        ContentType = 'application/json'
        Headers     = @{
            'Authorization' = "Basic $base64PatString"
        }
        Method      = 'Get'    
        URI         = $vstsURL
    }
    Write-Verbose "Getting the queue definitions for team project $vstsTeamProjectName"
    $authZResponse = Invoke-RestMethod @params
    return $authZResponse
}
catch {
    throw
}