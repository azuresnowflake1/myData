Param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$parameterFile,
    [Parameter(Mandatory = $True, HelpMessage='Specify the name of the RBAC role')]
    [String]$roleName,
    [Parameter(Mandatory = $True, HelpMessage='Specify the object id of the grantee')]
    [String]$granteeObjectId,
    [Parameter(Mandatory = $True, ParameterSetName = 'resourceGroup', HelpMessage='Specify to grant permission at resource group')]
    [switch]$resourceGroup,
    [Parameter(Mandatory = $False, ParameterSetName = 'adls', HelpMessage='Specify to grant permission on the adls')]
    [switch]$adls,
    [Parameter(Mandatory = $False, ParameterSetName = 'storage', HelpMessage='Specify to grant permission on the storage account')]
    [switch]$storageAccount,
    [Parameter(Mandatory = $False, ParameterSetName = 'storage', HelpMessage='Specify to grant permission on the storage account')]
    [switch]$dataBricks,
    [Parameter(Mandatory = $False, ParameterSetName = 'functionApp', HelpMessage='Specify to grant permission on a function app')]
    [switch]$functions,
    [Parameter(Mandatory = $False, ParameterSetName = 'appServicePlan', HelpMessage='Specify to grant permission on app service plan')]
    [switch]$appServicePlan,
    [Parameter(Mandatory = $False, ParameterSetName = 'WebApp', HelpMessage='Specify to grant permission on web app')]
    [switch]$WebApp,
    [Parameter(Mandatory = $False, ParameterSetName = 'LogicAppO365apiConnection', HelpMessage='Specify to grant permission on LogicApp O365apiConnection')]
    [switch]$logicAppO365apiConnection,
    [Parameter(Mandatory = $False, ParameterSetName = 'logicAppDatalakeapiConnection', HelpMessage='Specify to grant permission on LogicApp DatalakeapiConnection')]
    [switch]$logicAppDatalakeapiConnection,
    [Parameter(Mandatory = $False, ParameterSetName = 'logicAppSqlDWapiConnection', HelpMessage='Specify to grant permission on LogicApp SqlDWapiConnection')]
    [switch]$logicAppSqlDWapiConnection,
    [Parameter(Mandatory = $False, ParameterSetName = 'logicAppSqlapiConnection', HelpMessage='Specify to grant permission on LogicApp SqlapiConnection')]
    [switch]$logicAppSqlapiConnection,
    [Parameter(Mandatory = $False, ParameterSetName = 'logicAppMonitorLogapiConnection', HelpMessage='Specify to grant permission on LogicApp MonitorLogsapiConnection')]
    [switch]$logicAppMonitorLogapiConnection,
    [Parameter(Mandatory = $False, ParameterSetName = 'logicAppadlsgen2apiConnection', HelpMessage='Specify to grant permission on LogicApp adlsgen2apiConnection')]
    [switch]$logicAppadlsgen2apiConnection,
    [Parameter(Mandatory = $False, ParameterSetName = 'LogicApp', HelpMessage='Specify to grant permission on LogicApp')]
    [switch]$LogicApp,
    [Parameter(Mandatory = $False, ParameterSetName = 'LogAnalytics', HelpMessage='Specify to grant permission on LogAnalytics')]
    [switch]$LogAnalytics
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

$appResourceGroupName = $parameters.parameters.dataFactoryResourceGroupName.value

if ($resourceGroup)
{
    $resourceName = $appResourceGroupName
    $resource = Get-AzResourceGroup -Name $resourceName  
    $assignment = Get-AzRoleAssignment -ResourceGroupName $appResourceGroupName -RoleDefinitionName $roleName -ObjectId $granteeObjectId  
    if (-not $assignment) {
        New-AzRoleAssignment -ResourceGroupName $appResourceGroupName -RoleDefinitionName $roleName -ObjectId $granteeObjectId  
    } else {
        Write-Verbose "Role assignment already exists for $roleName on object $resourceName."
    }
    return
} elseif ($adls) { 
    $resourceName = $parameters.parameters.adlStoreName.value
    $resource = Get-AzResource -Name $resourceName  
} elseif ($storageAccount) {
    $resourceName = $parameters.parameters.storageAccountName.value
    $resource = Get-AzResource -Name $resourceName  
} elseif ($dataBricks) {
    $resourceName = $parameters.parameters.databricksWorkspaceName.value
    $resource = Get-AzResource -Name $resourceName  
} elseif ($functions) {
    $resourceName = $parameters.parameters.functionAppName.value
    $resource = Get-AzResource -Name $resourceName  
} elseif ($WebApp) {
    $resourceName = $parameters.parameters.webAppName.value
    $resource = Get-AzResource -Name $resourceName  
} elseif ($appServicePlan) {
    $resourceName = $parameters.parameters.appServicePlanName.value
    $resource = Get-AzResource -Name $resourceName  
} elseif ($logicAppO365apiConnection) {
    $resourceName = $parameters.parameters.logicAppO365apiConnection.value
    $resource = Get-AzResource -Name $resourceName  
} elseif ($logicAppDatalakeapiConnection) {
    $resourceName = $parameters.parameters.logicAppDatalakeapiConnection.value
    $resource = Get-AzResource -Name $resourceName  
} elseif ($logicAppMonitorLogapiConnection) {
    $resourceName = $parameters.parameters.azuremonitorlogs_name.value
    $resource = Get-AzResource -Name $resourceName  
} elseif ($logicAppadlsgen2apiConnection) {
    $resourceName = $parameters.parameters.apiconnection_adlsgen2_name.value
    $resource = Get-AzResource -Name $resourceName  
} elseif ($logicAppSqlDWapiConnection) {
    $resourceName = $parameters.parameters.logicAppSqlDWapiConnection.value
    $resource = Get-AzResource -Name $resourceName  
} elseif ($logicAppSqlapiConnection) {
    $resourceName = $parameters.parameters.logicAppSqlapiConnection.value
    $resource = Get-AzResource -Name $resourceName  
} elseif ($LogicApp) {
    $resourceName = $parameters.parameters.logicAppName.value
    $resource = Get-AzResource -Name $resourceName  
} elseif ($LogAnalytics) {
    $resourceName = $parameters.parameters.logAnalyticsWorkspaceName.value
    $resource = Get-AzResource -Name $resourceName  
}


# Set a component level permissions
$assignment = Get-AzRoleAssignment -ResourceGroupName $appResourceGroupName -ResourceName $resourceName -RoleDefinitionName $roleName -ResourceType $resource.ResourceType -ObjectId $granteeObjectId  
if (-not $assignment) {
    New-AzRoleAssignment -ResourceGroupName $appResourceGroupName -ResourceName $resourceName -RoleDefinitionName $roleName -ResourceType $resource.ResourceType -ObjectId $granteeObjectId  
} else {
    Write-Verbose "Role assignment already exists for $roleName on object $resourceName."
}
