Param
(
    [Parameter(Mandatory = $True, HelpMessage = 'Specify the parameter file')]
    [String]$parameterFile,

    [Parameter(HelpMessage = 'Specify to name of the adf pipeline')]
    [String]$pipelineName,

    [Parameter(HelpMessage = 'Specify a description of the adf pipeline')]
    [String]$pipelineDescription,

    [Parameter(HelpMessage = 'Specify to configue the name of the web activity that will call the webhook')]
    [String]$activityName,

    [Parameter(HelpMessage = 'Specify the webhook to call')]
    [String]$webhookUrl,

    [Parameter(HelpMessage = 'Specify the webhook expression that will pass values to the webhook')]
    [String]$webhookExpression="@concat(pipeline().DataFactory,',',pipeline().RunId,',','')",

    [Parameter(HelpMessage = 'Specify the json template file name')]
    [String]$pipelineTemplate="pipeline.webhook.json"
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

Function New-TemporaryFile() {
    return [System.IO.Path]::GetTempFileName()
}

Function CreateWebhookPipeline {
    param
    (
        # Parameter help description
        [String]$pName,
        [String]$aName,
        [String]$url,
        [String]$callback
    )
   
    $sourcePath = "$devOpsProjectFolder\DataFactoryV2\$pipelineTemplate"
    $pipeline = Get-Content -Path $sourcePath -Raw | ConvertFrom-JSON

    $pipeline.name = $pName
    $pipeline.properties.description = $pipelineDescription
    $pipeline.properties.activities[0].name = $aName
    $pipeline.properties.activities[0].typeProperties.url = $url
    $pipeline.properties.activities[0].typeProperties.body.value = $webhookExpression
    
    $destinationPath = New-TemporaryFile
    Write-Verbose "Writing $destinationPath with link service details"
    $pipeline | ConvertTo-JSON -Depth 10 | Out-File -filepath $destinationPath -Force
    return $destinationPath
}

# Create Linked Services
$dataFactoryResourceGroupName = $parameters.parameters.dataFactoryResourceGroupName.value 
$dataFactoryName = $parameters.parameters.dataFactoryName.value

$df = Get-AzDataFactoryV2 -ResourceGroupName $dataFactoryResourceGroupName -Name $dataFactoryName -ErrorAction SilentlyContinue
if (-not $df) {
    throw "Data Factory '$dataFactoryName' does not exist. Please create it first."
}
$filePath = CreateWebhookPipeline -pName $pipelineName -aName $activityName -url $webhookUrl
Set-AzDataFactoryV2Pipeline -ResourceGroupName $dataFactoryResourceGroupName -Name $pipelineName -DataFactoryName $DataFactoryName -File "$filePath" -Force
