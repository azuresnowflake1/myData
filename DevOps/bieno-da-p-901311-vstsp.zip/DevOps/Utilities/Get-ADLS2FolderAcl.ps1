[CmdletBinding()]
Param(
    [Parameter(Mandatory = $true, Position = 1)] [string] $parameterFile,
    [Parameter(Mandatory = $True, Position = 2)] [string] $path,
    [Parameter(Mandatory = $True, Position = 4)] [string] $bearerToken,
    [Parameter(Mandatory = $false, Position = 6)] [string] $fileSystemName="unilever"
)
# Rest documentation:
# https://docs.microsoft.com/en-gb/rest/api/storageservices/datalakestoragegen2/path/update

# Set the acl for a specified path.  Note that the list replaces the existing list.
# ACL string format is defined in the REST doc link above.  It is set in the header against x-ms-acl
$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile


# our default ACLs assume the ADLS file system was provisioned using the deployment SPN
function Get-DefaultAcls {
    Param(
    [string] $objectId
)
    #[scope:][type]:[id]:[permissions]
    $aclFormat = "{0}{1}:{2}:{3}"
    $acl = @()

    $acl += $aclFormat -f "", "user","" , "rwx"
    $acl += $aclFormat -f "", "group", "" , "r-x"
    $acl += $aclFormat -f "", "other", "", "---"

    return $acl
}

$method = "HEAD"

$headers = @{ } 
$headers.Add("x-ms-version", "2018-11-09")
$headers.Add("Authorization", "Bearer $BearerToken")
$headers.Add("x-ms-client-request-id", [guid]::NewGuid())

$path = (Join-Path -Path $fileSystemName -ChildPath $path).Replace("\", "/").Trim('\','/')
$URI = "https://$($parameters.parameters.adlStoreName.value).dfs.core.windows.net/" + $path + "?action=getAccessControl&upn=true"

try {
    $response=Invoke-WebRequest -method $method -Uri $URI -Headers $headers
    
    $response.Headers["x-ms-acl"]
    
}
catch {
    $ErrorMessage = $_.Exception.Message
    $StatusDescription = $_.Exception.Response.StatusDescription

    Throw $ErrorMessage + " " + $StatusDescription + " ACLPath: $path"
}