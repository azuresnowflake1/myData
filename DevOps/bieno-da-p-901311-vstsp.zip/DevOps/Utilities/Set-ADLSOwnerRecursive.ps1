param
(
    [Parameter(Mandatory=$true)]
    [string] $Account,
    [Parameter(Mandatory=$true)]
    [string] $Path
)
$accessAdminId="f92ec80e-b162-4d16-8cca-f25bedd9dd65"
$SpnIds = @{
    b="3e9178b0-66c6-4ca1-8533-69abfc064d43";
    p="9476af04-a285-4283-95df-1fd9602c68db";
    q="ccaa51f9-ede7-4bf3-9f29-445ec3fb7edd";
    d="ee7700fe-de1b-49b7-a51e-ff47d68a6d91";
    u="bd4aa67f-b14a-4758-8a67-a2d134e1b7cf";
}

# For BDL use landscape's SPN for everything
$SpnIds["d"] = "d3bac756-b523-45d2-8f1a-70adec30faf9"
$SpnIds["q"] = "d3bac756-b523-45d2-8f1a-70adec30faf9"
$SpnIds["u"] = "d3bac756-b523-45d2-8f1a-70adec30faf9"
$SpnIds["b"] = "d3bac756-b523-45d2-8f1a-70adec30faf9"
$SpnIds["p"] = "d3bac756-b523-45d2-8f1a-70adec30faf9"

$env = [string]$Account[7]

function enumerate
{
    param
    (
        [Parameter(Mandatory=$true)]
        [string] $Account,
        [Parameter(Mandatory=$true)]
        [string] $Path
    )

    $itemList = Get-AdlStoreChildItem -Account $Account -Path $Path
    foreach($item in $itemList)
    {
        $childPath = Join-Path -Path $Path -ChildPath $item.PathSuffix
        $Count=($item.path.ToCharArray()|Where-Object{$_-eq'/'}|Measure-Object).Count 

        if ($item.Type -ieq "DIRECTORY" -and $Count -le 4 -and -not($childPath.Contains("\_copy")))
        {
             $childPath
             #$groupName = 'SEC-ES-DA-p-56728-landscape'
             #$groupId = Get-AzADGroup -DisplayName $groupName
             #Get-AzDataLakeStoreItemOwner -AccountName $Account -Path $childPath -Type Group
             #Get-AzDataLakeStoreItemOwner -AccountName $Account -Path $childPath -Type User
             enumerate -Account $Account -Path $childPath 
             #Set-AzDataLakeStoreItemOwner -Account $Account -Path $childPath -Type Group -Id $accessAdminId
             Set-AzDataLakeStoreItemOwner -Account $Account -Path $childPath -Type User -Id $SpnIds[$env]
             
       }
    }
}
$Path
#Get-AzDataLakeStoreItemOwner -AccountName $Account -Path $path -Type Group -erroraction Stop
#Get-AzDataLakeStoreItemOwner -AccountName $Account -Path $path -Type User
#Set-AzDataLakeStoreItemOwner -Account $Account -Path $path -Type Group -Id $accessAdminId

Set-AzDataLakeStoreItemOwner -Account $Account -Path $path -Type User -Id $SpnIds[$env]
enumerate -Account $Account -Path $Path 
#Set-AzDataLakeStoreItemOwner -Account $Account -Path "/Unilever/" -Type User -Id $SpnIds[$env]
#Set-AzDataLakeStoreItemOwner -Account $Account -Path "/" -Type User -Id $SpnIds[$env]