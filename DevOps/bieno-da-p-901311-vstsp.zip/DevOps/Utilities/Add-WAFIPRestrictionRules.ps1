param
(
    [string]$parameterFile, 
    [string]$JsonRuleFile
)

# Deploy the SAAS Cubes *.xmla in a specified folder using a SSAS admin username/Password
$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

$ApiVersions = Get-AzResourceProvider -ProviderNamespace Microsoft.Web |
    Select-Object -ExpandProperty ResourceTypes |
    Where-Object ResourceTypeName -eq 'sites' |
    Select-Object -ExpandProperty ApiVersions

$LatestApiVersion = $ApiVersions[0]

$rules = Get-Content -Path "$utilitiesFolder\$JsonRuleFile" -Raw | ConvertFrom-JSON

foreach ($rule in $rules.rules)
{
    $WebAppConfig = Get-AzResource -ResourceType 'Microsoft.Web/sites/config' -ResourceName $parameters.parameters.webAppName.value -ResourceGroupName $parameters.parameters.webAppResourceGroupName.value -ApiVersion $LatestApiVersion

    if(($WebAppConfig.Properties.ipSecurityRestrictions.ipAddress).Contains($rule.ipAddress)){
        Write-Warning "Rule for IP Range $($rule.ipAddress) already exist"
        continue
    }    
    $ruleObj = [PSCustomObject]@{
        ipAddress = "$($rule.ipAddress)"
        action = "$($rule.action)"
        priority = [int]$($rule.priority)
        name = "$($rule.name)"
        description = "$($rule.description)"
    }

    #Write-Host $ruleObj
    $WebAppConfig.Properties.ipSecurityRestrictions =  $WebAppConfig.Properties.ipSecurityRestrictions + @($ruleObj)
    Set-AzResource -ResourceId $WebAppConfig.ResourceId -Properties $WebAppConfig.Properties -ApiVersion $LatestApiVersion -Force
}
