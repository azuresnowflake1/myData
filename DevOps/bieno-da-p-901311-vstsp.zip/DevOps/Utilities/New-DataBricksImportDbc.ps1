Param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$parameterFile,
    [Parameter(Mandatory = $True, HelpMessage='Specify the full path to the dbc file')]
    [String]$sourceFilePath,
    [Parameter(Mandatory = $True, HelpMessage='Specify the workspace folder path that will be the root of the import')]
    [String]$targetWorkspacePath="/Shared/Deploy",
    [Parameter(Mandatory = $False, HelpMessage='Specify to force folder overwrite.  If the folder exists and this is not specified an error will occur')]
    [switch]$overwriteExisting
)
# Import a single dbc file into a work space folder.  If the target folder doesn't exist, create it
# You can only use this to import into a user defined sub folder.  Recommendation is to do it below Shared/
# DON'T USE THIS FOR SOURCE FILES.  ONLY SUPPORTS DBC

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

$subscriptionId = $parameters.parameters.subscriptionId.value
$tenantId = $parameters.parameters.tenantId.value
$keyVaultName = $parameters.parameters.keyVaultName.value
$adlsName = $parameters.parameters.adlStoreName.value
$region=$parameters.parameters.location.value.Replace(" ", "")

$tokenSecretName = $parameters.parameters.databricksTokenSecretName.value
if (-not $tokenSecretName)
{
    $tokenSecretName = "DatabricksAccessToken"
}
$secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $tokenSecretName -ErrorAction SilentlyContinue
$accessToken = $secret.SecretValueText

$uriBase = "https://$region.azuredatabricks.net/api/2.0"

add-type @"
using System.Net;
using System.Security.Cryptography.X509Certificates;
public class TrustAllCertsPolicy : ICertificatePolicy {
    public bool CheckValidationResult(
        ServicePoint srvPoint, X509Certificate certificate,
        WebRequest request, int certificateProblem) {
        return true;
    }
}
"@
$AllProtocols = [System.Net.SecurityProtocolType]'Ssl3,Tls,Tls11,Tls12'
[System.Net.ServicePointManager]::SecurityProtocol = $AllProtocols

$targetDirectory = $targetWorkspacePath -replace "\\", "/"
$fileName = Split-Path -Path $sourceFilePath -Leaf
$a=($fileName -split "\.")

$extension = $a[1]
if ($extension -ne "dbc") {
    # assume is a source file.  
    Write-Error "You cannot use this script to import files with extension '$extension' use New-DataBricksImportSourceFile.ps1"
    return
}
function Get-Directory {
    param( [string]$path)
    # list the folders in the parent folder and look for a match
    $head = @{authorization = "Bearer $accessToken" }
    $path = $path -replace "\\", "/"
    $parentPath = Split-Path -Path $path -Parent
    $parentPath = $parentPath -replace "\\", "/"

    $uri = "$uriBase/workspace/list?path=$parentPath"
    $directories = Invoke-RestMethod -Uri $uri -Method 'GET' -Headers $head -ContentType "application/json"
    if ($directories)
    {
        foreach($dir in $directories.objects)
        {
            if ($dir.object_type -eq "DIRECTORY" -and $dir.path -eq $path){
                Write-Output "Target workspace directory '$path' already exists."
                return $dir
            }
        }
    }
    return $null
}
function New-Directory {
    param( [string]$path="/")
        $path = $path -replace "\\", "/"
        $uri = "$uriBase/workspace/mkdirs"
        $head = @{authorization = "Bearer $accessToken" }
        $body = @"
    {
        "path": "$path"
    }
"@

    Invoke-RestMethod -Uri $uri -Body $Body -Method 'POST' -Headers $head -ContentType "application/json"
}

function Remove-Directory {
    param( [string]$path="/")
        $uri = "$uriBase/workspace/delete"
        $head = @{authorization = "Bearer $accessToken" }
        $body = @"
    {
        "path": "$path",
        "recursive": true
    }
"@
    Invoke-RestMethod -Uri $uri -Body $Body -Method 'POST' -Headers $head -ContentType "application/json"
}
function New-ImportDbc {
    param( [string]$path="/", [string]$ifile="")
        $uri = "$uriBase/workspace/import"
        $head = @{authorization = "Bearer $accessToken" }
    
        $BinaryContents = [System.IO.File]::ReadAllBytes("$ifile")
        $EncodedContents = [System.Convert]::ToBase64String($BinaryContents)
       
            $Body = @"
    {
        "format": "DBC",
        "content": "$EncodedContents",
        "path": "$path"
    }
"@
    $params = @{    
        ContentType = 'application/json'
        Headers = $head
        body = $body
        Method = 'Post'    
        URI = $uri
    }
    Invoke-RestMethod -Uri $uri -Body $Body -Method 'POST' -Headers $head -ContentType "application/json"
}

$path = "\"
$parentDirectory = Split-Path -Path $targetDirectory -Parent 
$pathParts = $parentDirectory.Split("\\")

$targetExists=$True

# Make sure the target folder exists
foreach($target in $pathParts)
{
    $path = Join-Path -Path $path -ChildPath $target
    if($path -ne "\" -and -not (Get-Directory -path $path))
    {
        $targetExists=$False
        Write-Verbose "Creating target folder $path for dbc deployment"
        Write-Output "Creating target folder $path for dbc deployment"
        New-Directory -path $path
    }
}
$existingDir = Adb-Get-Directory -path $targetDirectory
if ($overwriteExisting -and ($existingDir) -and $targetExists) {
    Write-Output "Overwriting existing workspace folder '$targetDirectory'"
    Remove-Directory -path $targetDirectory
} elseif (-not $overwriteExisting -and ($existingDir) -and $targetExists) {
    Write-Error "The specified workspace directory already exists. Pass the overwriteExisting switch to force the deployment to existing folder '$targetDirectory'"
    Write-Output "Deploy dbc file to Databrick failed"
    return
}
New-ImportDbc -path $targetWorkspacePath -ifile $sourceFilePath
    
    

