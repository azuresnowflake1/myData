param
(
    [Parameter(Mandatory=$true)]
    [string] $Account,
    [Parameter(Mandatory=$true)]
    [string] $Path
)

function enumerate
{
    param
    (
        [Parameter(Mandatory=$true)]
        [string] $Account,
        [Parameter(Mandatory=$true)]
        [string] $Path
    )
    
    $returnList = @()

    $itemList = Get-AdlStoreChildItem -Account $Account -Path $Path

    foreach($item in $itemList)
    {
        $childPath = Join-Path -Path $Path -ChildPath $item.PathSuffix
        $childPath = $childPath.Replace("\", "/");

        $returnList += $childPath
        $charCount = ($item.path.ToCharArray() | Where-Object {$_ -eq '/'} | Measure-Object).Count 
        if ($item.Type -ieq "DIRECTORY" -and $charCount -ne 6)
        {
            enumerate -Account $Account -Path $childPath 

        }

    }

    return $returnList
}

try
{   
    Write-Warning "Please do not close this PowerShell window. Output will be provided at the end."

    return (enumerate -Account $Account -Path $Path)
}
catch
{
    Write-Error "Operation failed with the following error: $($error[0])"
}