Param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$parameterFile,
    [Parameter(Mandatory = $True, HelpMessage='Specify the source directory path')]
    [String]$sourceDirectoryPath,
    [Parameter(Mandatory = $True, HelpMessage='Specify the target directory path for the file to be imported into')]
    [String]$targetWorkspacePath="/Shared",
    [Parameter(Mandatory = $False, HelpMessage='Specify to force file overwrite.  If the file exists and this is not specified an error will occur')]
    [switch]$overwriteExisting=$False,
    [Parameter(Mandatory = $False, HelpMessage='Specify the region')]
    [String]$region="westeurope"
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

$subscriptionId = $parameters.parameters.subscriptionId.value
$tenantId = $parameters.parameters.tenantId.value
$keyVaultName = $parameters.parameters.keyVaultName.value
$adlsName = $parameters.parameters.adlStoreName.value

$tokenSecretName = $parameters.parameters.databricksTokenSecretName.value
if (-not $tokenSecretName)
{
    $tokenSecretName = "DatabricksAccessToken"
}
$secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $tokenSecretName -ErrorAction SilentlyContinue
$accessToken = $secret.SecretValueText

$uriBase = "https://$region.azuredatabricks.net/api/2.0"
function Get-Directory {
    param( [string]$path)
    # list the folders in the parent folder and look for a match
    $head = @{authorization = "Bearer $accessToken" }
    $parentPath = Split-Path -Path $path -Parent
    $parentPath = $parentPath -replace "\\", "/"
    $uri = "$uriBase/workspace/list?path=$parentPath"

    try {
        $directories = Invoke-RestMethod -Uri $uri -Method 'GET' -Headers $head -ContentType "application/json"
    } catch {
        Write-Host "Failed to list Databricks workspace path '$parentPath'"
        $statusCode = $_.Exception.Response.StatusCode.value__
        if ($statusCode -eq "404") {
            Write-Host "Target workspace path '$parentPath' does not exist"
            $directories = $null
        } else {
            Write-Error "HTTP status code $statusCode"
            throw $_.Exception
        }
    }

    if ($directories)
    {
        foreach($dir in $directories.objects)
        {
            if ($dir.object_type -eq "DIRECTORY" -and $dir.path -eq $path){
                Write-Host "Target workspace path '$path' already exists."
                return $dir
            }
        }
    }
    return $null
}

function New-Directory {
    param( [string]$path="/")
    $path = $path -replace "\\", "/"
    $uri = "$uriBase/workspace/mkdirs"
    $Head = @{authorization = "Bearer $accessToken" }
    $Body = @"
    {
        "path": "$path"
    }
"@
    $result = Invoke-RestMethod -Uri $uri -Body $Body -Method 'POST' -Headers $Head -ContentType "application/json"
}
function GetFiles([string]$path, [string] $targetPath)
{
    $i = 0;
    foreach ($item in Get-ChildItem $path)
    {
        if (Test-Path $item.FullName -PathType Container) {
            continue
        } else {
            # it's a file so import it
            $filePath = $item.FullName

            $parameters = @{
                'AccessToken' = $accessToken
                'sourceFilePath' = $filePath
                'targetDirectory' = $targetPath
            }
            if ($overwriteExisting) {
                $parameters['overwriteExisting'] = $True
            }

            if ($i -eq 0) {
                $parameters['createTargetFolder'] = $True
            }
            & "$PSScriptRoot\New-DataBricksImportSourceFile.ps1" @parameters
            $i++;
        }
    }

    # Handle sub folders
    foreach ($item in Get-ChildItem $path) {
        if (Test-Path $item.FullName -PathType Container) {
            $subRoot = Split-Path -Path $item.FullName -Leaf
            $root = Join-Path -Path $targetPath -ChildPath $subRoot
            GetFiles -path $item.FullName -targetPath $root
        } else {
            # it's a file so ignore it
            continue
        }
    }
}

$path = "\"
$pathParts = $targetWorkspacePath.Split("/")

# Make sure the first target folder exists
foreach($target in $pathParts) {
    $path = Join-Path -Path $path -ChildPath $target
    if($path -ne "\" -and -not (Get-Directory -path $path)) {
        New-Directory -path $path
    }
}

GetFiles -path $sourceDirectoryPath -targetPath $targetWorkspacePath