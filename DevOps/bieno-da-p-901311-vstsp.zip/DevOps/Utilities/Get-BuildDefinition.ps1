param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$parameterFile,

    [Parameter(Mandatory = $True, HelpMessage='The personal access token used to authorize vsts requests')]
    [String]$personalAccessToken
)

$teamProjectProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $teamProjectProjectFolder, "Utilities"
$parameters = & "$utilitiesFolder\Get-Parameters.ps1" -parameterFile $parameterFile

$vstsAccountName = $parameters.parameters.vstsAccountName.value
$vstsTeamProjectName = $parameters.parameters.vstsTeamProjectName.value
$vstsTeamProjectCIBuildDefinitionName = $parameters.parameters.vstsTeamProjectCIBuildDefinitionName.value
$vstsTeamProjectScheduledBuildDefinitionName = $parameters.parameters.vstsTeamProjectScheduledBuildDefinitionName.value

function Get-BuildDef
{
    param
    (
        [string]$vstsTeamProjectBuildDefinitionName
    )
    $patString = "{0}:{1}" -f "", $personalAccessToken
    $base64PatString =  [System.Convert]::ToBase64String([System.Text.Encoding]::ASCII.GetBytes($patString))

    try 
    {
        $vstsURL = "https://{0}.visualstudio.com/DefaultCollection/{1}/_apis/build/definitions?api-version=2.0" -f $vstsAccountName, $vstsTeamProjectName
        $params = @{    
            ContentType = 'application/json'
            Headers = @{
                'Authorization'="Basic $base64PatString"
            }
            Method = 'Get'    
            URI = $vstsURL
        }
        Write-Verbose "Getting the build definitions for team project $vstsTeamProjectName"
        $authZResponse =  Invoke-RestMethod @params
        $vstsTeamProjectBuildDefinitionId = ($authZResponse.value | Where-Object {$_.name -eq $vstsTeamProjectBuildDefinitionName}).id
        Write-Verbose "Build Definition id for build $vstsTeamProjectBuildDefinitionName is $vstsTeamProjectBuildDefinitionId"        

        $vstsURL = "https://{0}.visualstudio.com/DefaultCollection/{1}/_apis/build/definitions/{2}?api-version=2.0" -f $vstsAccountName, $vstsTeamProjectName, $vstsTeamProjectBuildDefinitionId
        $params = @{    
            ContentType = 'application/json'
            Headers = @{
                'Authorization'="Basic $base64PatString"
            }
            Method = 'Get'    
            URI = $vstsURL
        }
        $authZResponse =  Invoke-RestMethod @params
        return $authZResponse
    }
    catch
    {
        Write-Host "StatusCode:" $_.Exception.Response.StatusCode.value__ 
        Write-Host "StatusDescription:" $_.Exception.Response.StatusDescription
        throw
    }
}

Get-BuildDef -vstsTeamProjectBuildDefinitionName $vstsTeamProjectCIBuildDefinitionName
Get-BuildDef -vstsTeamProjectBuildDefinitionName $vstsTeamProjectScheduledBuildDefinitionName
