Param
(
    [Parameter(Mandatory = $True, HelpMessage = 'Specify the parameter file')]
    [String]$parameterFile,    

    [Parameter(Mandatory = $True, HelpMessage = 'The client secret for the deployment app client id')]
    [String]$clientSecret,

    [Parameter(Mandatory = $False, HelpMessage = 'The resource to get the access token for')]
    [String]$resource = "https://database.windows.net/"
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

$tenantId = $parameters.parameters.tenantId.value
$clientId = $parameters.parameters.deploymentApplicationId.value
$contentType = "application/x-www-form-urlencoded"
$uri = "https://login.microsoftonline.com/{0}/oauth2/token?api-version=1.0" -f $tenantId

$formData = @{
    client_id     = $clientId;
    client_secret = $clientSecret;    
    grant_type    = 'client_credentials';
    resource      = $resource
}

$response = Invoke-RestMethod -Uri $uri -Method Post -Body $formData -ContentType $contentType
return $response.access_token