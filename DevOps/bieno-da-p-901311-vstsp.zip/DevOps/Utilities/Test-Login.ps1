try {
    $subscription = Get-AzContext -ListAvailable
    if (-not $subscription -or $subscription.count -lt 1) { throw }
}
catch {
    Write-Output "Login to Azure"
    $subscription = Login-AzAccount -ErrorAction SilentlyContinue
    if (!$subscription) {
        Write-Error "You will need to Login to Azure to complete this script."
        throw
    }   
}
