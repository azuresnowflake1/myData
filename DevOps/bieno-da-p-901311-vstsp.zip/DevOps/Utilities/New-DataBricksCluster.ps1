Param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$parameterFile,
    [Parameter(Mandatory = $False, HelpMessage='Specify to create using the databricksCluster2 config value')]
    [switch]$cluster2

)
# Note that you can create mutiple clusters with the same name.  Probably not a good idea.

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile
$region=$parameters.parameters.location.value.Replace(" ", "")
if ($cluster2) {
    $clusterConfig = ($parameters.parameters.databricksCluster2.value | ConvertTo-Json)
} else {
    $clusterConfig = ($parameters.parameters.databricksCluster1.value | ConvertTo-Json)
}
$uriBase = "https://$region.azuredatabricks.net/api/2.0"

return Adb-New-Cluster -config $clusterConfig