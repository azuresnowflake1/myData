param(
    [Parameter(Mandatory=$true)] [string]$parameterFile,
    [Parameter(Mandatory=$false, ParameterSetName="rule1")] [switch]$ruleName1,
    [Parameter(Mandatory=$false, ParameterSetName="dtl", HelpMessage="Add a subnet rule for the DTL subnet")] [switch]$devTestLab,
    [Parameter(Mandatory=$false)] [switch]$deleteRule
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters.ps1" -parameterFile $parameterFile

$serverName = $parameters.parameters.sqlServerName.value
$rgName = $parameters.parameters.sqlServerResourceGroupName.value

if ($ruleName1) {
    $vnetRgName = $parameters.parameters.virtualNetworkResourceGroupName.value
    $vnetName = $parameters.parameters.virtualNetworkName.value
    $subnetName = $parameters.parameters.sqlServerSubnetName1.value
    if ([String]::IsNullOrEmpty($subnetName)) {
        Write-Error "The value for sqlServerSubnetName1 is blank in your parameter file.  Unable to set subnet rule."
        return
    }
} elseif ($devTestLab){

    switch ($Global:CtxBootstrap.NamePrefix) {
        "bnlwe" {
                $vnetRgName = "bnlwe-DA04-p-00000-Net-rg" 
                $subnetName = "bnlwe-da04-p-DTL-subnet01"
                $vnetName   = "bnlwe-da04-p-vnet01"
        }
        "bieno" {
                $vnetRgName = "bieno-DA12-p-00000-Net-rg" 
                $subnetName = "bieno-da12-p-DTL-subnet01"
                $vnetName   = "bieno-da12-p-vnet01"
                }
            }
        }
$ruleName = "sqlvnet-{0}" -f $subnetName

if ($deleteRule)
{
    if (Get-AzSqlServerVirtualNetworkRule -ResourceGroupName $rgName -ServerName $serverName -VirtualNetworkRuleName $ruleName -ErrorAction SilentlyContinue) {
        Remove-AzSqlServerVirtualNetworkRule -VirtualNetworkRuleName $ruleName -ServerName $serverName -ResourceGroupName $rgName
        Write-Host "Existing virtual network rule '$ruleName' was removed from server $serverName."
    } else {
       Write-Host "Virtual network rule '$ruleName' was not found in server $serverName.  Nothing was deleted!"    
    }
    return
}

$vNet = Get-AzVirtualNetwork -Name $vnetName -ResourceGroupName $vnetRgName -DefaultProfile $Global:CtxDev -ErrorAction SilentlyContinue

if ($vNet) {
    $subNet = Get-AzVirtualNetworkSubnetConfig -Name $subnetName -VirtualNetwork $vNet -DefaultProfile $Global:CtxDev 
    if ($subNet) {
        
        $ruleName = "sqlvnet-{0}" -f $subnetName
        if (Get-AzSqlServerVirtualNetworkRule -ResourceGroupName $rgName -ServerName $serverName -VirtualNetworkRuleName $ruleName -ErrorAction SilentlyContinue) {
            Set-AzSqlServerVirtualNetworkRule -VirtualNetworkRuleName $ruleName -VirtualNetworkSubnetId $subNet.Id -ServerName $serverName -ResourceGroupName $rgName
            Write-Host "Existing virtual network rule '$ruleName' was updated in server $serverName."
        } else {
            New-AzSqlServerVirtualNetworkRule -VirtualNetworkRuleName $ruleName -VirtualNetworkSubnetId $subNet.Id -ServerName $serverName -ResourceGroupName $rgName
            Write-Host "New virtual network rule '$ruleName' was added to server $serverName."    
        }
    }
}