[CmdletBinding()]
param(
    [Parameter(Mandatory = $True, HelpMessage = 'Specify the parameter file name')]
    [PSCustomObject]$parameters,
    [Parameter(Mandatory = $False, HelpMessage = 'The list of triggers you want to start')]
    [System.Collections.ArrayList]$startTriggers,
    [Parameter(Mandatory = $False, HelpMessage = 'Pass if you want to process trigger synchronously')]
    [switch]$runSynchonously,
    [Parameter(Mandatory = $False, HelpMessage = 'The number of triggers per asynchronous thread')]
    [Int]$maxItemsPerBatch=10
)

[System.Collections.ArrayList]$processedTriggers = @()
$syncRootName = [System.Guid]::NewGuid()
$syncRoot = New-Object 'Threading.Mutex' $false, $syncRootName
$startTime = Get-Date
# Number of parallel runspaces to execute this operation
$numRunspaces = 100
# This should always be $true. Set to $false to make the whole operation run single-threaded
$useRunspaces = (-not $runSynchonously)

# Accumulate processing stats (thread safe counters)
$itemsStats = @{
    itemsProcessed = New-Object System.Threading.SemaphoreSlim -ArgumentList @(0)
    itemsUpdated = New-Object System.Threading.SemaphoreSlim -ArgumentList @(0)
    itemsErrors = New-Object System.Threading.SemaphoreSlim -ArgumentList @(0)
}

# Parameters shared across all workers
$itemParams = @{
    parameters = $parameters
    azcontext = Get-AzContext
    syncRoot = $syncRoot
    processedTriggers = $processedTriggers
}
# Write to a collection in a thread safe manner
function Write-ProcessedTrigger {
    param(
        $mutex, $trigger, $triggers
    )
    # Block any other entry into the try catch block
    $mutex.WaitOne();
    try {
         $triggers.Add($trigger) | Out-Null
    }
    finally {
         # Release the lock
         $mutex.ReleaseMutex()
    }
}

# Worker script block
$scriptBlock = {
    Param ($triggers, $sharedParams, $batchNumber)
    $batchStartTime = Get-Date
    Write-Host "Batch number $batchNumber containing $($triggers.count) triggers started at $batchStartTime."
    $triggers | ForEach-Object {
        $adfParams = @{
            InputObject = $_
            ErrorAction = "Stop"
            #DefaultProfile = $sharedParams.azcontext
            Force = $true
        }
        try {
            $trigger = $_
            if ($sharedParams.StartTriggers) {
                Start-AzDataFactoryV2Trigger @adfParams | Out-Null
            } else {
                Stop-AzDataFactoryV2Trigger @adfParams | Out-Null
            }
            
            Write-ProcessedTrigger -mutex $sharedParams.syncRoot -trigger $_ -triggers $sharedParams.processedTriggers
            $itemsStats.itemsUpdated.Release()
        }
        catch {
            $host.UI.WriteErrorLine("Unknown failure processing $($trigger.name). Details: " + $_)
            $itemsStats.itemsErrors.Release()
        }
    }
    $elapsed = $(get-date) - $batchStartTime
    $totalTime = "{0:HH:mm:ss}" -f ([datetime]$elapsed.Ticks)
    Write-Host "Trigger batch $batchNumber completed in $totalTime."
}
# Setup our Runspace Pool
if ($useRunspaces) {
    $sessionState = [System.Management.Automation.Runspaces.InitialSessionState]::CreateDefault()
    $sessionState.ImportPSModule(@( "Az.Datafactory"));
    $sessionState.ThreadOptions = [System.Management.Automation.Runspaces.PSThreadOptions]::UseNewThread
    # Marshall variables & functions over to the RunspacePool
    $sessionState.Variables.Add((New-Object -TypeName System.Management.Automation.Runspaces.SessionStateVariableEntry -ArgumentList 'itemsStats', $itemsStats, ""))
    $sessionState.Commands.Add((New-Object System.Management.Automation.Runspaces.SessionStateFunctionEntry -ArgumentList 'Write-ProcessedTrigger', (Get-Content Function:\Write-ProcessedTrigger -ErrorAction Stop)))
    $runspacePool = [RunspaceFactory]::CreateRunspacePool(1, $numRunspaces, $sessionState, $Host)
    $runspacePool.Open()
}
$runSpaces = [System.Collections.ArrayList]@()
$triggerBatch = [System.Collections.ArrayList]@()
# Loop through the entire listing until we've processed all files & directories
if ($startTriggers) {
    $triggers = $startTriggers
    $itemParams.StartTriggers = $true

} else {
    $triggers = Get-AzDataFactoryV2Trigger -ResourceGroupName $parameters.parameters.dataFactoryResourceGroupName.value -DataFactoryName $parameters.parameters.dataFactoryName.value
}
Write-Information "Processing $($triggers.count) triggers"
$count = 0
$batchNumber = 0
foreach($trigger in $triggers) {
    $itemsStats.itemsProcessed.Release() | Out-Null
    $count++
    
    try {
        if ($itemParams.StartTriggers) {
            $triggerBatch.Add($trigger) | Out-Null
        } elseif ($trigger.RuntimeState -eq "Started") {
            $triggerBatch.Add($trigger) | Out-Null
        }
        if ($count -lt $triggers.Count -and $triggerBatch.Count -lt $maxItemsPerBatch) {
            # continue to construct the current batch
            continue
        }
        $batchNumber++
        if ($useRunspaces) {
            # Dispatch this list to a new runspace
            $ps = [powershell]::Create().
                AddScript($scriptBlock).
                AddArgument($triggerBatch).
                AddArgument($itemParams).
                AddArgument($batchNumber)
            $ps.RunspacePool = $runspacePool
            $runSpace = New-Object -TypeName psobject -Property @{
                PowerShell = $ps
                Handle = $($ps.BeginInvoke())
            }
            $runSpaces.Add($runSpace) | Out-Null
        }
        else {
            Invoke-Command -ScriptBlock $scriptBlock -ArgumentList @($triggerBatch, $itemParams, $batchNumber) | Out-Null
        }
        # start a new batch
        $triggerBatch = [System.Collections.ArrayList]@()
    }
    catch {
        $host.UI.WriteErrorLine("Failed to create trigger batches for $trigger : " + $_)
    }
} 

# Cleanup
$host.UI.WriteLine("Waiting for completion & cleaning up")
while ($runSpaces.Count -gt 0) {
    $idx = [System.Threading.WaitHandle]::WaitAny($($runSpaces | Select-Object -First 64 | ForEach-Object { $_.Handle.AsyncWaitHandle }))
    $runSpace = $runSpaces.Item($idx)
    $runSpace.PowerShell.EndInvoke($runSpace.Handle) | Out-Null
    $runSpace.PowerShell.Dispose()
    $runSpaces.RemoveAt($idx)
}
$elapsed = $(get-date) - $StartTime
$totalTime = "{0:HH:mm:ss}" -f ([datetime]$elapsed.Ticks)
if ($itemParams.StartTriggers) {
    $host.UI.WriteLine("Completed in $totalTime. Triggers processed: $($itemsStats.itemsProcessed.CurrentCount), Started: $($itemsStats.itemsUpdated.CurrentCount), errors: $($itemsStats.itemsErrors.CurrentCount)")
} else {
    $host.UI.WriteLine("Completed in $totalTime. Triggers processed: $($itemsStats.itemsProcessed.CurrentCount), Stopped: $($itemsStats.itemsUpdated.CurrentCount), errors: $($itemsStats.itemsErrors.CurrentCount)")
}
Write-Output $processedTriggers