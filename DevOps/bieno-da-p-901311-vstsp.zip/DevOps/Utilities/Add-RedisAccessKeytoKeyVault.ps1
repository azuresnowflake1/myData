Param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$parameterFile,
    
    [Parameter(Mandatory = $True, HelpMessage='The databricks workspace access token')]
    [String]$token,
    [Parameter(Mandatory = $False, HelpMessage='Specify to overwrite an existing token in key vault')]
    [switch]$force

)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$managerFolder = "{0}\{1}" -f $devOpsProjectFolder, "LandscapeManager"
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

& "$utilitiesFolder\Test-Login.ps1"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile
$secretExpiryYears = $parameters.parameters.keyVaultSecretExpiryTerm.value
$redisCacheName = $parameters.parameters.redisCacheName.value
$storageAccountResourceGroupName = $parameters.parameters.storageAccountResourceGroupName.value
$tokenSecretName = "RedisKeySecretName"
$secret = Get-AzKeyVaultSecret -VaultName $parameters.parameters.keyVaultName.value -Name $tokenSecretName -ErrorAction SilentlyContinue
if ($secret -and -not $force) {
   Write-Error "A RedisKeySecretName already exists in key vault.  You must pass the force parameter to overwrite it."
   return
}
$secureSecret = ConvertTo-SecureString -AsPlainText $token -Force
$secretCredential = New-Object System.Management.Automation.PSCredential ($tokenSecretName, $secureSecret)
$contentType = "The Redis Cache secret key."
if ($secret -and $secret.ContentType) {
   $contentType = $secret.ContentType
}
if ($force) {
   & "$utilitiesFolder\Set-KeyVaultSecret.ps1" -parameterFile $parameterFile -secretCredential $secretCredential -updateSecret $True -secretExpiryTermYears $secretExpiryYears -contentType $contentType
} else { 
   & "$utilitiesFolder\Set-KeyVaultSecret.ps1" -parameterFile $parameterFile -secretCredential $secretCredential -secretExpiryTermYears $secretExpiryYears -contentType $contentType 
}

