Param
(
    [Parameter(Mandatory = $True, HelpMessage = 'Specify the parameter file')]
    [String]$parameterFile
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

$batchAccountResourceGroupName = $parameters.parameters.batchAccountResourceGroupName.value
$batchAccountName = $parameters.parameters.batchAccountName.value

$batchAccount = Get-AzBatchAccountKey -ResourceGroupName $batchAccountResourceGroupName -AccountName $batchAccountName
if (-not $batchAccount)
{
    Write-Warning "Batch account $batchAccountName was not found.  Please create it."
    return
}

$pools = Get-AzBatchPool -BatchContext $batchAccount
if ($pools -and $pools.Count -eq 1) {
    $nodes = Get-AzBatchComputeNode -PoolId $pools[0].Id -BatchContext $batchAccount
    if ($nodes -and $nodes.Count -ge 1)
    {
        $ipAddress = $nodes[0].IPAddress
    } else {
        Write-Error "Unable to access the batch node IP address because batch account $batchAccountName has zero nodes."
        return $null
    }
} else {
    Write-Error "Unable to access the batch node IP address because batch account $batchAccountName has zero or > 1 batch pools."
    return $null
}

$ruleName = "BatchPool"
$ruleUpdated = $false

$server = Get-AzAnalysisServicesServer -ResourceGroupName $parameters.parameters.analysisServicesResourceGroupName.value -Name $parameters.parameters.analysisServicesName.value
if ($server.state -eq "Paused"){
    Write-Error "Add batch pool IP address to AAS failed because AAS $($parameters.parameters.analysisServicesName.value) was in the paused state."
    return
}

if ($server -and $server.FirewallConfig)
{
    foreach($rule in $server.FirewallConfig.FirewallRules){
        if ($rule.FirewallRuleName -eq $ruleName) {
            Write-Output "Updating existing firewall rule for batch."
            $rule.RangeEnd = $ipAddress
            $rule.RangeStart = $ipAddress
            $ruleUpdated = $true
            break
        }
    }
} else {
    Write-Warning "Add batch pool IP address to AAS failed because AAS $($parameters.parameters.analysisServicesName.value) was not found.  Please create AAS and try again."
    return
}
if (-not $ruleUpdated) {
    Write-Output "White-listing the batch pool IP $ipAddress in AAS $($parameters.parameters.analysisServicesName.value)"
    $rule = New-AzAnalysisServicesFirewallRule -FirewallRuleName $ruleName -RangeStart $ipAddress -RangeEnd $ipAddress
    $server.FirewallConfig.FirewallRules.Add($rule)
}

Set-AzAnalysisServicesServer -Name $parameters.parameters.analysisServicesName.value -ResourceGroupName $parameters.parameters.analysisServicesResourceGroupName.value `
    -FirewallConfig $server.FirewallConfig
   