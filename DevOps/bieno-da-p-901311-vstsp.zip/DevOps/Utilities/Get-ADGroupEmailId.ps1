Param
(
    [Parameter(Mandatory = $True, HelpMessage = 'Specify the parameter file')]
    [String]$parameterFile,
    
    [Parameter(Mandatory = $True, HelpMessage = 'Specify the landscape manager spn')]
    [String]$adGroupName,

    [Parameter(Mandatory = $True, HelpMessage = 'Specify the client Id. Client must be a native client')]
    [String]$clientId,
    
    [Parameter(Mandatory = $True, HelpMessage = 'Specify the redirect Uri for the client Id.')]
    [String]$redirectUri,

    [Parameter(Mandatory = $True, HelpMessage = 'Specify the resource to get access token for')]
    [String]$resourceId
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

$accessToken = & "$utilitiesFolder\Get-ADUserAccessToken.ps1" -parameterFile $parameterFile -clientId $clientId -redirectUri $redirectUri -resourceId $resourceId
$group = Get-AzADGroup -DisplayName $adGroupName
$groupObjectId = $group.ObjectId

Write-Verbose "Group Object Id is $groupObjectId"

$tenantName = $parameters.parameters.tenantDomainName.value
$authorization = "Bearer $accessToken"
$uri = "https://graph.windows.net/{0}/groups/{1}?api-version=1.6" -f $tenantName, $groupObjectId
Write-Verbose "Url is $uri"

$contentType = "application/json"
$headers = @{
    Host = 'graph.windows.net'
    Authorization = $authorization
}

$response = Invoke-RestMethod -Uri $uri -Method Get -Headers $headers -ContentType $contentType
return $response.mail