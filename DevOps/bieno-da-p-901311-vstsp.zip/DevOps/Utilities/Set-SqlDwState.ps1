param(
    [Parameter(Mandatory=$true)] [string]$parameterFile,
    [switch]$Pause,
    [switch]$Resume
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters.ps1" -parameterFile $parameterFile

if($Pause)
{
    Write-Host "Pause, Initiated."
    $status = Get-AzSqlDatabase -ResourceGroupName $parameters.parameters.sqlServerResourceGroupName.value`
                                                              -DatabaseName  $parameters.parameters.sqlDataWarehouseName.value`
                                                              -ServerName $parameters.parameters.sqlServerName.value
    if($status.status -ne 'Paused')
    {
        Suspend-AzSqlDatabase -ResourceGroupName $parameters.parameters.sqlServerResourceGroupName.value`
                                                           -DatabaseName $parameters.parameters.sqlDataWarehouseName.value`
                                                           -ServerName $parameters.parameters.sqlServerName.value
    }
    else 
    {
         Write-Host "$($parameters.parameters.sqlDataWarehouseName.value) is already in `"Paused`" state."
    }
     
}

if($Resume)
{
    Write-Host "Resume, Initiated."
    $status =  Get-AzSqlDatabase -ResourceGroupName $parameters.parameters.sqlServerResourceGroupName.value`
                                                                -DatabaseName  $parameters.parameters.sqlDataWarehouseName.value`
                                                                -ServerName $parameters.parameters.sqlServerName.value
    if($status.status -ne 'Online')
    {
        Resume-AzSqlDatabase -ResourceGroupName $parameters.parameters.sqlServerResourceGroupName.value`
                                                           -DatabaseName $parameters.parameters.sqlDataWarehouseName.value`
                                                           -ServerName $parameters.parameters.sqlServerName.value
    }
    else 
    {
        Write-Host "$($parameters.parameters.sqlDataWarehouseName.value) is already in `"Online`" state."
    }
}