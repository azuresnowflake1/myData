Param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$parameterFile
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

$storageAccountResourceGroupName = $parameters.parameters.storageAccountResourceGroupName.value
$sqlServerResourceGroupName = $parameters.parameters.sqlServerResourceGroupName.value
$dataFactoryResourceGroupName = $parameters.parameters.dataFactoryResourceGroupName.value

$objectId = $parameters.parameters.servicePrincipalId.value 

New-AzRoleAssignment -ObjectId $objectId -ResourceGroupName $storageAccountResourceGroupName -RoleDefinitionName Contributor
New-AzRoleAssignment -ObjectId $objectId -ResourceGroupName $sqlServerResourceGroupName -RoleDefinitionName Contributor
New-AzRoleAssignment -ObjectId $objectId -ResourceGroupName $dataFactoryResourceGroupName -RoleDefinitionName Contributor