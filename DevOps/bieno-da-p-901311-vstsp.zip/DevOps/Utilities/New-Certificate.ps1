Param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$parameterFile,

    [Parameter(Mandatory = $True, HelpMessage='Name of the Azure AD application to add certificate')]
    [String]$applicationName,

    [Parameter(Mandatory = $True, HelpMessage='Name of the certificate')]
    [String]$certificateName
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

$certFolder = [System.IO.Path]::GetTempPath()
$certFilePath = "$certFolder$certificateName.pfx"
$numberofYearsforClientSecret = $parameters.parameters.numberofYearsforClientSecret.value
$certStartDate = (Get-Date).Date
$certEndDate = $certStartDate.AddYears($numberofYearsforClientSecret)

$certName = $certificateName
$certPassword = & "$utilitiesFolder\New-Password.ps1"
$certPasswordSecureString = ConvertTo-SecureString -AsPlainText $certPassword -Force    

$certStoreLocation = "cert:\currentuser\My"

$cert = New-SelfSignedCertificate -DnsName $certName -CertStoreLocation $certStoreLocation -KeySpec KeyExchange -NotAfter $certEndDate -NotBefore $certStartDate -ErrorAction Ignore

if(-not $cert){
    $certStoreLocation = "cert:\localmachine\My"
    $cert = New-SelfSignedCertificate -DnsName $certName -CertStoreLocation $certStoreLocation -KeySpec KeyExchange -NotAfter $certEndDate -NotBefore $certStartDate
}

$certThumbprint = $cert.Thumbprint
$cert = (Get-ChildItem -Path $certStoreLocation\$certThumbprint)

Export-PfxCertificate -Cert $cert -FilePath $certFilePath -Password $certPasswordSecureString -Force | Out-Null

$certificatePFX = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2($certFilePath, $certPasswordSecureString)
$credential = [System.Convert]::ToBase64String($certificatePFX.GetRawCertData())

Remove-Item $certStoreLocation\$certThumbprint
Get-AzADApplication -DisplayName $applicationName | New-AzADAppCredential -DefaultProfile $global:CtxSPN -CertValue $credential -StartDate $certStartDate -EndDate $certEndDate

$props = @{
    FilePath = $certFilePath
    Password = $certPassword
    Thumbprint = $certThumbprint
}
$output = new-object psobject -Property $props

return $output