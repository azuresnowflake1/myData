Param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$parameterFile,
    [Parameter(Mandatory = $True, ParameterSetName="ById", HelpMessage='Specify the Id of the cluster')]
    [String]$clusterId,
    [Parameter(Mandatory = $True, ParameterSetName="ByName", HelpMessage='Specify the name of the cluster')]
    [String]$clusterName

)
# Get details of an existing cluster.  Returns object of type ClusterInfo see: https://docs.azuredatabricks.net/api/latest/clusters.html#clusterclusterinfo
# You can search by name or id.  Note that cluster name is not guranteed as unique!
$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

# $subscriptionId = $parameters.parameters.subscriptionId.value
# $tenantId = $parameters.parameters.tenantId.value
# $keyVaultName = $parameters.parameters.keyVaultName.value
# $region=$parameters.parameters.location.value.Replace(" ", "")
# $tokenSecretName = $parameters.parameters.databricksTokenSecretName.value
# if (-not $tokenSecretName)
# {
#     $tokenSecretName = "DatabricksAccessToken"
# }
# $secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $tokenSecretName -ErrorAction SilentlyContinue
# $accessToken = $secret.SecretValueText
# $uriBase = "https://$region.azuredatabricks.net/api/2.0"


$response = Adb-Get-Clusters
$clusters = $response.clusters

foreach($cluster in $clusters)
{
    if (($clusterName) -and $cluster.cluster_name -eq $clusterName)
    {
        Write-Verbose "Cluster found by name: "
        $cluster | Format-List -Property * | Out-String | Write-Verbose
        return $cluster
    } elseif (($clusterId) -and $cluster.cluster_id -eq $clusterId)
    {
        Write-Verbose "Cluster found by Id: "
        $cluster | Format-List -Property * | Out-String | Write-Verbose
        return $cluster
    }
}
Write-Verbose "Azure databricks cluster was not found!"
return