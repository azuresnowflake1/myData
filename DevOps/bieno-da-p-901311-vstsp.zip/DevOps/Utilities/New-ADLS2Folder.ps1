[CmdletBinding()]
Param(
    [Parameter(Mandatory = $true, Position = 1)] [object] $parameterFile,
    [Parameter(Mandatory = $True, Position = 2)] [string] $pathToCreate,
    [Parameter(Mandatory = $True, Position = 3)] [string] $bearerToken,
    [Parameter(Mandatory = $False, Position = 4)] [switch] $failIfExists,
    [Parameter(Mandatory = $False, Position = 5)] [string] $fileSystemName="unilever"
)
# Rest documentation:
# https://docs.microsoft.com/en-us/rest/api/storageservices/datalakestoragegen2/path/create

# Create a new hierarchical file system in ADLS Gen2
$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

$method = "PUT"

$headers = @{ } 
$headers.Add("x-ms-version", "2018-11-09")
$headers.Add("Authorization", "Bearer $BearerToken")
if ($failIfExists) {
    $headers.Add("If-None-Match", "*") # To fail if the destination already exists, use a conditional request with If-None-Match: "*"
}
$path = (Join-Path -Path $fileSystemName -ChildPath $pathToCreate).Replace("\", "/").Trim('\','/')
$URI = "https://$($parameters.parameters.adlStoreName.value).dfs.core.windows.net/" + $path + "?resource=directory"

try {
    Invoke-RestMethod -method $method -Uri $URI -Headers $headers | Out-Null   # returns empty response
}
catch {
    $ErrorMessage = $_.Exception.Message
    $StatusDescription = $_.Exception.Response.StatusDescription

    Throw $ErrorMessage + " " + $StatusDescription + " PathToCreate: $pathToCreate"
}