Param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$parameterFile,
    [Parameter(Mandatory = $False, HelpMessage='Specify the name of the cluster')]
    [String]$clusterName="ClusterForTesters"

)
# Note that you can create mutiple clusters with the same name.  Probably not a good idea.

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

$subscriptionId = $parameters.parameters.subscriptionId.value
$tenantId = $parameters.parameters.tenantId.value
$keyVaultName = $parameters.parameters.keyVaultName.value
$adlsName = $parameters.parameters.adlStoreName.value
$region=$parameters.parameters.location.value.Replace(" ", "")
$tokenSecretName = $parameters.parameters.databricksTokenSecretName.value
if (-not $tokenSecretName)
{
    $tokenSecretName = "DatabricksAccessToken"
}
$secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $tokenSecretName -ErrorAction SilentlyContinue
$accessToken = $secret.SecretValueText
$uriBase = "https://$region.azuredatabricks.net/api/2.0"

$clusterConfig = @"
{
    "autoscale": {
        "min_workers": 4,
        "max_workers": 8
    },
    "cluster_name": "$clusterName",
    "spark_version": "6.4.x-scala2.11",
    "spark_conf": {
        "spark.databricks.repl.allowedLanguages": "python,sql",
        "spark.databricks.pyspark.enableProcessIsolation": "true",
        "spark.databricks.passthrough.enabled": "true",
        "spark.databricks.cluster.profile": "serverless"
    },
    "node_type_id": "Standard_E8s_v3",
    "driver_node_type_id": "Standard_D13_v2",
    "ssh_public_keys": [],
    "custom_tags": {
        "ResourceClass": "Serverless",
        "Department": "empty",
        "Project": "empty",
        "Exclude_PMC": "Exclude_PMC",
        "Support Team": "empty@me.com"
    },
    "spark_env_vars": {
        "PYSPARK_PYTHON": "/databricks/python3/bin/python3"
    },
    "autotermination_minutes": 30,
    "enable_elastic_disk": true,
    "cluster_source": "UI",
    "init_scripts": [],
    "cluster_id": ""
}
"@

$cluster = & "$utilitiesFolder\New-DataBricksClusterGet.ps1" -parameterFile $parameterFile -clusterName $clusterName
if ($cluster) {
    Write-Host "Cluster '$clusterName' already exists"
    return $cluster
} else {
    return Adb-New-Cluster -config $clusterConfig
}