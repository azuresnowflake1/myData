Param
(
    [Parameter(Mandatory = $True, HelpMessage = 'Specify the source parameter file')]
    [String]$parameterFile,

    [Parameter(Mandatory = $True, HelpMessage = 'Specify the target environment parameter file')]
    [String]$targetParameterFile,
    [switch]$pointInTime,
    [switch]$geoBackup,
    [switch]$setScope
)

# Either a point in time - i.e. now or a geoback from the past 24 hours
# Only one must be selected


if ((!$pointInTime -and !$geoBackup) -or ($pointInTime -and $geoBackup)) {
    Write-Error "One backup method must be selected - Point In Time or Geo Restore"
    return
}

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"
$runbooksFolder = "{0}\{1}" -f $devOpsProjectFolder, "LandscapeManager\RunBooks"
$managerFolder = "{0}\{1}" -f $devOpsProjectFolder, "LandscapeManager"

if ($setScope -or -not $global:CtxBootStrap) {
    & "$managerFolder\Set-GlobalScope"
}

& "$runbooksFolder\Import-PlatformCore"

$targetParameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $targetParameterFile
$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

$sSubscriptionId = $parameters.parameters.subscriptionId.value

$sResourceGroupName = $parameters.parameters.sqlServerResourceGroupName.value
$sServerName = $parameters.parameters.sqlServerName.value 
$sDatabaseName = $parameters.parameters.sqlDataWarehouseName.value
$tDatabaseName =  "{0}{1}" -f $sDatabaseName, "-restore"

$tServerName = $targetParameters.parameters.sqlServerName.value
$tResourceGroupName = $targetParameters.parameters.sqlServerResourceGroupName.value
$tLocation = $targetParameters.parameters.location.value
$tSubscriptionId = $targetParameters.parameters.subscriptionId.value

$ctxSource = Get-SubscriptionBootstrap -subscriptionId $sSubscriptionId
$ctxTarget = Get-SubscriptionBootstrap -subscriptionId $tSubscriptionId

$params = @{
    resourceGroupName = $sResourceGroupName
    serverName = $sServerName
    databaseName = $sDatabaseName
}

#source database server must be running
$sDatabase = Get-AzSqlDatabase @params -defaultProfile $ctxSource.DefaultProfile -ErrorAction Stop
if($sDatabase.status -eq 'Paused') {
    Write-Error "The database $($sDatabaseName) on $($sServerName) is in a paused state. Please resume the server to complete the restore process."
    return
}

#create temporary server in source subscription within landscape resource group
$tempLandscapeSqlServer = New-SQLServer -bootstrap $Global:CtxBootStrap -landscape
$landscapeResourceGroupName = $Global:CtxBootStrap.landscapeResourceGroupName
$landscapeServerName = ((($landscapeResourceGroupName).split("-",5) | Select-Object -Index 0,1,2,3) -join "-"), "unilevercom-restore-01" -join "-"

$landscapeServerName
if ($pointInTime) {
    #create restore point for source
    $restorePoint = New-SqlRestorePoint @params
    $targetSqlName = ($sDatabaseName),"pit", ($restorePoint.RestorePointCreationDate.ToString("yyyyMMddHHmmss")) -join "-"
    
    Restore-AzSqlDatabase -FromPointInTimeBackup -PointInTime $restorePoint.RestorePointCreationDate `
    -ServerName $landscapeServerName `
    -TargetDatabaseName $targetSqlName `
    -ResourceId $sDatabase.ResourceId `
    -ResourceGroupName $landscapeResourceGroupName `
    -defaultProfile $ctxSource.DefaultProfile
}


if ($geoBackup) {
    
    $geoBackupResource = Get-Geobackup @params
    $geoRestoredDatabase = Restore-SqlGeoBackup -bootstrap $Global:CtxBootStrap -geobackup $geoBackupResource -landscape
    $targetSqlName = $geoRestoredDatabase.DatabaseName
}



Move-Resource -targetResourceGroupName $tResourceGroupName -resourceId $tempLandscapeSqlServer.ResourceId -ctx $ctxTarget.DefaultProfile
#$landscapeResourceGroupName = $Global:CtxBootStrap.landscapeResourceGroupName
#$targetSqlName = "bnlwe-da04-d-00018-unilevercom-sqldw-01-20200715101519"
#$landscapeServerName = ((($landscapeResourceGroupName).split("-",5) | Select-Object -Index 0,1,2,3) -join "-"), "unilevercom-restore-01" -join "-"
   
$params = @{
    resourceGroupName = $tResourceGroupName
    serverName = $landscapeServerName
    databaseName = $targetSqlName
}


$params
$targetDatabase = Get-AzSqlDatabase @params -defaultProfile $ctxTarget.DefaultProfile
$targetDatabase.ResourceID



#create restore point for moved db
$targetRestorePoint = New-SqlRestorePoint @params -defaultProfile $ctxTarget.DefaultProfile

 Restore-AzSqlDatabase -FromPointInTimeBackup -PointInTime $targetRestorePoint.RestorePointCreationDate `
 -ServerName $tServerName `
 -TargetDatabaseName $targetSqlName `
 -ResourceId $targetDatabase.ResourceId `
 -ResourceGroupName $tResourceGroupName `
 -defaultProfile $ctxTarget.DefaultProfile

#delete old ones
Remove-AzSqlServer -ServerName $landscapeServerName -resourceGroupName  $tResourceGroupName -defaultProfile $ctxTarget.DefaultProfile


 Write-Output "SQLDW $sDbName restore to Server $tServerName complete"

