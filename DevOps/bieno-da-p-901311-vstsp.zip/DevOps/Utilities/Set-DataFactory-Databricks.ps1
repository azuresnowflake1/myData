[CmdletBinding()]
Param
(
    [Parameter(Mandatory = $True, HelpMessage = 'Specify the parameter file', Position=0)]
    [String]$parameterFile,
    [Parameter(Mandatory = $False, HelpMessage = 'Specify to create using cluster1 config')]
    [switch]$cluster1,
    [Parameter(Mandatory = $False, HelpMessage = 'Specify to create using cluster2 config')]
    [switch]$cluster2
)
# Create an on demand databricks linked service or one to an existing cluster Id
$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

function CreateOnDemandLinkedService () {

    $keyVaultName = $parameters.parameters.keyVaultName.value
    $tokenSecretName = $parameters.parameters.databricksTokenSecretName.value
    if (-not $tokenSecretName)
    {
        $tokenSecretName = "DatabricksAccessToken"
    }
    $accessToken = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $tokenSecretName -ErrorAction SilentlyContinue
    if (-not $accessToken) {
        Write-Error "Create databrick linked service failed because the access token was not found in key vault." -ErrorAction Continue
        return
    }
    
    $dataFactoryGatewayName = $parameters.parameters.databricksSelfHostedIRName.value
    $sourcePath = "$devOpsProjectFolder\DataFactoryV2\databricks.json"
    $linkedService = Get-Content -Path $sourcePath -Raw | ConvertFrom-JSON
	
    $linkedService.name = "LS_ADB"
    $linkedService.properties.typeProperties.newClusterNodeType = $parameters.parameters.databricksCluster1.value.node_type_id
    $linkedService.properties.typeProperties.newClusterNumOfWorker = ([string]($parameters.parameters.databricksCluster1.value.autoscale.min_workers) + ":" + $parameters.parameters.databricksCluster1.value.autoscale.max_workers)      
    $linkedService.properties.typeProperties.newClusterVersion = $parameters.parameters.databricksCluster1.value.spark_version
    $linkedService.properties.typeProperties.accessToken.secretName = $tokenSecretName
    # remove this node if using the default integration runtime is to be used i.e. it's blank
    if ($dataFactoryGatewayName -eq "") {
        # The link must use the default integration runtime.  To do this we must remove the
        # properties.connectVia value from the object.
        $obj1 = $linkedService.properties | Select type,typeProperties,accessToken
        $linkedService.properties = $obj1
    } else {
        $linkedService.properties.connectVia.referenceName = $dataFactoryGatewayName
    }
    $destinationPath = New-TemporaryFile
    Write-Verbose "Writing $destinationPath with link service details"
    $linkedService | ConvertTo-JSON -Depth 10 | Out-File -filepath $destinationPath -Force
    Write-Verbose $destinationPath
    return $destinationPath
}
function CreateLinkedService () {
    param( [string]$clusterId)
    $keyVaultName = $parameters.parameters.keyVaultName.value
    $tokenSecretName = $parameters.parameters.databricksTokenSecretName.value
    if (-not $tokenSecretName)
    {
        $tokenSecretName = "DatabricksAccessToken"
    }
    $accessToken = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $tokenSecretName -ErrorAction SilentlyContinue
    if (-not $accessToken) {
        Write-Error "Create databrick linked service failed because the access token was not found in key vault." -ErrorAction Continue
        return
    }
    
    $dataFactoryGatewayName = $parameters.parameters.databricksSelfHostedIRName.value
    $sourcePath = "$devOpsProjectFolder\DataFactoryV2\databricks.existingcluster.json"
    $linkedService = Get-Content -Path $sourcePath -Raw | ConvertFrom-JSON
	
    $linkedService.properties.typeProperties.existingClusterId = $clusterId
    $linkedService.properties.typeProperties.accessToken.secretName = $tokenSecretName
    # remove this node if using the default integration runtime is to be used i.e. it's blank
    if ($dataFactoryGatewayName -eq "") {
        # The link must use the default integration runtime.  To do this we must remove the
        # properties.connectVia value from the object.
        $obj1 = $linkedService.properties | Select type,typeProperties,accessToken
        $linkedService.properties = $obj1
    } else {
        $linkedService.properties.connectVia.referenceName = $dataFactoryGatewayName
    }
    $destinationPath = New-TemporaryFile
    Write-Verbose "Writing $destinationPath with link service details"
    $linkedService | ConvertTo-JSON -Depth 10 | Out-File -filepath $destinationPath -Force
    Write-Verbose $destinationPath
    return $destinationPath
}
# Create Linked Service
$dataFactoryResourceGroupName = $parameters.parameters.dataFactoryResourceGroupName.value 
$dataFactoryName = $parameters.parameters.dataFactoryName.value
$linkedServiceName = $parameters.parameters.databricksLinkedServiceName.value
$cluster1Config = $parameters.parameters.databricksCluster1.value
$cluster2Config = $parameters.parameters.databricksCluster2.value

$df = Get-AzDataFactoryV2 -ResourceGroupName $dataFactoryResourceGroupName -Name $dataFactoryName -ErrorAction SilentlyContinue
if (-not $df) {
    throw "Data Factory does not exist. Please create it first."
}

if ($cluster1)
{
    Write-Host "Generating Databricks linked service configuration for cluster1"
    # Make sure the cluster exists
    $cluster = & "$utilitiesFolder\New-DataBricksClusterGet" -parameterFile $parameterFile -clusterName $cluster1Config.cluster_name
    if (-not $cluster) {
        # Create it
        $cluster = & "$utilitiesFolder\New-DataBricksCluster" -parameterFile $parameterFile
    }
    $tempOnPremConfigFile = CreateLinkedService -clusterId $cluster.cluster_id
}
elseif ($cluster2)
{
    Write-Host "Generating Databricks linked service configuration for cluster2"
    # Make sure the cluster exists
    $cluster = & "$utilitiesFolder\New-DataBricksClusterGet" -parameterFile $parameterFile -clusterName $cluster2Config.cluster_name
    if (-not $cluster) {
        # Create it
        $cluster = & "$utilitiesFolder\New-DataBricksCluster" -parameterFile $parameterFile -cluster2
    }
    $tempOnPremConfigFile = CreateLinkedService -clusterId $cluster.cluster_id
}
else {
    Write-Verbose "Generating Databricks linked service configuration for on demand cluster"
    $tempOnPremConfigFile = CreateOnDemandLinkedService
}
if ($tempOnPremConfigFile){
    Write-Verbose "Creating Databricks linked service configuration"
    $depl = Set-AzDataFactoryV2LinkedService -ResourceGroupName  $dataFactoryResourceGroupName `
    -DataFactoryName $dataFactoryName -Name $linkedServiceName -DefinitionFile $tempOnPremConfigFile -Force        
}
# For the dev environment created a dedicated cluster for testers.  This uses pass through so that the credentials of
# the caller are used to access ADLS
if ($parameters.parameters.projectEnvironment.value -eq 'd'){
    $cluster = & "$utilitiesFolder\New-DataBricksClusterForTester" -parameterFile $parameterFile
}