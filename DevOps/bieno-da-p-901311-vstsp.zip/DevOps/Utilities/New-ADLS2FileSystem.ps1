[CmdletBinding()]
Param(
    [Parameter(Mandatory = $true, Position = 1)] [string] $parameterFile,
    [Parameter(Mandatory = $True, Position = 2)] [string] $bearerToken,
    [Parameter(Mandatory = $False, Position = 3)] [string] $filesystemName="unilever"
)
# Rest documentation:
# https://docs.microsoft.com/en-us/rest/api/storageservices/datalakestoragegen2/path/create

# Create a new hierarchical file system in ADLS Gen2.  This appears as a container off the root
$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile
$method = "PUT"

$headers = @{ } 
$headers.Add("x-ms-version", "2018-11-09")
$headers.Add("Authorization", "Bearer $BearerToken")

$URI = "https://$($parameters.parameters.adlStoreName.value).dfs.core.windows.net/" + $FilesystemName + "?resource=filesystem"

try {
    Invoke-RestMethod -method $method -Uri $URI -Headers $headers # returns empty response
}
catch {
    $ErrorMessage = $_.Exception.Message
    $StatusDescription = $_.Exception.Response.StatusDescription

    Throw $ErrorMessage + " " + $StatusDescription + " FileSystemName: $filesystemName"
}