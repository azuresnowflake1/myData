Param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$parameterFile,
    [Parameter(Mandatory = $False, HelpMessage='Specify if you want to use an exising cluster')]
    [String]$clusterId,
    [Parameter(Mandatory = $False, HelpMessage='Specify the name of the ADLS mount point')]
    [String]$mountPointName="/mnt/adls",
    [Parameter(Mandatory = $False, HelpMessage='Specify the name of the central UDL/BDL ADLS mount point')]
    [String]$sharedMountPointName="/mnt/adls/centrallake",
    [Parameter(Mandatory = $False, HelpMessage='Specify the name of the PSLZ UDL ADLS mount point')]
    [String]$pslzMountPointName="/mnt/adls/pslzlake",
    [Parameter(Mandatory = $False, HelpMessage='Specify the name of the storage container mount point')]
    [String]$containerName="databricks",
    [Parameter(Mandatory = $False, HelpMessage='Specify if the local ADLS is Gen1 otherwise Gen2 is assumed')]
    [switch]$adlsGen1
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

$applicationId = $parameters.parameters.applicationId.value
$keyVaultName = $parameters.parameters.keyVaultName.value
$adlsName = $parameters.parameters.adlStoreName.value

$sharedAdlsName = $parameters.parameters.sharedAdlStoreName.value
$storageAccountResourceGroupName = $parameters.parameters.storageAccountResourceGroupName.value
$storageAccountName = $parameters.parameters.storageAccountName.value
$pslzFolderName = $parameters.parameters.pslzFolderName.value 
$pslzStoreName = $parameters.parameters.pslzStoreName.value
$region = $parameters.parameters.location.value.Replace(" ","")
# The name of the ADLSGen2 file system
$fileSystemName = "unilever"
# Handle Gen1 and Gen2 for the local ADLS mount point
if ($adlsGen1) {
    $adlsName = $parameters.parameters.adlStoreNameGen1.value
    $localMountUri = "adl://$adlsName.azuredatalakestore.net/Unilever"
    $localMountConfigName = "configsAdlsGen1"
} else {
    $localMountUri = "abfss://$fileSystemName@$adlsName.dfs.core.windows.net/"
    $localMountConfigName = "configs"
}
if ($Global:CtxBootStrap.Environment -eq "DR" -and -not $adlsGen1) {
    $localMountUri = "abfss://$fileSystemName@$adlsName-secondary.dfs.core.windows.net/"
    $localMountConfigName = "configs"
}


#$tokenSecretName = $parameters.parameters.databricksTokenSecretName.value
#if (-not $tokenSecretName)
#{
#    $tokenSecretName = "DatabricksAccessToken"
#}
#$secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $tokenSecretName -ErrorAction SilentlyContinue
#$accessToken = $secret.SecretValueText
$secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $parameters.parameters.adApplicationName.value -ErrorAction SilentlyContinue
$storageAccountKey = (Get-AzStorageAccountKey -ResourceGroupName $storageAccountResourceGroupName -Name $storageAccountName)[0].Value

if (-not ($containerName -eq ""))
{
    $storageContext = New-AzStorageContext -StorageAccountName $storageAccountName -StorageAccountKey $storageAccountKey 
    New-AzStorageContainer -Name $containerName -Context $storageContext -Permission Off -ErrorAction SilentlyContinue
}

$uriBase = "https://$region.azuredatabricks.net/api/2.0"


$script = @"
'''
This script is owned by landscape, do not edit it!  
It creates the default mandatory mount points for your ADLS and storage account.  It also creates an additional 
mount point for the UDL but in order to use this you must request folder access for your application SPN.  The UDL team
will grant access on a folder by folder basis.
'''
clientid="$($applicationId)"
credential=dbutils.secrets.get("Landscape","$($parameters.parameters.adApplicationName.value)")
storageAccountKey=dbutils.secrets.get("Landscape","$($storageAccountName)")
refreshurl="https://login.microsoftonline.com/f66fae02-5d36-495b-bfe0-78a6ff9f8e6e/oauth2/token"

configs = {"fs.azure.account.auth.type" : "OAuth",
           "fs.azure.account.oauth.provider.type" : "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
           "fs.azure.account.oauth2.client.id" : clientid,
           "fs.azure.account.oauth2.client.secret" : credential,
           "fs.azure.account.oauth2.client.endpoint" : refreshurl}

configs1 = {"fs.azure.account.key.$storageAccountName.blob.core.windows.net": storageAccountKey}

# Use this to mount Gen1 ADLS
configsAdlsGen1 = {"dfs.adls.oauth2.access.token.provider.type": "ClientCredential",
           "dfs.adls.oauth2.client.id": clientid,
           "dfs.adls.oauth2.credential": credential,
           "dfs.adls.oauth2.refresh.url": refreshurl}
try:
    dbutils.fs.unmount("/mnt/adls/centrallake")
except:
    print("Existing mount /mnt/adls/centrallake was not found.")
try:
    dbutils.fs.unmount("/mnt/adls")
except:
    print("Existing mount /mnt/adls was not found.")
try:
    dbutils.fs.unmount("/mnt/databricks")
except:
    print("Existing mount /mnt/databricks was not found.")
try:
    dbutils.fs.unmount("/mnt/adls/pslzlake")
except:
    print("Existing mount /mnt/adls/pslzlake was not found.")
try:
    dbutils.fs.unmount("/mnt/adls/dev")
except:
    print("Existing mount /mnt/adls/dev was not found.")


dbutils.fs.mount(
    source = "$localMountUri",
    mount_point = "$mountPointName",  extra_configs = $localMountConfigName)

dbutils.fs.mount(
  source = "wasbs://$containerName@$storageAccountName.blob.core.windows.net",
  mount_point = "/mnt/$containerName",  extra_configs = configs1)

dbutils.fs.mount(
    source = "adl://$sharedAdlsName.azuredatalakestore.net/Unilever",
    mount_point = "$sharedMountPointName",  extra_configs = configsAdlsGen1)

   
"@

if(-not ([string]::IsNullOrEmpty($pslzFolderName))) {

    # mount the adls using passthrough credentials
    $script += 
    @"

dbutils.fs.mount(
    source = "adl://$pslzStoreName.azuredatalakestore.net$pslzFolderName",
    mount_point = "$pslzMountPointName",  extra_configs = configsAdlsGen1) 
"@
}


if ("dx".Contains($parameters.parameters.projectEnvironment.value)) {
    # mount the adls using passthrough credentials
    $script += 
    @"

'''
This workspace has a tester cluster that can access ADLS using the user's credentials.
Mount the dev ADLS.
'''
configs2 = {
    "dfs.adls.oauth2.access.token.provider.type": "CustomAccessTokenProvider",
    "dfs.adls.oauth2.access.token.custom.provider": spark.conf.get("spark.databricks.passthrough.adls.tokenProviderClassName")
    }
    
dbutils.fs.mount(
    source = "adl://$adlsName.azuredatalakestore.net",
    mount_point = "/mnt/dev",
    extra_configs = configs2)
'''
dbutils.fs.mount(
    source = "adl://<QA adlsName>.azuredatalakestore.net",
    mount_point = "/mnt/qa",
    extra_configs = configs2)
    
dbutils.fs.mount(
    source = "adl://<PPD adlsName>.azuredatalakestore.net",
    mount_point = "/mnt/ppd",
    extra_configs = configs2)
    
dbutils.fs.mount(
    source = "adl://<Prod adlsName>.azuredatalakestore.net",
    mount_point = "/mnt/prod",
    extra_configs = configs2)
''' 
"@
}
    if (Adb-Get-Group -accessToken $accessToken){
        Adb-Remove-Group -accessToken $accessToken
    }
    
    $tmpFileName = [System.IO.Path]::GetTempFileName()
    $script | Out-File -FilePath $tmpFileName -Encoding ASCII -Force
    Write-Output $tmpFileName
    $landscapeDirectory = "/Landscape"
    $mountScriptPath = "$landscapeDirectory/mountadls"
    Adb-New-Directory -path $landscapeDirectory -accessToken $accessToken
    Adb-New-ImportNb -path "$mountScriptPath" -ifile $tmpFileName -accessToken $accessToken
    if ([string]::IsNullOrEmpty($clusterId)) {
        $job = Adb-New-Job -path $mountScriptPath -jname "mountAdls" 
    } else {
        $job = Adb-New-JobExistingCluster -path $mountScriptPath -jname "mountAdls" -clsId $clusterId
    }
    $job
    $run = Adb-New-RunJob -jobno $job.job_id
    
    $i=0
    while($true)
    {
        Write-Output "Waiting for ADLS mount job $i"
        Start-Sleep(15)
        $state = Adb-Get-Run -runId $run.run_id
        $s = $state.state
        
        if ($s)
        {
            Write-Verbose "$($s.life_cycle_state) *** $($s.state_message)"
            if ($s.life_cycle_state -eq "TERMINATED")
            {
                # job has finished. Check the state
                $r = Adb-Get-RunOutput -runId $run.run_id
                Write-Verbose $r.metadata.state
                if ($r.metadata.state.result_state -eq "SUCCESS") {
                    Write-Output "ADLS was successfully mounted."
                    break
                } else {
                    Write-Error "Mount ADLS failed: $($r.metadata.state.result_state) ** $($r.metadata.state.state_message)"
                    break
                }
                
            }
            elseif ($s.life_cycle_state -eq "INTERNAL_ERROR")
            {
                Write-Error "$($s.state_message)"
                Write-Error "The ADLS mount job has failed."
                break
            }
        }
        $i++
        if ($i -gt 28){
            Write-Warning "The ADLS mount job did not complete in the allotted time. ADLS may not be mounted"
            break
        }
    }

    
