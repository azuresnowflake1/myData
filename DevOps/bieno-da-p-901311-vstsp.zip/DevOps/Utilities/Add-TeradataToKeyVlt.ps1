Param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$parameterFile,
    
    [Parameter(Mandatory = $True, HelpMessage='The teradata server host name')]
    [String]$teradataHostName,

    [Parameter(Mandatory = $True, HelpMessage='The teradata user name')]
    [String]$teradataUserName,

    [Parameter(Mandatory = $True, HelpMessage='The teradata user password')]
    [String]$teradataPassword,

    [Parameter(Mandatory = $False, HelpMessage='A suffix to add the keyvault names')]
    [String]$namingSuffix = "01"
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

& "$utilitiesFolder\Test-Login.ps1"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

$teradataHostnameKeyVaultName =  "TeradataHostName$namingSuffix"
$teradataUserNameKeyVaultName = "TeradataUserName$namingSuffix"
$teradataPasswordKeyVaultName = "TeradataPassword$namingSuffix"
$secretExpiryYears = $parameters.parameters.keyVaultSecretExpiryTerm.value

$secureSecret = ConvertTo-SecureString -AsPlainText $teradataHostName -Force
$secretCredential = New-Object System.Management.Automation.PSCredential ($teradataHostnameKeyVaultName, $secureSecret)
$contentType = "The host name for teradata service. Used in an ADF linked service."
& "$utilitiesFolder\Set-KeyVaultSecret.ps1" -parameterFile $parameterFile -secretCredential $secretCredential -secretExpiryTermYears $secretExpiryYears -contentType $contentType

$secureSecret = ConvertTo-SecureString -AsPlainText $teradataUserName -Force
$secretCredential = New-Object System.Management.Automation.PSCredential ($teradataUserNameKeyVaultName, $secureSecret)
$contentType = "The user name used to access a teradata service. Used in an ADF linked service."
& "$utilitiesFolder\Set-KeyVaultSecret.ps1" -parameterFile $parameterFile -secretCredential $secretCredential -secretExpiryTermYears $secretExpiryYears -contentType $contentType

$secureSecret = ConvertTo-SecureString -AsPlainText $teradataPassword -Force
$secretCredential = New-Object System.Management.Automation.PSCredential ($teradataPasswordKeyVaultName, $secureSecret)
$contentType = "The user password for an account used to acceess a teradata service. Used in an ADF linked service."
& "$utilitiesFolder\Set-KeyVaultSecret.ps1" -parameterFile $parameterFile -secretCredential $secretCredential -secretExpiryTermYears $secretExpiryYears -contentType $contentType
