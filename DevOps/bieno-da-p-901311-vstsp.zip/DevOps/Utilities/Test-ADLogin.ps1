try {
    $application = Get-AzureADApplication -SearchString "xxyz"
}
catch {
    Write-Host "Login to Azure AD ..."
    Connect-AzureAD
}
