
Uninstall-Module -Name Az -AllVersions
Uninstall-Module -Name AzureRM -AllVersions
Uninstall-Module -Name SqlServer -AllVersions
Uninstall-Module -Name AzureAD -AllVersions
Set-PSRepository -Name 'PSGallery' -InstallationPolicy Trusted
Install-Module -Name Az -RequiredVersion 2.8.0 -AllowClobber 
Install-Module -Name SqlServer -RequiredVersion 21.1.18179 -AllowClobber
Install-Module -Name AzureAD -RequiredVersion 2.0.2.50 -AllowClobber 
