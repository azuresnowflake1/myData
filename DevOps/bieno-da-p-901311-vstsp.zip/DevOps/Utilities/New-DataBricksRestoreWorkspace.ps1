param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$parameterFile,
    [Parameter(ParameterSetName='forSingleUsers')]
    [String]$forUserEmailID,
    [Parameter(ParameterSetName='forAllUsers')]
    [Switch]$forAllUsers
)

$emailRegex = '^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$'

if($forAllUsers -ne $true){
    $didItMatch = $forUserEmailID -match $emailRegex
    if ($didItMatch -eq $false) {
        Write-Error "please provide user email id to restore single user or select switch forAllUsers to restore all users"
        return
    }    
}

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile
$keyVaultName = $parameters.parameters.keyVaultName.value
$tokenSecretName = "DatabricksAccessToken" #$parameters.parameters.databricksTokenSecretName.value
$secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $tokenSecretName
$accessToken = $secret.SecretValueText
$region=$parameters.parameters.location.value.Replace(" ", "")
$uriBase = "https://$region.azuredatabricks.net/api/2.0"
$head = @{authorization = "Bearer $accessToken" }

$logcontent = [System.Collections.ArrayList]@()




$usersList = Adb-get-allUserWorkspaces -path "/Users/" 

if($forAllUsers){
    $usersList = $usersList.objects
}else{
        $usersList = $usersList.objects.where{($_.path).contains($forUserEmailID.ToLower())}
}

foreach ($object in $usersList | Sort-Object path -Descending){
    $object_path = $object.path
    $object_type = $object.object_type
    Write-Output "$object_type : $object_path"
    if($object_path.contains("-backup-")){
        Adb-read-WorkspaceContent -userWorkspaces $object
    }
}

$logcontent | Export-Csv -Path .\DataBricksRestoreWorkspace.csv
