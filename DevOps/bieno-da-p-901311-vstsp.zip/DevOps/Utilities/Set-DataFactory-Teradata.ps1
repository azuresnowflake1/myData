Param
(
    [Parameter(Mandatory = $True, HelpMessage = 'Specify the parameter file')]
    [String]$parameterFile,

    [Parameter(Mandatory = $False, HelpMessage = 'Specify how to authenticate, Basic or Windows.  Defaults to Basic')]
    [String]$authenticationType = "Basic",

    [Parameter(Mandatory = $False, HelpMessage = 'Specify the linked service name suffix')]
    [String]$namingSuffix = "01"
)

Write-Verbose "PSScriptRoot is: $PSScriptRoot"
$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
Write-Verbose "DevOps Project Folder: $devOpsProjectFolder"
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

function CreateOnPremiseTeradataLinkedService () {

    $keyVaultName = $parameters.parameters.keyVaultName.value
    $hostname = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name "TeradataHostName$namingSuffix" -ErrorAction SilentlyContinue
    $userid =  Get-AzKeyVaultSecret -VaultName $keyVaultName -Name "TeradataUserName$namingSuffix" -ErrorAction SilentlyContinue
         
    $dataFactoryGatewayName = $parameters.parameters.dataFactoryGatewayName.value;
    $sourcePath = "$devOpsProjectFolder\DataFactoryV2\OnPremTeradata.json"
    $OnPremLinkedService = Get-Content -Path $sourcePath -Raw | ConvertFrom-JSON
	$OnPremLinkedServiceName | ConvertTo-JSON | Write-Verbose
    $OnPremLinkedService.name = "OnPremTeradataLinkedService$namingSuffix"
    $OnPremLinkedService.properties.typeProperties.authenticationType = $authenticationType
    $OnPremLinkedService.properties.typeProperties.server = $hostname.SecretValueText       
    $OnPremLinkedService.properties.typeProperties.username = $userid.SecretValueText
    $OnPremLinkedService.properties.typeProperties.password.secretName = "TeradataPassword$namingSuffix"
    $OnPremLinkedService.properties.connectVia.referenceName = $dataFactoryGatewayName

    $destinationPath = New-TemporaryFile
    Write-Verbose "Writing $destinationPath with link service details"
    $OnPremLinkedService | ConvertTo-JSON -Depth 10 | Out-File -filepath $destinationPath -Force
    return $destinationPath
}

# Create Linked Services
$dataFactoryResourceGroupName = $parameters.parameters.dataFactoryResourceGroupName.value 
$dataFactoryName = $parameters.parameters.dataFactoryName.value
Write-Verbose "$dataFactoryResourceGroupName $dataFactoryName"
$df = Get-AzDataFactoryV2 -ResourceGroupName $dataFactoryResourceGroupName -Name $dataFactoryName -ErrorAction SilentlyContinue
if ($df -eq $null) {
    throw "Data Factory does not exist. Please create it first."
}

Write-Verbose "Generating On Premise linked service configuration"
$tempOnPremConfigFile = CreateOnPremiseTeradataLinkedService
Write-Verbose "Creating On Premise Teradata linked service configuration"
$depl = Set-AzDataFactoryV2LinkedService -ResourceGroupName  $dataFactoryResourceGroupName `
-DataFactoryName $dataFactoryName -Name "OnPremTeradataLinkedService$namingSuffix" -DefinitionFile $tempOnPremConfigFile -Force        
