param(
	[Parameter(Mandatory=$true)][string]$xmlaCubeFilesDirectory,
	[Parameter(Mandatory=$true)][string]$parameterFile,
    [Parameter(Mandatory = $false)][switch]$whitelist
	
)

# Deploy the SAAS Cubes *.xmla in a specified folder using a SSAS admin username/Password
$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$a = Get-Module -ListAvailable -Name SqlServer
if (-not $a)
{
	Write-Host "installing SqlServer modules: start"
	Install-Module -Name SqlServer -Force -AllowClobber
	Write-Host "installing modules: end"

	Write-Host "getting modules list: start"
	Get-Module SqlServer -ListAvailable
	Write-Host "getting modules list: end"
}

# Write-Host "listing commands: start"
Import-Module -Name SqlServer

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile
$ssasServer = $parameters.parameters.analysisServicesName.value
$keyVaultName = $parameters.parameters.keyVaultName.value
$tenantId = $parameters.parameters.tenantId.value
$databaseServer = $parameters.parameters.sqlServerName.value
$databaseServer += ".database.windows.net"
$databaseName = $parameters.parameters.sqlDataWarehouseName.value
$appId = $parameters.parameters.applicationId.value
$location = $parameters.parameters.location.value
$region = $location.ToLower().Replace(" ", "")
$appSecret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $parameters.parameters.adApplicationName.value -ErrorAction SilentlyContinue

$aasUserId = $parameters.parameters.analysisServicesSqlUserLogin.value
$aasUserPwd = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $aasUserId -ErrorAction SilentlyContinue

$Credential = New-Object System.Management.Automation.PSCredential($appId, $appSecret.SecretValue)

$AASServerName = "asazure://$region.asazure.windows.net/$ssasServer"
$rolloutEnvironment = $AASServerName.Replace("asazure://", "").Split("/")[0]

if ($whitelist) {
	# whitelist the AAS server
	& "$utilitiesFolder\Set-SSASWhitelist" -parameterFile $parameterFile -forMe -ruleName "AASDeploy"
}

$magicServer = "##databaseServerName##"
$magicDatabase = "##databaseName##"
$magicUser = "##userId##"
$magicPassword = '##password##'

foreach($xmlaCubeFile in (Get-ChildItem -Path $xmlaCubeFilesDirectory -Filter "*.xmla"))
{
	$filePath = '{0}\{1}' -f $xmlaCubeFilesDirectory, $xmlaCubeFile
	Write-Verbose "Deploy AAS cube file $xmlaCubeFile"

	# Replace magic strings for database server, database, user and password		
	#$xmlaQuery = [string](get-content $filePath -Raw)
	$xmlaQuery = [string](get-content $filePath -Encoding UTF8)
	$xmlaQuery = $xmlaQuery -replace $magicPassword, $aasUserPwd.SecretValueText
	$xmlaQuery = $xmlaQuery -replace $magicServer, $databaseServer
	$xmlaQuery = $xmlaQuery -replace $magicDatabase, $databaseName
	$xmlaQuery = $xmlaQuery -replace $magicUser, $aasUserId
	Write-Verbose $xmlaQuery
	Invoke-ASCmd -Server $AASServerName -Query $xmlaQuery -Credential $Credential -ServicePrincipal -TenantId $tenantId
	#Invoke-ProcessASDatabase -Server $AASServerName -DatabaseName $AASDatabaseName -RefreshType "Full"
}
if ($whitelist) {
	# whitelist the AAS server
	& "$utilitiesFolder\Set-SSASWhitelist" -parameterFile $parameterFile -forMe -ruleName "AASDeploy" -deleteRule
}

Write-Host "Deploy-SSASCube.ps1 script execution completed."