#This script is used to set the expiry of KeyVault Secret to less than 30 days to test refreshKeyVault script

function splitstring {
    param (
        $stringtosplit,
        $spliybychar 
    )
    $values = $stringtosplit.split($spliybychar)
    return $values
}

function Add-ContentToFile{
    param(
        $secretName,
        $currentSecretExpiry,
        $newSecretExpiry,
        $comments
        )
         
    $content = "$((get-date).ToUniversalTime()), $($secretName), $($currentSecretExpiry), $($newSecretExpiry), $($comments)"
    #Write-Output $content
    Add-Content $outputfile $content
}


$outputfile = "Test-RefreshKeyVault$(get-date -f yyyyMMddHHmmss).csv"
$header1 = "Time, Secret Name, Expiry Date, New Expiry Date, Comments"
$landscapeITSGs = "56731", "56730", "56732", "56728"
    
#Write-Output $header1

Add-Content $outputfile $header1

#temporary variables
$landscapreresourcegrop = "bnlwe-da04-d-56731-rg"
Select-AzSubscription "Core Data Ecosystem-04"
$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$lanscapeKeyVaults = Get-AzKeyVault -ResourceGroupName $landscapreresourcegrop

foreach($lanscapeKeyVault in $lanscapeKeyVaults)
{
    Write-Output "Validating KeyVault $($lanscapeKeyVault.VaultName)"
    $environment = (splitstring -stringtosplit $lanscapeKeyVault.VaultName -spliybychar "-")[2]
    $itsg = (splitstring -stringtosplit $lanscapeKeyVault.VaultName -spliybychar "-")[3]        
    if($landscapeITSGs.Contains($itsg))
    {
        continue
    }

    $parameterFile = "{0}.{1}.{2}.json" -f "parameters", $environment, $itsg
    #$parameterFile = "parameters.d.00018.json"
    Write-Output "Parameter file $($parameterFile)"
    $parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

    if($lanscapeKeyVault.VaultName -ne "bnlwe-da04-d-00018-kv-01"){
        continue
    }

    if($lanscapeKeyVault.VaultName -eq $parameters.parameters.landscapeKeyVaultName.value){
        continue
    }

    $keyvaultsecrets = Get-AzKeyVaultSecret -VaultName $lanscapeKeyVault.VaultName
    foreach($keyvaultsecret in $keyvaultsecrets){            
        if($null -eq $keyvaultsecret.expires){
            $outputcontent = "$($keyvaultsecret.Name) does not expire"
            Write-Output $outputcontent
            continue
        }
        $certPasswordKey = "{0}-Password" -f $parameters.parameters.applicationIdentityCertificateName.value
        $secretsArray = $parameters.parameters.batchAccountName.value, $parameters.parameters.adApplicationName.value, $parameters.parameters.applicationIdentityCertificateName.value, $certPasswordKey, $parameters.parameters.analysisServicesSqlUserLogin.value,  $parameters.parameters.storageAccountConnectionSecretName.value
        $oldExpiry = $keyvaultsecret.expires.ToUniversalTime()
        $NewExpiry = ""
        if($secretsArray.Contains($keyvaultsecret.name) ){
            $daysdifference = NEW-TIMESPAN -Start (get-date).ToUniversalTime() -End $keyvaultsecret.expires.ToUniversalTime()
            if($daysdifference.Days -ge 30){
                $NewExpiry = (Get-Date).AddDays(10).ToUniversalTime()
                $Nbf = (Get-Date).ToUniversalTime()
                Update-AzureKeyVaultSecret -VaultName $lanscapeKeyVault.VaultName -Name $keyvaultsecret.Name -Expires $NewExpiry -NotBefore $Nbf
                $outputcontent = "$($keyvaultsecret.Name): updated Key Expiry to $($NewExpiry) from $($oldExpiry) in KeyVault $($lanscapeKeyVault.VaultName)"
                Write-Output $outputcontent
                Add-ContentToFile -secretName $keyvaultsecret.name -currentSecretExpiry $oldExpiry -newSecretExpiry $NewExpiry -comments $outputcontent
            }else{
                $outputcontent = "$($keyvaultsecret.Name): is expiring within 30 days"
                Write-Output $outputcontent
                Add-ContentToFile -secretName $keyvaultsecret.name -currentSecretExpiry $oldExpiry -newSecretExpiry $NewExpiry -comments $outputcontent
            }
        }else {
            $outputcontent = "$($keyvaultsecret.Name): not required to refresh"
            Write-Output $outputcontent
            Add-ContentToFile -secretName $keyvaultsecret.name -currentSecretExpiry $oldExpiry -newSecretExpiry $NewExpiry -comments $outputcontent
        }
    }
}
