Param
(
    [Parameter(Mandatory = $True, HelpMessage = 'Specify the parameter file')]
    [String]$parameterFile,
    [Parameter(Mandatory = $False, HelpMessage = 'Specify the umask to set. Default is 000.')]
    [String]$umask = "000"
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

$clusterName = $parameters.parameters.clusterName.value

$clusterAdminLogin = $parameters.parameters.clusterAdminLogin.value  
$keyVaultName = $parameters.parameters.keyVaultName.value
$secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $clusterAdminLogin -ErrorAction SilentlyContinue
$clusterAdminPassword = $secret.SecretValue

$credential = New-Object System.Management.Automation.PSCredential ($clusterAdminLogin, $clusterAdminPassword)
$serviceName = "HDFS"

function Set-UMaskConfig {
    $ambariURL = "https://{0}.azurehdinsight.net/api/v1/clusters/{0}/configurations?type=hdfs-site&tag=INITIAL" -f $clusterName
    $params = @{    
        ContentType = 'application/json'
        body        = $body
        Method      = 'Get'    
        URI         = $ambariURL
        Credential  = $credential
    }
    Write-Verbose "Getting the spark-thrift config"
    $configParameters = Invoke-RestMethod @params

    $dateTime = (Get-Date).ToString("yyyyMMddhhmmss")
    $newConfigParameters = New-Object PSObject -Property @{   
        Clusters = @{
            desired_config = @{
                tag                   = "version$dateTime"
                type                  = "hdfs-site"
                properties            = $configParameters.items.properties
                properties_attributes = $configParameters.items.properties_attributes
            }
        }
    }

    $newConfigParameters.Clusters.desired_config.properties."fs.permissions.umask-mode" = $umask
    $body = $newConfigParameters | ConvertTo-JSON -Depth 10

    $ambariURL = "https://{0}.azurehdinsight.net/api/v1/clusters/{0}" -f $clusterName
    $params = @{
        body       = $body
        Method     = 'Put'    
        URI        = $ambariURL
        Credential = $credential
        Headers    = @{
            "X-Requested-By" = "ambari"
        }        
    }
    $response = Invoke-WebRequest @params -UseBasicParsing
}
function Set-MaintenanceStatusOn {
    $maintenanceOnServiceMessage = New-Object PSObject -Propert @{
        RequestInfo = @{
            context = "Turning on maintenance mode for $serviceName"
        }
        Body        = @{
            ServiceInfo = @{
                maintenance_state = "ON"
            }
        }
    }
    $body = $maintenanceOnServiceMessage | ConvertTo-Json -Depth 10
    $ambariURL = "https://{0}.azurehdinsight.net/api/v1/clusters/{0}/services/{1}" -f $clusterName, $serviceName
    $params = @{
        body       = $body
        Method     = 'Put'    
        URI        = $ambariURL
        Credential = $credential
        Headers    = @{
            "X-Requested-By" = "ambari"
        } 
    }
    $response = Invoke-WebRequest @params -UseBasicParsing
}
function Get-MaintenanceStatus {
    $ambariURL = "https://{0}.azurehdinsight.net/api/v1/clusters/{0}/services/{1}" -f $clusterName, $serviceName
    $params = @{
        Method     = 'Get'    
        URI        = $ambariURL
        Credential = $credential
        Headers    = @{
            "X-Requested-By" = "ambari"
        } 
    }
    $response = Invoke-WebRequest @params -UseBasicParsing
    $respObj = ConvertFrom-Json $response.Content
    $status = $respObj.ServiceInfo.maintenance_state
    Write-Verbose "Maintenance status is $status"
}
function Set-ServiceOff {
    $turnOffServiceMessage = New-Object PSObject -Propert @{
        RequestInfo = @{
            context         = "_PARSE_.STOP.$serviceName"
            operation_level = @{
                level        = "SERVICE"
                cluster_name = "CLUSTERNAME"
                service_name = $serviceName
            }        
        }
        Body        = @{
            ServiceInfo = @{
                state = "INSTALLED"
            }
        }
    }
    $body = $turnOffServiceMessage | ConvertTo-Json -Depth 10
    $ambariURL = "https://{0}.azurehdinsight.net/api/v1/clusters/{0}/services/{1}" -f $clusterName, $serviceName
    $params = @{
        body       = $body
        Method     = 'Put'    
        URI        = $ambariURL
        Credential = $credential
        Headers    = @{
            "X-Requested-By" = "ambari"
        } 
    }
    $response = Invoke-WebRequest @params -UseBasicParsing
    $responseMessage = ConvertFrom-Json $response.Content
    $requestId = $responseMessage.Requests.id
    Write-Verbose "Request Id is $requestId"
    return $requestId
}
function Test-PendingRequests {
    param(
        [string]$requestId
    )
    $ambariURL = "https://{0}.azurehdinsight.net/api/v1/clusters/{0}/requests" -f $clusterName
    $params = @{
        Method     = 'Get'    
        URI        = $ambariURL
        Credential = $credential
        Headers    = @{
            "X-Requested-By" = "ambari"
        } 
    }
    $response = Invoke-WebRequest @params -UseBasicParsing
    $responseMessage = ConvertFrom-Json $response.Content
    foreach ($item in $responseMessage.items.Requests.id) {
        $status = Get-ServiceCompletedStatus -requestId $item
        if ($status -ne "COMPLETED")
        {
            return $true;
        }
    }
    return $false
}
function Get-ServiceCompletedStatus {
    param(
        [string]$requestId
    )
    $ambariURL = "https://{0}.azurehdinsight.net/api/v1/clusters/{0}/requests/{1}" -f $clusterName, $requestId
    $params = @{
        Method     = 'Get'    
        URI        = $ambariURL
        Credential = $credential
        Headers    = @{
            "X-Requested-By" = "ambari"
        } 
    }
        $response = Invoke-WebRequest @params -UseBasicParsing
        $respObj = ConvertFrom-Json $response.Content
        $status = $respObj.Requests.request_status
        Write-Verbose "Status of turn off request is $status"
        return $status
}
function Test-ServiceCompletedStatus {
    param(
        [string]$requestId
    )
    do {
        $status = Get-ServiceCompletedStatus -requestId $requestId
        if ($status -ne "COMPLETED") {
            Write-Output "Task not completed. Sleeping for 5 seconds..."
            Start-Sleep -s 5
        }
        else {
            Write-Output "Task completed"
        }
    }while ($status -ne "COMPLETED")
}
function Set-ServiceOn {
    $turnOnServiceMessage = New-Object PSObject -Propert @{
        RequestInfo = @{
            context         = "_PARSE_.STOP.$serviceName"
            operation_level = @{
                level        = "SERVICE"
                cluster_name = "CLUSTERNAME"
                service_name = $serviceName
            }        
        }
        Body        = @{
            ServiceInfo = @{
                state = "STARTED"
            }
        }
    }
    $body = $turnOnServiceMessage | ConvertTo-Json -Depth 10
    $ambariURL = "https://{0}.azurehdinsight.net/api/v1/clusters/{0}/services/{1}" -f $clusterName, $serviceName
    $params = @{
        body       = $body
        Method     = 'Put'    
        URI        = $ambariURL
        Credential = $credential
        Headers    = @{
            "X-Requested-By" = "ambari"
        } 
    }
    $response = Invoke-WebRequest @params -UseBasicParsing
}
function Set-MaintenanceStatusOff {
    $maintenanceOffServiceMessage = New-Object PSObject -Propert @{
        RequestInfo = @{
            context = "Turning off maintenance mode for $serviceName"
        }
        Body        = @{
            ServiceInfo = @{
                maintenance_state = "OFF"
            }
        }
    }
    $body = $maintenanceOffServiceMessage | ConvertTo-Json -Depth 10
    $ambariURL = "https://{0}.azurehdinsight.net/api/v1/clusters/{0}/services/{1}" -f $clusterName, $serviceName
    $params = @{
        body       = $body
        Method     = 'Put'    
        URI        = $ambariURL
        Credential = $credential
        Headers    = @{
            "X-Requested-By" = "ambari"
        } 
    }
    $response = Invoke-WebRequest @params -UseBasicParsing
}
function Set-UMask {
    Set-UMaskConfig
    Set-MaintenanceStatusOn
    Get-MaintenanceStatus
    $requestId = Set-ServiceOff
    Test-ServiceCompletedStatus -requestId $requestId
    Set-ServiceOn
    Set-MaintenanceStatusOff
    Get-MaintenanceStatus
}

while (Test-PendingRequests)
{
    Write-Output "Waiting 5 seconds for pending requests to complete..."
    Start-Sleep -s 5
}

Set-UMask
