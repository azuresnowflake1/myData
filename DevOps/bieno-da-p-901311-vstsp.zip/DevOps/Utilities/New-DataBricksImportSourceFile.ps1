Param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the databricks pesonnal accesstoken')]
    [String]$accessToken,
    [Parameter(Mandatory = $True, HelpMessage='Specify the source directory path')]
    [String]$sourceFilePath,
    [Parameter(Mandatory = $True, HelpMessage='Specify the target directory path for the file to be imported into')]
    [String]$targetDirectory,
    [Parameter(Mandatory = $False, HelpMessage='Specify to create the target workspace folder if required')]
    [switch]$createTargetFolder,
    [Parameter(Mandatory = $False, HelpMessage='Specify to force file overwrite.  If the file exists and this is not specified an error will occur')]
    [switch]$overwriteExisting,
    [Parameter(Mandatory = $False, HelpMessage='Specify the region')]
    [String]$region="westeurope"
)
# Import a single source file into a work space.  IF the target folder doesn't exist, create it
# DON'T USE THIS FOR DBC FILES

$uriBase = "https://$region.azuredatabricks.net/api/2.0"
add-type @"
using System.Net;
using System.Security.Cryptography.X509Certificates;
public class TrustAllCertsPolicy : ICertificatePolicy {
    public bool CheckValidationResult(
        ServicePoint srvPoint, X509Certificate certificate,
        WebRequest request, int certificateProblem) {
        return true;
    }
}
"@
$AllProtocols = [System.Net.SecurityProtocolType]'Ssl3,Tls,Tls11,Tls12'
[System.Net.ServicePointManager]::SecurityProtocol = $AllProtocols

$targetDirectory = $targetDirectory -replace "\\", "/"
$fileName = Split-Path -Path $sourceFilePath -Leaf
$a=($fileName -split "\.")

$extension = $a[1]
$targetPath = Join-Path -Path $targetDirectory -ChildPath $a[0]
$targetPath = $targetPath -replace "\\", "/"

if ($extension -eq "scala") {
    $language = "SCALA"
} elseif ($extension -eq "py") {
    $language = "PYTHON"
}
elseif ($extension -eq "sql") {
    $language = "SQL"
}
elseif ($extension -eq "r") {
    $language = "R"
}
else {
    # assume DBC.  language is ignored here
    Write-Error "You cannot use this script to import files with extension '$extension' use New-DataBricksImportDbc.ps1"
    return
}

$overwrite = "false"
if ($overwriteExisting){
    $overwrite = "true"
}
function New-ImportNb {
    param( [string]$path="/Shared", [string]$ifile="")
    $uri = "$uriBase/workspace/import"
    $head = @{authorization = "Bearer $accessToken" }
    $BinaryContents = [System.IO.File]::ReadAllBytes("$ifile")
    $EncodedContents = [System.Convert]::ToBase64String($BinaryContents)
    $Body = @"
    {
        "format": "SOURCE",
        "content": "$EncodedContents",
        "path": "$path",
        "overwrite": $overwrite,
        "language": "$language"
    }
"@

    $result = Invoke-RestMethod -Uri $uri -Body $Body -Method 'POST' -Headers $head -ContentType "application/json"
}

function Get-Directory {
    param( [string]$path)
    # list the folders in the parent folder and look for a match
    $head = @{authorization = "Bearer $accessToken" }
    $parentPath = Split-Path -Path $path -Parent
    $parentPath = $parentPath  -replace "\\", "/"
    $uri = "$uriBase/workspace/list?path=$parentPath"

    try {
        $directories = Invoke-RestMethod -Uri $uri -Method 'GET' -Headers $head -ContentType "application/json"
    } catch {
        Write-Host "Failed to list Databricks workspace path '$parentPath'"
        $statusCode = $_.Exception.Response.StatusCode.value__
        if ($statusCode -eq "404") {
            Write-Host "Target workspace path '$parentPath' does not exist"
            $directories = $null
        } else {
            Write-Error "HTTP status code $statusCode"
            throw $_.Exception
        }
    }

    if ($directories)
    {
        foreach($dir in $directories.objects)
        {
            if ($dir.object_type -eq "DIRECTORY" -and $dir.path -eq $path){
                Write-Host "Target workspace path '$path' already exists."
                return $dir
            }
        }
    }
    return $null
}

function New-Directory {
    param( [string]$path="/")
        $path = $path -replace "\\", "/"
        $uri = "$uriBase/workspace/mkdirs"
        $head = @{authorization = "Bearer $accessToken" }
        $body = @"
    {
        "path": "$path"
    }
"@
    $result = Invoke-RestMethod -Uri $uri -Body $Body -Method 'POST' -Headers $head -ContentType "application/json"
}

function Remove-Directory {
    param( [string]$path="/")
    $uri = "$uriBase/workspace/delete"
    $head = @{authorization = "Bearer $accessToken" }
    $body = @"
    {
        "path": "$path",
        "recursive": true
    }
"@
    $result = Invoke-RestMethod -Uri $uri -Body $Body -Method 'POST' -Headers $head -ContentType "application/json"
}

Write-Host "Importing source file '$sourceFilePath' into workspace path '$targetDirectory'"
if ($createTargetFolder -and (-not (Get-Directory -path $targetDirectory))) {
    Write-Host "Creating workspace path '$targetDirectory'"
    New-Directory -path $targetDirectory
}

New-ImportNb -path $targetPath -ifile $sourceFilePath
Write-Host "Imported source file '$sourceFilePath' into workspace path '$targetDirectory'"