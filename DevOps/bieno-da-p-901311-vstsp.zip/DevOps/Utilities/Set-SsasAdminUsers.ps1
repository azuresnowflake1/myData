Param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$parameterFile,
    
    [Parameter(Mandatory = $False, HelpMessage='A comma separated list of email addresses to set as SSAS admins')]
    [String]$emailAddressesCsv
)
# Set the SSAS admins using a comma separated list of email addresses

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

& "$utilitiesFolder\Test-Login.ps1"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile
$resourceGroupName = $parameters.parameters.analysisServicesResourceGroupName.value
$ssasServerName = $parameters.parameters.analysisServicesName.value

Set-AzAnalysisServicesServer -Name $ssasServerName -ResourceGroupName $resourceGroupName -Administrator $emailAddressesCsv
