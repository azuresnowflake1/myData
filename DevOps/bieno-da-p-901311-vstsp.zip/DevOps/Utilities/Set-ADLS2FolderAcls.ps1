[CmdletBinding()]
Param(
    [Parameter(Mandatory = $true, Position = 1)] [object] $parameterFile,
    [Parameter(Mandatory = $True, Position = 2)] [string] $path,
    [Parameter(Mandatory = $True, Position = 3)] [string[]] $acls,
    [Parameter(Mandatory = $True, Position = 4)] [string] $bearerToken,
    [Parameter(Mandatory = $false, Position = 6)] [string] $fileSystemName="unilever"
)
# Rest documentation:
# https://docs.microsoft.com/en-gb/rest/api/storageservices/datalakestoragegen2/path/update

# Set the acl for a specified path.  Note that the list replaces the existing list.
# ACL string format is defined in the REST doc link above.  It is set in the header against x-ms-acl
$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile


# our default ACLs assume the ADLS file system was provisioned using the deployment SPN
function Get-DefaultAcls {
    Param(
    [string] $objectId
)
    #[scope:][type]:[id]:[permissions]
    $aclFormat = "{0}{1}:{2}:{3}"
    $acl = @()

    $acl += $aclFormat -f "", "user","" , "rwx"
    $acl += $aclFormat -f "", "group", "" , "r-x"
    $acl += $aclFormat -f "", "other", "", "---"

    return $acl
}

# $acls = @()
# $acls += "{0}{1}:{2}:{3}" -f "", "user", $parameters.parameters.servicePrincipalId.value, "rwx"
# $acls += "{0}{1}:{2}:{3}" -f "default:", "user", $parameters.parameters.servicePrincipalId.value, "r-x"
$acList = @() #+ (Get-DefaultAcls -objectId $parameters.parameters.deploymentServicePrincipalId.value)
$acList += $acls

$method = "PATCH"

$headers = @{ } 
$headers.Add("x-ms-version", "2018-11-09")
$headers.Add("Authorization", "Bearer $BearerToken")
$headers.Add("x-ms-acl", ($acList -join ","))

if ($path -eq "/" -or $path -eq "") {
    # we need to retain the / before the query parameters in the uri when setting acls on the root
    $path = (Join-Path -Path $fileSystemName -ChildPath $path).Replace("\", "/")
} else {
    $path = (Join-Path -Path $fileSystemName -ChildPath $path).Replace("\", "/").Trim('\','/')
}

$URI = "https://$($parameters.parameters.adlStoreName.value).dfs.core.windows.net/" + $path + "?action=setAccessControl"

try {

    $args = @{
        method=$method; 
        Uri=$URI; 
        Headers=$headers
    }
    Set-Delay -Command 'Invoke-RestMethod' -Args $args -Retries 20 -SecondsDelay 5 -Verbose # returns empty response
}
catch {
    $ErrorMessage = $_.Exception.Message
    $StatusDescription = $_.Exception.Response.StatusDescription

    Throw $ErrorMessage + " " + $StatusDescription + " ACLPath: $path"
}