Param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$parameterFile,

    [Parameter(HelpMessage='Specify whether to create the storage account')]
    [Switch]$Storage,

    [Parameter(HelpMessage='Specify whether to create the storage account')]
    [Switch]$KVwebapp,

    [Parameter(HelpMessage='Specify whether to create the storage account')]
    [Switch]$SharedStorage,

    [Parameter(HelpMessage='Specify whether to create the sql database')]
    [Switch]$SqlDb,

    [Parameter(HelpMessage='Specify whether to create the sql data warehouse')]
    [Switch]$SqlDW,

    [Parameter(HelpMessage='Specify whether to create the data factory')]
    [Switch]$DataFactory,

    [Parameter(HelpMessage='Specify whether to create the data factory v1')]
    [Switch]$DataFactoryV1,

    [Parameter(HelpMessage = 'Specify to configue the on prem file server linked service')]
    [Switch]$OnPremFileServer,    

    [Parameter(HelpMessage='Specify whether to create the batch account')]
    [Switch]$Batch,

    [Parameter(HelpMessage='Specify whether to create the batch account')]
    [Switch]$Redis,

    [Parameter(HelpMessage='Specify whether to create the data lake store gen2')]
    [Switch]$ADLStore,

    [Parameter(HelpMessage='Specify whether to create the data lake store gen1')]
    [Switch]$ADLStoreGen1,

    [Parameter(HelpMessage='Specify whether to create the data lake analytics')]
    [Switch]$ADLAnalytics,

    [Parameter(HelpMessage='Specify whether to create the HDInsight cluster')]
    [Switch]$HDInsight,

    [Parameter(HelpMessage='Specify whether to create the HDInsight cluster with R Server')]
    [Switch]$HDInsightRServer,

    [Parameter(HelpMessage='Specify whether to create the HDInsight cluster with R Server')]
    [Switch]$HDInsightwithDataLakeStore,

    [Parameter(HelpMessage='Specify whether to create the HDInsight cluster with R Server')]
    [Switch]$HDInsightRServerWithDataLakeStore,

    [Parameter(HelpMessage='Specify whether to create the Analysis Services')]
    [Switch]$AnalysisServices,

    [Parameter(HelpMessage='Specify whether to create the Analysis Services')]
    [Switch]$AnalysisServicesWithOPDG,
    
    [Parameter(HelpMessage='Specify whether to create the IotHub')]
    [Switch]$IoTHub,

    [Parameter(HelpMessage='Specify whether to create the IotHub Device Provisioning')]
    [Switch]$IoTDeviceProv,
    
    [Parameter(HelpMessage='Specify whether to create the Time Series Insights')]
    [Switch]$TimeSeriesInsights,

    [Parameter(HelpMessage='Specify whether to create the Web App Service')]
    [Switch]$WebApp,

    [Parameter(HelpMessage='Specify whether to create Functions Container')]
    [Switch]$Functions,

    [Parameter(HelpMessage='Specify whether to create Machine learning studio')]
    [Switch]$MachineLearning,

    [Parameter(HelpMessage='Specify whether to create a log analytics workspace')]
    [Switch]$LogAnalytics,

    [Parameter(HelpMessage='Specify to create a resource group budget alert')]
    [Switch]$budgetAlert,

    [Parameter(HelpMessage='Specify to create a Logic app')]
    [Switch]$LogicApp,   

    [Parameter(HelpMessage='Specify to create a Stream Analytics Job')]
    [Switch]$StreamAnalyticsJob
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"
$managerFolder = "{0}\{1}" -f $devOpsProjectFolder, "LandscapeManager"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

$subscriptionId = $parameters.parameters.subscriptionId.value
$tenantId = $parameters.parameters.tenantId.value
$secretExpiryYears = $parameters.parameters.keyVaultSecretExpiryTerm.value
$location = $parameters.parameters.location.value
# convert the tag values into a hash table
$tagValues = @{}
$parameters.parameters.tagValues.value.psobject.properties | ForEach-Object { $tagValues[$_.Name.Replace("tag", "")] = $_.Value }

function Get-Cred {
    param(
        [string] $userName
    )        
    $pwdPlain = & "$utilitiesFolder\New-Password.ps1"
    $password = ConvertTo-SecureString $pwdPlain -AsPlainText -Force
    $cred = New-Object System.Management.Automation.PSCredential ($userName, $password)
    return $cred
}

Function CreateAppServicePlan
{
    Param
    (
        [string]$webAppResourceGroupName,
        [string]$appServicePlanName
    )
    
    $location = $parameters.parameters.location.value

    $appServicePlan = Get-AzAppServicePlan -ResourceGroupName $webAppResourceGroupName `
                            -Name $appServicePlanName

    if(!$appServicePlan) {
        
        $appServicePlanDeploymentName = $appServicePlanName + "_depl"
        $appServicePlanTemplateName = "$devOpsProjectFolder\Templates\web.app.service.plan.template.json"

        New-AzResourceGroupDeployment -Name $appServicePlanDeploymentName `
        -appServicePlanName $appServicePlanName `
        -ResourceGroupName $webAppResourceGroupName `
        -TemplateFile $appServicePlanTemplateName `
        -location $location | Out-Null
    }

}

if ($KVwebapp)
{
    $location = $parameters.parameters.location.value
    $tenantId = $parameters.parameters.tenantId.value
    $upn = (Get-AzContext).Account.Id
    $user = Get-AzADUser -UserPrincipalName $upn
    $keyVaultAdmin = $user.Id

    $keyVaultResourceGroupName = $parameters.parameters.webAppResourceGroupName.value
    $keyVaultNameWA = $parameters.parameters.keyVaultNameWA.value
    $keyVaultDeploymentName = $sqlServerName + $keyVaultNameWA + "_depl"
    $keyVaultTemplateFile = "$devOpsProjectFolder\Templates\keyvault.json"

    # convert the tag values into a hash table
    $tagValues = @{ }
    $parameters.parameters.tagValues.value.psobject.properties | ForEach-Object { $tagValues[$_.Name.Replace("tag", "")] = $_.Value }

    New-AzResourceGroupDeployment  -ResourceGroupName $keyVaultResourceGroupName `
        -Name $keyVaultDeploymentName -TemplateFile $keyVaultTemplateFile `
        -keyvaultName $keyVaultNameWA -tenantid $tenantid -location $location `
        -objectid $keyVaultAdmin -skuName Standard `
        -enableVaultForDeployment $true -enableVaultForDiskEncryption $true `
        -enabledForTemplateDeployment $true `
        -keysPermissions "All" -secretsPermissions "All" `
        -tagValues $tagValues -Force | Out-Null

    $keyVault = Get-AzKeyVault -ResourceGroupName $keyVaultResourceGroupName -VaultName $keyVaultNameWA
    $keyVault.enableSoftDelete
}

if ($Storage) 
{
    $storageAccountResourceGroupName = $parameters.parameters.storageAccountResourceGroupName.value 
    $storageAccountName = $parameters.parameters.storageAccountName.value
    $storageAccountType = $parameters.parameters.storageAccountType.value

    $storageDeploymentName = $storageAccountName + "_depl"
    $storageTemplateFile = "$devOpsProjectFolder\Templates\storage.json"
    New-AzResourceGroupDeployment -Name $storageDeploymentName -TemplateFile $storageTemplateFile `
    -ResourceGroupName $storageAccountResourceGroupName `
    -storageAccountName $storageAccountName -location $location `
    -storageType $storageAccountType `
    -tagValues $tagValues | Out-Null
}

if ($SharedStorage) 
{
    $sharedStorageAccountResourceGroupName = $parameters.parameters.sharedStorageAccountResourceGroupName.value 
    $sharedStorageAccountName = $parameters.parameters.sharedStorageAccountName.value

    $storageDeploymentName = $sharedStorageAccountName + "_depl"
    $storageTemplateFile = "$devOpsProjectFolder\Templates\storage.json"
    New-AzResourceGroupDeployment -Name $storageDeploymentName -TemplateFile $storageTemplateFile `
    -ResourceGroupName $sharedStorageAccountResourceGroupName `
    -storageAccountName $sharedStorageAccountName -location $location `
    -tagValues $tagValues | Out-Null
}

Function CreateSqlResources
{
    Param
    (
        [String]$edition,
        [String]$requestedServiceObjectiveName,
        [String]$maxSizeBytes,
        [String]$databaseName
    )
    $sqlServerResourceGroupName = $parameters.parameters.sqlServerResourceGroupName.value
    $sqlServerName = $parameters.parameters.sqlServerName.value    
    $sqlServerAdminLogin = $parameters.parameters.sqlServerAdminLogin.value
    $sqlServerAdminGroupName = $parameters.parameters.sqlServerAdminGroupName.value
    $sqlServerAdminGroupObjectId = $parameters.parameters.sqlServerAdminGroupObjectId.value
    $adTenantId = $parameters.parameters.tenantId.value
    Write-Verbose "SQL Server Name,Id,Tenant : $sqlServerAdminGroupName, $sqlServerAdminGroupObjectId, $tenantId"
    $sqlServerAuditStorageAccountResourceGroupName = $parameters.parameters.sqlServerAuditStorageAccountResourceGroupName.value 
    $sqlServerAuditStorageAccountName = $parameters.parameters.sqlServerAuditStorageAccountName.value
    $sqlServerStorageAccountSubscriptionId = $subscriptionId

    $storageAccount = Get-AzStorageAccount -ResourceGroupName $sqlServerAuditStorageAccountResourceGroupName -Name $sqlServerAuditStorageAccountName -ErrorAction SilentlyContinue
    if (!$storageAccount)
    {
        throw "ERROR: Storage account $sqlServerAuditStorageAccountName in resource group $sqlServerAuditStorageAccountResourceGroupName does not exist. Aborting installation."
    }

    # Generate a new sqladmin password.  We never store this or use it
    $secret = Get-Cred -userName $parameters.parameters.sqlServerAdminLogin.value
    $sqlAdminPassword = $secret.Password

    $sqldbDeploymentName = $databaseName + "_depl"
    $sqldbTemplateFile = "$devOpsProjectFolder\Templates\sql.json"
    New-AzResourceGroupDeployment -Name $sqldbDeploymentName -TemplateFile $sqldbTemplateFile `
    -ResourceGroupName $sqlServerResourceGroupName `
    -auditStorageAccountName $sqlServerAuditStorageAccountName -auditStorageAccountResourceGroupName $sqlServerAuditStorageAccountResourceGroupName `
    -auditStorageAccountSubscriptionId $sqlServerStorageAccountSubscriptionId `
    -serverName $sqlServerName -databaseName $databaseName `
    -edition $edition -requestedServiceObjectiveName $requestedServiceObjectiveName -maxSizeBytes $maxSizeBytes `
    -administratorLogin $sqlServerAdminLogin -administratorLoginPassword $sqlAdminPassword `
    -location $Location -aadAdminGroupName $sqlServerAdminGroupName -aadAdminGroupObjectId $sqlServerAdminGroupObjectId -aadTenantId $adTenantId `
    -tagValues $tagValues | Out-Null
    
}

if ($SqlDb)
{
    $edition = $parameters.parameters.sqlDatabaseEdition.value
    $requestedServiceObjectiveName = $parameters.parameters.sqlDatabaseSku.value
    $maxSizeBytes = $parameters.parameters.sqlDatabaseMaxSizeInBytes.value
    $sqlDatabaseName = $parameters.parameters.sqlDatabaseName.value
    CreateSqlResources -edition $edition -requestedServiceObjectiveName $requestedServiceObjectiveName -maxSizeBytes $maxSizeBytes -databaseName $sqlDatabaseName
}

if ($SqlDW)
{
    $edition = $parameters.parameters.sqlDataWarehouseEdition.value
    $requestedServiceObjectiveName = $parameters.parameters.sqlDataWarehouseSku.value
    $maxSizeBytes = $parameters.parameters.sqlDataWarehouseMaxSizeInBytes.value
    $sqlDataWarehouseName = $parameters.parameters.sqlDataWarehouseName.value
    CreateSqlResources -edition $edition -requestedServiceObjectiveName $requestedServiceObjectiveName -maxSizeBytes $maxSizeBytes -databaseName $sqlDataWarehouseName
}

if ($DataFactoryV1)
{
    $dataFactoryResourceGroupName = $parameters.parameters.dataFactoryResourceGroupName.value
    $dataFactoryName = $parameters.parameters.dataFactoryName.value

    $dfDeploymentName = $dataFactoryName + "_depl"
    $dfTemplateFile = "$devOpsProjectFolder\Templates\datafactoryv1.json"
    New-AzResourceGroupDeployment -Name $dfDeploymentName -TemplateFile $dfTemplateFile `
    -ResourceGroupName $dataFactoryResourceGroupName `
    -dataFactoryName $dataFactoryName `
    -location $Location `
    -tagValues $tagValues | Out-Null
}

if ($DataFactory)
{
    $dataFactoryLoggingStorageAccountResourceGroupName = $parameters.parameters.dataFactoryLoggingStorageAccountResourceGroupName.value
    $dataFactoryLoggingStorageAccountName = $parameters.parameters.dataFactoryLoggingStorageAccountName.value

    $dataFactoryResourceGroupName = $parameters.parameters.dataFactoryResourceGroupName.value
    $dataFactoryName = $parameters.parameters.dataFactoryName.value

    $dfDeploymentName = $dataFactoryName + "_depl"
    $dfTemplateFile = "$devOpsProjectFolder\Templates\datafactory.json"
    $dfTemplateObj = Get-Content -Path $dfTemplateFile -Raw | ConvertFrom-JSON
    $dfLocation = $parameters.parameters.location.value # $dfTemplateObj.parameters.location.defaultValue

     New-AzResourceGroupDeployment -Name $dfDeploymentName -TemplateFile $dfTemplateFile `
     -ResourceGroupName $dataFactoryResourceGroupName `
     -dataFactoryName $dataFactoryName `
     -loggingStorageAccountName $dataFactoryLoggingStorageAccountName `
     -loggingStorageAccountResourceGroupName $dataFactoryLoggingStorageAccountResourceGroupName `
     -location $dfLocation `
     -tagValues $tagValues | Out-Null
    

    $args = @{
        ResourceGroupName = $dataFactoryResourceGroupName;
        Name = $dataFactoryName; 
        Location = $dfLocation; 
        Force = $true;
            }

    Set-Delay -Command 'Set-AzDataFactoryV2' -Args $args -Retries 10 -SecondsDelay 5 -Verbose 
    Write-Host "MSI Set on Data Factory $datafactoryName."
    # Create the key vault linked service right away because other links depend on it
    &   "$utilitiesFolder\Set-DataFactory.ps1" -parameterFile $parameterFile -KeyVault
    
    Write-Output "Data Factory provisioned "
}

if ($OnPremFileServer) {
    & "$utilitiesFolder\Set-DataFactory.ps1" -parameterFile $parameterFile -OnPremFileServer $OnPremFileServer
}

if ($Batch)
{
    # Amount of time to wait before retrying the removal of the batch pool
    $batchPoolRemovalWaitPeriodInSeconds = 15
    # Number of attempts to remove the batch pool
    $numberofRetriesToRemoveBatchPool = 15

    $batchAccountResourceGroupName = $parameters.parameters.batchAccountResourceGroupName.value
    $batchAccountName = $parameters.parameters.batchAccountName.value

    $banDeploymentName = $batchAccountName + "_depl"
    $banTemplateFile = "$devOpsProjectFolder\Templates\batch.json"
    New-AzResourceGroupDeployment -Name $banDeploymentName -TemplateFile $banTemplateFile `
    -ResourceGroupName $batchAccountResourceGroupName `
    -batchAccountName $batchAccountName `
    -location $Location `
    -tagValues $tagValues | Out-Null

    $batchPoolName = $parameters.parameters.batchPoolName.value
    $batchVMSize = $parameters.parameters.batchVMSize.value
    $batchAutoScaleFormula = $parameters.parameters.batchAutoScaleFormula.value
    $batchAccountPoolMaxTasksPerComputeNode = $parameters.parameters.batchAccountPoolMaxTasksPerComputeNode.value

    # Creating Azure Batch Pool
    Write-Verbose "Creating Azure Batch Pool"
    $Context = Get-AzBatchAccount -AccountName $batchAccountName -ResourceGroupName $batchAccountResourceGroupName
    $osFamily = "5"
    $targetOSVersion = "*"
    $configuration = New-Object -TypeName "Microsoft.Azure.Commands.Batch.Models.PSCloudServiceConfiguration" -ArgumentList @($osFamily, $targetOSVersion)
    $currentNumberofRetriesToRemoveBatchPool = 0;
    $batchPool = Get-AzBatchPool -BatchContext $Context -Id $batchPoolName -ErrorAction SilentlyContinue
    if ($batchPool) {
        Remove-AzBatchPool -Id $batchPoolName -BatchContext $Context -Force 
        while ($batchPool -and $currentNumberofRetriesToRemoveBatchPool -lt $numberofRetriesToRemoveBatchPool) {
            Write-Verbose "Waiting until existing batch pool is removed. Checking again in $batchPoolRemovalWaitPeriodInSeconds seconds"
            $batchPool = Get-AzBatchPool -BatchContext $Context -Id $batchPoolName -ErrorAction SilentlyContinue
            $currentNumberofRetriesToRemoveBatchPool++
            Start-Sleep -Seconds $batchPoolRemovalWaitPeriodInSeconds
        }  
    }
    if ($batchPool)
    {
        throw "ERROR: Unable to remove batch pool $batchPoolName. Terminating the script unsuccessfully."
    }
    $keyVaultName = $parameters.parameters.keyVaultName.value
    $appSvcApplicationId = $parameters.parameters.applicationId.value
    $applicationIdentityCertificateName = $parameters.parameters.applicationIdentityCertificateName.value
    $applicationIdentityCertificatePassword = "{0}-Password" -f $parameters.parameters.applicationIdentityCertificateName.value

    $secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $applicationIdentityCertificateName -ErrorAction SilentlyContinue
    $secretValue = $secret.SecretValueText
    $rawCert = [System.Convert]::FromBase64String($secretValue)

    $secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $applicationIdentityCertificatePassword -ErrorAction SilentlyContinue
    $identityCertificatePassword = $secret.SecretValue
    $certificatePFX = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2($rawCert, $identityCertificatePassword, [System.Security.Cryptography.X509Certificates.X509KeyStorageFlags]::Exportable)
    $cert = Get-AzBatchCertificate -ThumbprintAlgorithm "sha1" -Thumbprint $certificatePFX.Thumbprint -BatchContext $Context -ErrorAction SilentlyContinue
    
    if (!$cert) {
        Write-Verbose "Installing SPN certificate"
        New-AzBatchCertificate -RawData $rawCert -Password $identityCertificatePassword -BatchContext $Context 
        $cert = Get-AzBatchCertificate -ThumbprintAlgorithm "sha1" -Thumbprint $certificatePFX.Thumbprint -BatchContext $Context
    } else {
        Write-Verbose "Certificate is already installed"
    }
    # Map the certificate to the pool
    $certReference = New-Object -TypeName "Microsoft.Azure.Commands.Batch.Models.PSCertificateReference"
    $certReference.StoreLocation = "currentuser"
    $certReference.StoreName = "My"
    $certReference.Thumbprint = $cert.Thumbprint
    $certReference.ThumbprintAlgorithm = $cert.ThumbprintAlgorithm
    
    $certRefs = ($certReference)
    New-AzBatchPool -Id $batchPoolName -VirtualMachineSize $batchVMSize -CloudServiceConfiguration $configuration -CertificateReferences $certRefs `
     -AutoScaleFormula $batchAutoScaleFormula -MaxTasksPerComputeNode $batchAccountPoolMaxTasksPerComputeNode -BatchContext $Context  | Out-Null
    
    $Context = Get-AzBatchAccountKey -AccountName $batchAccountName -ResourceGroupName $batchAccountResourceGroupName
     
    $secureSecret = ConvertTo-SecureString -AsPlainText $Context.PrimaryAccountKey -Force
    $secretCredential = New-Object System.Management.Automation.PSCredential ($batchAccountName, $secureSecret)
    $contentType = "The key for your batch account {0}.  Added as part of provioning." -f $batchAccountName
    & "$utilitiesFolder\Set-KeyVaultSecret.ps1" -parameterFile $parameterFile -secretCredential $secretCredential -secretExpiryTermYears $secretExpiryYears -contentType $contentType
}
if ($ADLStore) 
{
    $storageAccountResourceGroupName = $parameters.parameters.adlStoreResourceGroupName.value 
    $storageAccountName = $parameters.parameters.adlStoreName.value
    $storageSku = $parameters.parameters.adlStoreSku.value
    $storageDeploymentName = $storageAccountName + "_depl"
    $storageTemplateFile = "$devOpsProjectFolder\Templates\storage2.json"
    $depl= New-AzResourceGroupDeployment -Name $storageDeploymentName -TemplateFile $storageTemplateFile `
    -ResourceGroupName $storageAccountResourceGroupName `
    -storageAccountName $storageAccountName -location $location `
    -sku $storageSku `
    -tagValues $tagValues
}

if ($Redis) 
{
    $storageAccountResourceGroupName = $parameters.parameters.adlStoreResourceGroupName.value 
    $redisCacheName = $parameters.parameters.redisCacheName.value
    $RedisDeploymentName = $storageAccountName + "_depl"
    $RedisTemplateFile = "$devOpsProjectFolder\Templates\redis.json"
    $depl= New-AzResourceGroupDeployment -Name $RedisDeploymentName -TemplateFile $RedisTemplateFile `
    -ResourceGroupName $storageAccountResourceGroupName `
    -redisCacheName $redisCacheName
    
}

if ($ADLStoreGen1)
{
    $adlStoreResourceGroupName = $parameters.parameters.adlStoreResourceGroupName.value 
    $adlStoreName = $parameters.parameters.adlStoreNameGen1.value
    $dataLakeLocation = $parameters.parameters.dataLakeLocation.value
    $workStationIPStart = $parameters.parameters.workStationIPStart.value
    $workStationIPEnd = $parameters.parameters.workStationIPEnd.value
    $workStationFirewallRuleName = $parameters.parameters.workStationFirewallRuleName.value

    $adlStoreDeploymentName = $adlStoreName + "_depl"
    $adlStoreTemplateFile = "$devOpsProjectFolder\Templates\adlstore.json"
    New-AzResourceGroupDeployment -Name $adlStoreDeploymentName -TemplateFile $adlStoreTemplateFile `
    -ResourceGroupName $adlStoreResourceGroupName `
    -adlStoreName $adlStoreName -location $dataLakeLocation `
    -startIpAddress $workStationIPStart `
    -endIpAddress $workStationIPEnd `
    -firewallRuleName $workStationFirewallRuleName `
    -tagValues $tagValues | Out-Null
}

if ($ADLAnalytics)
{
    $adlAnalyticsResourceGroupName = $parameters.parameters.adlAnalyticsResourceGroupName.value 
    $adlAnalyticsName = $parameters.parameters.adlAnalyticsName.value
    $adlStoreName = $parameters.parameters.adlStoreName.value
    $dataLakeLocation = $parameters.parameters.dataLakeLocation.value

    $adlAnalyticsDeploymentName = $adlAnalyticsName + "_depl"
    $adlAnalyticsTemplateFile = "$devOpsProjectFolder\Templates\adlanalytics.json"
    New-AzResourceGroupDeployment -Name $adlAnalyticsDeploymentName -TemplateFile $adlAnalyticsTemplateFile `
    -ResourceGroupName $adlAnalyticsResourceGroupName -adlAnalyticsName $adlAnalyticsName `
    -adlStoreName $adlStoreName -location $dataLakeLocation `
    -tagValues $tagValues -Force | Out-Null
}

if ($HDInsight)
{
    $clusterResourceGroupName = $parameters.parameters.clusterResourceGroupName.value 
    $clusterName = $parameters.parameters.clusterName.value
    $clusterVersion = $parameters.parameters.clusterVersion.value

    $clusterAdminLogin = $parameters.parameters.clusterAdminLogin.value  
    $keyVaultName = $parameters.parameters.keyVaultName.value
    $secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $clusterAdminLogin -ErrorAction SilentlyContinue
    $clusterAdminPassword = $secret.SecretValue

    $clusterSSHUserName = $parameters.parameters.clusterSSHUserName.value
    $keyVaultName = $parameters.parameters.keyVaultName.value
    $secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $clusterSSHUserName -ErrorAction SilentlyContinue
    $clusterSSHUserPassword = $secret.SecretValue

    $clusterStorageAccountResourceGroupName = $parameters.parameters.clusterStorageAccountResourceGroupName.value
    $clusterStorageAccountName = $parameters.parameters.clusterStorageAccountName.value
    $clusterKind = $parameters.parameters.clusterKind.value
    $clusterType = $parameters.parameters.clusterType.value
    $clusterHeadNodeCount = $parameters.parameters.clusterHeadNodeCount.value
    $clusterHeadNodeVMSize = $parameters.parameters.clusterHeadNodeVMSize.value
    $clusterWorkerNodeCount = $parameters.parameters.clusterWorkerNodeCount.value
    $clusterWorkerNodeVMSize = $parameters.parameters.clusterWorkerNodeVMSize.value
    $clusterApiVersion = $parameters.parameters.clusterApiVersion.value
    $storageApiVersion = $parameters.parameters.storageApiVersion.value

    $clusterDeploymentName = $clusterName + "_depl"
    $clusterTemplateFile = "$devOpsProjectFolder\Templates\hdinsight.json"
  <#  $depl= New-AzResourceGroupDeployment -Name $clusterDeploymentName -TemplateFile $clusterTemplateFile `
    -ResourceGroupName $clusterResourceGroupName -clusterName $clusterName `
    -clusterVersion $clusterVersion `
    -clusterAdminLogin $clusterAdminLogin -clusterAdminPassword $clusterAdminPassword `
    -clusterSSHUserName $clusterSSHUserName -clusterSSHUserPassword $clusterSSHUserPassword `
    -clusterStorageAccountResourceGroupName $clusterStorageAccountResourceGroupName -clusterStorageAccountName $clusterStorageAccountName `
    -clusterKind $clusterKind -clusterType $clusterType `
    -clusterHeadNodeCount $clusterHeadNodeCount -clusterHeadNodeVMSize $clusterHeadNodeVMSize `
    -clusterWorkerNodeCount $clusterWorkerNodeCount -clusterWorkerNodeVMSize $clusterWorkerNodeVMSize `
    -clusterApiVersion $clusterApiVersion -storageApiVersion $storageApiVersion `
    -location $Location `
    -tagValues $tagValues
#>
    Write-Verbose "clusterResourceGroupName $clusterResourceGroupName"
    Write-Verbose "clusterName: $clusterName"
    Write-Verbose "clusterVersion: $clusterVersion"
    Write-Verbose "clusterAdminLogin: $clusterAdminLogin"
    Write-Verbose "clusterAdminPassword $clusterAdminPassword"
    Write-Verbose "clusterSSHUserName $clusterSSHUserName"
    Write-Verbose "clusterSSHUserPassword $clusterSSHUserPassword"
    Write-Verbose "location $location"
    Write-Verbose "clusterStorageAccountResourceGroupName $clusterStorageAccountResourceGroupName"
    Write-Verbose "clusterStorageAccountName $clusterStorageAccountName"
    Write-Verbose "clusterKind $clusterKind"
    Write-Verbose "clusterType $clusterType"
    Write-Verbose "clusterHeadNodeCount $clusterHeadNodeCount"
    Write-Verbose "clusterHeadNodeVMSize $clusterHeadNodeVMSize"
    Write-Verbose "clusterWorkerNodeCount $clusterWorkerNodeCount"
    Write-Verbose "clusterWorkerNodeVMSize $clusterWorkerNodeVMSize"
    Write-Verbose "clusterApiVersion $clusterApiVersion"
    Write-Verbose "storageApiVersion $storageApiVersion"
    Write-Verbose "tagValues $tagValues"

}

if ($HDInsightRServer)
{
    $clusterResourceGroupName = $parameters.parameters.clusterResourceGroupName.value 
    $clusterName = $parameters.parameters.clusterName.value
    $clusterVersion = $parameters.parameters.clusterVersion.value

    $clusterAdminLogin = $parameters.parameters.clusterAdminLogin.value  
    $keyVaultName = $parameters.parameters.keyVaultName.value
    $secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $clusterAdminLogin -ErrorAction SilentlyContinue
    $clusterAdminPassword = $secret.SecretValue

    $clusterSSHUserName = $parameters.parameters.clusterSSHUserName.value
    $keyVaultName = $parameters.parameters.keyVaultName.value
    $secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $clusterSSHUserName -ErrorAction SilentlyContinue
    $clusterSSHUserPassword = $secret.SecretValue

    $clusterStorageAccountResourceGroupName = $parameters.parameters.clusterStorageAccountResourceGroupName.value
    $clusterStorageAccountName = $parameters.parameters.clusterStorageAccountName.value
    $clusterHeadNodeCount = $parameters.parameters.clusterHeadNodeCount.value
    $clusterHeadNodeVMSize = $parameters.parameters.clusterHeadNodeVMSize.value
    $clusterWorkerNodeCount = $parameters.parameters.clusterWorkerNodeCount.value
    $clusterWorkerNodeVMSize = $parameters.parameters.clusterWorkerNodeVMSize.value
    $clusterZookeeperNodeCount = $parameters.parameters.clusterZookeeperNodeCount.value
    $clusterZookeeperNodeVMSize = $parameters.parameters.clusterZookeeperNodeVMSize.value
    $clusterEdgeNodeCount = $parameters.parameters.clusterEdgeNodeCount.value
    $clusterEdgeNodeVMSize = $parameters.parameters.clusterEdgeNodeVMSize.value
    $clusterApiVersion = $parameters.parameters.clusterApiVersion.value
    $clusterType = $parameters.parameters.clusterType.value
    $storageApiVersion = $parameters.parameters.storageApiVersion.value

    $clusterDeploymentName = $clusterName + "_depl"
    $clusterTemplateFile = "$devOpsProjectFolder\Templates\hdinsight.rserver.json"
    New-AzResourceGroupDeployment -Name $clusterDeploymentName -TemplateFile $clusterTemplateFile `
    -ResourceGroupName $clusterResourceGroupName -clusterName $clusterName `
    -clusterVersion $clusterVersion `
    -clusterAdminLogin $clusterAdminLogin -clusterAdminPassword $clusterAdminPassword `
    -clusterSSHUserName $clusterSSHUserName -clusterSSHUserPassword $clusterSSHUserPassword `
    -clusterStorageAccountResourceGroupName $clusterStorageAccountResourceGroupName -clusterStorageAccountName $clusterStorageAccountName `
    -clusterHeadNodeCount $clusterHeadNodeCount -clusterHeadNodeVMSize $clusterHeadNodeVMSize `
    -clusterWorkerNodeCount $clusterWorkerNodeCount -clusterWorkerNodeVMSize $clusterWorkerNodeVMSize `
    -clusterZookeeperNodeCount $clusterZookeeperNodeCount -clusterZookeeperNodeVMSize $clusterZookeeperNodeVMSize `
    -clusterEdgeNodeCount $clusterEdgeNodeCount -clusterEdgeNodeVMSize $clusterEdgeNodeVMSize `
    -clusterType $clusterType `
    -clusterApiVersion $clusterApiVersion -storageApiVersion $storageApiVersion `
    -location $Location `
    -tagValues $tagValues | Out-Null
}
if ($HDInsightwithDataLakeStore)
{
    $clusterResourceGroupName = $parameters.parameters.clusterResourceGroupName.value 
    $clusterName = $parameters.parameters.clusterName.value
    $clusterVersion = $parameters.parameters.clusterVersion.value
    
    $clusterAdminLogin = $parameters.parameters.clusterAdminLogin.value  
    $keyVaultName = $parameters.parameters.keyVaultName.value
    $secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $clusterAdminLogin -ErrorAction SilentlyContinue
    $clusterAdminPassword = $secret.SecretValue

    $clusterSSHUserName = $parameters.parameters.clusterSSHUserName.value
    $keyVaultName = $parameters.parameters.keyVaultName.value
    $secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $clusterSSHUserName -ErrorAction SilentlyContinue
    $clusterSSHUserPassword = $secret.SecretValue

    $clusterStorageAccountResourceGroupName = $parameters.parameters.clusterStorageAccountResourceGroupName.value
    $clusterStorageAccountName = $parameters.parameters.clusterStorageAccountName.value
    $clusterKind = $parameters.parameters.clusterKind.value
    $clusterType = $parameters.parameters.clusterType.value
    $sparkVersion = $parameters.parameters.sparkVersion.value
    $clusterHeadNodeCount = $parameters.parameters.clusterHeadNodeCount.value
    $clusterHeadNodeVMSize = $parameters.parameters.clusterHeadNodeVMSize.value
    $clusterWorkerNodeCount = $parameters.parameters.clusterWorkerNodeCount.value
    $clusterWorkerNodeVMSize = $parameters.parameters.clusterWorkerNodeVMSize.value
    $clusterZookeeperNodeCount = $parameters.parameters.clusterZookeeperNodeCount.value
    $clusterZookeeperNodeVMSize = $parameters.parameters.clusterZookeeperNodeVMSize.value
    $clusterEdgeNodeCount = $parameters.parameters.clusterEdgeNodeCount.value
    $clusterEdgeNodeVMSize = $parameters.parameters.clusterEdgeNodeVMSize.value
    $clusterApiVersion = $parameters.parameters.clusterApiVersion.value
    $storageApiVersion = $parameters.parameters.storageApiVersion.value

    $adlStoreName = $parameters.parameters.adlStoreName.value

    $keyVaultName = $parameters.parameters.keyVaultName.value
    $appSvcApplicationId = $parameters.parameters.applicationId.value
    $applicationIdentityCertificateName = $parameters.parameters.applicationIdentityCertificateName.value
    $applicationIdentityCertificatePassword = "{0}-Password" -f $parameters.parameters.applicationIdentityCertificateName.value

    $secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $applicationIdentityCertificateName -ErrorAction SilentlyContinue
    $identityCertificate = $secret.SecretValue

    $secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $applicationIdentityCertificatePassword -ErrorAction SilentlyContinue
    $identityCertificatePassword = $secret.SecretValue

    $clusterDeploymentName = $clusterName + "_depl"
    $clusterTemplateFile = "$devOpsProjectFolder\Templates\hdinsight.datalake.json"
    New-AzResourceGroupDeployment -Name $clusterDeploymentName -TemplateFile $clusterTemplateFile `
    -ResourceGroupName $clusterResourceGroupName -clusterName $clusterName `
    -clusterVersion $clusterVersion `
    -clusterAdminLogin $clusterAdminLogin -clusterAdminPassword $clusterAdminPassword `
    -clusterSSHUserName $clusterSSHUserName -clusterSSHUserPassword $clusterSSHUserPassword `
    -clusterStorageAccountResourceGroupName $clusterStorageAccountResourceGroupName -clusterStorageAccountName $clusterStorageAccountName `
    -clusterKind $clusterKind -clusterType $clusterType -sparkVersion $sparkVersion `
    -clusterHeadNodeCount $clusterHeadNodeCount -clusterHeadNodeVMSize $clusterHeadNodeVMSize `
    -clusterWorkerNodeCount $clusterWorkerNodeCount -clusterWorkerNodeVMSize $clusterWorkerNodeVMSize `
    -clusterZookeeperNodeCount $clusterZookeeperNodeCount -clusterZookeeperNodeVMSize $clusterZookeeperNodeVMSize `
    -clusterApiVersion $clusterApiVersion -storageApiVersion $storageApiVersion `
    -applicationId $appSvcApplicationId -adlStoreName $adlStoreName -tenantId $tenantId `
    -identityCertificate $identityCertificate -identityCertificatePassword $identityCertificatePassword `
    -location $Location `
    -tagValues $tagValues | Out-Null
}

if ($HDInsightRServerWithDataLakeStore)
{
    $clusterResourceGroupName = $parameters.parameters.clusterResourceGroupName.value 
    $clusterName = $parameters.parameters.clusterName.value
    $clusterVersion = $parameters.parameters.clusterVersion.value

    $clusterAdminLogin = $parameters.parameters.clusterAdminLogin.value  
    $keyVaultName = $parameters.parameters.keyVaultName.value
    $secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $clusterAdminLogin -ErrorAction SilentlyContinue
    $clusterAdminPassword = $secret.SecretValue

    $clusterSSHUserName = $parameters.parameters.clusterSSHUserName.value
    $keyVaultName = $parameters.parameters.keyVaultName.value
    $secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $clusterSSHUserName -ErrorAction SilentlyContinue
    $clusterSSHUserPassword = $secret.SecretValue

    $clusterStorageAccountResourceGroupName = $parameters.parameters.clusterStorageAccountResourceGroupName.value
    $clusterStorageAccountName = $parameters.parameters.clusterStorageAccountName.value
    $clusterHeadNodeCount = $parameters.parameters.clusterHeadNodeCount.value
    $clusterHeadNodeVMSize = $parameters.parameters.clusterHeadNodeVMSize.value
    $clusterWorkerNodeCount = $parameters.parameters.clusterWorkerNodeCount.value
    $clusterWorkerNodeVMSize = $parameters.parameters.clusterWorkerNodeVMSize.value
    $clusterZookeeperNodeCount = $parameters.parameters.clusterZookeeperNodeCount.value
    $clusterZookeeperNodeVMSize = $parameters.parameters.clusterZookeeperNodeVMSize.value
    $clusterEdgeNodeCount = $parameters.parameters.clusterEdgeNodeCount.value
    $clusterEdgeNodeVMSize = $parameters.parameters.clusterEdgeNodeVMSize.value
    $clusterType = $parameters.parameters.clusterType.value
    $sparkVersion = $parameters.parameters.sparkVersion.value
    $clusterApiVersion = $parameters.parameters.clusterApiVersion.value
    $storageApiVersion = $parameters.parameters.storageApiVersion.value

    $adlStoreName = $parameters.parameters.adlStoreName.value

    $appSvcApplicationId = $parameters.parameters.applicationId.value
    $applicationIdentityCertificateName = $parameters.parameters.applicationIdentityCertificateName.value
    $applicationIdentityCertificatePassword = "{0}-Password" -f $parameters.parameters.applicationIdentityCertificateName.value

    $secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $applicationIdentityCertificateName -ErrorAction SilentlyContinue
    $identityCertificate = $secret.SecretValue

    $secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $applicationIdentityCertificatePassword -ErrorAction SilentlyContinue
    $identityCertificatePassword = $secret.SecretValue

    $clusterDeploymentName = $clusterName + "_depl"
    $clusterTemplateFile = "$devOpsProjectFolder\Templates\hdinsight.rserver.datalake.json"
    New-AzResourceGroupDeployment -Name $clusterDeploymentName -TemplateFile $clusterTemplateFile `
    -ResourceGroupName $clusterResourceGroupName -clusterName $clusterName `
    -clusterVersion $clusterVersion `
    -clusterAdminLogin $clusterAdminLogin -clusterAdminPassword $clusterAdminPassword `
    -clusterSSHUserName $clusterSSHUserName -clusterSSHUserPassword $clusterSSHUserPassword `
    -clusterStorageAccountResourceGroupName $clusterStorageAccountResourceGroupName -clusterStorageAccountName $clusterStorageAccountName `
    -clusterHeadNodeCount $clusterHeadNodeCount -clusterHeadNodeVMSize $clusterHeadNodeVMSize `
    -clusterWorkerNodeCount $clusterWorkerNodeCount -clusterWorkerNodeVMSize $clusterWorkerNodeVMSize `
    -clusterZookeeperNodeCount $clusterZookeeperNodeCount -clusterZookeeperNodeVMSize $clusterZookeeperNodeVMSize `
    -clusterEdgeNodeCount $clusterEdgeNodeCount -clusterEdgeNodeVMSize $clusterEdgeNodeVMSize `
    -clusterApiVersion $clusterApiVersion -storageApiVersion $storageApiVersion `
    -clusterType $clusterType -sparkVersion $sparkVersion `
    -applicationId $appSvcApplicationId -tenantId $tenantId `
    -identityCertificate $identityCertificate -identityCertificatePassword $identityCertificatePassword `
    -location $Location `
    -tagValues $tagValues | Out-Null
}

if ($AnalysisServices)
{
    $analysisServicesStorageAccountResourceGroupName = $parameters.parameters.analysisServicesStorageAccountResourceGroupName.value
    $analysisServicesStorageAccountName = $parameters.parameters.analysisServicesStorageAccountName.value
    $analysisServicesStorageKey = Get-AzStorageAccountKey -ResourceGroupName $analysisServicesStorageAccountResourceGroupName -Name $analysisServicesStorageAccountName    
    $starttime = Get-Date
    $numberofYearsforAnalysisServicesContainerKey = $parameters.parameters.numberofYearsforAnalysisServicesContainerKey.value    
    $endtime = $starttime.AddYears($numberofYearsforAnalysisServicesContainerKey) 

    $analysisServicesName = $parameters.parameters.analysisServicesName.value
    $analysisServicesContainerName = $analysisServicesName
    $analysisServicesStorageaccountContext = New-AzStorageContext -StorageAccountName $analysisServicesStorageAccountName `
    -StorageAccountKey $analysisServicesStorageKey[0].Value
    
    $container = Get-AzStorageContainer -Name $analysisServicesContainerName -Context $analysisServicesStorageaccountContext -ErrorAction SilentlyContinue
    if (!$container)
    {
        Write-Verbose "Container $analysisServicesContainerName does not exist creating..."
        $container = New-AzStorageContainer -Name $analysisServicesContainerName -Context $analysisServicesStorageaccountContext
    }
    else 
    {
        Write-Verbose "Container $analysisServicesContainerName already exists"
    }
    
    $containerSASURI = New-AzStorageContainerSASToken -Name $analysisServicesContainerName `
    -Permission rwdl -FullUri -Context $analysisServicesStorageaccountContext `
    -StartTime $starttime -ExpiryTime $endtime

    $analysisServicesResourceGroupName = $parameters.parameters.analysisServicesResourceGroupName.value
    $analysisServicesAdminEmailId = $parameters.parameters.analysisServicesAdminEmailId.value
    $analysisServicesSku = $parameters.parameters.analysisServicesSku.value
    $workStationIPStart = $parameters.parameters.workStationIPStart.value
    $workStationIPEnd = $parameters.parameters.workStationIPEnd.value
    $workStationFirewallRuleName = $parameters.parameters.workStationFirewallRuleName.value

    $analysisServicesDeploymentName = $analysisServicesName + "_depl"
    $analysisServicesTemplateFile = "$devOpsProjectFolder\Templates\analysis.services.json"
    New-AzResourceGroupDeployment -Name $analysisServicesDeploymentName -TemplateFile $analysisServicesTemplateFile `
    -ResourceGroupName $analysisServicesResourceGroupName -analysisServicesName $analysisServicesName `
    -location $Location -sku $analysisServicesSku `
    -admin "SEC-ES-DA-d-56731-landscape@unilever.com" `
    -backupBlobContainerUri $containerSASURI `
    -ipAddressStart $workStationIPStart -ipAddressEnd $workStationIPEnd -firewallRuleName $workStationFirewallRuleName | Out-Null

    & "$utilitiesFolder\Set-SsasAdminUsers.ps1" -parameterFile $parameterFile -emailAddressesCsv $analysisServicesAdminEmailId
}
if ($AnalysisServicesWithOPDG)
{
    $analysisServicesStorageAccountResourceGroupName = $parameters.parameters.analysisServicesStorageAccountResourceGroupName.value
    $analysisServicesStorageAccountName = $parameters.parameters.analysisServicesStorageAccountName.value
    $analysisServicesStorageKey = Get-AzStorageAccountKey -ResourceGroupName $analysisServicesStorageAccountResourceGroupName -Name $analysisServicesStorageAccountName    
    $starttime = Get-Date
    $numberofYearsforAnalysisServicesContainerKey = $parameters.parameters.numberofYearsforAnalysisServicesContainerKey.value    
    $endtime = $starttime.AddYears($numberofYearsforAnalysisServicesContainerKey) 

    $analysisServicesName = $parameters.parameters.analysisServicesName.value
    $analysisServicesContainerName = $analysisServicesName
    $analysisServicesStorageaccountContext = New-AzStorageContext -StorageAccountName $analysisServicesStorageAccountName `
    -StorageAccountKey $analysisServicesStorageKey[0].Value
    
    $container = Get-AzStorageContainer -Name $analysisServicesContainerName -Context $analysisServicesStorageaccountContext -ErrorAction SilentlyContinue
    if (!$container)
    {
        Write-Verbose "Container $analysisServicesContainerName does not exist creating..."
        $container = New-AzStorageContainer -Name $analysisServicesContainerName -Context $analysisServicesStorageaccountContext
    }
    else 
    {
        Write-Verbose "Container $analysisServicesContainerName already exists"
    }
    
    $containerSASURI = New-AzStorageContainerSASToken -Name $analysisServicesContainerName `
    -Permission rwdl -FullUri -Context $analysisServicesStorageaccountContext `
    -StartTime $starttime -ExpiryTime $endtime
    
    $analysisServicesResourceGroupName = $parameters.parameters.analysisServicesResourceGroupName.value
    $analysisServicesAdminEmailId = $parameters.parameters.analysisServicesAdminEmailId.value
    $analysisServicesSku = $parameters.parameters.analysisServicesSku.value
    $analysisServicesOpdgInstallationName = $parameters.parameters.analysisServicesOpdgInstallationName.value
    $analysisServicesOpdgName = $parameters.parameters.analysisServicesOpdgName.value
    $workStationIPStart = $parameters.parameters.workStationIPStart.value
    $workStationIPEnd = $parameters.parameters.workStationIPEnd.value
    $workStationFirewallRuleName = $parameters.parameters.workStationFirewallRuleName.value

    if ([string]::IsNullOrEmpty($analysisServicesOpdgInstallationName))
    {
        Write-Error "You cannot deploy AAS with OPDG because the parameter file does not provide the OPDG installation name.  Add or update a value for 'analysisServicesOpdgInstallationName'."
        return
    }
    if ([string]::IsNullOrEmpty($analysisServicesOpdgName))
    {
        Write-Error "You cannot deploy AAS with OPDG because the parameter file does not provide the OPDG name.  Add or update a value for 'analysisServicesOpdgName'."
        return
    }

    $analysisServicesDeploymentName = $analysisServicesName + "_depl"
    $opdgDeploymentName = $analysisServicesOpdgInstallationName + "_depl"
    $analysisServicesTemplateFile = "$devOpsProjectFolder\Templates\analysis.services.opdg.json"

    # Make sure the PBI module is available
    if(-not (Get-Module -Name MicrosoftPowerBIMgmt.Profile -ListAvailable))
    {
        Write-Error "You must install the the PowerBI module MicrosoftPowerBIMgmt.Profile"
        return
    }

    $gateways = Invoke-PowerBIRestMethod -Url "https://api.powerbi.com/v1.0/myorg/gateways" -Method GET | ConvertFrom-JSON
    $gateway = $gateways.value | Where-Object -Property name -EQ $analysisServicesOpdgInstallationName

    if ($gateway) {
        $gatewayId = $gateway.id
        $opdgTemplateFile = "$devOpsProjectFolder\Templates\opdg.json"
        $gatewayLocation = $Location.ToLower().Replace(" ", "")
        $gatewayInstallationId = "/subscriptions/{0}/providers/Microsoft.Web/locations/{1}/connectionGatewayInstallations/{2}" -f $subscriptionId, $gatewayLocation, $gatewayId
        
        Write-Host "Deploying the OPDG $analysisServicesOpdgName"
        New-AzResourceGroupDeployment -Name $opdgDeploymentName -TemplateFile $opdgTemplateFile `
        -ResourceGroupName $analysisServicesResourceGroupName -gatewayName $analysisServicesOpdgName `
        -location $gatewayLocation -gatewayInstallationId $gatewayInstallationId | Out-Null
        
        $gateway = Get-AzResource -Name $analysisServicesOpdgName -ResourceType "Microsoft.Web/connectionGateways" -ResourceGroupName $analysisServicesResourceGroupName
        if ($gateway){
            Write-Host "Deploying AAS with OPDG $analysisServicesOpdgName configured."
            New-AzResourceGroupDeployment -Name $analysisServicesDeploymentName -TemplateFile $analysisServicesTemplateFile `
            -ResourceGroupName $analysisServicesResourceGroupName -analysisServicesName $analysisServicesName `
            -location $gatewayLocation -sku $analysisServicesSku `
            -admin "SEC-ES-DA-d-56731-landscape@unilever.com" `
            -backupBlobContainerUri $containerSASURI `
            -ipAddressStart $workStationIPStart -ipAddressEnd $workStationIPEnd -firewallRuleName $workStationFirewallRuleName -gatewayResourceId $gateway.ResourceId | Out-Null
        
            & "$utilitiesFolder\Set-SsasAdminUsers.ps1" -parameterFile $parameterFile -emailAddressesCsv $analysisServicesAdminEmailId
        } else {
            Write-Error "The PaaS OPDG $opdgName was not found in resource group $analysisServicesResourceGroupName.  Unable to delploy AAS server."
        }
    } else {
        Write-Error "AAS with OPDG deployment failed because the OPDG installation  was not found.  Install the OPDG software then try again."
    }
}
if ($IoTHub) {
    $iotHubResourceGroupName = $parameters.parameters.iotHubResourceGroupName.value
    $iotHubName = $parameters.parameters.iotHubName.value
    $iotHubSku = $parameters.parameters.iotHubSku.value
    $capacityUnits = $parameters.parameters.capacityUnits.value
    $d2cMessageRetentionInDaysPeriod = $parameters.parameters.d2cMessageRetentionInDaysPeriod.value
    $d2cPartitionCount = $parameters.parameters.d2cPartitionCount.value
    $c2dMessagesTTLAsIso8601 = $parameters.parameters.c2dMessagesTTLAsIso8601.value
    $c2dMessagesMaxDeliveryCount = $parameters.parameters.c2dMessagesMaxDeliveryCount.value
    $c2dFeebackMessagesTTLAsIso8601 = $parameters.parameters.c2dFeebackMessagesTTLAsIso8601.value
    $c2dFeedbackMessagesMaxDeliveryCount = $parameters.parameters.c2dFeedbackMessagesMaxDeliveryCount.value
    $c2dFeedbackMessagesLockDurationAsIso8601 = $parameters.parameters.c2dFeedbackMessagesLockDurationAsIso8601.value
    $d2cConsumerGroupName = $parameters.parameters.d2cConsumerGroupName.value

    $iotHubDeploymentName = $iotHubName + "_depl"
    $iotHubTemplateFile = "$devOpsProjectFolder\Templates\iotHub.json"
    New-AzResourceGroupDeployment -Name $iotHubDeploymentName -TemplateFile $iotHubTemplateFile `
    -ResourceGroupName $iotHubResourceGroupName -iotHubName $iotHubName `
    -skuName $iotHubSku -capacityUnits $capacityUnits `
    -d2cMessageRetentionInDaysPeriod $d2cMessageRetentionInDaysPeriod `
    -d2cPartitionCount $d2cPartitionCount -c2dMessagesTTLAsIso8601 $c2dMessagesTTLAsIso8601 `
    -c2dMessagesMaxDeliveryCount $c2dMessagesMaxDeliveryCount `
    -c2dFeebackMessagesTTLAsIso8601 $c2dFeebackMessagesTTLAsIso8601 `
    -c2dFeedbackMessagesMaxDeliveryCount $c2dFeedbackMessagesMaxDeliveryCount `
    -c2dFeedbackMessagesLockDurationAsIso8601 $c2dFeedbackMessagesLockDurationAsIso8601 `
    -d2cConsumerGroupName $d2cConsumerGroupName `
    -tagValues $tagValues | Out-Null
}

if ($IoTDeviceProv){
    $iotHubResourceGroupName = $parameters.parameters.iotHubResourceGroupName.value
    $iotHubName = $parameters.parameters.iotHubName.value
    $iotHubConnectionString = Get-AzIotHubConnectionString -ResourceGroupName $iotHubResourceGroupName `
    -Name $iotHubName -KeyName "iothubowner"
    if ($iotHubConnectionString){
        $iotHubUrl = "{0}.azure-devices.net" -f $iotHubName
        $deviceProvName = "{0}-dev" -f $iotHubName
        $iotHubDeploymentName = $iotHubName + "_dev_depl"
        $iotHubTemplateFile = "$devOpsProjectFolder\Templates\iotdevice.json"
        New-AzResourceGroupDeployment -Name $iotHubDeploymentName -TemplateFile $iotHubTemplateFile `
        -ResourceGroupName $iotHubResourceGroupName -iotHubName $iotHubUrl `
        -deviceProvName $deviceProvName -iotHubConnectionString $iotHubConnectionString.PrimaryConnectionString `
        -location $location -tagValues $tagValues | Out-Null
    }
}

if ($TimeSeriesInsights) {
    $tsInsightsResourceGroupName = $parameters.parameters.tsInsightsResourceGroupName.value
    $tsInsightsName = $parameters.parameters.tsInsightsName.value
    $tsInsightsSkuName = $parameters.parameters.tsInsightsSkuName.value
    $tsInsightsSkuTier = $parameters.parameters.tsInsightsSkuTier.value
    $tsInsightsSkuSize = $parameters.parameters.tsInsightsSkuSize.value
    $tsInsightsSkuCapacity = $parameters.parameters.tsInsightsSkuCapacity.value
    $tsInsightsDataRetentionTime = $parameters.parameters.tsInsightsDataRetentionTime.value
    $d2cConsumerGroupName = $parameters.parameters.d2cConsumerGroupName.value
    $tsInsightsFieldName = $parameters.parameters.tsInsightsFieldName.value
    $tsInsightsKeyName = $parameters.parameters.tsInsightsKeyName.value
    $groupid = $parameters.parameters.managerADGroupId.value    
    $iotHubResourceGroupName = $parameters.parameters.iotHubResourceGroupName.value
    $iotHubName = $parameters.parameters.iotHubName.value

    $iotHubObj = Get-AzIotHub -ResourceGroupName $iotHubResourceGroupName -Name $iotHubName
    $iotHubResourceId = $iotHubObj.Id
    Write-Verbose "iotHubResourceId is $iotHubResourceId"
    $keys = Get-AzIotHubKey -ResourceGroupName $iotHubResourceGroupName -Name $iotHubName -KeyName $tsInsightsKeyName
    $iotHubSharedAccessKey = $keys.PrimaryKey

    $tsInsightsDeploymentName = $tsInsightsName + "_depl"
    $tsInsightsTemplateFile = "$devOpsProjectFolder\Templates\tsinsights.json"
    New-AzResourceGroupDeployment -Name $tsInsightsDeploymentName `
    -TemplateFile $tsInsightsTemplateFile `
    -ResourceGroupName $tsInsightsResourceGroupName -tsInsightsName $tsInsightsName `
    -location $location `
    -skuName $tsInsightsSkuName -skuTier $tsInsightsSkuTier `
    -skuSize $tsInsightsSkuSize `
    -skuCapacity $tsInsightsSkuCapacity `
    -dataRetentionTime $tsInsightsDataRetentionTime `
    -principalObjectId $groupid `
    -iotHubName $iotHubName `
    -iotHubResourceId $iotHubResourceId `
    -keyName $tsInsightsKeyName `
    -consumerGroupName $d2cConsumerGroupName `
    -timeStampFieldName $tsInsightsFieldName `
    -tagValues $tagValues `
    -iotHubSharedAccessKey $iotHubSharedAccessKey | Out-Null
}

if ($WebApp) {
    $webAppResourceGroupName = $parameters.parameters.webAppResourceGroupName.value    
    $appServicePlanName = $parameters.parameters.appServicePlanName.value
    $webAppName = $parameters.parameters.webAppName.value
    $webAppStack = $parameters.parameters.webAppStack.value
    $webAppNetFrameworkVersion = $parameters.parameters.webAppNetFrameworkVersion.value
    $location = $parameters.parameters.location.value

    CreateAppServicePlan -webAppResourceGroupName $webAppResourceGroupName -appServicePlanName $appServicePlanName

    $webAppDeploymentName = $webAppName + "_depl"
    $webAppTemplateFile = "$devOpsProjectFolder\Templates\web.app.service.template.json"


    New-AzResourceGroupDeployment -Name $webAppDeploymentName `
             -appServiceName $webAppName `
             -ResourceGroupName $webAppResourceGroupName `
             -TemplateFile $webAppTemplateFile `
             -SubscriptionId $subscriptionId `
             -location $location `
             -hostingEnvironment "hostingenv" `
             -hostingPlanName $appServicePlanName `
             -serverFarmResourceGroup $webAppResourceGroupName `
             -currentStack $webAppStack `
             -netFrameworkVersion $webAppNetFrameworkVersion | Out-Null

    $webAppSPN = Get-AzADServicePrincipal -DisplayNameBeginsWith $webAppName
    $i=0
    while (-not $webAppSPN -and $i -lt 6) {
        Start-Sleep -Seconds 10
        $webAppSPN = Get-AzADServicePrincipal -DisplayNameBeginsWith $webAppName
        $i++
    }
    if ($webAppSPN) {
        # grant key vault access
        $keyVaultResourceGroupName = $parameters.parameters.keyVaultResourceGroupName.value
        $keyVaultName = $parameters.parameters.keyVaultName.value
        Set-AzKeyVaultAccessPolicy -VaultName $keyVaultName -ResourceGroupName $keyVaultResourceGroupName -ObjectId $webAppSPN.Id -PermissionsToSecrets get,list
    } else {
        Write-Error "Failed to grant key vault access for function app $webAppName."
    }
}

if ($functions) {
    
    $webAppResourceGroupName = $parameters.parameters.webAppResourceGroupName.value
    
    $appServicePlanName = $parameters.parameters.appServicePlanName.value
    $webAppName = $parameters.parameters.webAppName.value
    $webAppStack = $parameters.parameters.webAppStack.value
    $webAppNetFrameworkVersion = $parameters.parameters.webAppNetFrameworkVersion.value
    $location = $parameters.parameters.location.value
    $functionAppName = $parameters.parameters.functionAppName.value

    #Switch Below on if Service plan required for function app. Current version is Pay on Demand.
    #CreateAppServicePlan -webAppResourceGroupName $webAppResourceGroupName -appServicePlanName $appServicePlanName

    $functionDeploymentName = $functionAppName + "_depl"
    $functionTemplateFile = "$devOpsProjectFolder\Templates\functionapp.json"

    New-AzResourceGroupDeployment -Name $functionDeploymentName `
                -TemplateFile $functionTemplateFile `
                -ResourceGroupName $webAppResourceGroupName `
                -parFunctionAppName $functionAppName `
                -parPlanAppName  $parameters.parameters.appServicePlanName.value | Out-Null

    $funcAppSPN = Get-AzADServicePrincipal -DisplayNameBeginsWith $functionAppName
    $i=0
    while (-not $funcAppSPN -and $i -lt 6) {
        Start-Sleep -Seconds 10
        $funcAppSPN = Get-AzADServicePrincipal -DisplayNameBeginsWith $functionAppName
        $i++
    }
    if ($funcAppSPN) {
        # grant key vault access
        $keyVaultResourceGroupName = $parameters.parameters.keyVaultResourceGroupName.value
        $keyVaultName = $parameters.parameters.keyVaultName.value
        Set-AzKeyVaultAccessPolicy -VaultName $keyVaultName -ResourceGroupName $keyVaultResourceGroupName -ObjectId $funcAppSPN.Id -PermissionsToSecrets get,list
    } else {
        Write-Error "Failed to grant key vault access for function app $functionAppName."
    }
}

if($MachineLearning)
{
    $machineLearningWorkspaceName = $parameters.parameters.machineLearningWorkspaceName.value 
    $machineLearningResourceGroupName = $parameters.parameters.machineLearningResourceGroupName.value
    $storageAccountName = $parameters.parameters.storageAccountName.value
    $applicationInsightsName = $parameters.parameters.applicationInsightsName.value 
    $containerRegistryName = $parameters.parameters.containerRegistryName.value 
    $machineLearningKeyVaultName = $parameters.parameters.machineLearningKeyVaultName.value


    $machineLearningTemplateFile = "$devOpsProjectfolder\Templates\machinelearning.template.json"
    $machineLearningDeploymentName = $machineLearningName + "_depl"
    New-AzResourceGroupDeployment -Name $MachineLearningDeploymentName `
                -TemplateFile $machineLearningTemplateFile `
                -ResourceGroupName $machineLearningResourceGroupName `
                -workspaceName $machineLearningWorkspaceName `
                -storageAccountName $storageAccountName `
                -keyVaultName $machineLearningKeyVaultName `
                -applicationInsightsName $applicationInsightsName `
                -containerRegistryName $containerRegistryName `
                -tagValues $tagValues

    # If this is a data science env we need to grant access for the data engineer
    if ($parameters.parameters.dataEngineerADGroupId.value) {
        if("dx".Contains($parameters.parameters.ProjectEnvironment.value)) {
            $roleName = "InA Tech DS Engineer Contributor"
        } else {
            $roleName = "InA Tech DS Engineer Reader"
        }
    }
     
    $resource = Get-AzResource -Name $machineLearningWorkspaceName
    $granteeObjectId = $parameters.parameters.dataEngineerADGroupId.value
    $assignment = Get-AzRoleAssignment -ResourceGroupName $machineLearningResourceGroupName -ResourceName $machineLearningWorkspaceName -RoleDefinitionName $roleName -ResourceType $resource.ResourceType -ObjectId $granteeObjectId
  
    if (-not $assignment) {
        New-AzRoleAssignment -ResourceGroupName $machineLearningResourceGroupName -ResourceName $machineLearningWorkspaceName -RoleDefinitionName $roleName -ResourceType $resource.ResourceType -ObjectId $granteeObjectId
    } else {
        Write-Verbose "Role assignment already exists for $roleName on object $resourceName."
    }
}

if ($LogAnalytics) {
    
    $resourceGroupName = $parameters.parameters.logAnalyticsResourceGroupName.value
    
    $workspaceName = $parameters.parameters.logAnalyticsWorkspaceName.value
    $location = $parameters.parameters.location.value
    $functionDeploymentName = $workspaceName + "_depl"
    $functionTemplateFile = "$devOpsProjectFolder\Templates\loganalytics.json"

    New-AzResourceGroupDeployment -Name $functionDeploymentName `
                -TemplateFile $functionTemplateFile `
                -ResourceGroupName $resourceGroupName `
                -workspace_name $workspaceName -location $location | Out-Null


    $resource = Get-AzResource -Name $workspaceName
    $roleName = "Log Analytics Reader"
    $granteeObjectId = $parameters.parameters.appReaderGroupId.value
    $assignment = Get-AzRoleAssignment -ResourceGroupName $resourceGroupName -ResourceName $workspaceName -RoleDefinitionName $roleName -ResourceType $resource.ResourceType -ObjectId $granteeObjectId
    if (-not $assignment) {
        New-AzRoleAssignment -ResourceGroupName $resourceGroupName -ResourceName $workspaceName -RoleDefinitionName $roleName -ResourceType $resource.ResourceType -ObjectId $granteeObjectId
    } else {
        Write-Verbose "Role assignment already exists for $roleName on object $workspaceName."
    }
    $roleName = "Log Analytics Contributor"
    $granteeObjectId = $parameters.parameters.appContributorGroupId.value
    $assignment = Get-AzRoleAssignment -ResourceGroupName $resourceGroupName -ResourceName $workspaceName -RoleDefinitionName $roleName -ResourceType $resource.ResourceType -ObjectId $granteeObjectId
    if (-not $assignment) {
        New-AzRoleAssignment -ResourceGroupName $resourceGroupName -ResourceName $workspaceName -RoleDefinitionName $roleName -ResourceType $resource.ResourceType -ObjectId $granteeObjectId
    } else {
        Write-Verbose "Role assignment already exists for $roleName on object $workspaceName."
    }

<#
    $roleName = "Log Analytics Contributor"
    $granteeObjectId = $parameters.parameters.servicePrincipalId.value
Write-Verbose "parameters.parameters.applicationId.value $($parameters.parameters.applicationId.value)"
Write-Verbose "granteeObjectId $granteeObjectId"
    $assignment = Get-AzRoleAssignment -ResourceGroupName $resourceGroupName -ResourceName $workspaceName -RoleDefinitionName $roleName -ResourceType $resource.ResourceType -ObjectId $granteeObjectId
    if (-not $assignment) {
        New-AzRoleAssignment -ResourceGroupName $resourceGroupName -ResourceName $workspaceName -RoleDefinitionName $roleName -ResourceType $resource.ResourceType -ObjectId $granteeObjectId
    } else {
        Write-Verbose "Role assignment already exists for $roleName on object $workspaceName."
    }
#>
}

if ($budgetAlert) {

    $resourceGroupName = $parameters.parameters.budgetAlertResourceGroupName.value
    $budgetAlertName = $parameters.parameters.budgetAlertName.value
    $budgetLimitGBP = $parameters.parameters.budgetLimitGBP.value

    $year = (Get-Date).Year
    $month = (Get-Date).Month 
    $startDate = Get-Date -Year $Year -Month $Month -Day 1
    $endDate = $startDate.AddYears(1)
    $emailNotification = $parameters.parameters.actionGroupSupportEmail.value
    $budgetDeploymentName = $budgetAlertName + "_depl"
    $budgetTemplateFile = "$devOpsProjectFolder\Templates\budgetalert.template.json"

    New-AzResourceGroupDeployment -Name $budgetDeploymentName `
                                -TemplateFile $budgetTemplateFile `
                                -ResourceGroupName $resourceGroupName `
                                -BudgetName $budgetAlertName `
                                -amount $budgetLimitGBP `
                                -startDate $startDate `
                                -endDate $endDate  `
                                -contactEmails $emailNotification

}

if ($LogicApp) {  
    & "$utilitiesFolder\New-LogicApp.ps1" -parameterFile $parameterFile -SqlDb:$SqlDb -SqlDW:$SqlDW -LogAnalytics:$LogAnalytics -ADLStore:$AdlsGen2 -ADLStoreGen1:$ADLStoreGen1 -Permissions
}

if ($StreamAnalyticsJob) {
    $resourceGroupName = $parameters.parameters.streamAnalyticsJobResourceGroupName.value
    $streamAnalyticsJobName = $parameters.parameters.streamAnalyticsJobName.value
    $numberOfStreamingUnits = $parameters.parameters.numberOfStreamingUnits.value
    $streamAnalyticsJobDeploymentName = $streamAnalyticsJobName + "_depl"
    $templateFile = "$devOpsProjectFolder\Templates\streamAnalyticsJob.template.json"

    New-AzResourceGroupDeployment  `
    -Name $streamAnalyticsJobDeploymentName  `
    -ResourceGroupName "bnlwe-da04-d-00018-rg"  `
    -TemplateFile $templateFile  `
    -streamAnalyticsJobName $streamAnalyticsJobName `
    -numberOfStreamingUnits $numberOfStreamingUnits
}
