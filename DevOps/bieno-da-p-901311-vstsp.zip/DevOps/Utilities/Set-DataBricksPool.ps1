Param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify workspace access token')]
    [ValidatePattern("^(Prod|Prod2|Prod3)$")]
    [String]$subscriptionName,
    [Parameter(Mandatory = $True, HelpMessage='Specify the number of cores to reserve/return')]
    [int32]$CoresRequired,
    [Parameter(Mandatory = $False, HelpMessage='Specify the parameter file')]
    [String]$region="northeurope",
    [Parameter(Mandatory = $False, HelpMessage='PAss this to return cores to the pool')]
    [switch]$returnToPool

)
# Use to allocate ADB cores from one of 3 pools from landscape ADB workspaces in Prod, Prod2 and Prod3
# Written to support CoronaVirus 
$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

if ($subscriptionId -eq "Prod3") {
    $region="westeurope"
}

if ($CoresRequired % 4 -ne 0){
    throw "The value specificed for coresRequired must be divisible by 4."
}

$quota = @{
    Prod=2000
    Prod2=2000
    Prod3=1000
}
$coresPerVM = @{
    Prod=8
    Prod2=4
    Prod3=8
}
if ($CoresRequired -lt $coresPerVM[$subscriptionName]){
    throw "The minimum allowed value for coresRequired is $coresPerVM[$subscriptionName] and must be divisible by 4."
}
$uriBase = "https://$region.azuredatabricks.net/api/2.0"

add-type @"
using System.Net;
using System.Security.Cryptography.X509Certificates;
public class TrustAllCertsPolicy : ICertificatePolicy {
    public bool CheckValidationResult(
        ServicePoint srvPoint, X509Certificate certificate,
        WebRequest request, int certificateProblem) {
        return true;
    }
}
"@
$AllProtocols = [System.Net.SecurityProtocolType]'Ssl3,Tls,Tls11,Tls12'
[System.Net.ServicePointManager]::SecurityProtocol = $AllProtocols

$tokens=@{
    Prod="dapi1147e7cb008ef6a6538112ea6e839132"
    Prod2="dapie6b4f457924aa31ddc79ca0b03d94149"
    Prod3="dapi603d963d98ba7d7a2fa82eaeedf6787d"
}
$accessToken = $tokens["$subscriptionName"]
function Get-Pool {
    param($poolId)
        $uri = "$uriBase/instance-pools/get?$poolId"
        $head = @{authorization = "Bearer $accessToken" }

    $pools = Invoke-RestMethod -Uri $uri -Method 'GET' -Headers $head -ContentType "application/json"
    return $pools
}
function Get-Pools {
    param()
        $uri = "$uriBase/instance-pools/list"
        $head = @{authorization = "Bearer $accessToken" }

    $pools = Invoke-RestMethod -Uri $uri -Method 'GET' -Headers $head -ContentType "application/json"
    return $pools
}
function Get-Pools {
    param()
        $uri = "$uriBase/instance-pools/list"
        $head = @{authorization = "Bearer $accessToken" }

    $pools = Invoke-RestMethod -Uri $uri -Method 'GET' -Headers $head -ContentType "application/json"
    return $pools
}
function Set-Pool {
    param($body)
        $uri = "$uriBase/instance-pools/edit"
        $head = @{authorization = "Bearer $accessToken" }

    $pools = Invoke-RestMethod -Uri $uri -Method 'POST' -Body $body -Headers $head -ContentType "application/json"
    return $pools
}
$response = Get-Pools
if ($pools.response.count -gt 1) {
    throw "There are multiple pools in this workspace.  Only one is allowed."
}
$pool = $response.instance_pools[0]
$initialCapacity = $pool.max_capacity*$coresPerVM[$subscriptionName]
$initialCapacityVms = $pool.max_capacity

if ($returnToPool) {
    $maxCapacity = $pool.max_capacity*$coresPerVM[$subscriptionName] + $CoresRequired
    if ($maxCapacity -gt $quota[$subscriptionName]){
        throw "If you return $CoresRequired cores then the max cores assigned to the pool will breach our allocation of $($quota[$subscriptionName])."
    }
} else {
    $maxCapacity = $pool.max_capacity*$coresPerVM[$subscriptionName] - $CoresRequired
}
if ($maxCapacity -lt 0 ) {
    throw "There aren't enough cores to service your request.  Only $($pool.max_capacity*$coresPerVM[$subscriptionName]) available."
}
$finalCapacityVms = $maxCapacity / $coresPerVM[$subscriptionName]
$json = @"
{
    "instance_pool_id": "0101-120000-brick1-pool-ABCD1234",
    "instance_pool_name": "my-edited-pool",
    "node_type_id": "Standard_D3_v2",
    "min_idle_instances": 5,
    "max_capacity": 200,
    "idle_instance_autotermination_minutes": 30
  }
"@
$body = ConvertFrom-Json -InputObject $json
$body.instance_pool_id = $pool.instance_pool_id
$body.instance_pool_name = $pool.instance_pool_name
$body.node_type_id = $pool.node_type_id
$body.min_idle_instances = $finalCapacityVms
$body.idle_instance_autotermination_minutes = $pool.idle_instance_autotermination_minutes
$body.max_capacity = $finalCapacityVms

$body = ConvertTo-Json -InputObject $body
Set-Pool -body $body

Write-Host "Pool $($pool.instance_pool_name)[$($pool.instance_pool_id)] in $subscriptionName was resized from $initialCapacity cores to $($maxCapacity) cores."
Write-Host "Pool $($pool.instance_pool_name)[$($pool.instance_pool_id)] in $subscriptionName was resized from $initialCapacityVms Vms to $($finalCapacityVms) Vms."
return