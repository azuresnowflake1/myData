Param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$parameterFile,
    [Parameter(Mandatory = $True, HelpMessage='Specify the name of the cluster')]
    [String]$clusterId
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

$subscriptionId = $parameters.parameters.subscriptionId.value
$tenantId = $parameters.parameters.tenantId.value
$keyVaultName = $parameters.parameters.keyVaultName.value
$region=$parameters.parameters.location.value.Replace(" ", "")

$tokenSecretName = $parameters.parameters.databricksTokenSecretName.value
if (-not $tokenSecretName)
{
    $tokenSecretName = "DatabricksAccessToken"
}
$secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $tokenSecretName -ErrorAction SilentlyContinue
$accessToken = $secret.SecretValueText
$uriBase = "https://$region.azuredatabricks.net/api/2.0"

return Adb-Remove-Cluster