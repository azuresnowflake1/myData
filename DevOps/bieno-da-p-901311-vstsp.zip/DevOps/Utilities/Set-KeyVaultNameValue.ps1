[CmdletBinding(DefaultParameterSetName='expiryYears')]
Param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [string]$parameterFile,

    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [string]$secretName,
    
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [string]$secretValue,

    [Parameter(Mandatory = $False, HelpMessage='Specify an optional description for the secret')]
    [string]$contentType="",

    [Parameter(Mandatory=$False,HelpMessage='Update the secret in the key vault if it exists')]
    [switch]$updateSecret = $False,

    [Parameter(Mandatory=$False,HelpMessage='Pass this to add to Landscape key vault')]
    [switch]$landscape = $False,

    [Parameter(Mandatory=$False,HelpMessage='Pass this to override the default secret expiry term in years', ParameterSetName="expiryYears")]
    [int]$secretExpiryTermYears=4,

    [Parameter(Mandatory=$False,HelpMessage='Pass this to specify the secret expiry date', ParameterSetName="expiryDate")]
    [datetime]$secretExpiryDate
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$location = $parameters.parameters.location.value

$tenantId = $parameters.parameters.tenantId.value
$applicationId = $parameters.parameters.deploymentApplicationId.value

function Set-KvSecret {
    param([string]$pFile, [string]$name, [string]$value)
    
    $parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $pFile
    $subscriptionId = $parameters.parameters.subscriptionId.value
    $sub = Select-AzSubscription -SubscriptionId $subscriptionId

    $keyVaultName = $parameters.parameters.keyVaultName.value

    if ($landscape) {
        $keyVaultName = $parameters.parameters.landscapeKeyVaultName.value
    }

    $keyVaultSecretExpiryTerm = $parameters.parameters.keyVaultSecretExpiryTerm.value
    if ($secretExpiryTermYears -gt 0) {
        $keyVaultSecretExpiryTerm = $secretExpiryTermYears
    }
    if ($secretExpiryDate) {
        $keyVaultSecretExpiry = $secretExpiryDate
    } else {
        $keyVaultSecretExpiry = (Get-Date).AddYears($keyVaultSecretExpiryTerm)
    }
    $keyValue = ConvertTo-SecureString -AsPlainText $value -Force
    $secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $name -ErrorAction SilentlyContinue
    if (-not $secret){
        $NBF =(Get-Date).ToUniversalTime()
        $kyvlt = Set-AzKeyVaultSecret -VaultName $keyVaultName -Name $name -SecretValue $keyValue -Expires $keyVaultSecretExpiry -ContentType $contentType -notbefore $NBT
        Write-Host "Secret $name added to the key vault $keyVaultName"
        
    } elseif ($updateSecret) {
        Write-Host "Update specified for the secret $name in the key vault $keyVaultName"
        if (!$contentType) {
            $contentType = $secret.ContentType
        }
        $kyvlt = Set-AzKeyVaultSecret -VaultName $keyVaultName -Name $name -SecretValue $keyValue -Expires $keyVaultSecretExpiry -ContentType $contentType
        Write-Host "Existing secret $name was updated to the key vault $keyVaultName"
    }
    else{
        Write-Warning "Secret $name exists in the key vault $keyVaultName.  The Value was not updated!"
    }

}

Set-KvSecret -pFile $parameterFile -name $secretName -value $secretValue