[CmdletBinding(DefaultParameterSetName='expiryYears')]
Param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [string]$parameterFile,
    
    [Parameter(HelpMessage='Specify the secret.')]
    [PSCredential] $secretCredential,

    [Parameter(Mandatory=$False,HelpMessage='An optional description for the secret')]
    [string]$contentType,

    [Parameter(Mandatory=$False,HelpMessage='Update the secret in the key vault if it exists')]
    [bool]$updateSecret = $False,

    [Parameter(Mandatory=$False,HelpMessage='Pass this to add to Landscape key vault')]
    [switch]$landscape = $False,

    [Parameter(Mandatory=$False,HelpMessage='Pass this to override the default secret expiry term in years', ParameterSetName="expiryYears")]
    [int]$secretExpiryTermYears=4,

    [Parameter(Mandatory=$False,HelpMessage='Pass this to specify the secret expiry date', ParameterSetName="expiryDate")]
    [datetime]$secretExpiryDate
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

$keyVaultName = $parameters.parameters.keyVaultName.value
if ($landscape) {
    $keyVaultName = $parameters.parameters.landscapeKeyVaultName.value
}

$keyVaultSecretExpiryTerm = $parameters.parameters.keyVaultSecretExpiryTerm.value
if ($secretExpiryTermYears -gt 0) {
    $keyVaultSecretExpiryTerm = $secretExpiryTermYears
}
if ($secretExpiryDate) {
    $keyVaultSecretExpiry = $secretExpiryDate
} else {
    $keyVaultSecretExpiry = (Get-Date).AddYears($keyVaultSecretExpiryTerm)
}

$secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $secretCredential.UserName -ErrorAction SilentlyContinue
if (!$secret){
    Set-AzKeyVaultSecret -VaultName $keyVaultName -Name $secretCredential.UserName -SecretValue $secretCredential.Password -Expires $keyVaultSecretExpiry -contentType $contentType | Out-Null
    Write-Verbose "Secret $($secretCredential.UserName) added to the key vault $keyVaultName"
    Start-Sleep -s 5
}elseif ($updateSecret){
    Write-Verbose "Update specified for the secret $($secretCredential.UserName) in the key vault $keyVaultName"
    if (!$contentType) {
        $contentType = $secret.ContentType
    }
    Set-AzKeyVaultSecret -VaultName $keyVaultName -Name $secretCredential.UserName -SecretValue $secretCredential.Password -Expires $keyVaultSecretExpiry -contentType $contentType | Out-Null
    Write-Verbose "Secret $($secretCredential.UserName) updated to the key vault $keyVaultName"
    Start-Sleep -s 5
}
else{
    Write-Warning "Secret $($secretCredential.UserName) exists in the key vault $keyVaultName. No update was made!"
}


