Param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$parameterFile,
    [Parameter(Mandatory = $False, HelpMessage='Specify the name of the ADLS mount point')]
    [String]$scopeName="Landscape"
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

$subscriptionId = $parameters.parameters.subscriptionId.value
$tenantId = $parameters.parameters.tenantId.value
$applicationId = $parameters.parameters.applicationId.value
$keyVaultName = $parameters.parameters.keyVaultName.value
$adlsName = $parameters.parameters.adlStoreName.value
$sharedAdlsName = $parameters.parameters.sharedAdlStoreName.value
$storageAccountResourceGroupName = $parameters.parameters.storageAccountResourceGroupName.value
$storageAccountName = $parameters.parameters.storageAccountName.value
$region=$parameters.parameters.location.value.Replace(" ", "")

$tokenSecretName = $parameters.parameters.databricksTokenSecretName.value
if (-not $tokenSecretName)
{
    $tokenSecretName = "DatabricksAccessToken"
}
$secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $tokenSecretName -ErrorAction SilentlyContinue
$accessToken = $secret.SecretValueText

$uriBase = "https://$region.azuredatabricks.net/api/2.0"

if (Adb-Get-SecretScope -scopeName $scopeName){
    Write-Host "Removing existing secret scope '$scopeName'"
    Adb-Remove-SecretScope -scopeName $scopeName

} else {
    Write-Warning "Secret scope '$scopeName' was not found."
}
