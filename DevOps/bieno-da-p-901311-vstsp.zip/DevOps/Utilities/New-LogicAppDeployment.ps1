Param
(
    [Parameter(Mandatory = $True, HelpMessage = 'Specify the parameter file')]
    [String]$parameterFile,
    [Parameter(Mandatory = $True, HelpMessage = 'Specify the path from the repo root to where the ARM templates are checked in.')]
    [String]$armFolderName,
    [Parameter(Mandatory = $True, HelpMessage = 'The file name of the ARM template.')]
    [String]$armTemplateFileName
)
# Deploy logic app using the ARM template published to git.
$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"
$customFolder = "{0}\{1}" -f $devOpsProjectFolder, "Custom"
$armFolder = Join-Path -Path $customFolder -ChildPath $armFolderName

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

$templateFilePath = Join-Path -Path $armFolder -ChildPath $armTemplateFileName

$logicAppParameters = Get-Content -Path $templateFilePath -Raw | ConvertFrom-JSON

$logicAppResourceGroupName = $parameters.parameters.logicAppResourceGroupName.value
$logicAppName = $parameters.parameters.logicAppName.value
$logicAppO365apiConnection = $parameters.parameters.logicAppO365apiConnection.value

Write-Output "Logic App name is" + $logicAppName
Write-Output "Connection name is" + $logicAppO365apiConnection

$keyVaultName = $parameters.parameters.keyVaultName.value
$adApplicationName = $parameters.parameters.adApplicationName.value
$adApplicationId = $parameters.parameters.applicationId.value
$subscriptionId = $parameters.parameters.subscriptionId.value

if($logicAppParameters.parameters.logicapp_sqldw_username){
    $logicAppSqlDWapiConnectionUser = "sqllogicappuser"
    $logicAppSqlDWapiConnectionUserValue = ConvertTo-SecureString $logicAppSqlDWapiConnectionUser -AsPlainText -Force
    $secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $logicAppSqlDWapiConnectionUser
    $logicAppSqlDWapiConnectionPasswordValue = $secret.SecretValueText
    $logicAppSqlDWapiConnectionPasswordValue = ConvertTo-SecureString $logicAppSqlDWapiConnectionPasswordValue -AsPlainText -Force    
}

$secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $adApplicationName
$applicationId_token_clientSecret = $secret.SecretValueText
$applicationId_token_clientSecret = ConvertTo-SecureString $applicationId_token_clientSecret -AsPlainText -Force

$params = @{
    #"Name" = $logicAppName
    "logicAppName" = $logicAppName
    "ResourceGroupName" = $logicAppResourceGroupName
    "TemplateFile" = $templateFilePath 
    "logicAppO365apiConnection" = $logicAppO365apiConnection
}
#$logicAppParameters.resources[0].properties.definition.actions.Run_query_and_list_results.inputs.queries.subscriptions

if($logicAppParameters.parameters.logicapp_sqldw_username){
    $params.Add("logicapp_sqldw_username",$logicAppSqlDWapiConnectionUserValue)
    $params.Add("logicapp_sqldw_password",$logicAppSqlDWapiConnectionPasswordValue)
}

if($logicAppParameters.parameters.datalake_token_clientSecret){
    $params.Add("datalake_token_clientSecret", $applicationId_token_clientSecret)
    $params.Add("datalake_token_clientId", $adApplicationId)
}

if($logicAppParameters.parameters.monitorlogs_token_clientSecret){
    $params.Add("monitorlogs_token_clientSecret",  $applicationId_token_clientSecret)
    $params.Add("monitorlogs_token_clientId",  $adApplicationId)
}

New-AzResourceGroupDeployment @params

#Get-AzLogicAppTriggerCallbackUrl -ResourceGroupName $logicAppResourceGroupName -Name $logicAppName -TriggerName "manual" -Verbose