param(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file for the target environment')]
    [String]$parameterFile,
    [Parameter(Mandatory=$false)] [string]$soureParameterFile="parameters.q.80013.json",
    [Parameter(Mandatory=$false)] [string]$containerName="azurebatch",
    [Parameter(Mandatory=$false)] [string]$folderName="monitoring"
)
# Copy the files in a specified directory to to a blob container
# Use this to deploy a custom ADF task to a BLOB container.  It also deploys the parameter file as parameters.json

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"
$parameterFileSourcePath = & "$utilitiesFolder\Get-ParametersFile.ps1" -parameterFile $parameterFile
$parameterFileTargetPath = "{0}\parameters.json" -f $folderName

$parameters = & "$utilitiesFolder\Get-Parameters.ps1" -parameterFile $parameterFile
$sParameters = & "$utilitiesFolder\Get-Parameters.ps1" -parameterFile $soureParameterFile

$subscriptionId = $parameters.parameters.subscriptionId.value
$sub = Select-AzSubscription -SubscriptionId $subscriptionId
Write-Verbose $sub

$useResourceGroupName = $parameters.parameters.storageAccountResourceGroupName.value;
$storageAccountName = $parameters.parameters.storageAccountName.value;

$accountKeys = Get-AzStorageAccountKey -ResourceGroupName $useResourceGroupName -Name $storageAccountName
$storageContext = New-AzStorageContext -StorageAccountName $storageAccountName -StorageAccountKey $accountKeys[0].Value 

$sSubscriptionId = $sParameters.parameters.subscriptionId.value
$sSub = Select-AzSubscription -SubscriptionId $sSubscriptionId
Write-Verbose $sub

$sUseResourceGroupName = $sParameters.parameters.storageAccountResourceGroupName.value;
$sStorageAccountName = $sParameters.parameters.storageAccountName.value;

$sAccountKeys = Get-AzStorageAccountKey -ResourceGroupName $sUseResourceGroupName -Name $sStorageAccountName
$sStorageContext = New-AzStorageContext -StorageAccountName $sStorageAccountName -StorageAccountKey $sAccountKeys[0].Value 

# Create the container if it doesn't exist
New-AzStorageContainer -Name $containerName -Context $storageContext -Permission Off -ErrorAction SilentlyContinue

$files = Get-AzStorageBlob -Container $containerName -Context $sStorageContext -Prefix $folderName
for ($i=0; $i -lt $files.Count; $i++) {
    
    $name = Split-Path -Path $files[$i].Name -Leaf
    if ($name -eq "parameters.json") {
        continue;
    }
    else {
        Write-Output "Deploying file $name"
        Write-Verbose $files[$i].Name
        Start-AzStorageBlobCopy -SrcBlob $files[$i].Name -SrcContainer $containerName -DestContainer $containerName -Context $sStorageContext -DestContext $storageContext -Force
    }
    
}
Set-AzStorageBlobContent -File $parameterFileSourcePath `
     -Container $ContainerName `
     -Blob $parameterFileTargetPath `
     -Context $storageContext -Force

Write-Host "File copy is completed."