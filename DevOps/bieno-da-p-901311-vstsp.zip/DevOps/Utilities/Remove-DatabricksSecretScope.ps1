Param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$parameterFile,
    [Parameter(Mandatory = $False, HelpMessage='Specify the parameter file')]
    [String]$region="westeurope"
)



$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"
$managerFolder = "{0}\{1}" -f $devOpsProjectFolder, "LandscapeManager"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

$keyVaultName = $parameters.parameters.keyVaultName.value

$tokenSecretName = $parameters.parameters.databricksTokenSecretName.value
if (-not $tokenSecretName)
{
    $tokenSecretName = "DatabricksAccessToken"
}
$secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $tokenSecretName -ErrorAction SilentlyContinue
$accessToken = $secret.SecretValueText
$secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $parameters.parameters.adApplicationName.value -ErrorAction SilentlyContinue

$uriBase = "https://$region.azuredatabricks.net/api/2.0"

add-type @"
using System.Net;
using System.Security.Cryptography.X509Certificates;
public class TrustAllCertsPolicy : ICertificatePolicy {
    public bool CheckValidationResult(
        ServicePoint srvPoint, X509Certificate certificate,
        WebRequest request, int certificateProblem) {
        return true;
    }
}
"@
$AllProtocols = [System.Net.SecurityProtocolType]'Ssl3,Tls,Tls11,Tls12'
[System.Net.ServicePointManager]::SecurityProtocol = $AllProtocols
#[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPoli 

function List-Secret {
    $uri = "$uriBase/secrets/scopes/list"
    $head = @{authorization = "Bearer $accessToken" }
    
    Invoke-RestMethod -Uri $uri -Method 'GET' -Headers $head -ContentType "application/json"
}


function Remove-SecretScope {
    param( [string]$scopeName)
        $uri = "$uriBase/secrets/scopes/delete"
        $head = @{authorization = "Bearer $accessToken" }
        $body = @"
        {
            "scope": "$scopeName"
        }
"@
    Invoke-RestMethod -Uri $uri -Body $Body -Method 'POST' -Headers $head -ContentType "application/json"
}

$secrets = List-Secret
$secrets
foreach ($secret in $secrets)
    {
    If ($secret.scopes.name -eq "Landscape")
            {
    Remove-SecretScope -scopeName "Landscape"
            }
    }

$keyVaultName = $parameters.parameters.keyVaultName.value
$KeyVaultAccess = Get-AzKeyVault -VaultName $keyVaultName
    foreach ($KeyVaultAccessPolicy in $KeyVaultAccess.AccessPolicies) {
    
        if($KeyVaultAccessPolicy.DisplayName.StartsWith("AzureDatabricks")) {
            
            Remove-AzKeyVaultAccessPolicy -VaultName $keyVaultName -ObjectId $KeyVaultAccessPolicy.ObjectId
        }
    }
