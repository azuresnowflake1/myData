Param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$parameterFile,
    [switch]$outputToDisk
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile
& "$utilitiesFolder\Test-Login.ps1"
   
$keyVaultName = $parameters.parameters.keyVaultName.value
$keyVaultResourceGroupName = $parameters.parameters.keyVaultResourceGroupName.value
if (-not (Get-AzKeyVault -VaultName $keyVaultName -ResourceGroupName $keyVaultResourceGroupName)) {
    Write-Host "Key vault $keyVaultName doesn't exist."
    return $null
}

$applicationIdentityCertificateName = $parameters.parameters.applicationIdentityCertificateName.value
$applicationIdentityCertificatePassword = "{0}-Password" -f $parameters.parameters.applicationIdentityCertificateName.value

$secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $applicationIdentityCertificateName -ErrorAction SilentlyContinue
$secretValue = $secret.SecretValueText
$rawCert = [System.Convert]::FromBase64String($secretValue)

$secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $applicationIdentityCertificatePassword -ErrorAction SilentlyContinue
$identityCertificatePassword = $secret.SecretValue
$certificatePFX = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2($rawCert, $identityCertificatePassword, [System.Security.Cryptography.X509Certificates.X509KeyStorageFlags]::Exportable)

if ($outputToDisk) {
    $dd=$certificatePFX.Subject.Split("=")
    $destinationPath = "{0}\{1}" -f $devOpsProjectFolder, $dd[1]
    $secretValue | Out-File -filepath $destinationPath -Force
    Write-Host $secret.SecretValueText
}

return $certificatePFX
