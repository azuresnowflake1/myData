Param
(
    [Parameter(Mandatory = $True, HelpMessage = 'Specify the parameter file')]
    [String]$parameterFile
)
# Deploy a data factory using the ARM template published to git.
# Run this from a branch after you have merged your adf_publish branch
$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"
$projectsFolder = "{0}\{1}" -f $devOpsProjectFolder, "Projects"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile
$resourceGroupName = $parameters.parameters.dataFactoryResourceGroupName.value


# Generate a name for the merged parameter file.  This will be created in the projects folder and is the actual file that will
# be used to perform the deployment.
$mergedParameterFileName = "{0}.deploy.json" -f $parameters.parameters.dataFactoryName.value
$mergedParameterFilePath = Join-Path -Path $projectsFolder -ChildPath $mergedParameterFileName

$existingPipelines = Get-AzDataFactoryV2Pipeline -ResourceGroupName $resourceGroupName -DataFactoryName $parameters.parameters.dataFactoryName.value | Select-Object -ExpandProperty Name
$existingDatasets =  Get-AzDataFactoryV2Dataset  -ResourceGroupName $resourceGroupName -DataFactoryName $parameters.parameters.dataFactoryName.value | Select-Object -ExpandProperty Name
$existingLinkedservices =  Get-AzDataFactoryV2LinkedService  -ResourceGroupName $resourceGroupName -DataFactoryName $parameters.parameters.dataFactoryName.value | Select-Object -ExpandProperty Name

    if (-not $existingPipelines) {
        $existingPipelines = @()
    }
	
    if (-not $existingDatasets) {
        $existingDatasets = @()
    }

    if (-not $existingLinkedservices) {
        $existingLinkedservices = @()
    }

	
    foreach($pl in $existingPipelines)
    {
        if(-not $pl){
            continue
        }
        if ($existingPipelines.Contains($pl)) {
            Write-Output "Pipeline $pl found "
			######Remove-AzDataFactoryV2Pipeline -ResourceGroupName $resourceGroupName -DataFactoryName $parameters.parameters.dataFactoryName.value -Name $pl -Force

        } else {
            Write-Warning "Unable to find pipeline $pl in $($parameters.parameters.dataFactoryName.value). It doesn't exist!"
        }
    }
	
    foreach($ds in $existingDatasets)
    {
        if(-not $ds){
            continue
        }
        if ($existingDatasets.Contains($ds)) {
            Write-Output "Dataset $ds found "
			######Remove-AzDataFactoryV2Dataset  -ResourceGroupName $resourceGroupName -DataFactoryName $parameters.parameters.dataFactoryName.value -Name $ds -Force

        } else {
            Write-Warning "Unable to find Dataset $ds in $($parameters.parameters.dataFactoryName.value). It doesn't exist!"
        }
    }

    foreach($ls in $existingLinkedservices)
    {
        if(-not $ls){
            continue
        }
        if ($existingLinkedservices.Contains($ls)) {
            Write-Output "Linked Service $ls found "
			######Remove-AzDataFactoryV2LinkedService  -ResourceGroupName $resourceGroupName -DataFactoryName $parameters.parameters.dataFactoryName.value -Name $ls -Force

        } else {
            Write-Warning "Unable to find Linked Service $ls in $($parameters.parameters.dataFactoryName.value). It doesn't exist!"
        }
    }