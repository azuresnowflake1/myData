
param(
    [Parameter(Mandatory=$true)][string]$parameterFile,
    [Parameter(Mandatory=$false)] [switch]$disallow
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

& "$utilitiesFolder\Test-Login.ps1"
$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile
$sqlServerResourceGroupName = $parameters.parameters.sqlServerResourceGroupName.value


$SQLServerName = $parameters.parameters.sqlServerName.value

$GetAzureRmSqlServerFirewallRules = Get-AzSqlServerFirewallRule -ResourceGroupName $sqlServerResourceGroupName -ServerName $SQLServerName | 
                                    Where-Object {$_.FirewallRuleName -match "AllowAll*"}

$s = $GetAzureRmSqlServerFirewallRules.FirewallRuleName
if ($disallow)
{
    if ($GetAzureRmSqlServerFirewallRules)
    {
        Write-Host "Removing Firewall :- $s"
        Remove-AzSqlServerFirewallRule -FirewallRuleName $s -ServerName $SQLServerName -ResourceGroupName $sqlServerResourceGroupName -Force
        return
    }
    else {
        Write-Host "Allow azure services is already disabled.  No change to the firewall was made!"
        return
    }
} else {
    if(!$GetAzureRmSqlServerFirewallRules){  
        Write-Host "Creating Firewall :- AllowAllAzureIPs"
        New-AzSqlServerFirewallRule -ResourceGroupName $sqlServerResourceGroupName -ServerName $SQLServerName -AllowAllAzureIPs  
    }
    else {
        Write-Host "Allow azure services is already enabled.  No change to the firewall was made!"
        return
    }
}