Param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$parameterFile,
    [Parameter(Mandatory = $False, HelpMessage='Specify the this to use the cluster 2 config')]
    [switch] $cluster2,
    [Parameter(Mandatory = $False, HelpMessage='Pass this if you want use Gen1 mount points')]
    [switch]$adlsGen1
)
# Call this afteryou have added an access token to key vault.  It will create the clusters and mount ADLS

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"
$managerFolder = "{0}\{1}" -f $devOpsProjectFolder, "LandscapeManager"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

#$keyVaultName = $parameters.parameters.keyVaultName.value
#$region=$parameters.parameters.location.value.Replace(" ", "")
#$tokenSecretName = $parameters.parameters.databricksTokenSecretName.value
#if (-not $tokenSecretName)
#{
#    $tokenSecretName = "DatabricksAccessToken"
#}
#$secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $tokenSecretName -ErrorAction SilentlyContinue
#$accessToken = $secret.SecretValueText


# convert the tag values into a hash table
$p = @{
    parameterFile=$parameterFile;
}
if ($cluster2) {
    $clusterName = $parameters.parameters.databricksCluster2.value.cluster_name
    $p["cluster2"] = $cluster2
} else {
    $clusterName = $parameters.parameters.databricksCluster1.value.cluster_name
    $p["cluster1"] = $True
}

# Create the notebook depoloyment directory
$dirRoot = "/MyWorkbooks"
Adb-New-Directory -path $dirRoot

# In dev the tester group has contributor on the ADB workspace.  This is required so that
# testers can start the tester cluster and attach notebooks
if ("dqx".Contains($parameters.parameters.ProjectEnvironment.value)) {
    # In QA we want developers and tester to be able to see the workspace
    & "$managerFolder\Sync-DataBricksWithAad.ps1" -parameterFile $parameterFile -developer -tester -devOps
} elseif ($parameters.parameters.ProjectEnvironment.value -eq "u") {
    # In QA we want developers and tester to be able to see the workspace
    & "$managerFolder\Sync-DataBricksWithAad.ps1" -parameterFile $parameterFile -devOps
} elseif ($parameters.parameters.ProjectEnvironment.value -eq "b") {
    # In QA we want developers and tester to be able to see the workspace
    & "$managerFolder\Sync-DataBricksWithAad.ps1" -parameterFile $parameterFile -devOps
} elseif ("rp".Contains($parameters.parameters.ProjectEnvironment.value)) {
    # In QA we want developers and tester to be able to see the workspace
    & "$managerFolder\Sync-DataBricksWithAad.ps1" -parameterFile $parameterFile -devOps
}

# Create a linked service and permanent cluster
& "$utilitiesFolder\Set-Datafactory-Databricks.ps1" @p

$cluster = & "$utilitiesFolder\New-DataBricksClusterGet.ps1" -parameterFile $parameterFile -clusterName $clusterName
$args = @{
    parameterFile=$parameterFile
}
if ($adlsGen1) {
    $args.adlsGen1=$true
}
if ($cluster) {
    # mount ADLS.  This will use the cluster that was just created
    $args.clusterId=$cluster.cluster_id
}
& "$utilitiesFolder\New-DataBricksMountPoint.ps1" @args

# If Log analytic is provisioned intialise the databricks backed key vault
#if ($parameters.parameters.logAnalyticsWorkspaceName -and $parameters.parameters.logAnalyticsWorkspaceName.value) {
try {
    $loganalyticsworkspace = Get-AzOperationalInsightsWorkspace -Name $parameters.parameters.logAnalyticsWorkspaceName.value -ResourceGroupName $parameters.parameters.logAnalyticsResourceGroupName.value -ErrorAction -SilentlyContinue
    
    if ($loganalyticsworkspace) {
        Write-Host "Configuring databricks backed key vault."
        & "$utilitiesFolder\New-DataBricksKeyVault.ps1" -parameterFile $parameterFile -logAnalyticsWorkspace $loganalyticsworkspace
    }
}
catch {
    Write-Verbose "Log Analytics not provisioned"

}
#}
