#copy paste and run on powershell console
$targetKeyVault = "bieno-da-d-57098-appk-01" 
$keys = @('isu-wd-hrs-analytics-unilever6-myleaves','isu-wd-hrs-analytics-unilever-sandbox') 
$secrets = @('7f31H$i*o','A#D^c$GUM7xup7kn')
$contentTypes = @('Description1','Description2')
for ($i=0; $i -lt $keys.length; $i++) {
    $keyName = $keys[$i]
    $keyValue = ConvertTo-SecureString -AsPlainText $secrets[$i]  -Force
    $secretCredential = New-Object System.Management.Automation.PSCredential ($keyName, $keyValue)
    $keyVaultSecretExpiry = (Get-Date).AddYears(4)
    $secret = Get-AzKeyVaultSecret -VaultName $targetKeyVault -Name $secretCredential.UserName -ErrorAction SilentlyContinue
    if ( $secret -eq $null){
        $kyvlt = Set-AzKeyVaultSecret -VaultName $targetKeyVault -Name $secretCredential.UserName -SecretValue $secretCredential.Password -Expires $keyVaultSecretExpiry -contentType $contentTypes[i]
        Write-Host "Secret $($secretCredential.UserName) added to the key vault $targetKeyVault"
       #Start-Sleep -s 5
    }else {
        if ($contentTypes[i]) {
            $contentType = $contentTypes[i]
        } else {
            $contentType = $secret.ContentType
        }
        Write-Host "Update specified for the secret $($secretCredential.UserName) in the key vault $keyVaultName"
        $kyvlt = Set-AzKeyVaultSecret -VaultName $targetKeyVault -Name $secretCredential.UserName -SecretValue $secretCredential.Password -Expires $keyVaultSecretExpiry -contentType $contentType
        Write-Host "Secret $($secretCredential.UserName) updated to the key vault $targetKeyVault"
       #Start-Sleep -s 5
    }
     
}

