Param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$parameterFile,

    [Parameter(Mandatory = $True, HelpMessage='The name of the sql user. Use naming convention sql<user purpose>user')]
    [String]$SqlLoginName
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"
$managerFolder = "{0}\{1}" -f $devOpsProjectFolder, "LandscapeManager"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

Get-Module -Name SqlPS | Remove-Module
$a = Get-Module -ListAvailable -Name SqlServer
if (-not $a)
{
	Write-Host "installing SqlServer modules: start"
	Install-Module -Name SqlServer -Force -AllowClobber
	Write-Host "installing modules: end"
}

$cred = & "$managerFolder\Get-LandscapeServiceAccount" -parameterFile $parameterFile
if ($cred) {
    $sqlUser = $cred.UserName
    $sqlPwd = $cred.Password.SecretValueText
} else {
    Write-Error "The landscape service account credential was not found."
    return
}

$keyVaultName = $parameters.parameters.keyVaultName.value

$secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $SqlLoginName
$sqlUserPassword = $secret.SecretValueText

Function UpdateLogintoSql()
{
    param
    (
        # Parameter help description
        [String]$userName        
    )
    
    $sqlServerName = $parameters.parameters.sqlServerName.value    
    $sqlLoginStr = "ALTER LOGIN [{0}] WITH password='{1}'"    
    $sqlLoginCmdStr = $sqlLoginStr -f $SqlLoginName, $sqlUserPassword
    $sqlLoginCmdTmpFile = New-TemporaryFile
    $sqlLoginCmdStr > $sqlLoginCmdTmpFile

    try{
        $sqlCmdConnectString="Server=$sqlServerName.database.windows.net;Initial Catalog=master;Persist Security Info=False;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Authentication=""Active Directory Password"";User ID={0};Password={1}" -f $sqlUser, $sqlPwd
        Invoke-SqlCmd -Query $sqlLoginCmdStr -ConnectionString $sqlCmdConnectString
        Write-Host "Login $SqlLoginName updated in sql server $sqlServerName"
    }catch{
        throw
    }
}
UpdateLogintoSql -userName $DbUserName

