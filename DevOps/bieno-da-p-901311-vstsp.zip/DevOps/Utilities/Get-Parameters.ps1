Param
(
    [Parameter(Mandatory = $True, HelpMessage = 'Specify the parameter file')]
    [String]$parameterFile,
    [Parameter(Mandatory = $False, HelpMessage = 'Specify the parameter override file.  Use this to set specific values to something else. Useful if you need to create multiple instances of components.')]
    [String]$overrideFile="",
    [Parameter(Mandatory = $False, HelpMessage = 'Specify if you want to a specific landscape storage account in the event the parameter file is not available on the local disk.')]
    [Hashtable]$bootStrap
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

function Copy-Property{
    [CmdletBinding()]
    param([Parameter(ValueFromPipeline=$true)]$InputObject,
          $SourceObject,
          [string[]]$Property,
          [switch]$Passthru)
     
          $passthruHash=@{Passthru=$passthru.IsPresent}
         
          $propHash=@{}
          $property | Foreach-Object {
                        $propHash+=@{$_=$SourceObject.$_}
                      }
          $inputObject | Add-Member -NotePropertyMembers $propHash @passthruHash
        }
$tokens = $parameterFile.Split(".")
if ($tokens.Count -eq 2) {
    # Assume a contracted parameter file name was passed.
    $parameterFile = "{0}.$parameterFile.json" -f "parameters"
}

if ($overrideFile -ne "")
{
    $newFile = & "$utilitiesFolder\Get-ParametersFileName.ps1" -parameterFile $parameterFile -overrideFile $overrideFile
    
    # if the override file doesn't exist, create it
    try {
        $args = @{
            parameterFile=$newFile
            erroraction='silentlycontinue'
        }
        if ($bootStrap) {
            $args.bootStrap = $bootStrap
        }
        $paramFile = & "$utilitiesFolder\Get-ParametersFile.ps1" @args

        # handle the case when the override file doesn't have a valur in $suffix.  In this case we want to apply the overrides to
        # the main parameter file rather than create a new one with the suffix added to the name
        throw [System.IO.FileNotFoundException] "Override parameters will be applied to the main parameter file $parameterFile."
    }
    catch {
        Write-Host "New param override file doesn't exist.  Creating it"
        $args = @{
            parameterFile=$overrideFile
        }
        if ($bootStrap) {
            $args.bootStrap = $bootStrap
        }
        $overrideParameters = & "$utilitiesFolder\Get-Parameters.ps1" @args
        $args.parameterFile = $parameterFile
        $parameters = & "$utilitiesFolder\Get-Parameters.ps1" @args
        
        $properties = $overrideParameters.parameters | Get-Member -MemberType Properties | Select-Object
        $properties.GetType
        ForEach($property in $properties) {
            $parameters.parameters.psobject.properties.remove($property.Name)
            Copy-Property -InputObject $parameters.parameters -Property $property.Name -SourceObject $overrideParameters.parameters

        }
        $parameterProjectFile = "{0}\Projects\$newFile" -f $devOpsProjectFolder
        $parameters | ConvertTo-JSON -Depth 10 | Out-File -filepath $parameterProjectFile -Force
        Write-Host "Overridden parameter file created at: $parameterProjectFile"

    }
    # return the overridden file
    $parameterFile = $newFile
}
$args = @{
    parameterFile=$parameterFile
}
if ($bootStrap) {
    $args.bootStrap = $bootStrap
}
$paramFile = & "$utilitiesFolder\Get-ParametersFile.ps1" @args
$parameters = Get-Content -Path $paramFile -Raw | ConvertFrom-JSON
return $parameters