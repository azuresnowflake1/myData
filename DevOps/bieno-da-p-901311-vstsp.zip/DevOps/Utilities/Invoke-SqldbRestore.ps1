Param
(
    [Parameter(Mandatory = $True, HelpMessage = 'Specify the source parameter file')]
    [String]$parameterFile,

    [Parameter(Mandatory = $False, HelpMessage = 'Specify the target environment parameter file')]
    [String]$targetParameterFile=$parameterFile
)

# Restore a database.  Default name of the restored db is the same as the source.
##################################################################################################################
# WARNING:  THIS SCRIPT IS DESIGNED TO MOVE A DATABASE FROM DUBLIN TO NEW FOUNDATION
# IT WILL RESET THE LOCAL ADMIN PASSWORD IN THE TARGET SERVER WHICH IS FINE FOR NEW FOUNDATION.  IT ISN'T FOR OLD
##################################################################################################################
$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

function Get-SqlAdminPassword {
    param([string]$pFile,$params,$ctx)
    $subs=@("50327adb-f8a0-4908-8d31-aa182df19f02","204671af-5130-4ef5-819c-e314b65f9d06","9abbdd30-3391-4dfc-bfb6-217a40627488")
    $adminPwdSecret = & "$utilitiesFolder\Get-KeyVaultSecret" -parameterFile $pFile -secretName $params.sqlServerAdminLogin.value
     
    if (-not $adminPwdSecret) {
        if ($subs.Contains($ctx.SubScription.Id)) {
            throw "You cannot perform this export as it will reset the sql admin password in an old foundation subscription $($ctx.SubScription.Id)"
        }
        # Assume new foundation so reset pwd and discard
        $pwd = & "$utilitiesFolder\New-Password.ps1"
        Set-AzSqlServer -ResourceGroupName $params.sqlServerResourceGroupName.value -ServerName $params.sqlServerName.value -SqlAdministratorPassword (ConvertTo-SecureString $pwd -AsPlainText -Force) -DefaultProfile $ctx | Out-Null
    } else {
        $pwd = $adminPwdSecret.SecretValueText
    }
    return $pwd
}
function Set-ImportExportMonitor {
    param([Microsoft.Azure.Commands.Sql.ImportExport.Model.AzureSqlDatabaseImportExportBaseModel]$request, $ctx, $taskType="Export")

    $stopwatch =  [system.diagnostics.stopwatch]::StartNew()
    # Check status of the export
    $status = Get-AzSqlDatabaseImportExportStatus -OperationStatusLink $request.OperationStatusLink -DefaultProfile $ctx

    Write-Host "$taskType database $($request.ServerName).$($request.DatabaseName)"
    while ($status.Status -eq "InProgress")
    {
        Write-Host "." -NoNewline
        Start-Sleep -s 10
        $status = Get-AzSqlDatabaseImportExportStatus -OperationStatusLink $request.OperationStatusLink -DefaultProfile $ctx
    }
    $status
    $stopwatch.Stop()
    $stopwatch
    $Status= $status.Status
    if($Status -eq "Succeeded")
    {
        Write-Host "Azure SQL DB $taskType $Status for $($request.ServerName).$($request.DatabaseName)."
    }
    else
    {
        Write-Error "Azure SQL DB $taskType $Status for $($request.ServerName).$($request.DatabaseName)."
    }
}
$targetParameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $targetParameterFile
$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

$tCtx=Set-AzContext -SubscriptionId $targetParameters.parameters.subscriptionId.value
$sCtx=Set-AzContext -SubscriptionId $parameters.parameters.subscriptionId.value


$sResourceGroupName = $parameters.parameters.sqlServerResourceGroupName.value
$sServerName = $parameters.parameters.sqlServerName.value
$sDbName = $parameters.parameters.sqlDatabaseName.value
$sDb = Get-AzSqlDatabase -ResourceGroupName $sResourceGroupName -Servername $sServerName -DataBaseName $sDbName -DefaultProfile $sCtx

$tResourceGroupName = $targetParameters.parameters.sqlServerResourceGroupName.value
$tServerName = $targetParameters.parameters.sqlServerName.value
$tDbName = $targetParameters.parameters.sqlDatabaseName.value
$tStorageAccountName = $targetParameters.parameters.storageAccountName.value

# Write the bacup file into the target storage account.  Create a container of one isn't there
$accountKeys = Get-AzStorageAccountKey -ResourceGroupName $tResourceGroupName -Name $tStorageAccountName -DefaultProfile $tCtx
$storageContext = New-AzStorageContext -StorageAccountName $tStorageAccountName -StorageAccountKey $accountKeys[0].Value
if(-not(Get-AzStorageContainer -Name $sDbName -Context $storageContext -ErrorAction SilentlyContinue)) 
{
    New-AzStorageContainer -Name $sDbName -Context $storageContext -Permission Off -ErrorAction SilentlyContinue
}

# Database to export
$DatabaseName = $sDbName
$serverPassword = Get-SqlAdminPassword -pFile $parameterFile -params $parameters.parameters -ctx $sCtx
$securePassword = ConvertTo-SecureString -String $serverPassword -AsPlainText -Force 

# Generate a unique filename for the BACPAC
$bacpacFilename = $DatabaseName + (Get-Date).ToString("yyyy-MM-dd-HH-mm") + ".bacpac"

# Storage account info for the BACPAC
$BaseStorageUri = "https://{0}.blob.core.windows.net/{1}" -f $tStorageAccountName, $sDbName
$BacpacUri = $BaseStorageUri + "/Daily/" + $bacpacFilename
$StorageKeytype = "StorageAccessKey"
$exportRequest = New-AzSqlDatabaseExport -ResourceGroupName $sResourceGroupName -ServerName $sServerName `
-DatabaseName $sDbName -StorageKeytype $StorageKeytype -StorageKey $accountKeys[0].Value -StorageUri $BacpacUri `
-AdministratorLogin $parameters.parameters.sqlServerAdminLogin.value -AdministratorLoginPassword $securePassword -DefaultProfile $sCtx

Set-ImportExportMonitor -ctx $sCtx -request $exportRequest -taskType "Export"

# Get the local admin passeword 
$serverPassword = Get-SqlAdminPassword -pFile $targetParameterFile -params $targetParameters.parameters -ctx $tCtx
$securePassword = ConvertTo-SecureString -String $serverPassword -AsPlainText -Force 
$importRequest = New-AzSqlDatabaseImport -ResourceGroupName $tResourceGroupName -ServerName $tServerName `
-DatabaseName $tDbName -StorageKeytype $StorageKeytype -StorageKey $accountKeys[0].Value -StorageUri $BacpacUri `
-AdministratorLogin $targetParameters.parameters.sqlServerAdminLogin.value -AdministratorLoginPassword $securePassword -DefaultProfile $tCtx `
-Edition $sDb.Edition -ServiceObjectiveName $sDb.CurrentServiceObjectiveName -DatabaseMaxSizeBytes $sDb.MaxSizeBytes

Set-ImportExportMonitor -ctx $tCtx -request $importRequest -taskType "Import"
