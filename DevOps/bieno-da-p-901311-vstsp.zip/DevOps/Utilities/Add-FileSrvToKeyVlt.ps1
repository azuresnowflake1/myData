Param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$parameterFile,
    
    [Parameter(Mandatory = $True, HelpMessage='The on prem host server name')]
    [String]$OnPremiseFileServerHostName,

    [Parameter(Mandatory = $True, HelpMessage='The user name to access on prem files')]
    [String]$OnPremiseFileServerUserName,

    [Parameter(Mandatory = $True, HelpMessage='The password to access on prem file share')]
    [String]$OnPremiseFileServerPassword 
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

& "$utilitiesFolder\Test-Login.ps1"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile
$secretExpiryYears = $parameters.parameters.keyVaultSecretExpiryTerm.value

Write-Output "Adding the data management gateway on premises file server host name"
$hostName = $parameters.parameters.OnPremiseFileServerHostName.value
$secureSecret = ConvertTo-SecureString -AsPlainText $OnPremiseFileServerHostName -Force
$secretCredential = New-Object System.Management.Automation.PSCredential ($hostName, $secureSecret)
$contentType = "The host name of an on prem file server.  Used in an ADF linked service."
& "$utilitiesFolder\Set-KeyVaultSecret.ps1" -parameterFile $parameterFile -secretCredential $secretCredential -updateSecret:$True -secretExpiryTermYears $secretExpiryYears -contentType $contentType

Write-Output "Adding the data management gateway on premises user name"
$userName =  $parameters.parameters.OnPremiseFileServerUserName.value
$secureSecret = ConvertTo-SecureString -AsPlainText $OnPremiseFileServerUserName -Force
$secretCredential = New-Object System.Management.Automation.PSCredential ($userName, $secureSecret)
$contentType = "The user name of an AD principal used to access a file server.  Used in an ADF linked service."
& "$utilitiesFolder\Set-KeyVaultSecret.ps1" -parameterFile $parameterFile -secretCredential $secretCredential -updateSecret:$True -secretExpiryTermYears $secretExpiryYears -contentType $contentType

Write-Output "Adding the data management gateway on premises password"
$passwd = $parameters.parameters.OnPremiseFileServerPassword.value
$secureSecret = ConvertTo-SecureString -AsPlainText $OnPremiseFileServerPassword -Force
$secretCredential = New-Object System.Management.Automation.PSCredential ($passwd, $secureSecret)
$contentType = "The password for an AD principal that will access a file server.  Used in an ADF linked service."
& "$utilitiesFolder\Set-KeyVaultSecret.ps1" -parameterFile $parameterFile -secretCredential $secretCredential -updateSecret:$True -secretExpiryTermYears $secretExpiryYears -contentType $contentType
