Param
(
    [Parameter(Mandatory = $True, HelpMessage = 'Specify the parameter file')]
    [String]$parameterFile,

    [Parameter(Mandatory = $True, HelpMessage = 'Specify the client Id. Client must be a native client')]
    [String]$clientId,
    
    [Parameter(Mandatory = $True, HelpMessage = 'Specify the redirect Uri for the client Id.')]
    [String]$redirectUri,

    [Parameter(Mandatory = $True, HelpMessage = 'Specify the resource to get access token for')]
    [String]$resourceId
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

$tenantId = $parameters.parameters.tenantId.value

$login = "https://login.microsoftonline.com"
$authContext = New-Object Microsoft.IdentityModel.Clients.ActiveDirectory.AuthenticationContext ("{0}/{1}" -f $login,$tenantId)
$authenticationResult = $authContext.AcquireToken($resourceId, $clientID, $redirectUri) 

$accessToken = $authenticationResult.AccessToken
return $accessToken