[CmdletBinding()]
Param(
    [Parameter(Mandatory = $true, Position = 1)] [string] $parameterFile
)
# only landscape personnel can run this script
$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

$tenantId = $parameters.parameters.tenantId.value
$clientSecret = & "$utilitiesFolder\Get-KeyVaultSecret" -parameterFile $parameterFile -secretName $parameters.parameters.deploymentAdApplicationName.value -landscape

$TokenEndpoint = {https://login.windows.net/{0}/oauth2/token} -f $tenantId 
$ARMResource = "https://management.core.windows.net/";

$Body = @{
        'resource'= $ARMResource
        'client_id' = $parameters.parameters.deploymentApplicationId.value;
        'grant_type' = 'client_credentials'
        'client_secret' = $clientSecret.secretValueText;
}

$params = @{
    ContentType = 'application/x-www-form-urlencoded'
    Headers = @{'accept'='application/json'}
    Body = $Body
    Method = 'Post'
    URI = $TokenEndpoint
}

try {
    $response = Invoke-RestMethod @params
    return $response.access_token
}
catch {
    $ErrorMessage = $_.Exception.Message
    $StatusDescription = $_.Exception.Response.StatusDescription
    $false

    Throw $ErrorMessage + " " + $StatusDescription + " ClientID: $ClientID, GrantType: $GrantType, DirectoryID: $DirectoryID"
}