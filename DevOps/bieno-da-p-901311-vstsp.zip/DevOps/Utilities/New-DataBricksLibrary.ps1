Param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$parameterFile,
    [Parameter(Mandatory = $True, HelpMessage='Specify a json string for your library install see: https://docs.azuredatabricks.net/api/latest/libraries.html#install')]
    [String]$libraryListJson,
    [Parameter(Mandatory = $True, HelpMessage='Specify the id of an existing cluster')]
    [String]$clusterId
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

$subscriptionId = $parameters.parameters.subscriptionId.value
$tenantId = $parameters.parameters.tenantId.value
$keyVaultName = $parameters.parameters.keyVaultName.value
$region=$parameters.parameters.location.value.Replace(" ", "")

$tokenSecretName = $parameters.parameters.databricksTokenSecretName.value
if (-not $tokenSecretName)
{
    $tokenSecretName = "DatabricksAccessToken"
}
$secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $tokenSecretName -ErrorAction SilentlyContinue
$accessToken = $secret.SecretValueText

$uriBase = "https://$region.azuredatabricks.net/api/2.0"

add-type @"
using System.Net;
using System.Security.Cryptography.X509Certificates;
public class TrustAllCertsPolicy : ICertificatePolicy {
    public bool CheckValidationResult(
        ServicePoint srvPoint, X509Certificate certificate,
        WebRequest request, int certificateProblem) {
        return true;
    }
}
"@
$AllProtocols = [System.Net.SecurityProtocolType]'Ssl3,Tls,Tls11,Tls12'
[System.Net.ServicePointManager]::SecurityProtocol = $AllProtocols
 
function New-Library {
    param( [string]$clsId, [string]$libraryList )
        $uri = "$uriBase/libraries/install"
        $head = @{authorization = "Bearer $accessToken" }
        $body = @"
        {
            "cluster_id": "$clsId",
            "libraries": [
              $libraryList
            ]
          }
"@
    Invoke-RestMethod -Uri $uri -Body $Body -Method 'POST' -Headers $head -ContentType "application/json"
}

New-Library -clsId $clusterId -libraryList $libraryListJson
    
