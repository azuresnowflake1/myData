<#
Service Account : SVC_AUTO_IATECH
Domain :S2
Member Groups Added :  
rSvc-DenyInteractiveLogon

The password will be read from landscape keyvault

nslookup smtp-in.unilever.com
telnet smtp-in.unilever.com  25
telnet bnlwepdcss20001.s2.ms.unilever.com 25
telnet smtp-in.wip.unilever.com 25
#>


$SmtpHost ='smtp-in.wip.unilever.com'
$SmtpPort ='25'
$MailUsername='svc_auto_iatech@unilever.com'
#Read from keyvault
$MailPassword=''

$MailSender='svc_auto_iatech@unilever.com'
$MailRecepients='santosh.gaikwad3@unilever.com'

$mailRecepientsArr = @($MailRecepients.Split(',', [StringSplitOptions]::RemoveEmptyEntries) | ForEach-Object{$_.Trim()});
$mailSecurePassword = ConvertTo-SecureString -String $MailPassword -AsPlainText -Force;
$mailCredential = New-Object System.Management.Automation.PSCredential $MailUsername, $mailSecurePassword;  


$mailSubject='Test mail from SMTP'
$mailBody='Please ignore this message: this is just a SMTP testing'

Send-MailMessage -SmtpServer $SmtpHost -From $MailSender -Subject $mailSubject -Body $mailBody -To $MailRecepientsArr -Port $SmtpPort -Credential $mailCredential -BodyAsHtml -UseSsl;


$SmtpHost ='smtp-in.wip.unilever.com'
$SmtpPort ='25'
$MailUsername='svc_auto_iatech@unilever.com'
#Read from keyvault
$MailPassword=''
$Smtp = New-Object Net.Mail.SmtpClient($SmtpHost,$SmtpPort)
$Smtp.EnableSsl = $true
$to = New-Object System.Net.Mail.MailAddress("santosh.gaikwad3@domain.com")
$from = New-Object System.Net.Mail.MailAddress("svc_auto_iatech@unilever.com")
$msg = New-Object System.Net.Mail.MailMessage($from, $to)
$msg.subject = "test"
$msg.body = "testing"
$smtp.host = "smtp-in.unilever.com"
$Smtp.Credentials = New-Object System.Net.NetworkCredential($MailUsername,$MailPassword)
$smtp.send($msg)


