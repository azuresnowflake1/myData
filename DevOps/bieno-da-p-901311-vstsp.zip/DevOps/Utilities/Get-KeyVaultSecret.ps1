Param
(
    [Parameter(Mandatory = $True, HelpMessage = 'Specify the parameter file')]
    [String]$parameterFile,

    [String]$secretName,

    [Parameter(Mandatory = $False, HelpMessage = 'Specify to create the certificate file')]
    [Switch]$Certificate,

    [Parameter(Mandatory = $False, HelpMessage = 'Specify to search in landscape''s key vault')]
    [Switch]$landscape
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile
if ($landscape) {
    $keyVaultName = $parameters.parameters.landscapeKeyVaultName.value
} else {
    
    $keyVaultName = $parameters.parameters.keyVaultName.value
}

Write-Verbose "KeyVault Name $keyVaultName"

function Get-Secret {
    Param
    (
        [String]$name
    )
    try {
        $secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $name -ErrorAction Stop
        return $secret
    }
    catch {
        Write-Error "Failed to get secret named '$name' from key vault $keyVaultName"
        throw $_
    }
}
$secret = Get-Secret -name $secretName

if ($secret -and $Certificate){
    $certificateByteArray = [System.Convert]::FromBase64String($secret.SecretValueText)
    $applicationIdentityCertificatePasswordName = "{0}-Password" -f $secretName
    $certificatePassword = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $applicationIdentityCertificatePasswordName
    $certificatePFX = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2($certificateByteArray, $certificatePassword.SecretValueText, [System.Security.Cryptography.X509Certificates.X509KeyStorageFlags]::Exportable)
    $filePath = "C:\temp\{0}.pfx" -f $secretName
    Export-PfxCertificate -Cert $certificatePFX -FilePath $filePath -Password $certificatePassword.SecretValue -Force
}
return $secret