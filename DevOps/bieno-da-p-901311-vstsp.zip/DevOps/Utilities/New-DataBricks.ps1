Param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$parameterFile,
    [Parameter(Mandatory = $False, HelpMessage='Specify the databrick ARM template file')]
    [String]$ARMTemplateFile='databricks.json'
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"
$managerFolder = "{0}\{1}" -f $devOpsProjectFolder, "LandscapeManager"
$runbookFolder = "{0}\{1}" -f $managerFolder, "RunBooks"

& "$runbookFolder\Import-DatabricksCore.ps1"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

# convert the tag values into a hash table
$tagValues = @{}
$parameters.parameters.tagValues.value.psobject.properties | ForEach-Object { $tagValues[$_.Name.Replace("tag", "")] = $_.Value }

# Create a basic DataBricks workspace
$workspaceName = $parameters.parameters.databricksWorkspaceName.value
$pricingTier = $parameters.parameters.databricksPricingTier.value
$region=$parameters.parameters.location.value.Replace(" ", "")
$keyVaultName = $parameters.parameters.keyVaultName.value
$resourceGroupName = $parameters.parameters.databricksResourceGroupName.value 
$contributor = $parameters.parameters.appContributorGroupId.value
$testers = $parameters.parameters.testerADGroupId.value
$databricksResourceUri = "2ff814a6-3304-4ab8-85cb-cd0e6f879c1d" 
$managementResourceUri = "https://management.core.windows.net/"

$subscriptionId = $parameters.parameters.subscriptionId.value
$armTemplate = "$devOpsProjectFolder\Templates\$ARMTemplateFile"
$deployment = New-AzResourceGroupDeployment -WorkspaceName $workspaceName -TemplateFile $armTemplate `
-ResourceGroupName $resourceGroupName -pricingTier $pricingTier 

$databricksToken = & "$managerFolder\Get-oAuthToken.ps1" -parameterFile $parameterFile -resourceUri $databricksResourceUri
$managementToken = & "$managerFolder\Get-oAuthToken.ps1" -parameterFile $parameterFile -resourceUri $managementResourceUri

$databricksId = (Get-AzResource -ResourceGroupName $resourceGroupName -Name $workspaceName).ResourceId

$uri = "https://management.azure.com/subscriptions/$($subscriptionId)/resourceGroups/$($resourceGroupName)/providers/Microsoft.Databricks/workspaces/$($workspaceName)?api-version=2018-04-01"

& "$utilitiesFolder\Add-DatabricksTokenToKeyVlt.ps1" -parameterFile $parameterFile -force

$tokenSecretName = $parameters.parameters.databricksTokenSecretName.value
if (-not $tokenSecretName)
{
   $tokenSecretName = "DatabricksAccessToken"
}
$secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $tokenSecretName -ErrorAction SilentlyContinue
$accessToken = $secret.SecretValueText

$uriBase = "https://$region.azuredatabricks.net/api/2.0"


#databricks backed keyvault
& "$utilitiesFolder\New-DataBricksKeyVault.ps1" -parameterFile $parameterFile
& "$utilitiesFolder\New-DatabricksInitialise.ps1" -parameterFile $parameterFile 


if ($parameters.parameters.ProjectEnvironment.value -eq "d") {
    # Forced to do this too so the tester group can use the Tester cluster in dev
    & "$utilitiesFolder\New-RoleAssignment.ps1" -parameterFile $parameterFile -roleName "Reader" -granteeObjectId $testers -dataBricks
}

& "$utilitiesFolder\New-DataBricksKeyVault.ps1" -parameterFile $parameterFile -removeKeyVault
