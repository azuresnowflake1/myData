[CmdletBinding()]
Param(
    [Parameter(Mandatory = $true, Position = 1)] [string] $parameterFile,
    [Parameter(Mandatory = $True, Position = 2)] [string] $bearerToken,
    [Parameter(Mandatory = $False, Position = 3)] [string] $filesystemName="unilever"
)
# Rest documentation:
# https://docs.microsoft.com/en-us/rest/api/storageservices/datalakestoragegen2/path/list

# search for a file system by name and if found return it else return null
$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile
$method = "GET"

$headers = @{ } 
$headers.Add("x-ms-version", "2018-11-09")
$headers.Add("Authorization", "Bearer $BearerToken")

$URI = "https://$($parameters.parameters.adlStoreName.value).dfs.core.windows.net/?resource=account"

try {
    $response = Invoke-RestMethod -method $method -Uri $URI -Headers $headers
    if ($response -and $response.fileSystems) {
        foreach($fileSystem in $response.fileSystems) {
            if ($fileSystem.name -eq $filesystemName) {
                return $fileSystem
            }
        }

    } else { return $null }
    return $null
}
catch {
    $ErrorMessage = $_.Exception.Message
    $StatusDescription = $_.Exception.Response.StatusDescription

    Throw $ErrorMessage + " " + $StatusDescription + " FileSystemName: $filesystemName"
}