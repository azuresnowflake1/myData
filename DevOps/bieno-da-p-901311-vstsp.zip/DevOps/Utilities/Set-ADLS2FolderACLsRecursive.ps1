# Use this to set ACLs on large numbers of folders and files recursively
# Runs quickly because the processing runs batches in parallel
[CmdletBinding(DefaultParameterSetName = 'Merge')]
param(
    [Parameter(Mandatory = $True, HelpMessage = 'Specify the parameter file name')]
    [String]$parameterFile,
    [Parameter(Mandatory = $True, HelpMessage = 'The new ACLs you want to set. Create this array using Set-AzDataLakeGen2ItemAclObject')]
    [Microsoft.WindowsAzure.Commands.Storage.Model.ResourceModel.PSPathAccessControlEntry[]]$acls,
    [Parameter(Mandatory = $True, HelpMessage = 'Specify to merge ACLs into each file system object''s existing ACL.', ParameterSetName = "Merge")]
    [switch]$merge,
    [Parameter(Mandatory = $True, HelpMessage = 'Specify to replace existing ACLs with the ones you specify.', ParameterSetName = "Replace")]
    [switch]$replace,
    [Parameter(Mandatory = $True, HelpMessage = 'Specify to remove entity specific ACLs from existing ACL.', ParameterSetName = "Delete")]
    [switch]$delete,
    [Parameter(Mandatory = $False, HelpMessage = 'Specify the name of the ADLS gen2 container')]
    [String]$container = "unilever",
    [Parameter(Mandatory = $False, HelpMessage = 'The path from which to ecurively set permissions.  Leave blank for the container root')]
    [String]$rootPath = ""
)

$scriptRootPath = (Get-Item -Path $PSScriptRoot).Parent.Parent.FullName
$devOpsProjectFolder = "{0}\{1}" -f $scriptRootPath, "DevOps"
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

if ($acls.Count -eq 0) {
    throw "You must pass in at least one ACL entry."
}
if ((Get-AzContext).Subscription.Id -ne $parameters.parameters.subscriptionId.value) {
    Set-AzContext -subscription $parameters.parameters.subscriptionId.value
}
# Parameters
# For token authN & authZ
# Identify location to apply ACL update from
$accountName = $parameters.parameters.adlStoreName.value

# Number of parallel runspaces to execute this operation
$numRunspaces = 100
# This should always be $true. Set to $false to make the whole operation run single-threaded
$useRunspaces = $true
# Max # of items per parallel batch
$maxItemsPerBatch = 500

# Convert ACL into rwx
$aclAction = @{
    7 = "rwx"
    6 = "rw-"
    5 = "r-x"
    4 = "r--"
    3 = "-wx"
    2 = "-w-"
    1 = "--x"
    0 = "---"
}
# Accumulate processing stats (thread safe counters)
$itemsStats = @{
    itemsProcessed = New-Object System.Threading.SemaphoreSlim -ArgumentList @(0)
    itemsUpdated   = New-Object System.Threading.SemaphoreSlim -ArgumentList @(0)
    itemsErrors    = New-Object System.Threading.SemaphoreSlim -ArgumentList @(0)
}
$oldProgressPreference = $Global:ProgressPreference
$Global:ProgressPreference = "SilentlyContinue"
$ctx = New-AzStorageContext -StorageAccountName $accountName -UseConnectedAccount

# Clone the specified acl so we can construct a file friendly version
# We don't want to grant x on file objects
$objectIds = [System.Collections.ArrayList]@()
$fileAcls = $null
foreach ($acl in $acls) {
    if ($acl.EntityId) {
        $objectIds.Add($acl.EntityId) | Out-Null
    }
    switch ([int]$acl.Permissions) {
        7 { $rwx = $aclAction[[int]$acl.Permissions - 1]; break }
        5 { $rwx = $aclAction[[int]$acl.Permissions - 1]; break }
        3 { $rwx = $aclAction[[int]$acl.Permissions - 1]; break }
        1 { $rwx = $aclAction[[int]$acl.Permissions - 1]; break }
        default { $rwx = $aclAction[[int]$acl.Permissions]; }
    }
    $aclParams = @{
        EntityId          = $acl.EntityId
        Permission        = $rwx
        AccessControlType = $acl.AccessControlType
        DefaultScope      = $false
    }
    if ($fileAcls) {
        $aclParams.InputObject = $fileAcls
    }
    $fileAcls = Set-AzDataLakeGen2ItemAclObject @aclParams
}
if ($merge) {
    # convert permissions to string to rwx so they can be merged at item level
    foreach ($fileAcl in $fileAcls) {
        Add-Member -InputObject $fileAcl -TypeName "string" -NotePropertyName "PermissionRWX" -NotePropertyValue $aclAction[[int]$fileAcl.Permissions]
    }
    foreach ($acl in $acls) {
        Add-Member -InputObject $acl -TypeName "string" -NotePropertyName "PermissionRWX" -NotePropertyValue $aclAction[[int]$acl.Permissions]
    }
} 

if ($objectIds.Count -eq 0 -and $delete) {
    throw "Invalid ACL delete request.  The ACL supplied doesn't include any permissions for an AD principal and so the net result of processing it is null.  There's no point!"
}
# Parameters shared across all workers
$itemParams = @{
    context   = $ctx
    container = $container
    ACL       = $acls
    FileACL   = $fileAcls
    merge     = $merge
    replace   = $replace
    delete    = $delete
    EntityIds = $objectIds
}

# Worker script block
$scriptBlock = {
    Param ($items, $sharedParams)

    $Global:ProgressPreference = "SilentlyContinue"
    $items | ForEach-Object {
        #$host.UI.WriteDebugLine("Processing: " + $_.name)
        $itemsStats.itemsProcessed.Release() | Out-Null
        $item = $_
        $newACL = $sharedParams.ACL
        try {
            $adlsParams = @{
                Context    = $sharedParams.context
                FileSystem = $sharedParams.container
            }
            if ($_.File) {
                # We are setting ACLs on a file
                $adlsParams["Path"] = $item.File.Path
                $newACL = $sharedParams.FileACL
            }
            elseif ($item.isDirectory -and $item.Name) {
                # We are setting ACLs on a directory
                $adlsParams["Path"] = $item.Directory.Path
            }
            if ($sharedParams.merge) {
                # Merge the new ACL entries into the existing item's ACL
                try {
                    foreach ($acl in $newACL) {
                        if (-not $acl.DefaultScope) {
                            $item.ACL = Set-AzDataLakeGen2ItemAclObject -AccessControlType $acl.AccessControlType -EntityID $acl.EntityId -Permission $acl.PermissionRWX -InputObject $item.ACL
                        }
                        elseif (-not $item.File) {
                            # Ok to set a default perm on a directory or the root
                            $item.ACL = Set-AzDataLakeGen2ItemAclObject -AccessControlType $acl.AccessControlType -EntityID $acl.EntityId -Permission $acl.PermissionRWX -DefaultScope -InputObject $item.ACL
                        }
                        else {
                            # ignore. Can't set a default permissions on a file
                        }
                    }
                    $adlsParams["Acl"] = $item.ACL
                    Update-AzDataLakeGen2Item @adlsParams
                }
                catch {
                    $host.UI.WriteErrorLine("Failed to merge ACL for $($item.name). This object will be skipped. Details: " + $_)
                    $itemsStats.itemsErrors.Release()
                }
            }
            elseif ($sharedParams.replace) {
                $host.UI.WriteDebugLine("Replacing ACL for: $($_.name)")
                try {
                    $adlsParams["Acl"] = $newACL
                    Update-AzDataLakeGen2Item @adlsParams
                    $itemsStats.itemsUpdated.Release()
                }
                catch {
                    $host.UI.WriteErrorLine("Failed to replace ACL for $($item.name). Details: " + $_)
                    $itemsStats.itemsErrors.Release()
                }
            }
            elseif ($sharedParams.delete) {
                # We only support removal of ACLs permissions where the object id (entity Id) is specified
                $newACLs = [System.Collections.ArrayList]@()
                foreach ($acl in $item.ACL) {
                    if (-not $acl.EntityId -or -not $sharedParams.EntityIds.Contains($acl.EntityId)) {
                        $newACLs.Add($acl) | Out-Null
                    }
                }
                $adlsParams["Acl"] = $newACLs
                Update-AzDataLakeGen2Item @adlsParams | Out-Null
            }
        }
        catch {
            $host.UI.WriteErrorLine("Unknown failure processing $($item.name). Details: " + $_)
            $itemsStats.itemsErrors.Release()
        }
    }
}
# Setup our Runspace Pool
if ($useRunspaces) {
    $sessionState = [System.Management.Automation.Runspaces.InitialSessionState]::CreateDefault()
    $sessionState.ThreadOptions = [System.Management.Automation.Runspaces.PSThreadOptions]::UseNewThread
    # Marshall variables & functions over to the RunspacePool
    $sessionState.Variables.Add((New-Object -TypeName System.Management.Automation.Runspaces.SessionStateVariableEntry -ArgumentList 'itemsStats', $itemsStats, ""))
    $runspacePool = [RunspaceFactory]::CreateRunspacePool(1, $numRunspaces, $sessionState, $Host)
    $runspacePool.Open()
}
$runSpaces = [System.Collections.ArrayList]@()

# Loop through the entire listing until we've processed all files & directories
$continuationToken = $null
$rootParams = @{
    Context     = $ctx
    FileSystem  = $container
    ErrorAction = "Stop"
}
if ($rootPath -and $rootPath -ne "/" -and $rootPath -ne "\") {
    # We are not setting ACLs at root container level.  i.e. a directory was passed
    $rootParams["Path"] = $rootPath
}
$item = Get-AzDataLakeGen2Item @rootParams
$rootParams["Recurse"] = $true
$rootParams["FetchProperty"] = $true
$rootParams["MaxCount"] = $maxItemsPerBatch
do {
    try {
        if ($continuationToken) {
            $rootParams["ContinuationToken"] = $continuationToken
        }
        $items = Get-AzDataLakeGen2ChildItem @rootParams
        if ($item) {
            $items = ,$item + $items
            $item = $null
        }
        if ($items.Length -le 0) { 
            Break
        }
        $continuationToken = $items[$items.Length - 1].ContinuationToken;
        if ($useRunspaces) {
            # Dispatch this list to a new runspace
            $ps = [powershell]::Create().
            AddScript($scriptBlock).
            AddArgument($items).
            AddArgument($itemParams)
            $ps.RunspacePool = $runspacePool
            $runSpace = New-Object -TypeName psobject -Property @{
                PowerShell = $ps
                Handle     = $($ps.BeginInvoke())
            }
            $runSpaces.Add($runSpace) | Out-Null
        }
        else {
            Invoke-Command -ScriptBlock $scriptBlock -ArgumentList @($items, $itemParams)
        }
    }
    catch {
        $host.UI.WriteErrorLine("Failed to list directories and files. Details: " + $_)
    }
} while ($continuationToken)

# Cleanup
$host.UI.WriteLine("Waiting for completion & cleaning up")
while ($runSpaces.Count -gt 0) {
    $idx = [System.Threading.WaitHandle]::WaitAny($($runSpaces | Select-Object -First 64 | ForEach-Object { $_.Handle.AsyncWaitHandle }))
    $runSpace = $runSpaces.Item($idx)
    $runSpace.PowerShell.EndInvoke($runSpace.Handle) | Out-Null
    $runSpace.PowerShell.Dispose()
    $runSpaces.RemoveAt($idx)
}
$Global:ProgressPreference = $oldProgressPreference
$host.UI.WriteLine("Completed. Items processed: $($itemsStats.itemsProcessed.CurrentCount), items updated: $($itemsStats.itemsUpdated.CurrentCount), errors: $($itemsStats.itemsErrors.CurrentCount)")
