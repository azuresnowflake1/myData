Param
(
    [Parameter(Mandatory = $True, HelpMessage = 'Specify the parameter file')]
    [String]$parameterFile,
    [Parameter(Mandatory = $False, HelpMessage = 'Specify whether to create Sql API connection')]
    [switch]$SqlDb,
    [Parameter(Mandatory = $False, HelpMessage = 'Specify whether to create Sql DW API connection')]
    [switch]$SqlDW,
    [Parameter(Mandatory = $False, HelpMessage = 'Specify whether to create log analytics API connection')]
    [switch]$LogAnalytics,
    [Parameter(Mandatory = $False, HelpMessage = 'Specify whether to create data lake API connection')]
    [switch]$ADLStoreGen1, 
    [Parameter(Mandatory = $False, HelpMessage = 'Specify whether to create ADLS Gen 2 API connection')]
    [switch]$ADLStore,
    [Parameter(Mandatory = $False, HelpMessage = 'Set RBAC permissions on connectors. Only need to do this once')]
    [switch]$Permissions
)
# Deploy logic app using the ARM template published to git.
$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$armFolder = Join-Path -Path $devOpsProjectFolder -ChildPath "Templates"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

$templateFilePath = Join-Path -Path $armFolder -ChildPath "logicapp.template.json"

$logicAppParameters = Get-Content -Path $templateFilePath -Raw | ConvertFrom-JSON

$logicAppResourceGroupName = $parameters.parameters.logicAppResourceGroupName.value
$logicAppName = $parameters.parameters.logicAppName.value
$keyVaultName = $parameters.parameters.keyVaultName.value
$adApplicationName = $parameters.parameters.adApplicationName.value
$logicAppDeploymentName = $parameters.parameters.logicAppName.value + "_depl"
$sql_server = $parameters.parameters.sqlServerName.value + ".database.windows.net"
$params = @{}

#o365 connection parameters
$logicAppO365apiConnection = $parameters.parameters.logicAppO365apiConnection.value
$office365_displayName = "someone@example.com"
$params.Add("logicAppO365apiConnection", $logicAppO365apiConnection)
$params.Add("office365_displayName", $office365_displayName)

#SQL DW connection parameters
$sqldwResource = Get-AzResource -Name $parameters.parameters.sqlDataWarehouseName.value

$logicAppSqlDWapiConnectionUser = $parameters.parameters.logicAppSqlUserLogin.value
$logicAppSqlDWapiConnection = $parameters.parameters.logicAppSqlDWapiConnection.value
$logicAppSqlDWapiConnectionDisplay = $parameters.parameters.logicAppSqlDWapiConnectionDisplay.value
$sqldw_database = $parameters.parameters.sqlDataWarehouseName.value 

$params.Add("logicAppSqlDWapiConnection", $logicAppSqlDWapiConnection)
$params.Add("logicAppSqlDWapiConnectionDisplay", $logicAppSqlDWapiConnectionDisplay)
$params.Add("sqldw_server", $sql_server)
$params.Add("sqldw_database", $sqldw_database)  
if ($SqlDW -or $sqldwResource) {
    
    $logicAppSqlDWapiConnectionUserValue = ConvertTo-SecureString $logicAppSqlDWapiConnectionUser -AsPlainText -Force
   
    & "$utilitiesFolder\New-SqlUserWithRole.ps1" -parameterFile $parameterFile -SqlUserName $parameters.parameters.logicAppSqlUserLogin.value -DbRole db_datareader

    $sqlUserPasword = Get-AzKeyVaultSecret -VaultName $parameters.parameters.keyvaultname.value -Name $parameters.parameters.logicAppSqlUserLogin.value    
   
    $params.Add("sqldw_username", $logicAppSqlDWapiConnectionUserValue)
    $params.Add("sqldw_password", $sqlUserPasword.SecretValue)
    
    $params.Add("createSqlDwConnection", $true)
}

#Data lake connection parameters
$adlsResource = Get-AzResource -Name $parameters.parameters.adlStoreNameGen1.value
$logicAppDatalakeapiConnection = $parameters.parameters.logicAppDatalakeapiConnection.value
$logicAppDatalakeapiConnectionDisplay = $parameters.parameters.logicAppDatalakeapiConnectionDisplay.value
$azuredatalake_token_clientId = $parameters.parameters.applicationId.value
$azuredatalake_token_tenantId = $parameters.parameters.tenantId.value
$azuredatalake_token_resourceUri = "https://management.core.windows.net/"

$params.Add("logicAppDatalakeapiConnection", $logicAppDatalakeapiConnection)
$params.Add("logicAppDatalakeapiConnectionDisplay", $logicAppDatalakeapiConnectionDisplay)
$params.Add("azuredatalake_token_clientId", $azuredatalake_token_clientId)
$params.Add("azuredatalake_token_TenantId", $azuredatalake_token_tenantId)
$params.Add("azuredatalake_token_resourceUri", $azuredatalake_token_resourceUri)

if ($ADLStoreGen1 -or $adlsResource) {   
    $secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $adApplicationName
    $secretValue = $secret.SecretValueText

    $azuredatalake_token_clientSecret = ConvertTo-SecureString -String $secretValue -AsPlainText -Force
    $params.Add("azuredatalake_token_clientSecret", $azuredatalake_token_clientSecret)      
    $params.Add("createDatalakeConnection", $true)
}

#ADLS Gen2 connection parameters
$adlsGen2Resource = Get-AzResource -Name $parameters.parameters.adlStoreName.value
$apiconnection_adlsgen2_name = $parameters.parameters.apiconnection_adlsgen2_name.value
$apiconnection_adlsgen2_accountName = $parameters.parameters.adlStoreName.value
$params.Add("apiconnection_adlsgen2_name", $apiconnection_adlsgen2_name)
$params.Add("apiconnection_adlsgen2_accountName", $apiconnection_adlsgen2_accountName)
$params.Add("apiconnection-adlsgen2_resourceGroupName", $parameters.parameters.adlStoreResourceGroupName.value)
if ($ADLStore -or $adlsGen2Resource) {
    $params.Add("createADLSGen2Connection", $true)
}

#Monitor Logs connection parameters
$logAnalyticsResource = Get-AzResource -Name $parameters.parameters.logAnalyticsWorkspaceName.value
$azuremonitorlogs_name = $parameters.parameters.azuremonitorlogs_name.value
$azuremonitorlogs_displayName = $parameters.parameters.azuremonitorlogs_displayName.value
$azuremonitorlogs_token_TenantId = $parameters.parameters.tenantId.value
$azuremonitorlogs_token_resourceUri = "https://management.core.windows.net/"
$params.Add("azuremonitorlogs_name", $azuremonitorlogs_name)
$params.Add("azuremonitorlogs_displayName", $azuremonitorlogs_displayName) 
$params.Add("azuremonitorlogs_token_TenantId", $azuremonitorlogs_token_TenantId)
$params.Add("azuremonitorlogs_token_resourceUri", $azuremonitorlogs_token_resourceUri)

if ($LogAnalytics -or $logAnalyticsResource) {
    $projectEnvironment = $parameters.parameters.projectEnvironment.value
    if ($projectEnvironment -ne "d" ) {             
        $azuremonitorlogs_token_clientId = $parameters.parameters.applicationId.value
    }
    else {
        $keyVaultName = $parameters.parameters.landscapeKeyVaultName.value
        $adApplicationName = $parameters.parameters.deploymentAdApplicationName.value            
        $azuremonitorlogs_token_clientId = $parameters.parameters.deploymentApplicationId.value
    }
    
    $secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $adApplicationName
    $applicationId_token_clientSecret = $secret.SecretValueText
    $azuremonitorlogs_token_clientSecret = ConvertTo-SecureString -String $applicationId_token_clientSecret -AsPlainText -Force
    
    $params.Add("azuremonitorlogs_token_clientId", $azuremonitorlogs_token_clientId)
    $params.Add("azuremonitorlogs_token_clientSecret", $azuremonitorlogs_token_clientSecret) 
    $params.Add("createMonitorLogsConnection", $true)   
}

#SQL connection parameters
$sqlResource = Get-AzResource -Name $parameters.parameters.sqlDatabaseName.value

$logicAppSqlapiConnectionUser = $parameters.parameters.logicAppSqlUserLogin.value
$logicAppSqlapiConnection = $parameters.parameters.logicAppSqlapiConnection.value
$logicAppSqlapiConnectionDisplay = $parameters.parameters.logicAppSqlapiConnectionDisplay.value
$sqldb_sqlConnectionString = "Server=tcp:{0}.database.windows.net,1433;Initial Catalog={1};Persist Security Info=False;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;" -f $parameters.parameters.sqlServerName.value, $parameters.parameters.sqlDatabaseName.value
$sql_database = $parameters.parameters.sqlDatabaseName.value 

$params.Add("logicAppSqlapiConnection", $logicAppSqlapiConnection)
$params.Add("logicAppSqlapiConnectionDisplay", $logicAppSqlapiConnectionDisplay)
$params.Add("sql_server", $sql_server)
$params.Add("sql_database", $sql_database)  	
$params.Add("sqldb_sqlConnectionString", $sqldb_sqlConnectionString)
if ($SqlDb -or $sqlResource) {
    
    $logicAppSqlapiConnectionUserValue = ConvertTo-SecureString $logicAppSqlapiConnectionUser -AsPlainText -Force
       
    & "$utilitiesFolder\New-SqlUserWithRole.ps1" -parameterFile $parameterFile -SqlUserName $parameters.parameters.logicAppSqlUserLogin.value -DbRole db_datareader -SqlDb
    
    $sqlUserPasword = Get-AzKeyVaultSecret -VaultName $parameters.parameters.keyvaultname.value -Name $parameters.parameters.logicAppSqlUserLogin.value
   
    $params.Add("sql_username", $logicAppSqlapiConnectionUserValue)
    $params.Add("sql_password", $sqlUserPasword.SecretValue)
   
    $params.Add("createSqlConnection", $true)
}

$params.Add("logicAppName", $logicAppName)
$params.Add("logicAppLocation", $parameters.parameters.location.value)



$armTemplateParameters = $logicAppParameters.parameters  | Get-Member -MemberType Properties | Select-Object

ForEach ($property in $armTemplateParameters) {
    if (-not $params[$property.Name]) {
        $params[$property.Name] = ($logicAppParameters.parameters).($property.Name).DefaultValue 
    } 
}

New-AzResourceGroupDeployment `
    -Name $logicAppDeploymentName `
    -ResourceGroupName  $logicAppResourceGroupName `
    -TemplateFile  $templateFilePath `
    -TemplateParameterObject $params

if ($Permissions) {           
    if ($parameters.parameters.projectEnvironment.value -eq "d" ) {
        $granteeObjectId = $parameters.parameters.appContributorGroupId.value
    }
    else {
        $granteeObjectId = $parameters.parameters.appReaderGroupId.value
    }

    #Logic App permissions
    if ($parameters.parameters.projectEnvironment.value -eq "d" ) {
        & "$utilitiesFolder\New-RoleAssignment.ps1" -parameterFile $parameterFile -roleName "Logic App Contributor" -granteeObjectId $granteeObjectId -LogicApp    
        
    }
    else {
        & "$utilitiesFolder\New-RoleAssignment.ps1" -parameterFile $parameterFile -roleName "Logic App Operator" -granteeObjectId $granteeObjectId -LogicApp            
    }

    #O365 connector permissions
    if ($parameters.parameters.projectEnvironment.value -eq "d" ) {
        & "$utilitiesFolder\New-RoleAssignment.ps1" -parameterFile $parameterFile -roleName "Contributor" -granteeObjectId $granteeObjectId -logicAppO365apiConnection
    }
    else {
        if ($parameters.parameters.projectEnvironment.value -eq "q") {
            & "$utilitiesFolder\New-RoleAssignment.ps1" -parameterFile $parameterFile -roleName "Contributor" -granteeObjectId $granteeObjectId -logicAppO365apiConnection        
        }
        else {
            $granteeObjectId = $parameters.parameters.supportADGroupId.value
            & "$utilitiesFolder\New-RoleAssignment.ps1" -parameterFile $parameterFile -roleName "Contributor" -granteeObjectId $granteeObjectId -logicAppO365apiConnection                        
        }
    }
 
    #SQLDW connector permissions
    if ($SqlDW -or $sqldwResource) {
        if ($parameters.parameters.projectEnvironment.value -eq "d" ) {
            & "$utilitiesFolder\New-RoleAssignment.ps1" -parameterFile $parameterFile -roleName "Contributor" -granteeObjectId $granteeObjectId -logicAppSqlDWapiConnection
        }
    }

    #Datalake connector permissions
    if ($ADLStoreGen1 -or $adlsResource) {
        if ($parameters.parameters.projectEnvironment.value -eq "d" ) {
            & "$utilitiesFolder\New-RoleAssignment.ps1" -parameterFile $parameterFile -roleName "Contributor" -granteeObjectId $granteeObjectId -logicAppDatalakeapiConnection
        }
    }

    #ADLS Gen2 connector permissions
    if ($ADLStore -or $adlsGen2Resource) {
        if ($parameters.parameters.projectEnvironment.value -eq "d" ) {
            & "$utilitiesFolder\New-RoleAssignment.ps1" -parameterFile $parameterFile -roleName "Contributor" -granteeObjectId $granteeObjectId -logicAppadlsgen2apiConnection
        }
    }

    #Log Analytics connector permissions
    if ($LogAnalytics -or $logAnalyticsResource) {
        if ($parameters.parameters.projectEnvironment.value -ne "d" ) {
            $granteeObjectId = $parameters.parameters.servicePrincipalId.value
            Write-Verbose "granteeObjectId $granteeObjectId"
            & "$utilitiesFolder\New-RoleAssignment.ps1" -parameterFile $parameterFile -roleName "Log Analytics Reader" -granteeObjectId $granteeObjectId -LogAnalytics
            & "$utilitiesFolder\New-RoleAssignment.ps1" -parameterFile $parameterFile -roleName "Contributor" -granteeObjectId $granteeObjectId -logicAppMonitorLogapiConnection
        }
    }

    #SQLDW connector permissions
    if ($SqlDb -or $sqldwResource) {
        if ($parameters.parameters.projectEnvironment.value -eq "d" ) {
            & "$utilitiesFolder\New-RoleAssignment.ps1" -parameterFile $parameterFile -roleName "Contributor" -granteeObjectId $granteeObjectId -logicAppSqlapiConnection
        }
    }
}
