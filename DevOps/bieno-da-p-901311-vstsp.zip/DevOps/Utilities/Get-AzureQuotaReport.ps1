Param
(
    [Parameter(Mandatory = $True, HelpMessage = 'Specify the parameter file')]
    [String]$parameterFile
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

$subscriptionId = $parameters.parameters.subscriptionId.value
Select-AzSubscription -SubscriptionId $subscriptionId | Out-Null


# A simple script to return the number of Data Factories / Data Lakes , Azure SQL Servers and Azure Batch within a Subscription
# Soft Lmits can be accessed at https://docs.microsoft.com/en-us/azure/azure-subscription-service-limits and the variable updatd to reflect
# This is a very basic script to show how it could be achieved, clearly more advanced scripting would be required if you wished to automate and productionise in some way.
$tmp = New-TemporaryFile
& "$utilitiesFolder\Get-AzureQuota" -parameterFile $parameterFile | Out-File -FilePath $tmp.FullName -Force
& "$utilitiesFolder\Get-AzureQuotaProd2" -parameterFile $parameterFile | Out-File -FilePath $tmp.FullName -Append

#Copy the file to BLOB 56731
$useResourceGroupName = "bieno-da-d-56731-stg-rg";
$storageAccountName = "043bienobrunilevercomstg";
$containerName = "azurequota";
Select-AzSubscription -SubscriptionName "PROD" | Out-Null
$accountKeys = Get-AzStorageAccountKey -ResourceGroupName $useResourceGroupName -Name $storageAccountName
$storageContext = New-AzStorageContext -StorageAccountName $storageAccountName -StorageAccountKey $accountKeys[0].Value 

# Copy the parameter file for current env into the source folder.  We want to deploy it as parameters.json
Set-AzStorageBlobContent -File $tmp.FullName -Container $ContainerName -Blob "AzureQuotaReport.txt" -Context $storageContext -Force
