Param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$parameterFile,
    [PSCustomObject]$logAnalyticsWorkspace,
    [switch]$removeKeyVault
)
# Create a databricks backed key vault for use at runtime by ADB scripts
# We only add secrets that are required at runtime
$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

$applicationId = $parameters.parameters.applicationId.value
$keyVaultName = $parameters.parameters.keyVaultName.value
$storageAccountResourceGroupName = $parameters.parameters.storageAccountResourceGroupName.value
$region=$parameters.parameters.location.value.Replace(" ", "")

#$tokenSecretName = $parameters.parameters.databricksTokenSecretName.value
#if (-not $tokenSecretName)
#{
#    $tokenSecretName = "DatabricksAccessToken"
#}
#$secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $tokenSecretName -ErrorAction SilentlyContinue
#$accessToken = $secret.SecretValueText

#$uriBase = "https://$region.azuredatabricks.net/api/2.0"

if (-not(Adb-Get-SecretScope)){
    Adb-New-SecretScope
}

$adApplicationName =  $parameters.parameters.adApplicationName.value
$storageAccountName = $parameters.parameters.storageAccountName.value

$secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $adApplicationName
$adClientSecret = $secret.SecretValueText

$secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $storageAccountName
$StorageSecret = $secret.SecretValueText

Adb-Add-Secret -scopeName "Landscape" -secretName $adApplicationName -secretValue $adClientSecret 
Adb-Add-Secret -scopeName "Landscape" -secretName $storageAccountName -secretValue $StorageSecret 


if ($removeKeyVault) {
    Adb-Remove-SecretScope -scopeName "Landscape" 
    Write-Output "Databricks KeyVault removed"
}

if ($logAnalyticsWorkspace) {
    Adb-New-SecretScope -scopeName "ProjectKeyVault" 
    Adb-Add-Secret -secretName "USR-LogAnalyticsWorkspaceAppId" -secretValue $workSpaces.CustomerId 
    $keys = Get-AzOperationalInsightsWorkspaceSharedKey -ResourceGroupName $storageAccountResourceGroupName -Name $logAnalyticsWorkspace.Name
    if ($keys) {
        Adb-Add-Secret -scopeName "ProjectKeyVault" -secretName "KEY-LogAnalyticsWorkspaceAppKey" -secretValue $keys.PrimarySharedKey 
    }
}
