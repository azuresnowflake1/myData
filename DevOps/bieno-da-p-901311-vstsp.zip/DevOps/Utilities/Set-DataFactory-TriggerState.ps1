Param
(
    [Parameter(Mandatory = $True, HelpMessage = 'Specify the parameter file')]
    [String]$parameterFile,
    
    [Parameter(Mandatory = $False, HelpMessage = 'Specify the parameter file')]
    [String]$overrideFile,

	[Parameter(Mandatory = $False, HelpMessage = 'Specify to disable the triggers')]
	[switch]$disableTriggers
	
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"
$rootPath = (Get-Item -Path $devOpsProjectFolder).Parent.FullName


if ($overrideFile) {
	$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile -overrideFile $overrideFile
} else {
	$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile
}

$dataFactoryResourceGroupName = $parameters.parameters.dataFactoryResourceGroupName.value 
$dataFactoryName = $parameters.parameters.dataFactoryName.value
$TriggerPath = Join-Path -path $rootPath -childPath "Adf"
$TriggerPath = Join-Path -path $TriggerPath -childPath $dataFactoryName

$df = Get-azDataFactoryV2 -ResourceGroupName $dataFactoryResourceGroupName -Name $dataFactoryName -ErrorAction SilentlyContinue
if (-not $df) {
    Write-Warning "Data Factory does not exist"
    return
}
try{
	if ($disableTriggers) {
		
		Write-Verbose "stopping trigger"
		$TriggerPath = Join-Path -path $TriggerPath -childPath "triggers"
	} else {
		Write-Verbose "starting trigger"
		$TriggerPath = Join-Path -path $TriggerPath -childPath "triggers"
	}
    
    $sourcePath = Get-ChildItem "$TriggerPath\*.csv" -ErrorAction Stop
    if($null -eq $sourcePath){
        Write-Host "no trigger file found in $TriggerPath"
        return
    }
    $triggerdetails=Get-Content -Path $sourcePath
    foreach($trigger in $triggerdetails)
    {
		if($trigger -eq ""){
			continue
		}
		
		if ($disableTriggers) {
			$depl = Stop-AzDataFactoryV2Trigger -ResourceGroupName $dataFactoryResourceGroupName -DataFactoryName $dataFactoryName -Name $trigger -force
		} else {
			$depl = Start-AzDataFactoryV2Trigger -ResourceGroupName $dataFactoryResourceGroupName -DataFactoryName $dataFactoryName -Name $trigger -force
		}
        Write-Host "$depl"
    }
}
catch{
	Write-Error $_
	throw
}
