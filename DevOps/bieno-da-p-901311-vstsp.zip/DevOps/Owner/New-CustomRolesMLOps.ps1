

Write-Host "PSScriptRoot is: $PSScriptRoot"
$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
Write-Host "DevOps Project Folder: $devOpsProjectFolder"
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"
Write-Host "Utilties folder: $utilitiesFolder"


# Sandbox
$subscriptionId = "bc41a9ef-b853-4107-aa12-cc8d592c8e91"
Select-AzSubscription -SubscriptionId $subscriptionId | Out-Null

#
# Configure a custom role to be available on Resource Group level only
function Set-Scope {
    param( [Microsoft.Azure.Commands.Resources.Models.Authorization.PSRoleDefinition]$roleDefinition)

    $roleDefinition.AssignableScopes.Clear();
    $roleDefinition.AssignableScopes.Add("/subscriptions/105fbd8d-388f-4b19-9fda-d56f44121122")
    # Amsterdam 01, 02, 03 & 04
    # $roleDefinition.AssignableScopes.Add("/subscriptions/e2b0e829-5210-40ae-b73f-20805aa01351") #01
    # $roleDefinition.AssignableScopes.Add("/subscriptions/8b4fb847-3b45-410f-a6e7-3247c9d459b7") #02
    # $roleDefinition.AssignableScopes.Add("/subscriptions/43046d94-2b34-46fa-8b8b-4a3a72b53df6") #03
    # $roleDefinition.AssignableScopes.Add("/subscriptions/105fbd8d-388f-4b19-9fda-d56f44121122") #04
    # $roleDefinition.AssignableScopes.Add("/subscriptions/c70cf1d8-50bd-486d-b921-b910ffb03a70") #16
    # $roleDefinition.AssignableScopes.Add("/subscriptions/65c24fb4-4567-43b8-a31f-d06f8f1d0dd7") #13
    # $roleDefinition.AssignableScopes.Add("/subscriptions/8b4fb847-3b45-410f-a6e7-3247c9d459b7")
    #$role.AssignableScopes.Add("/subscriptions/e2b0e829-5210-40ae-b73f-20805aa01351/resourceGroups/*")
    # Amsterdam
    #$role.AssignableScopes.Add("/subscriptions/e2b0e829-5210-40ae-b73f-20805aa01351/resourceGroups/*")
    #$role.AssignableScopes.Add("/subscriptions/8b4fb847-3b45-410f-a6e7-3247c9d459b7/resourceGroups/*")
}
# Write all role assignments to standard out
function Write-RoleActions
{
    param( [string]$name)
    Get-AzRoleDefinition $Name | ConvertTo-Json
}
function Copy-RoleActions {
    param( [Microsoft.Azure.Commands.Resources.Models.Authorization.PSRoleDefinition]$roleDefinition, [string]$roleName)


    # Add actions from the fixed contributor role
    $actions = (Get-AzRoleDefinition $roleName).Actions
    foreach($action in $actions)
    {
        if (-not ($role.Actions.Contains($action))) {
            $role.Actions.Add($action)
        }
    }
    $actions = (Get-AzRoleDefinition $roleName).NotActions
    foreach($action in $actions)
    {
        if (-not ($role.NotActions.Contains($action))) {
            $role.NotActions.Add($action)
        }
    }
    $actions = (Get-AzRoleDefinition $roleName).DataActions
    foreach($action in $actions)
    {
        if (-not ($role.DataActions.Contains($action))) {
            $role.DataActions.Add($action)
        }
    }
    $actions = (Get-AzRoleDefinition $roleName).NotDataActions
    foreach($action in $actions)
    {
        if (-not ($role.NotDataActions.Contains($action))) {
            $role.NotDataActions.Add($action)
        }
    }
}

# Create a custom contributor role that includes actions from Reader plus machine learning actions
# function New-AdminRole {
#     $roleName = "InA Tech DS Admin"
#     $roleDescription = "I&A Tech's custom resource group admin role for data science environments."
#     $role = Get-AzRoleDefinition $roleName
#     if ($role)
#     {
#         Write-Host "Custom role $roleName already exists."
#     }
#     else{
#         Write-Host "Custom role $roleName does not exist!"
#         $role = Get-AzRoleDefinition "Reader"
#         $role.Id = $null
#         $role.Name = $roleName

#     }
#     $role.Description = $roleDescription
#     $role.Actions.Clear()
#     $role.NotActions.Clear()
#     $role.DataActions.Clear()
#     $role.NotDataActions.Clear()
#     Copy-RoleActions -roleDefinition $role -roleName "Reader"

#     # Issues: This actions are granted but test cases say they shouldn't be
#     # Microsoft.MachineLearningServices/workspaces/datastores/write
#     # Microsoft.MachineLearningServices/workspaces/datastores/delete
#     # Microsoft.MachineLearningServices/workspaces/environments/write (test cases look wrong for qa and prod)
#     # Microsoft.MachineLearningServices/workspaces/services/aks/prod/score/action (think we are confused because 'prod' is mentioned in the action)
#     # Microsoft.MachineLearningServices/workspaces/services/aks/prod/listkeys/action (ditto, test case outcomes look wrong)


#     $role.Actions.Add("Microsoft.MachineLearningServices/workspaces/*/read")
#     $role.Actions.Add("Microsoft.MachineLearningServices/workspaces/*/write")
#     $role.Actions.Add("Microsoft.MachineLearningServices/workspaces/*/delete")
#     $role.Actions.Add("Microsoft.MachineLearningServices/workspaces/*/action")
    
#     $role.NotActions.Add("Microsoft.MachineLearningServices/workspaces/write")
#     $role.NotActions.Add("Microsoft.MachineLearningServices/workspaces/delete")
#     $role.NotActions.Add("Microsoft.MachineLearningServices/workspaces/services/aci/write")
#     $role.NotActions.Add("Microsoft.MachineLearningServices/workspaces/services/aci/listkeys/action")


#     # Prevent data fatory deletion.  This means that the landscape group must not be added to this role.
#     $role.NotActions.Add("Microsoft.DataFactory/factories/delete")
#     Set-Scope -roleDefinition $role
#     if ($role.Id) {
#         # update existing
#         Set-AzRoleDefinition -Role $role
#     } else {
#         # Create forthe first time
#         New-AzRoleDefinition -Role $role
#     }
#     return $role
# }

function New-ContributorRole {
    $roleName = "InA Tech DS Contributor"
    $roleDescription = "I&A Tech's custom resource group contributor role for data science environments."
    $role = Get-AzRoleDefinition $roleName
    if ($role)
    {
        Write-Host "Custom role $roleName already exists."
    }
    else{
        Write-Host "Custom role $roleName does not exist!"
        $role = Get-AzRoleDefinition "Reader"
        $role.Id = $null
        $role.Name = $roleName
    }
    $role.Description = $roleDescription
    $role.Actions.Clear()
    $role.NotActions.Clear()
    $role.DataActions.Clear()
    $role.NotDataActions.Clear()
    Copy-RoleActions -roleDefinition $role -roleName "Reader"

    # Issues: This actions are granted but test cases say they shouldn't be
    # Microsoft.MachineLearningServices/workspaces/datastores/write
    # Microsoft.MachineLearningServices/workspaces/datastores/delete
    # Microsoft.MachineLearningServices/workspaces/environments/write (test cases look wrong for qa and prod)
    # Microsoft.MachineLearningServices/workspaces/services/aks/prod/score/action (think we are confused because 'prod' is mentioned in the action)
    # Microsoft.MachineLearningServices/workspaces/services/aks/prod/listkeys/action (ditto, test case outcomes look wrong)

    # Not required, comes as default with Reader
    #$role.Actions.Add("Microsoft.MachineLearningServices/workspaces/*/read")
    $role.Actions.Add("Microsoft.MachineLearningServices/workspaces/*/write")
    $role.Actions.Add("Microsoft.MachineLearningServices/workspaces/*/delete")
    $role.Actions.Add("Microsoft.MachineLearningServices/workspaces/*/action")
    
    $role.NotActions.Add("Microsoft.MachineLearningServices/workspaces/write")
    $role.NotActions.Add("Microsoft.MachineLearningServices/workspaces/delete")
    $role.NotActions.Add("Microsoft.MachineLearningServices/workspaces/services/aci/write")
    $role.NotActions.Add("Microsoft.MachineLearningServices/workspaces/services/aci/delete")
    $role.NotActions.Add("Microsoft.MachineLearningServices/workspaces/services/aci/listkeys/action")

    # Add stuff from data factory contributor
    Copy-RoleActions -roleDefinition $role -roleName "Data Factory Contributor"

    # Prevent data fatory deletion.  This means that the landscape group must not be added to this role.
    $role.NotActions.Add("Microsoft.DataFactory/factories/delete")
    $role.NotActions.Add("Microsoft.DataFactory/factories/integrationruntimes/regenerateauthkey/action")
    $role.NotActions.Add("Microsoft.DataFactory/factories/integrationruntimes/removelinks/action")
    $role.NotActions.Add("Microsoft.DataFactory/factories/integrationruntimes/linkedIntegrationRuntime/action")

    # Enable ADF alerting via action groups
    $role.Actions.Add("Microsoft.Insights/actionGroups/read")
    $role.Actions.Add("Microsoft.Insights/actionGroups/write")
    $role.Actions.Add("Microsoft.SecurityGraph/diagnosticsettings/read")
    $role.Actions.Add("Microsoft.SecurityGraph/diagnosticsettingscategories/read")
    $role.Actions.Add("Microsoft.Insights/metricalerts/*")
    
    Set-Scope -roleDefinition $role
    if ($role.Id) {
        # update existing
        Set-AzRoleDefinition -Role $role
    } else {
        # Create forthe first time
        New-AzRoleDefinition -Role $role
    }
    return $role
}
# Custom Resource Group Reader Roles.  This doesn't give access to data
function New-ReaderRole {
    $roleName = "InA Tech DS Reader"
    $roleDescription = "I&A Tech's custom resource group reader role for data science."
    $role = Get-AzRoleDefinition $roleName
    if ($role)
    {
        Write-Host "Custom role $roleName already exists."
    }
    else{
        Write-Host "Custom role $roleName does not exist!"
        $role = Get-AzRoleDefinition "Reader"
        $role.Id = $null
        $role.Name = $roleName

    }
    $role.Description = $roleDescription
    $role.Actions.Clear()
    $role.NotActions.Clear()
    $role.DataActions.Clear()
    $role.NotDataActions.Clear()
    Copy-RoleActions -roleDefinition $role -roleName "Reader"

    $role.Actions.Add("Microsoft.MachineLearningServices/workspaces/datadriftdetectors/*")
    $role.Actions.Add("Microsoft.MachineLearningServices/workspaces/labeling/export/action")
    $role.Actions.Add("Microsoft.MachineLearningServices/workspaces/labeling/*")
    #This doesn't exist
    #$role.Actions.Add("Microsoft.MachineLearningServices/workspaces/models/download/action")
    $role.Actions.Add("Microsoft.MachineLearningServices/workspaces/models/package/action")
    #This doesn't exist
    #$role.Actions.Add("Microsoft.MachineLearningServices/workspaces/services/aks/devtest/score/action")
    $role.Actions.Add("Microsoft.MachineLearningServices/workspaces/services/aks/*/score/action")

    # Data dactory read only stuff
    $role.Actions.Add("Microsoft.DataFactory/datafactories/*/action")
    $role.Actions.Add("Microsoft.DataFactory/factories/*")
    $role.Actions.Add("Microsoft.DataFactory/locations/getFeatureValue/action")

    # Enable ADF alerting via action groups
    $role.Actions.Add("Microsoft.Insights/actionGroups/read")
    $role.Actions.Add("Microsoft.Insights/actionGroups/write")
    $role.Actions.Add("Microsoft.SecurityGraph/diagnosticsettings/read")
    $role.Actions.Add("Microsoft.SecurityGraph/diagnosticsettingscategories/read")
    $role.Actions.Add("Microsoft.Insights/AlertRules/*")
    $role.Actions.Add("Microsoft.Insights/metricalerts/*")

    $role.Actions.Add("Microsoft.ResourceHealth/availabilityStatuses/read")
    $role.Actions.Add("Microsoft.Support/*")
    $role.Actions.Add("Microsoft.EventGrid/eventSubscriptions/write")

    # Disable this stuff
    $role.NotActions.Add("Microsoft.DataFactory/factories/write")
    $role.NotActions.Add("Microsoft.DataFactory/factories/delete")
    $role.NotActions.Add("Microsoft.DataFactory/factories/*/write")
    $role.NotActions.Add("Microsoft.DataFactory/factories/*/delete")
    $role.NotActions.Add("Microsoft.DataFactory/factories/integrationruntimes/regenerateauthkey/action")
    $role.NotActions.Add("Microsoft.DataFactory/factories/integrationruntimes/removelinks/action")
    $role.NotActions.Add("Microsoft.DataFactory/factories/integrationruntimes/linkedIntegrationRuntime/action")
    $role.NotActions.Add("Microsoft.DataFactory/datafactories/*/write")
    $role.NotActions.Add("Microsoft.DataFactory/datafactories/*/delete")

    Set-Scope -roleDefinition $role

    if ($role.Id) {
        # update existing
        Set-AzRoleDefinition -Role $role
    } else {
        # Create forthe first time
        New-AzRoleDefinition -Role $role
    }
    return $role
}

function New-EngineerContributorRole {
    $roleName = "InA Tech DS Engineer Contributor"
    $roleDescription = "I&A Tech's custom data engineer contributor role for data science."
    $role = Get-AzRoleDefinition $roleName
    if ($role)
    {
        Write-Host "Custom role $roleName already exists."
    }
    else{
        Write-Host "Custom role $roleName does not exist!"
        $role = Get-AzRoleDefinition "Reader"
        $role.Id = $null
        $role.Name = $roleName

    }
    $role.Description = $roleDescription
    $role.Actions.Clear()
    $role.NotActions.Clear()
    $role.DataActions.Clear()
    $role.NotDataActions.Clear()
    Copy-RoleActions -roleDefinition $role -roleName "Reader"


    $role.Actions.Add("Microsoft.MachineLearningServices/workspaces/datastores/*")
    $role.Actions.Add("Microsoft.MachineLearningServices/workspaces/datasets/*")
    $role.Actions.Add("Microsoft.MachineLearningServices/workspaces/services/aks/*/score/action")
    $role.Actions.Add("Microsoft.MachineLearningServices/workspaces/labeling/*")
    $role.Actions.Add("Microsoft.MachineLearningServices/workspaces/models/package/action")
    
    $role.Actions.Add("Microsoft.DataFactory/datafactories/datapipelines/pause/action")
    $role.Actions.Add("Microsoft.DataFactory/datafactories/datapipelines/resume/action")
    $role.Actions.Add("Microsoft.DataFactory/datafactories/gateways/connectioninfo/action")
    $role.Actions.Add("Microsoft.DataFactory/factories/*")
    $role.Actions.Add("Microsoft.DataFactory/factories/debugpipelineruns/cancel/action")
    $role.Actions.Add("Microsoft.DataFactory/factories/pipelineruns/*")
    $role.Actions.Add("Microsoft.DataFactory/factories/pipelines/createrun/action")
    $role.Actions.Add("Microsoft.DataFactory/factories/pipelines/sandbox/action")
    $role.Actions.Add("Microsoft.DataFactory/factories/triggers/start/action")
    $role.Actions.Add("Microsoft.DataFactory/factories/triggers/stop/action")
    $role.Actions.Add("Microsoft.DataFactory/locations/getFeatureValue/action")

    $role.NotActions.Add("Microsoft.DataFactory/factories/write")

    $role.Actions.Add("Microsoft.Insights/AlertRules/Read")
    $role.Actions.Add("Microsoft.Insights/AlertRules/Activated/Action")
    $role.Actions.Add("Microsoft.Insights/AlertRules/Resolved/Action")
    $role.Actions.Add("Microsoft.Insights/AlertRules/Throttled/Action")
    $role.Actions.Add("Microsoft.Insights/AlertRules/Incidents/Read")

    $role.Actions.Add("Microsoft.ResourceHealth/availabilityStatuses/read")
    $role.Actions.Add("Microsoft.Support/*")
    Set-Scope -roleDefinition $role

    if ($role.Id) {
        # update existing
        Set-AzRoleDefinition -Role $role
    } else {
        # Create forthe first time
        New-AzRoleDefinition -Role $role
    }
    return $role
}

function New-EngineerReaderRole {
    $roleName = "InA Tech DS Engineer Reader"
    $roleDescription = "I&A Tech's custom data engineer reader role for data science."
    $role = Get-AzRoleDefinition $roleName
    if ($role)
    {
        Write-Host "Custom role $roleName already exists."
    }
    else{
        Write-Host "Custom role $roleName does not exist!"
        $role = Get-AzRoleDefinition "Reader"
        $role.Id = $null
        $role.Name = $roleName

    }
    $role.Description = $roleDescription
    $role.Actions.Clear()
    $role.NotActions.Clear()
    $role.DataActions.Clear()
    $role.NotDataActions.Clear()
    
    Copy-RoleActions -roleDefinition $role -roleName "Reader"

    $role.Actions.Add("Microsoft.MachineLearningServices/workspaces/services/aks/*/score/action")
    Set-Scope -roleDefinition $role

    if ($role.Id) {
        # update existing
        Set-AzRoleDefinition -Role $role
    } else {
        # Create forthe first time
        New-AzRoleDefinition -Role $role
    }
    return $role
}

& "$devOpsProjectFolder\LandscapeManager\Set-GlobalScope.ps1"

New-ContributorRole
New-ReaderRole
#New-EngineerContributorRole
#New-EngineerReaderRole
