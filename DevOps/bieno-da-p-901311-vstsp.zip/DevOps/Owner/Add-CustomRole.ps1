Param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the subscription you want to assign I&As rule against')]
    [String]$targetSubscriptionId
)
# Select a subscriotion where the roles are already installed
$subscriptionId = "e2b0e829-5210-40ae-b73f-20805aa01351"
Select-AzSubscription -SubscriptionId $subscriptionId | Out-Null
$ctx = Get-AzContext
if (-not $ctx) {
    Write-Error "You must call Login-AzAccount and select your target subscription before running this script."
    return
}
$subscriptionId = $ctx.Subscription.Id
# Configure a custom role to be available on Resource Group level only
function Set-ScopeResourceGroups {
    param([Microsoft.Azure.Commands.Resources.Models.Authorization.PSRoleDefinition]$roleDefinition)
    
    $scope = "/subscriptions/{0}" -f $targetSubscriptionId
    if (-not $roleDefinition.AssignableScopes.Contains($scope)) {
        Write-Host "Assigning InA custom role '$($roleDefinition.Name)' to scope $scope."
        $roleDefinition.AssignableScopes.Add($scope)
        Set-AzRoleDefinition -Role $role
    } else {
        Write-Warning "InA custom role '$($roleDefinition.Name)' is already assigned to scope $scope."
    }
}

$roleName="Ina Tech Data Reader"
$role = Get-AzRoleDefinition $roleName
if ($role) {
    Set-ScopeResourceGroups -roleDefinition $role
}

$roleName="Ina Tech Data Writer"
$role = Get-AzRoleDefinition $roleName
if ($role) {
    Set-ScopeResourceGroups -roleDefinition $role
}

$roleName="Ina Tech Data Owner"
$role = Get-AzRoleDefinition $roleName
if ($role) {
    Set-ScopeResourceGroups -roleDefinition $role
}

$roleName="Ina Tech Contributor"
$role = Get-AzRoleDefinition $roleName
if ($role) {
    Set-ScopeResourceGroups -roleDefinition $role
}

$roleName="InA Tech Reader"
$role = Get-AzRoleDefinition $roleName
if ($role) {
    Set-ScopeResourceGroups -roleDefinition $role
}
