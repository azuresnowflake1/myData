

Write-Verbose "PSScriptRoot is: $PSScriptRoot"
$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
Write-Verbose "DevOps Project Folder: $devOpsProjectFolder"
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"
Write-Verbose "Utilties folder: $utilitiesFolder"



$subscriptionId = "e2b0e829-5210-40ae-b73f-20805aa01351"
Select-AzSubscription -SubscriptionId $subscriptionId | Out-Null

#
function Set-ScopeSubscription {
    param( [Microsoft.Azure.Commands.Resources.Models.Authorization.PSRoleDefinition]$roleDefinition, [string]$roleName)

    $roleDefinition.AssignableScopes.Clear();
    $roleDefinition.AssignableScopes.Add("/subscriptions/bc41a9ef-b853-4107-aa12-cc8d592c8e91")
    # Amsterdam
    $roleDefinition.AssignableScopes.Add("/subscriptions/e2b0e829-5210-40ae-b73f-20805aa01351")
    # $roleDefinition.AssignableScopes.Add("/subscriptions/8b4fb847-3b45-410f-a6e7-3247c9d459b7")
}
# Configure a custom role to be available on Resource Group level only
function Set-ScopeResourceGroups {
    param( [Microsoft.Azure.Commands.Resources.Models.Authorization.PSRoleDefinition]$roleDefinition)

    $roleDefinition.AssignableScopes.Clear();
    $roleDefinition.AssignableScopes.Add("/subscriptions/bc41a9ef-b853-4107-aa12-cc8d592c8e91")
    # Amsterdam 01, 02, 03 & 04
    $roleDefinition.AssignableScopes.Add("/subscriptions/e2b0e829-5210-40ae-b73f-20805aa01351") #01
    $roleDefinition.AssignableScopes.Add("/subscriptions/8b4fb847-3b45-410f-a6e7-3247c9d459b7") #02
    $roleDefinition.AssignableScopes.Add("/subscriptions/43046d94-2b34-46fa-8b8b-4a3a72b53df6") #03
    $roleDefinition.AssignableScopes.Add("/subscriptions/105fbd8d-388f-4b19-9fda-d56f44121122") #04
    $roleDefinition.AssignableScopes.Add("/subscriptions/c70cf1d8-50bd-486d-b921-b910ffb03a70") #16
    $roleDefinition.AssignableScopes.Add("/subscriptions/65c24fb4-4567-43b8-a31f-d06f8f1d0dd7") #13
    # $roleDefinition.AssignableScopes.Add("/subscriptions/8b4fb847-3b45-410f-a6e7-3247c9d459b7")
    #$role.AssignableScopes.Add("/subscriptions/e2b0e829-5210-40ae-b73f-20805aa01351/resourceGroups/*")
    # Amsterdam
    #$role.AssignableScopes.Add("/subscriptions/e2b0e829-5210-40ae-b73f-20805aa01351/resourceGroups/*")
    #$role.AssignableScopes.Add("/subscriptions/8b4fb847-3b45-410f-a6e7-3247c9d459b7/resourceGroups/*")
}
# Write all role assignments to standard out
function Write-RoleActions
{
    param( [string]$name)
    Get-AzRoleDefinition $Name | ConvertTo-Json
}
function Copy-RoleActions {
    param( [Microsoft.Azure.Commands.Resources.Models.Authorization.PSRoleDefinition]$roleDefinition, [string]$roleName)


    # Add actions from the fixed contributor role
    $actions = (Get-AzRoleDefinition $roleName).Actions
    foreach($action in $actions)
    {
        if (-not ($role.Actions.Contains($action))) {
            $role.Actions.Add($action)
        }
    }
    $actions = (Get-AzRoleDefinition $roleName).NotActions
    foreach($action in $actions)
    {
        if (-not ($role.NotActions.Contains($action))) {
            $role.NotActions.Add($action)
        }
    }
    $actions = (Get-AzRoleDefinition $roleName).DataActions
    foreach($action in $actions)
    {
        if (-not ($role.DataActions.Contains($action))) {
            $role.DataActions.Add($action)
        }
    }
    $actions = (Get-AzRoleDefinition $roleName).NotDataActions
    foreach($action in $actions)
    {
        if (-not ($role.NotDataActions.Contains($action))) {
            $role.NotDataActions.Add($action)
        }
    }
}

function New-DevOpsADFContributorRole {
    $roleName = "InA Tech DevOps ADF Contributor"
    $roleDescription = "I&A Tech's custom ADF contributor role."
    $role = Get-AzRoleDefinition $roleName
    if ($role)
    {
        Write-Verbose "Custom role $roleName already exists."
    }
    else{
        Write-Verbose "Custom role $roleName does not exist!"
        $role = Get-AzRoleDefinition "Reader"
        $role.Id = $null
        $role.Name = $roleName

    }
    $role.Description = $roleDescription
    $role.Actions.Clear()
    $role.NotActions.Clear()
    $role.DataActions.Clear()
    $role.NotDataActions.Clear()
    Copy-RoleActions -roleDefinition $role -roleName "Reader"
    Copy-RoleActions -roleDefinition $role -roleName "Data Factory Contributor"
    $role.Actions.Add("Microsoft.Resources/deployments/read")
    $role.Actions.Add("Microsoft.Resources/deployments/write")
    # Prevent data fatory deletion.  This means that the landscape group must not be added to this role.
    $role.NotActions.Add("Microsoft.DataFactory/factories/delete")
    $role.NotActions.Add("Microsoft.DataFactory/factories/linkedServices/delete")
    $role.NotActions.Add("Microsoft.DataFactory/factories/linkedServices/write")
    
    if ($role.Id) {
        # update existing
        Set-AzRoleDefinition -Role $role
    } else {
        # Create forthe first time
        New-AzRoleDefinition -Role $role
    }
    return $role
}

function New-DevOpsADFRGContributorRole {
    $roleName = "InA Tech DevOps ADF RG Contributor"
    $roleDescription = "I&A Tech's custom ADF Resource Group contributor role."
    $role = Get-AzRoleDefinition $roleName
    if ($role)
    {
        Write-Verbose "Custom role $roleName already exists."
    }
    else{
        Write-Verbose "Custom role $roleName does not exist!"
        $role = Get-AzRoleDefinition "Reader"
        $role.Id = $null
        $role.IsCustom = $true
        $role.Name = $roleName

    }
    $role.Description = $roleDescription
    $role.Actions.Clear()
    $role.NotActions.Clear()
    $role.DataActions.Clear()
    $role.NotDataActions.Clear()
    $role.AssignableScopes.Clear()
    $role.AssignableScopes.Add("/subscriptions/e2b0e829-5210-40ae-b73f-20805aa01351")
    Copy-RoleActions -roleDefinition $role -roleName "Reader"
    
    
    $role.Actions.Add("Microsoft.Resources/deployments/read")
    $role.Actions.Add("Microsoft.Resources/deployments/write")
    
    if ($role.Id) {
        # update existing
        Set-AzRoleDefinition -Role $role
    } else {
        # Create forthe first time
        New-AzRoleDefinition -Role $role
    }
    return $role
}
# Create a customer contributor role that includes actions from various roles
function New-ContributorRole {
    $roleName = "InA Tech Contributor"
    $roleDescription = "I&A Tech's custom resource group contributor role."
    $role = Get-AzRoleDefinition $roleName
    if ($role)
    {
        Write-Verbose "Custom role $roleName already exists."
    }
    else{
        Write-Verbose "Custom role $roleName does not exist!"
        $role = Get-AzRoleDefinition "Reader"
        $role.Id = $null
        $role.Name = $roleName

    }
    $role.Description = $roleDescription
    $role.Actions.Clear()
    $role.NotActions.Clear()
    $role.DataActions.Clear()
    $role.NotDataActions.Clear()
    Copy-RoleActions -roleDefinition $role -roleName "Reader"
    Copy-RoleActions -roleDefinition $role -roleName "Data Factory Contributor"
    # Prevent data fatory deletion.  This means that the landscape group must not be added to this role.
    $role.NotActions.Add("Microsoft.DataFactory/factories/delete")
    Set-ScopeResourceGroups -roleDefinition $role
    if ($role.Id) {
        # update existing
        Set-AzRoleDefinition -Role $role
    } else {
        # Create forthe first time
        New-AzRoleDefinition -Role $role
    }
    return $role
}
# Custom Resource Group Reader Roles.  This doesn't give access to data
function New-ReaderRole {
    $roleName = "InA Tech Reader"
    $roleDescription = "I&A Tech's custom resource group reader role."
    $role = Get-AzRoleDefinition $roleName
    if ($role)
    {
        Write-Verbose "Custom role $roleName already exists."
    }
    else{
        Write-Verbose "Custom role $roleName does not exist!"
        $role = Get-AzRoleDefinition "Reader"
        $role.Id = $null
        $role.Name = $roleName

    }
    $role.Description = $roleDescription
    $role.Actions.Clear()
    $role.NotActions.Clear()
    $role.DataActions.Clear()
    $role.NotDataActions.Clear()
    Copy-RoleActions -roleDefinition $role -roleName "Reader"
    #Copy-RoleActions -roleDefinition $role -roleName "Data Factory Contributor"
    # Add all the read actions from Data Factory Contributor fixed role
    $role.Actions.Add("Microsoft.DataFactory/factories/read")
    $role.Actions.Add("Microsoft.DataFactory/factories/cancelpipelinerun/action")
    $role.Actions.Add("Microsoft.DataFactory/factories/getGitHubAccessToken/action")
    $role.Actions.Add("Microsoft.DataFactory/factories/querytriggerruns/action")
    $role.Actions.Add("Microsoft.DataFactory/factories/querypipelineruns/action")
    $role.Actions.Add("Microsoft.DataFactory/factories/querydebugpipelineruns/action")
    $role.Actions.Add("Microsoft.DataFactory/factories/linkedServices/read")
    $role.Actions.Add("Microsoft.DataFactory/factories/pipelines/read")
    $role.Actions.Add("Microsoft.DataFactory/factories/pipelines/createrun/action")
    $role.Actions.Add("Microsoft.DataFactory/factories/pipelineruns/read")
    $role.Actions.Add("Microsoft.DataFactory/factories/pipelineruns/cancel/action")
    $role.Actions.Add("Microsoft.DataFactory/factories/pipelineruns/queryactivityruns/action")
    $role.Actions.Add("Microsoft.DataFactory/factories/pipelineruns/activityruns/read")
    $role.Actions.Add("Microsoft.DataFactory/factories/datasets/read")
    $role.Actions.Add("Microsoft.DataFactory/factories/integrationruntimes/read")
    $role.Actions.Add("Microsoft.DataFactory/factories/integrationruntimes/start/action")
    $role.Actions.Add("Microsoft.DataFactory/factories/integrationruntimes/stop/action")
    $role.Actions.Add("Microsoft.DataFactory/factories/integrationruntimes/synccredentials/action")
    $role.Actions.Add("Microsoft.DataFactory/factories/integrationruntimes/getObjectMetadata/action")
    $role.Actions.Add("Microsoft.DataFactory/factories/integrationruntimes/refreshObjectMetadata/action")
    $role.Actions.Add("Microsoft.DataFactory/factories/integrationruntimes/getconnectioninfo/read")
    $role.Actions.Add("Microsoft.DataFactory/factories/integrationruntimes/getstatus/read")
    $role.Actions.Add("Microsoft.DataFactory/factories/integrationruntimes/monitoringdata/read")
    $role.Actions.Add("Microsoft.DataFactory/factories/integrationruntimes/nodes/read")
    $role.Actions.Add("Microsoft.DataFactory/factories/integrationruntimes/nodes/ipAddress/action")
    $role.Actions.Add("Microsoft.DataFactory/factories/triggers/read")
    $role.Actions.Add("Microsoft.DataFactory/factories/triggers/start/action")
    $role.Actions.Add("Microsoft.DataFactory/factories/triggers/stop/action")
    $role.Actions.Add("Microsoft.DataFactory/factories/triggers/triggerruns/read")
    $role.Actions.Add("Microsoft.DataFactory/factories/triggerruns/read")
    $role.Actions.Add("Microsoft.DataFactory/factories/pipelines/pipelineruns/read")
    $role.Actions.Add("Microsoft.DataFactory/factories/querytriggerruns/read")
    $role.Actions.Add("Microsoft.DataFactory/factories/querypipelineruns/read")
    $role.Actions.Add("Microsoft.DataFactory/factories/pipelineruns/queryactivityruns/read")
    $role.Actions.Add("Microsoft.DataFactory/factories/pipelines/pipelineruns/activityruns/progress/read")

    $role.Actions.Add("Microsoft.DataFactory/datafactories/read")
    $role.Actions.Add("Microsoft.DataFactory/datafactories/linkedServices/read")
    $role.Actions.Add("Microsoft.DataFactory/datafactories/datapipelines/read")
    $role.Actions.Add("Microsoft.DataFactory/datafactories/datapipelines/pause/action")
    $role.Actions.Add("Microsoft.DataFactory/datafactories/datapipelines/resume/action")
    $role.Actions.Add("Microsoft.DataFactory/datafactories/datasets/read")
    $role.Actions.Add("Microsoft.DataFactory/datafactories/tables/read")
    $role.Actions.Add("Microsoft.DataFactory/datafactories/datasets/slices/read")
    $role.Actions.Add("Microsoft.DataFactory/datafactories/datasets/sliceruns/read")
    $role.Actions.Add("Microsoft.DataFactory/datafactories/runs/loginfo/read")
    $role.Actions.Add("Microsoft.DataFactory/datafactories/activitywindows/read")
    $role.Actions.Add("Microsoft.DataFactory/datafactories/datapipelines/activitywindows/read")
    $role.Actions.Add("Microsoft.DataFactory/datafactories/datapipelines/activities/activitywindows/read")
    $role.Actions.Add("Microsoft.DataFactory/datafactories/datasets/activitywindows/read")
    $role.Actions.Add("Microsoft.DataFactory/datafactories/gateways/read")
    $role.Actions.Add("Microsoft.DataFactory/datafactories/gateways/connectioninfo/action")
    $role.Actions.Add("Microsoft.DataFactory/datafactories/gateways/listauthkeys/action")

    $role.Actions.Add("Microsoft.Insights/AlertRules/Read")
    $role.Actions.Add("Microsoft.Insights/AlertRules/Activated/Action")
    $role.Actions.Add("Microsoft.Insights/AlertRules/Resolved/Action")
    $role.Actions.Add("Microsoft.Insights/AlertRules/Throttled/Action")
    $role.Actions.Add("Microsoft.Insights/AlertRules/Incidents/Read")

    $role.Actions.Add("Microsoft.ResourceHealth/availabilityStatuses/read")

    $role.Actions.Add("Microsoft.Resources/subscriptions/resourceGroups/read")
    $role.Actions.Add("Microsoft.Support/*")
    Set-ScopeResourceGroups -roleDefinition $role

    if ($role.Id) {
        # update existing
        Set-AzRoleDefinition -Role $role
    } else {
        # Create forthe first time
        New-AzRoleDefinition -Role $role
    }
    return $role
}


# This role gives access to reader data in BLOB. It should be granted to storage
# and/or ADLS component
function New-DataReaderRole {
    $roleName = "InA Tech Data Reader"
    $roleDescription = "I&A Tech's custom data reader role. Provides access to read BLOB and ADLS data"
    $role = Get-AzRoleDefinition $roleName
    if ($role)
    {
        Write-Verbose "Custom role $roleName already exists."
    }
    else{
        Write-Verbose "Custom role $roleName does not exist!"
        $role = Get-AzRoleDefinition "Reader"
        $role.Id = $null
        $role.Name = $roleName

    }
    $role.Description = $roleDescription
    $role.Actions.Clear()
    $role.NotActions.Clear()
    $role.DataActions.Clear()
    $role.NotDataActions.Clear()
    # Not sure if Reader fixed role is required, hope not
    #Copy-RoleActions -roleDefinition $role -roleName "Reader"
    Copy-RoleActions -roleDefinition $role -roleName "Storage Blob Data Reader"
    Set-ScopeResourceGroups -roleDefinition $role

    if ($role.Id) {
        # update existing
        Set-AzRoleDefinition -Role $role
    } else {
        # Create forthe first time
        New-AzRoleDefinition -Role $role
    }
    return $role
}

# Allows admin permissions on BLOB and ADLS.  This should be granted at component level.
function New-DataOwnerRole {
    $roleName = "InA Tech Data Owner"
    $roleDescription = "I&A Tech's custom data owner role. Provides permissions access data and to administer access to data."
    $role = Get-AzRoleDefinition $roleName
    if ($role)
    {
        Write-Verbose "Custom role $roleName already exists."
    }
    else{
        Write-Verbose "Custom role $roleName does not exist!"
        $role = Get-AzRoleDefinition "Reader"
        $role.Id = $null
        $role.Name = $roleName

    }
    $role.Description = $roleDescription
    $role.Actions.Clear()
    $role.NotActions.Clear()
    $role.DataActions.Clear()
    $role.NotDataActions.Clear()
    # Not sure if Reader fixed role is required, hope not
    #Copy-RoleActions -roleDefinition $role -roleName "Reader"
    Copy-RoleActions -roleDefinition $role -roleName "Storage Blob Data Owner"
    # Prevent access control propagation
    #$role.NotActions.Add("Microsoft.Authorization/roleAssignments/write")
    # grant control of ADLS folder ACLs data
    $role.Actions.Add("Microsoft.Authorization/roleAssignments/*")
    $role.Actions.Add("Microsoft.DataLakeStore/accounts/Superuser/action")

    # $role.Actions.Add("Microsoft.Authorization/roleAssignments/read")
    # $role.Actions.Add("Microsoft.Authorization/roleAssignments/execute")

    Set-ScopeResourceGroups -roleDefinition $role

    if ($role.Id) {
        # update existing
        Set-AzRoleDefinition -Role $role
    } else {
        # Create forthe first time
        New-AzRoleDefinition -Role $role
    }
    return $role
}
function New-DataOwnerRole1 {
    $roleName = "InA Tech Data Owner1"
    $roleDescription = "I&A Tech's custom data owner role. Provides permissions access data and to administer access to data."
    $role = Get-AzRoleDefinition $roleName
    if ($role)
    {
        Write-Verbose "Custom role $roleName already exists."
    }
    else{
        Write-Verbose "Custom role $roleName does not exist!"
        $role = Get-AzRoleDefinition "Reader"
        $role.Id = $null
        $role.Name = $roleName

    }
    $role.Description = $roleDescription
    $role.Actions.Clear()
    $role.NotActions.Clear()
    $role.DataActions.Clear()
    $role.NotDataActions.Clear()
    # Not sure if Reader fixed role is required, hope not
    #Copy-RoleActions -roleDefinition $role -roleName "Reader"
    Copy-RoleActions -roleDefinition $role -roleName "Storage Blob Data Owner"
    # Prevent access control propagation
    #$role.NotActions.Add("Microsoft.Authorization/roleAssignments/write")
    # grant control of ADLS folder ACLs data
    # $role.Actions.Add("Microsoft.Authorization/*/read")
    # $role.Actions.Add("Microsoft.DataLakeStore/accounts/* ")

    $role.Actions.Add("*/read")
    $role.Actions.Add("Microsoft.Authorization/roleAssignments/write")
    $role.Actions.Add("Microsoft.DataLakeStore/accounts/Superuser/action")

    #$role.DataActions.Add("Microsoft.Authorization/roleAssignments/write")
    #$role.DataActions.Add("Microsoft.DataLakeStore/accounts/Superuser/action")
    # $role.Actions.Add("Microsoft.Authorization/roleAssignments/read")
    # $role.Actions.Add("Microsoft.Authorization/roleAssignments/execute")

    Set-ScopeResourceGroups -roleDefinition $role

    if ($role.Id) {
        # update existing
        Set-AzRoleDefinition -Role $role
    } else {
        # Create forthe first time
        New-AzRoleDefinition -Role $role
    }
    return $role
}

function New-DataOwnerRole2 {
    $roleName = "InA Tech Data Owner2"
    $roleDescription = "I&A Tech's custom data owner role. Provides permissions access data and to administer access to data."
    $role = Get-AzRoleDefinition $roleName
    if ($role)
    {
        Write-Verbose "Custom role $roleName already exists."
    }
    else{
        Write-Verbose "Custom role $roleName does not exist!"
        $role = Get-AzRoleDefinition "Reader"
        $role.Id = $null
        $role.Name = $roleName

    }
    $role.Description = $roleDescription
    $role.Actions.Clear()
    $role.NotActions.Clear()
    $role.DataActions.Clear()
    $role.NotDataActions.Clear()
    # Not sure if Reader fixed role is required, hope not
    #Copy-RoleActions -roleDefinition $role -roleName "Reader"
    #Copy-RoleActions -roleDefinition $role -roleName "Storage Blob Data Owner"
    # Prevent access control propagation
    #$role.NotActions.Add("Microsoft.Authorization/roleAssignments/write")
    # grant control of ADLS folder ACLs data
    # $role.Actions.Add("Microsoft.Authorization/*/read")
    # $role.Actions.Add("Microsoft.DataLakeStore/accounts/* ")

    # $role.Actions.Add("Microsoft.Authorization/roleAssignments/write")
    # $role.Actions.Add("Microsoft.Resources/subscriptions/resourceGroups/read")
    # $role.Actions.Add("Microsoft.DataLakeStore/accounts/*")
    $role.Actions.Add("*")

    # $role.Actions.Add("Microsoft.Authorization/roleAssignments/read")
    # $role.Actions.Add("Microsoft.Authorization/roleAssignments/execute")

    Set-ScopeResourceGroups -roleDefinition $role

    if ($role.Id) {
        # update existing
        Set-AzRoleDefinition -Role $role
    } else {
        # Create forthe first time
        New-AzRoleDefinition -Role $role
    }
    return $role
}

function New-DataWriterRole {
    $roleName = "InA Tech Data Writer"
    $roleDescription = "I&A Tech's custom data writer role. Provides permissions to edit data"
    $role = Get-AzRoleDefinition $roleName
    if ($role)
    {
        Write-Verbose "Custom role $roleName already exists."
    }
    else{
        Write-Verbose "Custom role $roleName does not exist!"
        $role = Get-AzRoleDefinition "Reader"
        $role.Id = $null
        $role.Name = $roleName

    }
    $role.Description = $roleDescription
    $role.Actions.Clear()
    $role.NotActions.Clear()
    $role.DataActions.Clear()
    $role.NotDataActions.Clear()
    # Not sure if Reader fixed role is required, hope not
    #Copy-RoleActions -roleDefinition $role -roleName "Reader"
    Copy-RoleActions -roleDefinition $role -roleName "Storage Blob Data Contributor"

    $role.Actions.Add("Microsoft.DataLakeStore/accounts/Superuser/action")
    $role.Actions.Add("Microsoft.Authorization/roleAssignments/read")

    Set-ScopeResourceGroups -roleDefinition $role

    if ($role.Id) {
        # update existing
        Set-AzRoleDefinition -Role $role
    } else {
        # Create forthe first time
        New-AzRoleDefinition -Role $role
    }
    return $role
}

# New-DevOpsADFRGContributorRole
# $roleName = "InA Tech DevOps ADF RG Contributor"
# $role = Get-AzRoleDefinition $roleName
# if ($role) {
#     Write-Host "Updated subscriptions for $roleName"
#     $role.AssignableScopes.Clear();
#     # PDS Amsterdam prod
#     $role.AssignableScopes.Add("/subscriptions/e2b0e829-5210-40ae-b73f-20805aa01351")
#     # # UDL Prod
#     # $role.AssignableScopes.Add("/subscriptions/b3c4d044-fa50-40d7-a7da-554df6dcd693")
#     # # PDS Prod north europe
#     # $role.AssignableScopes.Add("/subscriptions/291887e7-fc87-453a-ba96-5f2386363348")
#     # # BDL Prod
#     # $role.AssignableScopes.Add("/subscriptions/23c97e5c-d961-43fd-8653-5a528cb5a2f5")
#     Set-AzRoleDefinition -Role $role
# }

New-DevOpsADFContributorRole
$roleName="InA Tech DevOps ADF Contributor"
$role = Get-AzRoleDefinition $roleName
if ($role) {
    Write-Host "Updated subscriptions for $roleName"
    $role.AssignableScopes.Clear();
    # PDS Amsterdam prod
    $role.AssignableScopes.Add("/subscriptions/e2b0e829-5210-40ae-b73f-20805aa01351")
    # UDL Prod
    $role.AssignableScopes.Add("/subscriptions/b3c4d044-fa50-40d7-a7da-554df6dcd693")
    # PDS Prod north europe
    $role.AssignableScopes.Add("/subscriptions/291887e7-fc87-453a-ba96-5f2386363348")
    # BDL Prod
    $role.AssignableScopes.Add("/subscriptions/23c97e5c-d961-43fd-8653-5a528cb5a2f5")
    Set-AzRoleDefinition -Role $role
}
# New-ContributorRole
# New-ReaderRole
# #New-DataOwnerRole1
# New-DataOwnerRole
# New-DataReaderRole
# New-DataWriterRole

# $role = Get-AzRoleDefinition "Reader"
# ##$role = New-DataContributorRole
# Write-RoleActions -name "Ina Tech Data Reader"
# Write-RoleActions -name "Ina Tech Data Writer"
# Write-RoleActions -name "Ina Tech Data Owner"
# Write-RoleActions -name "Ina Tech Reader"
# Write-RoleActions -name "Ina Tech Contributor"
# $roleName="Ina Tech Data Reader"
# $role = Get-AzRoleDefinition $roleName
# if ($role) {
#     Write-Host "Updated subscriptions for $roleName"
#     Set-ScopeResourceGroups -roleDefinition $role
#     Set-AzRoleDefinition -Role $role
# }

# $roleName="Ina Tech Data Writer"
# $role = Get-AzRoleDefinition $roleName
# if ($role) {
#     Write-Host "Updated subscriptions for $roleName"
#     Set-ScopeResourceGroups -roleDefinition $role
#     Set-AzRoleDefinition -Role $role
# }

# $roleName="Ina Tech Data Owner"
# $role = Get-AzRoleDefinition $roleName
# if ($role) {
#     Write-Host "Updated subscriptions for $roleName"
#     Set-ScopeResourceGroups -roleDefinition $role
#     Set-AzRoleDefinition -Role $role
# }

# $roleName="Ina Tech Data Reader"
# $role = Get-AzRoleDefinition $roleName
# if ($role) {
#     Write-Host "Updated subscriptions for $roleName"
#     Set-ScopeResourceGroups -roleDefinition $role
#     Set-AzRoleDefinition -Role $role
# }

# $roleName="Ina Tech Contributor"
# $role = Get-AzRoleDefinition $roleName
# if ($role) {
#     Write-Host "Updated subscriptions for $roleName"
#     Set-ScopeResourceGroups -roleDefinition $role
#     Set-AzRoleDefinition -Role $role
# }

# $roleName="InA Tech Reader"
# $role = Get-AzRoleDefinition $roleName
# if ($role) {
#     Write-Host "Updated subscriptions for $roleName"
#     Set-ScopeResourceGroups -roleDefinition $role
#     Set-AzRoleDefinition -Role $role
# }
