/****** Object:  View [dbo].[vw_expected_spg_for_each_product_group]    Script Date: 1/18/2021 1:16:49 PM ******/
IF OBJECT_ID ( 'dbo.vw_expected_spg_for_each_product_group', 'V' ) IS NOT NULL   
    DROP VIEW dbo.vw_expected_spg_for_each_product_group;  
GO 

CREATE VIEW  [dbo].[vw_expected_spg_for_each_product_group]
AS select X.salesman_product_group_code , X.standardised_salesman_product_group , trim(X.expected_Spg) as expected_spg
FROM (
	select distinct [salesman_product_group_code]
	,[standardised_salesman_product_group]
	,value expected_spg 
	FROM dbo.[dim_salesman]
	CROSS APPLY STRING_SPLIT(expected_spg , ';')
	) X;
GO

---------------------------------------------------------------------------------
/****** Object:  View [dbo].[vw_spg_mapping_for_historical_spg_change]    Script Date: 1/18/2021 1:16:49 PM ******/

/*

IF OBJECT_ID ( 'dbo.vw_spg_mapping_for_historical_spg_change', 'V' ) IS NOT NULL   
    DROP VIEW dbo.vw_spg_mapping_for_historical_spg_change;  
GO 

CREATE VIEW  [dbo].[vw_spg_mapping_for_historical_spg_change] AS select P.master_outlet_code, 
  P.master_salesman_code, 
  P.standardised_salesman_product_group,
  m.product_hierarchy as division
    from (
select 
  X.master_outlet_code, 
  X.master_salesman_code, 
  X.standardised_salesman_product_group

from 
  (
    select 
      master_outlet_code, 
      master_salesman_code, 
      s.standardised_salesman_product_group, 
      row_number() over(
        partition by master_outlet_code 
        order by 
          invoice_date desc
      ) as rank 
    from 
      dbo.fact_daily_sales t 
      join dbo.dim_salesman s on t.master_salesman_code = s.salesman_code  
    where 
      no_of_salespersons_serving_outlet_in_this_spg = 1
  ) X 
where 
  X.rank = 1 

union 

 -- mapping spg table for outlets with expected no of spg greater than 1 

select * from (

--  gets latest salesman for each outlet 
select 
  X.master_outlet_code, 
  X.master_salesman_code, 
  X.standardised_salesman_product_group
from 
  (
    select 
      master_outlet_code, 
      master_salesman_code, 
      s.standardised_salesman_product_group, 
      row_number() over(
        partition by master_outlet_code 
        order by 
          invoice_date desc
      ) as rank 
    from 
      dbo.fact_daily_sales t 
      join dbo.dim_salesman s on t.master_salesman_code = s.salesman_code 
      
    where 
      master_outlet_code = 741941 
      AND no_of_salespersons_serving_outlet_in_this_spg > 1
  ) X 
where 
  X.rank = 1 
union 
select 
  * 
from 
  (
    
    -- get second latest salesman record for particular outlet by joining the dss data with the mapping file for expected SPG and get the next latest salesman 
    select 
      C.master_outlet_code, 
      C.master_salesman_code, 
      C.standardised_salesman_product_group  
    FROM 
      (
        select 
          t.master_outlet_code, 
          master_salesman_code, 
          s.standardised_salesman_product_group,     
          row_number() over(
            partition by t.master_outlet_code 
            order by 
              invoice_date desc
          ) as rank 
        from 
          dbo.fact_daily_sales t 
          join dbo.dim_salesman s on t.master_salesman_code = s.salesman_code 
          JOIN (
            SELECT 
              * 
            FROM 
              (
              -- join latest spg for each outlet with the expected SPG
                SELECT 
                  Y.master_outlet_code, 
                  vw.expected_spg 
                FROM 
                  (
                  -- get latest salesman and its spg for each outlet
                    SELECT 
                      * 
                    FROM 
                      (
                        SELECT 
                          master_outlet_code, 
                          master_salesman_code, 
                          salesman_product_group_code, 
                          Row_number() OVER(
                            partition BY master_outlet_code 
                            ORDER BY 
                              invoice_date DESC
                          ) AS rank 
                        FROM 
                          dbo.fact_daily_sales t 
                          JOIN dbo.dim_salesman s ON t.master_salesman_code = s.salesman_code 
                        WHERE  
                           no_of_salespersons_serving_outlet_in_this_spg > 1
                      ) X 
                    WHERE 
                      X.rank = 1
                  ) Y 
                  JOIN vw_expected_spg_for_each_product_group AS vw ON Y.salesman_product_group_code = vw.salesman_product_group_code
              ) Z
          ) A on t.master_outlet_code = A.master_outlet_code 
          and s.standardised_salesman_product_group = A.expected_spg
      ) C 
    where 
      C.rank = 1
  ) T
)G

)P

join [dbo].[map_spg_to_PH] m

on P.standardised_salesman_product_group = m.[standardised_SPG];
GO

*/
---------------------------------------------------------------------------------
/****** Object:  View [dbo].[vw_dim_time]    Script Date: 1/18/2021 1:16:49 PM ******/


IF OBJECT_ID ( 'dbo.vw_dim_time', 'V' ) IS NOT NULL   
    DROP VIEW dbo.vw_dim_time;  
GO 

CREATE VIEW  [dbo].[vw_dim_time]
AS select
Dt as time_key,
Dt_og as day,
year_month as month_key,
year as year_id,
Day as day_name,
Wk as week_of_year,
Month as month_name,
format(Dt_og, 'MMM-yy') month_id,
Trading_day as trading_day,
Cumulatv_trading_day_wk as cum_trading_day_wk,
Cumulatv_trading_day_Mth as cum_trading_day_mth,
Total_trading_day_wk as tot_trading_day_wk,
Total_trading_day_month as tot_trading_day_mth,
DATEPART(QUARTER,cast(Dt_og as DATETIME)) qtr_id,
concat('Qtr-',DATEPART(QUARTER,cast(Dt_og as DATETIME))) as qtr_desc,
CASE WHEN DATEPART(QUARTER,cast(Dt_og as DATETIME)) >= 3 THEN 2 ELSE 1 END sem_id,
CASE WHEN DATEPART(QUARTER,cast(Dt_og as DATETIME)) >= 3 THEN 'Sem-2' ELSE 'Sem-1' END sem_desc
from dim_time;
GO


---------------------------------------------------------------------------------
/****** Object:  View [dbo].[Fact_DSS]    Script Date: 1/18/2021 1:16:49 PM ******/

/*
IF OBJECT_ID ( 'dbo.Fact_DSS', 'V' ) IS NOT NULL   
    DROP VIEW dbo.Fact_DSS;  
GO 

CREATE VIEW  [dbo].[Fact_DSS]
AS select product_code, InvoiceNumber, invoice_date from fact_daily_sales_staging

union 

select product_code, InvoiceNumber, invoice_date from fact_daily_sales;
GO

*/
---------------------------------------------------------------------------------
/****** Object:  View [dbo].[vw_check_object_stats]    Script Date: 1/18/2021 1:16:49 PM ******/


IF OBJECT_ID ( 'dbo.vw_check_object_stats', 'V' ) IS NOT NULL   
    DROP VIEW dbo.vw_check_object_stats;  
GO 

CREATE VIEW  [dbo].[vw_check_object_stats]
AS select 
objIdsWithStats.[object_id], 
actualRowCounts.[schema], 
actualRowCounts.logical_table_name, 
statsRowCounts.stats_row_count, 
actualRowCounts.actual_row_count,
row_count_difference = CASE
	WHEN actualRowCounts.actual_row_count >= statsRowCounts.stats_row_count THEN actualRowCounts.actual_row_count - statsRowCounts.stats_row_count
	ELSE statsRowCounts.stats_row_count - actualRowCounts.actual_row_count
END,
percent_deviation_from_actual = CASE
	WHEN actualRowCounts.actual_row_count = 0 THEN statsRowCounts.stats_row_count
	WHEN statsRowCounts.stats_row_count = 0 THEN actualRowCounts.actual_row_count
	WHEN actualRowCounts.actual_row_count >= statsRowCounts.stats_row_count THEN CONVERT(NUMERIC(18, 0), CONVERT(NUMERIC(18, 2), (actualRowCounts.actual_row_count - statsRowCounts.stats_row_count)) / CONVERT(NUMERIC(18, 2), actualRowCounts.actual_row_count) * 100)
	ELSE CONVERT(NUMERIC(18, 0), CONVERT(NUMERIC(18, 2), (statsRowCounts.stats_row_count - actualRowCounts.actual_row_count)) / CONVERT(NUMERIC(18, 2), actualRowCounts.actual_row_count) * 100)
END
from
(
	select distinct object_id from sys.stats where stats_id > 1
) objIdsWithStats
left join
(
	select object_id, sum(rows) as stats_row_count from sys.partitions group by object_id
) statsRowCounts
on objIdsWithStats.object_id = statsRowCounts.object_id 
left join
(
	SELECT sm.name [schema] ,
	tb.name logical_table_name ,
	tb.object_id object_id ,
	SUM(rg.row_count) actual_row_count
	FROM sys.schemas sm
	INNER JOIN sys.tables tb ON sm.schema_id = tb.schema_id
	INNER JOIN sys.pdw_table_mappings mp ON tb.object_id = mp.object_id
	INNER JOIN sys.pdw_nodes_tables nt ON nt.name = mp.physical_name
	INNER JOIN sys.dm_pdw_nodes_db_partition_stats rg
	ON rg.object_id = nt.object_id
	AND rg.pdw_node_id = nt.pdw_node_id
	AND rg.distribution_id = nt.distribution_id
	WHERE 1 = 1
	GROUP BY sm.name, tb.name, tb.object_id
) actualRowCounts
on objIdsWithStats.object_id = actualRowCounts.object_id;
GO


---------------------------------------------------------------------------------
/****** Object:  View [dbo].[vw_fact_daily_sales]    Script Date: 1/18/2021 1:16:49 PM ******/

IF OBJECT_ID ( 'dbo.vw_fact_daily_sales', 'V' ) IS NOT NULL   
    DROP VIEW dbo.vw_fact_daily_sales;  
GO 

CREATE VIEW  [dbo].[vw_fact_daily_sales] AS select 
country_code,
product_code,
dss.division,
invoice_number,
site_code_year,
transactional_distributor_code,
master_distributor_code,
transactional_site_code,
master_site_code,
transactional_outlet_code,
dss.master_outlet_code,
invoice_date,
transactional_salesman_code,
master_salesman_code,
salesman_product_group_code,
transactional_spg,
isnull(master_spg,'UNASG') as master_spg,
dss.no_of_salespersons,
invoicetype,
customer_ZRSS_flag,
sales_ret_ref_invoice_number,
gross_sales_val,
gross_sales_val_mn,
net_invoice_val,
gross_sales_return_val,
sales_return_val,
on_invoice_discount_val,
value_added_tax,
off_inv_discount_val,
turn_over_val,
sales_with_return_pc_qty,
sales_return_pc_qty,
sales_pc_qty,
sales_cs_vol,
sales_kg_vol,
sales_lt_vol,
free_pc_qty,
salesforce,
brand,
category_code,
brand_cat_core,
cast(year_id as int) year_id,
cast(month_id as int) month_id,
cast(dss.time_key as int) time_key
from
(select
  country_code,
  dss.product_code,
  pd.division,
  invoice_number,
  site_code_year,
  transactional_distributor_code,
  isnull(master_distributor_code, transactional_distributor_code) as master_distributor_code,
  transactional_site_code,
  isnull(master_site_code, transactional_site_code) as master_site_code,
  transactional_outlet_code,
  isnull(om.master_outlet_code, transactional_outlet_code) as master_outlet_code,
  invoice_date,
  transactional_salesman_code,
  sm.salesman_product_group_code,
  sm.standardised_salesman_product_group transactional_spg, 
  isnull(cast(sm.no_of_salespersons_serving_outlet_in_this_spg as int),0) no_of_salespersons,
  invoicetype,
  customer_ZRSS_flag,
  sales_ret_ref_invoice_number,
  gross_sales_val,
  gsv_million as gross_sales_val_mn,
  net_invoice_val,
  gross_sales_return_val,
  sales_return_val,
  on_invoice_discount_val,
  value_added_tax,
  off_inv_discount_val,
  turn_over_val,
  sales_with_return_pc_qty,
  sales_return_pc_qty,
  sales_pc_qty,
  sales_cs_vol,
  sales_kg_vol,
  sales_lt_vol,
  free_pc_qty,
  dss.salesforce,
  dss.brand,
  dss.category_code,
  brand_cat_core,
  year_id,
  month_id,
  time_key
  from dbo.fact_daily_sales dss
  left outer join 
  (select 
	old_outlet_code,
	new_outlet_code as master_outlet_code,
	distributor_code as master_distributor_code,
	site_code as master_site_code
	from hist_outlet_map
  ) om 
  on dss.transactional_outlet_code = om.old_outlet_code
  left outer join dim_salesman sm 
  on dss.transactional_salesman_code= sm.salesman_code
  left outer join dim_product pd
  on dss.product_code = pd.product_code
) dss
left outer join ref_hist_spg_map spg
on dss.master_outlet_code= spg.master_outlet_code
and dss.division= spg.division;

GO


---------------------------------------------------------------------------------
/****** Object:  View [dbo].[vw_tgt_distributor_site_category_aggregate_gsv]    Script Date: 1/18/2021 1:16:49 PM ******/
/*

IF OBJECT_ID ( 'dbo.vw_tgt_distributor_site_category_aggregate_gsv', 'V' ) IS NOT NULL   
    DROP VIEW dbo.vw_tgt_distributor_site_category_aggregate_gsv;  
GO 

CREATE VIEW  [dbo].[vw_tgt_distributor_site_category_aggregate_gsv] AS SELECT year, month, transactional_distributor_code, transactional_site_code, transactional_outlet_code , T.category_code , new_outlet_code , ot.distributor_code as new_distributor_code, ot.site_code as new_site_code, GSV
FROM [dbo].[hist_outlet_map] ot

join 
(

select year, month , transactional_distributor_code, transactional_site_code, transactional_outlet_code, ds.category_code, sum (GrossSalesValue) as GSV
FROM  [dbo].[fact_daily_sales] ds

JOIN [dbo].[dim_product] p

on p.product_code = ds.product_code

JOIN [dbo].[dim_time] t 

on t.Dt = ds.invoice_date

where transactional_outlet_code != master_outlet_code -- and last_modified_datetime >  dateadd(dd, -7, current_timestamp)

group by year, month, transactional_distributor_code, transactional_site_code, transactional_outlet_code, ds.category_code
) T 
on T.transactional_outlet_code = ot.old_outlet_code;
GO

*/
---------------------------------------------------------------------------------


/****** Object:  View [dbo].[vw_TableSizes]    Script Date: 1/18/2021 1:16:49 PM ******/
IF OBJECT_ID ( 'dbo.vw_TableSizes', 'V' ) IS NOT NULL   
    DROP VIEW dbo.vw_TableSizes;  
GO 


CREATE VIEW [dbo].[vw_TableSizes]
AS WITH base
AS
(
SELECT
 GETDATE()                                                             AS  [execution_time]
, DB_NAME()                                                            AS  [database_name]
, s.name                                                               AS  [schema_name]
, t.name                                                               AS  [table_name]
, QUOTENAME(s.name)+'.'+QUOTENAME(t.name)                              AS  [two_part_name]
, nt.[name]                                                            AS  [node_table_name]
, ROW_NUMBER() OVER(PARTITION BY nt.[name] ORDER BY (SELECT NULL))     AS  [node_table_name_seq]
, tp.[distribution_policy_desc]                                        AS  [distribution_policy_name]
, c.[name]                                                             AS  [distribution_column]
, nt.[distribution_id]                                                 AS  [distribution_id]
, i.[type]                                                             AS  [index_type]
, i.[type_desc]                                                        AS  [index_type_desc]
, nt.[pdw_node_id]                                                     AS  [pdw_node_id]
, pn.[type]                                                            AS  [pdw_node_type]
, pn.[name]                                                            AS  [pdw_node_name]
, di.name                                                              AS  [dist_name]
, di.position                                                          AS  [dist_position]
, nps.[partition_number]                                               AS  [partition_nmbr]
, nps.[reserved_page_count]                                            AS  [reserved_space_page_count]
, nps.[reserved_page_count] - nps.[used_page_count]                    AS  [unused_space_page_count]
, nps.[in_row_data_page_count]
    + nps.[row_overflow_used_page_count]
    + nps.[lob_used_page_count]                                        AS  [data_space_page_count]
, nps.[reserved_page_count]
 - (nps.[reserved_page_count] - nps.[used_page_count])
 - ([in_row_data_page_count]
         + [row_overflow_used_page_count]+[lob_used_page_count])       AS  [index_space_page_count]
, nps.[row_count]                                                      AS  [row_count]
from
    sys.schemas s
INNER JOIN sys.tables t
    ON s.[schema_id] = t.[schema_id]
INNER JOIN sys.indexes i
    ON  t.[object_id] = i.[object_id]
    AND i.[index_id] <= 1
INNER JOIN sys.pdw_table_distribution_properties tp
    ON t.[object_id] = tp.[object_id]
INNER JOIN sys.pdw_table_mappings tm
    ON t.[object_id] = tm.[object_id]
INNER JOIN sys.pdw_nodes_tables nt
    ON tm.[physical_name] = nt.[name]
INNER JOIN sys.dm_pdw_nodes pn
    ON  nt.[pdw_node_id] = pn.[pdw_node_id]
INNER JOIN sys.pdw_distributions di
    ON  nt.[distribution_id] = di.[distribution_id]
INNER JOIN sys.dm_pdw_nodes_db_partition_stats nps
    ON nt.[object_id] = nps.[object_id]
    AND nt.[pdw_node_id] = nps.[pdw_node_id]
    AND nt.[distribution_id] = nps.[distribution_id]
LEFT OUTER JOIN (select * from sys.pdw_column_distribution_properties where distribution_ordinal = 1) cdp
    ON t.[object_id] = cdp.[object_id]
LEFT OUTER JOIN sys.columns c
    ON cdp.[object_id] = c.[object_id]
    AND cdp.[column_id] = c.[column_id]
WHERE pn.[type] = 'COMPUTE'
)
, size
AS
(
SELECT
   [execution_time]
,  [database_name]
,  [schema_name]
,  [table_name]
,  [two_part_name]
,  [node_table_name]
,  [node_table_name_seq]
,  [distribution_policy_name]
,  [distribution_column]
,  [distribution_id]
,  [index_type]
,  [index_type_desc]
,  [pdw_node_id]
,  [pdw_node_type]
,  [pdw_node_name]
,  [dist_name]
,  [dist_position]
,  [partition_nmbr]
,  [reserved_space_page_count]
,  [unused_space_page_count]
,  [data_space_page_count]
,  [index_space_page_count]
,  [row_count]
,  ([reserved_space_page_count] * 8.0)                                 AS [reserved_space_KB]
,  ([reserved_space_page_count] * 8.0)/1000                            AS [reserved_space_MB]
,  ([reserved_space_page_count] * 8.0)/1000000                         AS [reserved_space_GB]
,  ([reserved_space_page_count] * 8.0)/1000000000                      AS [reserved_space_TB]
,  ([unused_space_page_count]   * 8.0)                                 AS [unused_space_KB]
,  ([unused_space_page_count]   * 8.0)/1000                            AS [unused_space_MB]
,  ([unused_space_page_count]   * 8.0)/1000000                         AS [unused_space_GB]
,  ([unused_space_page_count]   * 8.0)/1000000000                      AS [unused_space_TB]
,  ([data_space_page_count]     * 8.0)                                 AS [data_space_KB]
,  ([data_space_page_count]     * 8.0)/1000                            AS [data_space_MB]
,  ([data_space_page_count]     * 8.0)/1000000                         AS [data_space_GB]
,  ([data_space_page_count]     * 8.0)/1000000000                      AS [data_space_TB]
,  ([index_space_page_count]  * 8.0)                                   AS [index_space_KB]
,  ([index_space_page_count]  * 8.0)/1000                              AS [index_space_MB]
,  ([index_space_page_count]  * 8.0)/1000000                           AS [index_space_GB]
,  ([index_space_page_count]  * 8.0)/1000000000                        AS [index_space_TB]
FROM base
)
SELECT *
FROM size;
GO

---------------------------------------------------------------------------------
/****** Object:  View [dbo].[vw_data_vol_report]    Script Date: 1/18/2021 1:16:49 PM ******/

IF OBJECT_ID ( 'dbo.vw_data_vol_report', 'V' ) IS NOT NULL   
    DROP VIEW dbo.vw_data_vol_report;  
GO 

CREATE VIEW [dbo].[vw_data_vol_report]
AS SELECT
     database_name
,    schema_name
,    table_name
,    distribution_policy_name
,      distribution_column
,    index_type_desc
,    COUNT(distinct partition_nmbr) as nbr_partitions
,    SUM(row_count)                 as table_row_count
,    SUM(reserved_space_GB)         as table_reserved_space_GB
,    SUM(data_space_GB)             as table_data_space_GB
,    SUM(index_space_GB)            as table_index_space_GB
,    SUM(unused_space_GB)           as table_unused_space_GB
FROM
    dbo.vw_TableSizes
GROUP BY
     database_name
,    schema_name
,    table_name
,    distribution_policy_name
,      distribution_column
,    index_type_desc
;
GO