--vw_dim_outlet
--vw_local_product_hierarchy

print('Creating TTS Views ..')

IF OBJECT_ID ( 'dbo.vw_dim_outlet', 'V' ) IS NOT NULL   
    DROP VIEW [dbo].[vw_dim_outlet];  
GO 

CREATE VIEW [dbo].[vw_dim_outlet]
AS select distinct
ot.outlet_code,
ot.outlet_name,
ot.outletstatuscode,
case when upper(chn.group_channel) ='PROFESSIONAL' then 'PROFESSIONAL'
	 when upper(chn.group_channel) ='IC' then 'IC'
     else chn.channel
end channel,
perfect_store
from dim_outlet ot
inner join dim_channel chn on chn.channel= ot.channel;
GO


IF OBJECT_ID ( 'dbo.vw_local_product_hierarchy', 'V' ) IS NOT NULL   
    DROP VIEW [dbo].[vw_local_product_hierarchy];  
GO 

CREATE VIEW [dbo].[vw_local_product_hierarchy]
AS select c.*,
case when c.product_code='NA' then 'Unassigned'
	 when (c.product_code!='NA' and (c.banded_flag+c.banded_PH8_level)>0) then 'Banded' else 'Non-Banded' end as banded
from
(select
b.*,
case when PATINDEX('%([1-9]+[A-z0-9]%', am.material_desc)!=0 then 1 else 0 end as banded_flag,
case when PATINDEX('%BANDED%', upper(am.PH8_description))!=0 then 1 else 0 end as banded_PH8_level
from 
(select
cast(a.product_code as varchar(50)) product_code,
--a.product_code,
a.dp_name,
a.cotc,
a.packsize,
a.packgroup,
a.brand_variant,
a.subbrand,
a.brand,
a.segment,
a.ccbt,
a.category,
a.category_code,
a.division,
a.cd_view_1,
a.cd_view_2,
a.sorting_index from
dbo.dim_product a
union all
select 'NA' as product_code,'Unassigned' as dp_name,'Unassigned' as cotc,'Unassigned' as packsize,'Unassigned'as packgroup,'Unassigned' as brand_variant,'Unassigned' as subbrand,'Unassigned' as brand,'Unassigned' as segment,'Unassigned' as ccbt,'Unassigned' as category, 'Unassigned' as category_code, 'Unassigned' as division,'Unassigned' as cd_view_1,'Unassigned' as cd_view_2,null as sorting_index) as b 
left join dbo.dim_article_master am
on b.product_code=am.material_code) as c;
GO

print('TTS Views created..')




