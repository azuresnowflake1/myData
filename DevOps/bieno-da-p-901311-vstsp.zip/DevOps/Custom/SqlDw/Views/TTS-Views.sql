--vw_dim_outlet
--vw_local_product_hierarchy

print('Creating TTS Views ..')

IF OBJECT_ID ( 'dbo.vw_dim_outlet', 'V' ) IS NOT NULL   
    DROP VIEW [dbo].[vw_dim_outlet];  
GO 

CREATE VIEW [dbo].[vw_dim_outlet]
AS select distinct
ot.outlet_code,
ot.outlet_name,
ot.outletstatuscode,
case when upper(chn.group_channel) ='PROFESSIONAL' then 'PROFESSIONAL'
	 when upper(chn.group_channel) ='IC' then 'IC'
     else chn.channel
end channel,
perfect_store
from dim_outlet ot
inner join dim_channel chn on chn.channel= ot.channel;
GO


IF OBJECT_ID ( 'dbo.vw_local_product_hierarchy', 'V' ) IS NOT NULL   
    DROP VIEW [dbo].[vw_local_product_hierarchy];  
GO 

CREATE VIEW [dbo].[vw_local_product_hierarchy]
AS select c.*,
case when c.product_code='NA' then 'Not Assigned'
	 when (c.product_code!='NA' and (c.banded_flag+c.banded_PH8_level)>0) then 'Banded' else 'Non-Banded' end as banded
from
(select
b.*,
case when PATINDEX('%([1-9]+[A-z0-9]%', am.material_desc)!=0 then 1 else 0 end as banded_flag,
case when PATINDEX('%BANDED%', upper(am.PH8_description))!=0 then 1 else 0 end as banded_PH8_level
from 
(select
cast(a.product_code as varchar(50)) product_code,
--a.product_code,
a.dp_name,
a.cotc,
a.packsize,
a.packgroup,
a.brand_variant,
a.subbrand,
a.brand,
a.segment,
a.ccbt,
a.category,
a.category_code,
a.division,
a.cd_view_1,
a.cd_view_2,
(case when a.category='Not Assigned' then 10000 else a.sorting_index end) sorting_index from
dbo.dim_product a
union all
select 'NA' as product_code,'Not Assigned' as dp_name,'Not Assigned' as cotc,'Not Assigned' as packsize,'Not Assigned'as packgroup,'Not Assigned' as brand_variant,'Not Assigned' as subbrand,'Not Assigned' as brand,'Not Assigned' as segment,'Not Assigned' as ccbt,'Not Assigned' as category, 'Not Assigned' as category_code, 'Not Assigned' as division,'Not Assigned' as cd_view_1,'Not Assigned' as cd_view_2,10000 as sorting_index) as b 
left join dbo.dim_article_master am
on b.product_code=am.material_code) as c;
GO


IF OBJECT_ID ( 'dbo.vw_dim_month', 'V' ) IS NOT NULL   
    DROP VIEW dbo.vw_dim_month;  
GO 

CREATE VIEW [dbo].[vw_dim_month]
AS select * from
(select distinct(convert(varchar(25),EOMONTH(a.[day]),112)) 'time_month_key'
--,EOMONTH(a.[day]) as 'day'                                    
,EOMONTH(a.[day]) as 'day'
,datepart(week,EOMONTH(a.[day])) as 'week_of_year'
,a.month_id 
,a.month_name
,a.qtr_id
,a.qtr_desc
,a.sem_id
,a.year_id
,concat(cast(a.month_key as varchar(25)),'01') as 'start_day'
,concat(format(dateadd(month,-1,a.[day]),'MMM'),'-',format(a.[day],'yy')) as 'prev_month'
,concat(format(a.[day],'MMM'),'-',format(dateadd(year,-1,a.[day]),'yy')) as 'prev_year_same_month'
from dbo.vw_dim_time a) b
where cast(b.time_month_key as int)>=(select min(time_key) from [dbo].[fact_monthly_promo_agg])
 and
cast(b.time_month_key as int)<=(select max(time_key) from [dbo].[fact_monthly_promo_agg]);
GO


print('TTS Views created..')




