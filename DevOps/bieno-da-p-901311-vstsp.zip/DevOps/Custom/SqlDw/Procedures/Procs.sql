IF OBJECT_ID ( 'dbo.computeStatsFactDailySales', 'P' ) IS NOT NULL   
    DROP PROCEDURE dbo.computeStatsFactDailySales;  
GO 
 
CREATE PROC [dbo].[computeStatsFactDailySales] AS
BEGIN

--CREATE STATISTICS stats_dss_time_key ON dbo.fact_daily_sales (time_key);
--CREATE STATISTICS stats_dss_year_id ON dbo.fact_daily_sales (year_id);
--CREATE STATISTICS stats_dss_month_id ON dbo.fact_daily_sales (month_id);
--CREATE STATISTICS stats_dss_txn_outlet ON dbo.fact_daily_sales (transactional_outlet_code);

UPDATE STATISTICS dbo.fact_daily_sales (stats_dss_time_key);
UPDATE STATISTICS dbo.fact_daily_sales (stats_dss_year_id);
UPDATE STATISTICS dbo.fact_daily_sales (stats_dss_month_id);
UPDATE STATISTICS dbo.fact_daily_sales (stats_dss_txn_outlet);

UPDATE STATISTICS dbo.fact_daily_sales;

-- DEPENDENT TABLES UPDATE STATS

update statistics hist_outlet_map;
update statistics dim_salesman;
update statistics dim_product;
update statistics ref_hist_spg_map;

END;
GO