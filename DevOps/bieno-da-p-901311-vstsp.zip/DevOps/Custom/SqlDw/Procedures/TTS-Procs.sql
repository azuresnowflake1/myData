
IF OBJECT_ID ( 'dbo.computeStatsFactDailyPromo', 'P' ) IS NOT NULL   
    DROP PROCEDURE dbo.computeStatsFactDailyPromo;  
GO 


CREATE PROC [dbo].[computeStatsFactDailyPromo] AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    --SET NOCOUNT ON

	--CREATE STATISTICS stats_nrmdss_time_key ON dbo.dbo.fact_daily_promotions (time_key);
	--CREATE STATISTICS stats_nrmdss_year_id ON dbo.dbo.fact_daily_promotions (year_id);
	--CREATE STATISTICS stats_nrmdss_month_id ON dbo.dbo.fact_daily_promotions (month_id);
	--CREATE STATISTICS stats_nrmdss_outlet_code ON dbo.dbo.fact_daily_promotions (outlet_code);
	--CREATE STATISTICS stats_nrmdss_promotion_id ON dbo.dbo.fact_daily_promotions (promotion_id);

UPDATE STATISTICS dbo.fact_daily_promotions (stats_nrmdss_time_key);
UPDATE STATISTICS dbo.fact_daily_promotions(stats_nrmdss_year_id);
UPDATE STATISTICS dbo.fact_daily_promotions (stats_nrmdss_month_id);
UPDATE STATISTICS dbo.fact_daily_promotions (stats_nrmdss_outlet_code);
UPDATE STATISTICS dbo.fact_daily_promotions (stats_nrmdss_promotion_id);

UPDATE STATISTICS dbo.fact_daily_promotions;

	-- Insert statements for procedure here
    --SELECT <@Param1, sysname, @p1>, <@Param2, sysname, @p2>

END
GO




IF OBJECT_ID ( 'dbo.computeStatsFactMonthlyPromo', 'P' ) IS NOT NULL   
    DROP PROCEDURE dbo.computeStatsFactMonthlyPromo;  
GO 

CREATE PROC [dbo].[computeStatsFactMonthlyPromo] AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    --SET NOCOUNT ON

	--CREATE STATISTICS stats_nrmdss_agg_time_key ON dbo.fact_monthly_promo_agg (time_key);
	--CREATE STATISTICS stats_nrmdss_agg_year_id ON dbo.fact_monthly_promo_agg (year_id);
	--CREATE STATISTICS stats_nrmdss_agg_month_id ON dbo.fact_monthly_promo_agg (month_id);
	--CREATE STATISTICS stats_nrmdss_agg_outlet_code ON dbo.fact_monthly_promo_agg (outlet_code);
	--CREATE STATISTICS stats_nrmdss_agg_promotion_id ON dbo.fact_monthly_promo_agg (promotion_id);

UPDATE STATISTICS dbo.fact_monthly_promo_agg (stats_nrmdss_agg_time_key);
UPDATE STATISTICS dbo.fact_monthly_promo_agg (stats_nrmdss_agg_year_id);
UPDATE STATISTICS dbo.fact_monthly_promo_agg (stats_nrmdss_agg_month_id);
UPDATE STATISTICS dbo.fact_monthly_promo_agg (stats_nrmdss_agg_outlet_code);
UPDATE STATISTICS dbo.fact_monthly_promo_agg (stats_nrmdss_agg_promotion_id);

UPDATE STATISTICS dbo.fact_monthly_promo_agg;

	-- Insert statements for procedure here
    --SELECT <@Param1, sysname, @p1>, <@Param2, sysname, @p2>

END
GO


IF OBJECT_ID ( 'dbo.computeStatsFactMonthlySales', 'P' ) IS NOT NULL   
    DROP PROCEDURE dbo.computeStatsFactMonthlySales;  
GO 

CREATE PROC [dbo].[computeStatsFactMonthlySales] AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    --SET NOCOUNT ON

	--CREATE STATISTICS stats_dss_agg_time_key ON dbo.fact_monthly_sales_agg (time_key);
	--CREATE STATISTICS stats_dss_agg_year_id ON dbo.fact_monthl_sales_agg (year_id);
	--CREATE STATISTICS stats_dss_agg_month_id ON dbo.fact_monthly_sales_agg (month_id);
	--CREATE STATISTICS stats_dss_agg_txn_outlet_code ON dbo.fact_monthly_sales_agg (transactional_outlet_code);
	
	UPDATE STATISTICS dbo.fact_monthly_sales_agg (stats_dss_agg_time_key);
	UPDATE STATISTICS dbo.fact_monthly_sales_agg (stats_dss_agg_year_id);
	UPDATE STATISTICS dbo.fact_monthly_sales_agg (stats_dss_agg_month_id);
	UPDATE STATISTICS dbo.fact_monthly_sales_agg (stats_dss_agg_txn_outlet_code);
	

	UPDATE STATISTICS dbo.fact_monthly_sales_agg;

	-- Insert statements for procedure here
    --SELECT <@Param1, sysname, @p1>, <@Param2, sysname, @p2>

END
GO