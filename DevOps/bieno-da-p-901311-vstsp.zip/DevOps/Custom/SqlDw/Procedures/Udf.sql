/****** Object:  UserDefinedFunction [dbo].[lpad]    Script Date: 1/18/2021 2:06:11 PM ******/
DROP FUNCTION IF EXISTS [dbo].[lpad]
GO

CREATE FUNCTION [dbo].[lpad] (@string [VARCHAR](MAX),@length [INT],@pad [CHAR]) RETURNS VARCHAR(MAX)
AS
BEGIN
    RETURN replicate(@pad, @length - len(@string)) + @string;
END
GO