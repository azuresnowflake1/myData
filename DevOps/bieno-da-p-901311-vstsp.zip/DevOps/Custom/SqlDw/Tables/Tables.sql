--------------------------------------------------------------------------------------
print('Creating Tables now...');

IF NOT EXISTS (select 'a' FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='access_control' and TABLE_SCHEMA = 'dbo')
CREATE TABLE [dbo].[access_control]
(
	[site_code] [varchar](20) NULL,
	[email_addr] [nvarchar](255) NULL,
	[Role] [nvarchar](250) NULL,
	[Role_biz] [nvarchar](250) NULL,
	[key_col] [nvarchar](250) NULL
	
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
);


IF NOT EXISTS (select 'a' FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='dim_distributor' and TABLE_SCHEMA = 'dbo')
CREATE TABLE [dbo].[dim_distributor]
(
	[country_code] [varchar](100) NULL,
	[site_code] [varchar](100) NOT NULL,
	[site_name] [nvarchar](100) NULL,
	[distributor_code] [varchar](30) NULL,
	[distributor_type] [varchar](100) NULL,
	[distributor_name] [nvarchar](100) NULL,
	[dt_region] [nvarchar](100) NULL,
	[dt_area] [nvarchar](100) NULL,
	[dt_district] [varchar](100) NULL,
	[salesorg] [varchar](100) NULL,
 CONSTRAINT [Cnstr_dee346eb393d498384cc0aaed91f0af5] PRIMARY KEY NONCLUSTERED 
	(
		[site_code] ASC
	) NOT ENFORCED 
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
);

IF NOT EXISTS (select 'a' FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='dim_salesman' and TABLE_SCHEMA = 'dbo')
CREATE TABLE [dbo].[dim_salesman]
(
	[salesman_code] [int] NOT NULL,
	[site_code] [varchar](100) NULL,
	[salesman_product_group_code] [varchar](100) NULL,
	[salesman_product_group] [varchar](100) NULL,
	[standardised_salesman_product_group] [varchar](100) NULL,
	[salesforce] [varchar](100) NULL,
	[kpi_in_scope] [varchar](100) NULL,
	[role_business_scope_assignment] [varchar](100) NULL,
	[no_of_salespersons_serving_outlet_in_this_spg] [varchar](100) NULL,
	[expected_spg] [varchar](100) NULL,
	[BM] [nvarchar](100) NULL,
	[ASM] [nvarchar](100) NULL,
	[Supervisor] [nvarchar](100) NULL,
	[salesman_name] [nvarchar](250) NULL,
 CONSTRAINT [Cnstr_1a2da5fe53f94d6fa80dd11b8924f6b7] PRIMARY KEY NONCLUSTERED 
	(
		[salesman_code] ASC
	) NOT ENFORCED 
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
);


IF NOT EXISTS (select 'a' FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='dim_outlet' and TABLE_SCHEMA = 'dbo')
CREATE TABLE [dbo].[dim_outlet]
(
	[outlet_code] [varchar](100) NOT NULL,
	[outletsubtypecode] [varchar](100) NULL,
	[outletstatuscode] [varchar](100) NULL,
	[channel] [varchar](100) NULL,
	[perfect_store] [varchar](20) NULL,
	[sorting_index] [int] NULL,
	[outlet_name] [nvarchar](250) NULL,
 CONSTRAINT [Cnstr_faf53855dc2c4dd6a2eeedbfda72f37a] PRIMARY KEY NONCLUSTERED 
	(
		[outlet_code] ASC
	) NOT ENFORCED 
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
);

IF NOT EXISTS (select 'a' FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='dim_product' and TABLE_SCHEMA = 'dbo')
CREATE TABLE [dbo].[dim_product]
(
	[product_code] [int] NOT NULL,
	[dp_name] [nvarchar](100) NULL,
	[cotc] [varchar](30) NULL,
	[packsize] [varchar](100) NULL,
	[packgroup] [varchar](100) NULL,
	[brand_variant] [varchar](100) NULL,
	[subbrand] [varchar](100) NULL,
	[brand] [varchar](100) NULL,
	[segment] [varchar](100) NULL,
	[ccbt] [varchar](100) NULL,
	[category] [varchar](100) NULL,
	[category_code] [varchar](100) NULL,
	[division] [varchar](100) NULL,
	[cd_view_1] [varchar](100) NULL,
	[cd_view_2] [varchar](100) NULL,
	[sorting_index] [int] NULL,
 CONSTRAINT [Cnstr_6cf3d39035a242bfac8f2491058b7a6a] PRIMARY KEY NONCLUSTERED 
	(
		[product_code] ASC
	) NOT ENFORCED 
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
);


IF NOT EXISTS (select 'a' FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='dim_time' and TABLE_SCHEMA = 'dbo')
CREATE TABLE [dbo].[dim_time]
(
	[Dt_og] [date] NULL,
	[Dt] [int] NOT NULL,
	[year_month] [int] NULL,
	[Month] [varchar](30) NULL,
	[Day] [varchar](30) NULL,
	[Wk] [int] NULL,
	[Year] [int] NULL,
	[Wk_year] [varchar](30) NULL,
	[Trading_day] [int] NULL,
	[Cumulatv_trading_day_wk] [int] NULL,
	[Cumulatv_trading_day_Mth] [int] NULL,
	[Total_trading_day_wk] [int] NULL,
	[Total_trading_day_month] [int] NULL,
	[startofweekCY] [date] NULL,
	[endofweekCY] [date] NULL,
	[startofweekPY] [date] NULL,
	[endofweekPY] [date] NULL,
	[startofmonthCY] [date] NULL,
	[startofmonthPY] [date] NULL,
	[past13week] [varchar](10) NULL,
	[past8week] [varchar](10) NULL,
	[past4week] [varchar](10) NULL,
 CONSTRAINT [Cnstr_935cfc3db4db40f6b04991122694ac17] PRIMARY KEY NONCLUSTERED 
	(
		[Dt] ASC
	) NOT ENFORCED 
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
);

IF NOT EXISTS (select 'a' FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='fact_daily_sales' and TABLE_SCHEMA = 'dbo')
CREATE TABLE [dbo].[fact_daily_sales]
(
	[country_code] [nvarchar](50) NULL,
	[product_code] [nvarchar](50) NULL,
	[invoice_number] [nvarchar](50) NULL,
	[site_code_year] [nvarchar](50) NULL,
	[transactional_distributor_code] [nvarchar](50) NULL,
	[transactional_site_code] [nvarchar](50) NULL,
	[transactional_outlet_code] [nvarchar](50) NULL,
	[invoice_date] [date] NULL,
	[transactional_salesman_code] [nvarchar](50) NULL,
	[invoicetype] [nvarchar](50) NULL,
	[customer_ZRSS_flag] [nvarchar](50) NULL,
	[sales_ret_ref_invoice_number] [nvarchar](50) NULL,
	[gross_sales_val] [float] NULL,
	[gsv_million] [float] NULL,
	[net_invoice_val] [float] NULL,
	[gross_sales_return_val] [float] NULL,
	[sales_return_val] [float] NULL,
	[on_invoice_discount_val] [float] NULL,
	[value_added_tax] [float] NULL,
	[off_inv_discount_val] [float] NULL,
	[turn_over_val] [float] NULL,
	[sales_with_return_pc_qty] [int] NULL,
	[sales_return_pc_qty] [int] NULL,
	[sales_pc_qty] [int] NULL,
	[sales_cs_vol] [float] NULL,
	[sales_kg_vol] [float] NULL,
	[sales_lt_vol] [float] NULL,
	[free_pc_qty] [int] NULL,
	[salesforce] [nvarchar](100) NULL,
	[brand] [nvarchar](100) NULL,
	[category_code] [nvarchar](50) NULL,
	[brand_cat_core] [nvarchar](100) NULL,
	[year_id] [int] NULL,
	[month_id] [int] NULL,
	[time_key] [int] NULL,
	[insert_ts] [datetime] NULL,
	[update_ts] [datetime] NULL
)
WITH
(
	DISTRIBUTION = HASH ( [transactional_outlet_code] ),
	CLUSTERED COLUMNSTORE INDEX
);


IF NOT EXISTS (select 'a' FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='fact_kpi' and TABLE_SCHEMA = 'dbo')
CREATE TABLE [dbo].[fact_kpi]
(
dt int,
wk int,
planned_calls_weekly int,
actual_calls_weekly int,
salesforce varchar(50),
salesman_product_group varchar(50),
salesman_code int,
[year] int,
actual_outlet_time int,
distributor_code varchar(50),
site_code varchar(50),
[month] varchar(50),
country varchar(50),
trading_day int,
trading_days_month int,
trading_days_passed int,
wk_wt float,
kpi_in_scope varchar(30),
trading_days_remaining int,
PC_target float,
ECO_target varchar(50),
EB_target varchar(50),
total_lines_target float,
assortment_target varchar(50),
FourP_target varchar(50),
cotc_target varchar(50),
wp_target varchar(50),
geo_target varchar(50),
non_pc_above_eot_target varchar(50),
pjp_target varchar(50),
RL_target varchar(50),
NPD_target varchar(50),
avg_time_spent_target float,
weekend_target_PC varchar(50),
remaining_target_PC float,
weekly_cumulative_PC_target float,
PC_target_monthly float,
key_col varchar(50),
Role_Business_Scope_Assignment varchar(50),
effective_outlet_time float,
geo_complied_calls int,
pjp_complied_calls int,
geo_complied_calls_weekly int,
pjp_complied_calls_weekly int,
planned_calls int,
total_sales_return bigint,
actual_calls int,
total_outlet_count float,
FourP_compliance_outlet float,
EB_target_abs float,
EB_actual float,
RL_target_abs float,
RL_actual float,
WP_target_abs float,
WP_actual float,
COTC_target_abs float,
COTC_actual float,
NPD_target_abs float,
NPD_actual float,
active_shop_in_pjp float,
eco_actual float,
calls_to_be_visited float,
sales_actual float,
PC float,
total_sku_line float,
lppc float,
sales_target bigint,
salesperson_with_target varchar(50),
assortment_target_abs float,
assortment_achieved float,
EOT_benchmark int,
week_flag int,
cum_wk_wt float,
sales_perc float,
sales_balance_to_hit float,
sales_balance_to_hit_daily float,
PC_target_month float,
PC_perc float,
PC_per_salesperson float,
PC_balance_to_hit float,
PC_balance_to_hit_daily float,
PJP_compliance float,
geo_compliance float,
avg_time_spent_daily float,
ECO_perc float,
ECO_balance_to_hit float,
total_lines_perc float,
total_lines_balance_to_hit_month float,
total_lines_balance_to_hit_daily float,
RL_perc float,
EB_perc float,
WP_perc float,
COTC_perc float,
NPD_perc float,
FourP_perc float,
Assortment_perc float,
Non_prod_pjp_above_eot float,
Non_prod_pjp float,
Non_pc_above_eot_perc float,
sales_status varchar(50),
PC_status varchar(50),
PJP_status varchar(50),
Geo_status varchar(50),
RL_status varchar(50),
avg_time_spent_status varchar(50),
EB_status varchar(50),
WP_status varchar(50),
total_lines_status varchar(50),
NPD_status varchar(50),
Assortment_status varchar(50),
COTC_status varchar(50),
FourP_status varchar(50),
ECO_status varchar(50),
non_PC_above_eot_status varchar(50),
recommendation_id int,
issue_type varchar(50),
performance varchar(50)
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
);


IF NOT EXISTS (select 'a' FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='fact_qualitystores' and TABLE_SCHEMA = 'dbo')
CREATE TABLE [dbo].[fact_qualitystores]
(
	[distributor_code] [varchar](50) NULL,
	[year] [int] NULL,
	[month] [varchar](20) NULL,
	[wk_no] [int] NULL,
	[total_month_flag] [varchar](10) NULL,
	[transactional_quality_stores] [int] NULL,
	[master_quality_stores] [int] NULL,
	[transactional_active_stores] [int] NULL,
	[master_active_stores] [int] NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
);

IF NOT EXISTS (select 'a' FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='tgt_distributor_site_product' and TABLE_SCHEMA = 'dbo')
CREATE TABLE [dbo].[tgt_distributor_site_product]
(
	[year] [int] NULL,
	[month] [varchar](10) NULL,
	[year_month] [int] NULL,
	[brand_cat_core] [varchar](100) NULL,
	[distributor_code] [varchar](30) NULL,
	[site_code] [varchar](100) NULL,
	[master_product_Category_code] [varchar](30) NULL,
	[brand] [varchar](50) NULL,
	[cotc] [varchar](50) NULL,
	[before_target_prod] [float] NULL,
	[after_target_prod] [float] NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
);

IF NOT EXISTS (select 'a' FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='tgt_distributor_site_category' and TABLE_SCHEMA = 'dbo')
CREATE TABLE [dbo].[tgt_distributor_site_category]
(
	[year] [int] NULL,
	[year_month] [int] NULL,
	[distributor_code] [int] NULL,
	[site_code] [varchar](20) NULL,
	[master_product_Category_code] [varchar](20) NULL,
	[month] [varchar](10) NULL,
	[before_transition_target] [float] NULL,
	[after_transition_target] [float] NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
);


IF NOT EXISTS (select 'a' FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='tgt_distributor_site_salesforce' and TABLE_SCHEMA = 'dbo')
CREATE TABLE [dbo].[tgt_distributor_site_salesforce]
(
	[year] [int] NULL,
	[month] [varchar](10) NULL,
	[year_month] [int] NULL,
	[distributor_code] [varchar](30) NULL,
	[site_code] [varchar](100) NULL,
	[salesforce] [varchar](30) NULL,
	[before_transition_target_sf] [float] NULL,
	[after_transition_target_sf] [float] NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
);

IF NOT EXISTS (select 'a' FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='ref_hist_spg_map' and TABLE_SCHEMA = 'dbo')
CREATE TABLE [dbo].[ref_hist_spg_map]
(
	[time_key] [int] NULL,
	[master_outlet_code] [nvarchar](30) NULL,
	[master_salesman_code] [nvarchar](30) NULL,
	[master_spg] [nvarchar](30) NULL,
	[division] [nvarchar](30) NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX
);

IF NOT EXISTS (select 'a' FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='hist_outlet_map' and TABLE_SCHEMA = 'dbo')
CREATE TABLE [dbo].[hist_outlet_map]
(
	[dt] [int] NULL,
	[old_outlet_code] [varchar](100) NULL,
	[new_outlet_code] [varchar](100) NULL,
	[distributor_code] [varchar](50) NULL,
	[site_code] [varchar](50) NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX
);

IF NOT EXISTS (select 'a' FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='map_spg_to_PH' and TABLE_SCHEMA = 'dbo')
CREATE TABLE [dbo].[map_spg_to_PH]
(
	[salesforce] [varchar](30) NULL,
	[standardised_SPG] [varchar](30) NULL,
	[product_hierarchy] [varchar](30) NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
);

IF NOT EXISTS (select 'a' FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='mid_dist_site' and TABLE_SCHEMA = 'dbo')
CREATE TABLE [dbo].[mid_dist_site]
(
	[distributor_code] [varchar](30) NULL,
	[site_code] [varchar](100) NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
);

IF NOT EXISTS (select 'a' FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='mid_prod_cat' and TABLE_SCHEMA = 'dbo')
CREATE TABLE [dbo].[mid_prod_cat]
(
	[category_code] [varchar](100) NULL,
	[sorting_index] [int] NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
);

IF NOT EXISTS (select 'a' FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='mid_prod_cat_core' and TABLE_SCHEMA = 'dbo')
CREATE TABLE [dbo].[mid_prod_cat_core]
(
	[brand] [varchar](100) NULL,
	[category_code] [varchar](100) NULL,
	[category_name] [varchar](100) NULL,
	[cotc] [varchar](30) NULL,
	[brand_cat_core] [varchar](100) NULL,
	[sorting_index] [int] NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
);

IF NOT EXISTS (select 'a' FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='mid_unique_sf' and TABLE_SCHEMA = 'dbo')
CREATE TABLE [dbo].[mid_unique_sf]
(
	[salesforce] [varchar](30) NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
);


IF NOT EXISTS (select 'a' FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='site_annual_target' and TABLE_SCHEMA = 'dbo')
CREATE TABLE [dbo].[site_annual_target]
(
	[year] [int] NULL,
	[site_code] [varchar](30) NULL,
	[site_code_year] [varchar](30) NOT NULL,
	[original_annual_growth_target] [float] NULL,
	[quality_stores_abs_target] [int] NULL,
	[dist_comment] [varchar](225) NULL,
 CONSTRAINT [Cnstr_471aadcd432746f6a1650c743ae7b011] PRIMARY KEY NONCLUSTERED 
	(
		[site_code_year] ASC
	) NOT ENFORCED 
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
);

IF NOT EXISTS (select 'a' FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='mid_access' and TABLE_SCHEMA = 'dbo')
CREATE TABLE [dbo].[mid_access]
(
	[site_code] [varchar](30) NULL,
	[role_biz] [nvarchar](250) NOT NULL,
	[key_col] [nvarchar](250) NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
);


IF NOT EXISTS (select 'a' FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='Month_Toggle' and TABLE_SCHEMA = 'dbo')
CREATE TABLE [dbo].[Month_Toggle]
(
	[header] [nvarchar](20) NULL
);


IF NOT EXISTS (select 'a' FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='Outlet_Toggle' and TABLE_SCHEMA = 'dbo')
CREATE TABLE [dbo].[Outlet_Toggle]
(
	[header] [nvarchar](20) NULL
);


IF NOT EXISTS (select 'a' FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='Executive_Column_Chart' and TABLE_SCHEMA = 'dbo')
CREATE TABLE [dbo].[Executive_Column_Chart]
(
	[header] [nvarchar](20) NULL,
	[index] integer
);

IF NOT EXISTS (select 'a' FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='HeaderGroupforSalespersonSummary' and TABLE_SCHEMA = 'dbo')
CREATE TABLE [dbo].[HeaderGroupforSalespersonSummary]
(
	[header] [nvarchar](100) NULL,
	[index] integer
);

IF NOT EXISTS (select 'a' FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='Issue_type' and TABLE_SCHEMA = 'dbo')
CREATE TABLE [dbo].[Issue_type]
(
	[Issue_type] [nvarchar](20) NULL
);

IF NOT EXISTS (select 'a' FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='kpi_group' and TABLE_SCHEMA = 'dbo')
CREATE TABLE [dbo].[kpi_group]
(
	[kpi_group] [nvarchar](20) NULL,
	[index] integer
);


IF NOT EXISTS (select 'a' FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='language_translations' and TABLE_SCHEMA = 'dbo')
CREATE TABLE [dbo].[language_translations]
(
    [language] [nvarchar](500) NULL
);


IF NOT EXISTS (select 'a' FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='fact_salesman_monthly_target' and TABLE_SCHEMA = 'dbo')
CREATE TABLE [dbo].[fact_salesman_monthly_target]
(
	[year] [int] NULL,
	[year_month] [int],
	[month] varchar(2),
	[site_code] [varchar](30) NULL,
	[target] [float] NULL,
	[SPG] [nvarchar](250) NULL
);

IF NOT EXISTS (select 'a' FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='fact_kpi_monthly_target' and TABLE_SCHEMA = 'dbo')
CREATE TABLE [dbo].[fact_kpi_monthly_target]
(
	[year] [int] NULL,
	[year_month] [int],
	[month] varchar(2),
	[kpi] [nvarchar](250) NULL,
	[target] [float] NULL,
	[SPG] [nvarchar](250) NULL
);


IF NOT EXISTS (select 'a' FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='fact_fcs_by_spg_target' and TABLE_SCHEMA = 'dbo')
CREATE TABLE [dbo].[fact_fcs_by_spg_target]
(
	[year_month] [int],
	[distributor_code] [varchar](30) NULL,
    salesman_code [varchar](30) NULL,
	[target] [float] NULL,
	[SPG] [nvarchar](250) NULL	
);


IF NOT EXISTS (select 'a' FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='comparison_group' and TABLE_SCHEMA = 'dbo')
CREATE TABLE [dbo].[comparison_group]
(
	[index] int,
	[comparison] [nvarchar](250) NULL
);


IF NOT EXISTS (select 'a' FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='selection_group' and TABLE_SCHEMA = 'dbo')
CREATE TABLE [dbo].[selection_group]
(
	[index] int,
	[kpi] [nvarchar](250) NULL
);


IF NOT EXISTS (select 'a' FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='ddb_tab3' and TABLE_SCHEMA = 'dbo')
CREATE TABLE [dbo].[ddb_tab3]
(
	[index] int,
	[header] [nvarchar](250) NULL
);


IF NOT EXISTS (select 'a' FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='measureT3' and TABLE_SCHEMA = 'dbo')
CREATE TABLE [dbo].[measureT3]
(
	[index] int,
	[measure] [nvarchar](250) NULL
);

IF NOT EXISTS (select 'a' FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='HeaderGroupforTable1' and TABLE_SCHEMA = 'dbo')
CREATE TABLE [dbo].[HeaderGroupforTable1]
(
	[index] int,
	[group] [nvarchar](250) NULL,
	[header] [nvarchar](250) NULL
);

IF NOT EXISTS (select 'a' FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='HeaderGroupforTable2' and TABLE_SCHEMA = 'dbo')
CREATE TABLE [dbo].[HeaderGroupforTable2]
(
	[index] int,
	[group] [nvarchar](250) NULL,
	[header] [nvarchar](250) NULL
);


IF NOT EXISTS (select 'a' FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='grp_hdr_idx' and TABLE_SCHEMA = 'dbo')
CREATE TABLE [dbo].[grp_hdr_idx]
(
	[header] [nvarchar](250) NULL,
	[group] [nvarchar](250) NULL,
	[index] int
);


IF NOT EXISTS (select 'a' FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='pct_hdr' and TABLE_SCHEMA = 'dbo')
CREATE TABLE [dbo].[pct_hdr]
(
	[header] [nvarchar](20) NULL,
	sorting_index int
);


IF NOT EXISTS (select 'a' FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='fact_dss_aggregate' and TABLE_SCHEMA = 'dbo')
CREATE TABLE [dbo].[fact_dss_aggregate]
(
total_sku_lines bigint,
non_zero_amount_bill_count bigint,
total_bill_count bigint,
salesman_product_group_code [nvarchar](50) NULL,
transactional_spg [nvarchar](50) NULL,
[transactional_distributor_code] [nvarchar](50) NULL,
[transactional_site_code] [nvarchar](50) NULL,
[transactional_outlet_code] [nvarchar](50) NULL,
[invoice_date] [date] NULL,
[transactional_salesman_code] [nvarchar](50) NULL,
[gross_sales_val] [float] NULL,
[net_invoice_val] [float] NULL,
[salesforce] [nvarchar](100) NULL,
invoice_range [nvarchar](100) NULL,
[year_id] [int] NULL,
[month_id] [int] NULL,
[time_key] [int] NULL,
[insert_ts] [datetime] NULL,
[update_ts] [datetime] NULL,
map_index int
)
WITH
(
DISTRIBUTION = HASH ( [transactional_outlet_code] ),
CLUSTERED COLUMNSTORE INDEX
);


GO

print('Table creation complete ..')
---------------------------------------------------------

print('Executing ALTER  script..')

IF NOT EXISTS (
  SELECT * 
  FROM   sys.columns 
  WHERE  object_id = OBJECT_ID(N'[dbo].[dim_PRODUCT]') 
         AND name = 'aux1'
)
ALTER TABLE DBO.dim_PRODUCT add aux1 varchar(20);
ALTER TABLE DBO.dim_PRODUCT alter column aux1 varchar(50);
go

IF NOT EXISTS (
  SELECT * 
  FROM   sys.columns 
  WHERE  object_id = OBJECT_ID(N'[dbo].[dim_outlet]') 
         AND name = 'location'
)
ALTER TABLE DBO.dim_outlet add location nvarchar(50);
go


IF EXISTS (
  SELECT * 
  FROM   sys.columns 
  WHERE  object_id = OBJECT_ID(N'[dbo].[dim_product]') 
         AND name = 'aux1'
)
ALTER TABLE DBO.dim_product drop column aux1;
GO


print('ALTER  script completed..')
--------------------------------------------------------------------------------------
print('Stats creation script completed..')


if NOT EXISTS (SELECT NAME  from sys.stats where name =N'stats_dss_month_id' 
and object_id=object_id(N'dbo.fact_daily_sales'))
CREATE STATISTICS   [stats_dss_month_id]  ON dbo.fact_daily_sales (month_id); 

if NOT EXISTS (SELECT NAME  from sys.stats where name =N'stats_dss_time_key' 
and object_id=object_id(N'dbo.fact_daily_sales'))
CREATE STATISTICS   [stats_dss_time_key]  ON dbo.fact_daily_sales (time_key);

if NOT EXISTS (SELECT NAME  from sys.stats where name =N'stats_dss_year_id' 
and object_id=object_id(N'dbo.fact_daily_sales'))
CREATE STATISTICS   [stats_dss_year_id]  ON dbo.fact_daily_sales (year_id); 

if NOT EXISTS (SELECT NAME  from sys.stats where name =N'stats_dss_txn_outlet' 
and object_id=object_id(N'dbo.fact_daily_sales'))
CREATE STATISTICS   [stats_dss_txn_outlet]  ON dbo.fact_daily_sales (transactional_outlet_code); 

print('Stats creation script completed..')

--------------------------------------------------------------------------------------
print('INSERT  script started..')

TRUNCATE TABLE dbo.Outlet_Toggle;

INSERT INTO dbo.Outlet_Toggle values('Before');
INSERT INTO dbo.Outlet_Toggle values('After');

TRUNCATE TABLE dbo.Month_Toggle;

INSERT INTO dbo.Month_Toggle values('Weekly');
INSERT INTO dbo.Month_Toggle values('Full Month');

TRUNCATE TABLE dbo.Executive_Column_Chart;

INSERT INTO dbo.Executive_Column_Chart values('MTD',1);
INSERT INTO dbo.Executive_Column_Chart values('YTD',2);
INSERT INTO dbo.Executive_Column_Chart values('Annual Target %',3);
INSERT INTO dbo.Executive_Column_Chart values('YTG %',4);

TRUNCATE TABLE dbo.HeaderGroupforSalespersonSummary;

INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('Sales Status', 1)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('PC Status', 2)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('Sales Target', 3) 	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('Sales Actual (MTD)', 4)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('Sales % to Target', 5)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('Balance to Hit: Sales (Month)', 6)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('Balance to Hit: Sales (Daily)', 7)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('Productive Calls Target', 8)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('PC (MTD)', 9)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('PC % to Target', 10)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('PC / Day per Salesperson', 11)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('Balance to Hit: PC (Month)', 12)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('Balance to Hit: PC (Daily)', 13)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('ECO % Target', 14)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('No. of Active Stores in PJP ', 15)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('ECO Actual (MTD)', 16)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('ECO %', 17)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('Balance to Hit: ECO (Month)', 18)	;
--Disciplinary	
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('PJP Status', 19)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('GEO Status', 20)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('PJP Compliance Target',21)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('PJP Compliance (Current Week)', 22)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('PJP Compliance (MTD)', 23)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('Geo Compliance Target', 24)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('Geo Compliance (Current Week)', 25)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('Geo Compliance (MTD)', 26)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('Average Time Spent (In Hrs) per day Target',27)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('Average Time Spent In Hrs (MTD) per day', 28)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('% of Non PC Above EOT Benchmark Target',29)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('EOT Benchmark (In Mins)',30)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('# Non Productive PJP Complied Calls above EOT Benchmark (MTD)',31)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('# Non Productive PJP Complied Calls Total (MTD)',32)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('% of Non PC Above EOT Benchmark', 33)	;
--FCS++	
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('Total Lines Status', 34)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('Total Lines Target', 35)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('Total Lines (MTD)', 36)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('Total Lines % to Target', 37)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('LPPC (MTD)', 38)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('Balance to Hit: Total Lines (Month)', 39)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('Balance to Hit: Total Lines (Daily)', 40)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('WP % Target',41)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('WP Target',42)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('WP Actual',43)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('%WP',44)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('NPD % Target',45)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('NPD Target',46)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('NPD Actual',47)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('%NPD' ,48)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('Assortment Target',49)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('Assortment Actual',50)	;
--Others-iQ	
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('RL % Target',51)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('Redline Target',52)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('Redline Actual',53)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('%RL ',54)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('EB % Target',55)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('EB Target',56)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('EB Actual',57)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('%EB',58)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('CotC % Target',59)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('CotC Target',60)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('CotC Actual',61)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('%CotC',62)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('4P Compliance % Target',63)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('Total Outlet Count',64)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('4P Compliance Outlet',65)	;
INSERT INTO dbo.HeaderGroupforSalespersonSummary values 	('4P Compliance %',66)	;

TRUNCATE TABLE dbo.issue_type;

INSERT INTO dbo.issue_type values('Disciplinary');
INSERT INTO dbo.issue_type values('Capability');
INSERT INTO dbo.issue_type values('IQ');
INSERT INTO dbo.issue_type values('Planning');
INSERT INTO dbo.issue_type values('No Issue');

TRUNCATE TABLE dbo.kpi_group;

INSERT INTO dbo.kpi_group values('Sales',1);
INSERT INTO dbo.kpi_group values('Disciplinary',2);
INSERT INTO dbo.kpi_group values('FCS++',3);
INSERT INTO dbo.kpi_group values('Others-iQ',4);

-- Language Translations
TRUNCATE TABLE dbo.language_translations;

INSERT INTO dbo.language_translations values('English');
INSERT INTO dbo.language_translations values('Vietnamese');

-- Comparison Group
TRUNCATE TABLE dbo.comparison_group;

INSERT INTO dbo.comparison_group values(1,'Absolute');
INSERT INTO dbo.comparison_group values(2,'Percent');


-- Selection Group
TRUNCATE TABLE dbo.selection_group;

INSERT INTO dbo.selection_group values(1,'Selected Date');
INSERT INTO dbo.selection_group values(2,'Previous Trading Day');
INSERT INTO dbo.selection_group values(3,'Avg MTD');
INSERT INTO dbo.selection_group values(4,'Avg L3M');

-- ddb_tab3
TRUNCATE TABLE dbo.ddb_tab3;

INSERT INTO dbo.ddb_tab3 values(1,'GSV');
INSERT INTO dbo.ddb_tab3 values(2,'Lines');
INSERT INTO dbo.ddb_tab3 values(3,'Bills');

-- measureT3
TRUNCATE TABLE dbo.measureT3;

INSERT INTO dbo.measureT3 values(1,'MTD/day');
INSERT INTO dbo.measureT3 values(2,'MTG/day');
INSERT INTO dbo.measureT3 values(3,'MTG/day - MTD/day');
INSERT INTO dbo.measureT3 values(4,'MTGvsMTD');

-- headergroupfortable1
TRUNCATE TABLE dbo.headergroupfortable1;

INSERT INTO dbo.headergroupfortable1 values(1,'Selected Date','#Bills');
INSERT INTO dbo.headergroupfortable1 values(1,'Selected Date','GSV');
INSERT INTO dbo.headergroupfortable1 values(1,'Selected Date','Lines');
INSERT INTO dbo.headergroupfortable1 values(5,'vs Previous Trading Day','#Bills');
INSERT INTO dbo.headergroupfortable1 values(5,'vs Previous Trading Day','GSV');
INSERT INTO dbo.headergroupfortable1 values(5,'vs Previous Trading Day','Lines');
INSERT INTO dbo.headergroupfortable1 values(6,'vs Avg MTD','#Bills');
INSERT INTO dbo.headergroupfortable1 values(6,'vs Avg MTD','GSV');
INSERT INTO dbo.headergroupfortable1 values(6,'vs Avg MTD','Lines');
INSERT INTO dbo.headergroupfortable1 values(7,'vs Avg L3M','#Bills');
INSERT INTO dbo.headergroupfortable1 values(7,'vs Avg L3M','GSV');
INSERT INTO dbo.headergroupfortable1 values(7,'vs Avg L3M','Lines');
INSERT INTO dbo.headergroupfortable1 values(8,'Avg MTD vs Avg L3M','#Bills');
INSERT INTO dbo.headergroupfortable1 values(8,'Avg MTD vs Avg L3M','GSV');
INSERT INTO dbo.headergroupfortable1 values(8,'Avg MTD vs Avg L3M','Lines');


-- headergroupfortable2
TRUNCATE TABLE dbo.headergroupfortable2;

INSERT INTO dbo.headergroupfortable2 values(1,'Today/Selective Date','#Bills');
INSERT INTO dbo.headergroupfortable2 values(1,'Today/Selective Date','GSV');
INSERT INTO dbo.headergroupfortable2 values(1,'Today/Selective Date','Lines');
INSERT INTO dbo.headergroupfortable2 values(5,'','% Contribution Bills');
INSERT INTO dbo.headergroupfortable2 values(5,'','% Contribution GSV');
INSERT INTO dbo.headergroupfortable2 values(5,'','% Contribution Lines');
INSERT INTO dbo.headergroupfortable2 values(5,'','GSV/Bills');
INSERT INTO dbo.headergroupfortable2 values(5,'','GSV/Lines');
INSERT INTO dbo.headergroupfortable2 values(5,'','Lines/Bills');


-- grp_hdr_idx
TRUNCATE TABLE dbo.grp_hdr_idx;

INSERT INTO dbo.grp_hdr_idx values('Abs MTD','Bills date (date with bills)',1);
INSERT INTO dbo.grp_hdr_idx values('Abs MTD','GSV',1);
INSERT INTO dbo.grp_hdr_idx values('Abs MTD','Lines',1);
INSERT INTO dbo.grp_hdr_idx values('%Ach vs Norm target','Bills date (date with bills)',2);
INSERT INTO dbo.grp_hdr_idx values('%Ach vs Norm target','GSV',2);
INSERT INTO dbo.grp_hdr_idx values('%Ach vs Norm target','Lines',2);
INSERT INTO dbo.grp_hdr_idx values('%Ach vs Total target','Bills date (date with bills)',3);
INSERT INTO dbo.grp_hdr_idx values('%Ach vs Total target','GSV',3);
INSERT INTO dbo.grp_hdr_idx values('%Ach vs Total target','Lines',3);



-- pct_hdr
TRUNCATE TABLE dbo.pct_hdr;

INSERT INTO dbo.pct_hdr values('50%',1);
INSERT INTO dbo.pct_hdr values('80%',2);
INSERT INTO dbo.pct_hdr values('90%',3);
INSERT INTO dbo.pct_hdr values('100%',4);


go
--------------------------------------------------------------------------------------
print('INSERT  script completed..')

--------------------------------------------------------------------------------------
