--dim_article_master
--dim_channel
--dim_coded_consolidated
--dim_dynamic_axis
--dim_promo_all
--dim_promo_flexible
--dim_promo_summarised
--dim_promotion
--fact_daily_promotions
--fact_monthly_promo_agg
--fact_monthly_sales_agg

print('Creating TTS Tables now...');

IF NOT EXISTS (select 'a' FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='dim_article_master' and TABLE_SCHEMA = 'dbo')
CREATE TABLE [dbo].[dim_article_master]
(
	[material_code] [varchar](50) NOT NULL,
	[material_desc] [varchar](100) NULL,
	[price_per_su] [float] NULL,
	[su_type] [varchar](50) NULL,
	[PC_per_SU] [int] NULL,
	[cs_type] [varchar](50) NULL,
	[PC_per_CS] [int] NULL,
	[pc_type] [varchar](50) NULL,
	[creation_date] [varchar](50) NULL,
	[PH1_code] [varchar](50) NULL,
	[PH1_description] [varchar](100) NULL,
	[PH2_code] [varchar](50) NULL,
	[PH2_description] [varchar](100) NULL,
	[PH3_code] [varchar](50) NULL,
	[PH3_description] [varchar](100) NULL,
	[PH4_code] [varchar](50) NULL,
	[PH4_description] [varchar](100) NULL,
	[PH5_code] [varchar](50) NULL,
	[PH5_description] [varchar](100) NULL,
	[PH6_code] [varchar](50) NULL,
	[PH6_description] [varchar](100) NULL,
	[PH7_code] [varchar](50) NULL,
	[PH7_description] [varchar](100) NULL,
	[PH8_code] [varchar](50) NULL,
	[PH8_description] [varchar](100) NULL,
	[PH9_code] [varchar](50) NULL,
	[PH9_description] [varchar](100) NULL,
	[site] [varchar](50) NULL,
	[status] [varchar](50) NULL,
 CONSTRAINT [PK_dim_article_master] PRIMARY KEY NONCLUSTERED 
	(
		[material_code] ASC
	) NOT ENFORCED 
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
);

IF NOT EXISTS (select 'a' FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='dim_channel' and TABLE_SCHEMA = 'dbo')
CREATE TABLE [dbo].[dim_channel]
(
	[COC4] [varchar](100) NOT NULL,
	[COC4_description] [varchar](100) NULL,
	[COC5] [varchar](100) NULL,
	[COC5_description] [varchar](100) NULL,
	[group_channel] [varchar](100) NULL,
	[channel] [varchar](100) NULL,
	[location] [varchar](100) NULL,
 CONSTRAINT [PK_dim_channel] PRIMARY KEY NONCLUSTERED 
	(
		[COC4] ASC
	) NOT ENFORCED 
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
);

IF NOT EXISTS (select 'a' FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='dim_coded_consolidated' and TABLE_SCHEMA = 'dbo')
CREATE TABLE [dbo].[dim_coded_consolidated]
(
	[ref_type] [varchar](100) NOT NULL,
	[ref_desc] [varchar](100) NULL,
	[ref_code] [int] NOT NULL,
	[param1] [int] NULL,
	[param2] [int] NULL,
 CONSTRAINT [PK_dim_coded_consolidated] PRIMARY KEY NONCLUSTERED 
	(
		[ref_type] ASC,
		[ref_code] ASC
	) NOT ENFORCED 
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
);

IF NOT EXISTS (select 'a' FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='dim_dynamic_axis' and TABLE_SCHEMA = 'dbo')
CREATE TABLE [dbo].[dim_dynamic_axis]
(
	[axis_dimension] [nvarchar](100) NULL,
	[axis_dimension_index] [int] NULL,
	[region] [nvarchar](100) NULL,
	[region_index] [int] NULL,
	[channel] [nvarchar](100) NULL,
	[channel_index] [int] NULL,
	[store_size_class] [nvarchar](100) NULL,
	[store_size_index] [int] NULL,
	[category] [nvarchar](100) NULL,
	[category_index] [int] NULL,
	[axis_value] [nvarchar](100) NULL,
	[axis_index] [int] NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX
);

IF NOT EXISTS (select 'a' FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='dim_promo_all' and TABLE_SCHEMA = 'dbo')
CREATE TABLE [dbo].[dim_promo_all]
(
	[promo_type] [varchar](100) NOT NULL,
	[group] [varchar](100) NULL,
	[index] [int] NULL,
 CONSTRAINT [PK_dim_promo_all] PRIMARY KEY NONCLUSTERED 
	(
		[promo_type] ASC
	) NOT ENFORCED 
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
);

IF NOT EXISTS (select 'a' FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='dim_promo_flexible' and TABLE_SCHEMA = 'dbo')
CREATE TABLE [dbo].[dim_promo_flexible]
(
	[axis_dimension] [varchar](100) NULL,
	[dimension_index] [int] NULL,
	[axis_value] [varchar](100) NULL,
	[axis_index] [int] NULL,
	[promo_summarised] [varchar](100) NULL,
	[promotion_type] [varchar](100) NULL,
	[budget_holder] [varchar](100) NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
);

IF NOT EXISTS (select 'a' FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='dim_promo_summarised' and TABLE_SCHEMA = 'dbo')
CREATE TABLE [dbo].[dim_promo_summarised]
(
	[promo_summarised] [varchar](100) NOT NULL,
	[index] [int] NULL,
 CONSTRAINT [PK_dim_promo_summarised] PRIMARY KEY NONCLUSTERED 
	(
		[promo_summarised] ASC
	) NOT ENFORCED 
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
);

IF NOT EXISTS (select 'a' FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='dim_promotion' and TABLE_SCHEMA = 'dbo')
CREATE TABLE [dbo].[dim_promotion]
(
	[invoice_type] [varchar](100) NOT NULL,
	[promotion_type] [varchar](100) NOT NULL,
	[promotion_type_desc] [varchar](100) NULL,
	[promotion_index] [int] NULL,
	[promo_summarized] [varchar](100) NULL,
	[promo_invoice_type] [varchar](100) NULL,
	[summarized_index] [int] NULL,
 CONSTRAINT [PK_dim_promotion] PRIMARY KEY NONCLUSTERED 
	(
		[invoice_type] ASC,
		[promotion_type] ASC
	) NOT ENFORCED 
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
);

IF NOT EXISTS (select 'a' FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='fact_daily_promotions' and TABLE_SCHEMA = 'dbo')
CREATE TABLE [dbo].[fact_daily_promotions]
(
	[invoice_number] [nvarchar](100) NULL,
	[product_code] [nvarchar](100) NULL,
	[standard_product_group_code] [nvarchar](100) NULL,
	[promotion_id] [nvarchar](100) NULL,
	[IO] [nvarchar](100) NULL,
	[promotion_mechanism] [nvarchar](100) NULL,
	[promotion_desc] [nvarchar](300) NULL,
	[promotion_type] [nvarchar](100) NULL,
	[budget_holder_group] [nvarchar](100) NULL,
	[invoice_type] [nvarchar](100) NULL,
	[promo_start_date] [date] NULL,
	[promo_end_date] [date] NULL,
	[value_based_promo_disc] [float] NULL,
	[header_lvl_disc] [float] NULL,
	[free_quantity_value] [float] NULL,
	[promotion_value] [float] NULL,
	[distributor_code] [nvarchar](100) NULL,
	[site_code] [nvarchar](100) NULL,
	[outlet_code] [nvarchar](100) NULL,
	[channel] [nvarchar](100) NULL,
	[banded] [nvarchar](100) NULL,
	[gift_price_available] [nvarchar](100) NULL,
	[country] [nvarchar](100) NULL,
	[year_id] [int] NULL,
	[month_id] [int] NULL,
	[time_key] [int] NULL
)
WITH
(
	DISTRIBUTION = HASH ( [outlet_code] ),
	CLUSTERED COLUMNSTORE INDEX
);

IF NOT EXISTS (select 'a' FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='fact_monthly_promo_agg' and TABLE_SCHEMA = 'dbo')
CREATE TABLE [dbo].[fact_monthly_promo_agg]
(
	[distributor_code] [nvarchar](100) NULL,
	[site_code] [nvarchar](100) NULL,
	[outlet_code] [nvarchar](100) NULL,
	[product_code] [nvarchar](100) NULL,
	[region] [nvarchar](100) NULL,
	[channel] [nvarchar](100) NULL,
	[standard_product_group_code] [nvarchar](100) NULL,
	[banded] [nvarchar](100) NULL,
	[promotion_type] [nvarchar](100) NULL,
	[promotion_mechanism] [nvarchar](100) NULL,
	[promotion_id] [nvarchar](100) NULL,
	[budget_holder_group] [nvarchar](100) NULL,
	[invoice_type] [nvarchar](100) NULL,
	[banded_code] [int] NULL,
	[perfect_store_status_code] [int] NULL,
	[channel_code] [int] NULL,
	[region_code] [int] NULL,
	[store_size_code] [nvarchar](100) NULL,
	[gift_price_available] [nvarchar](100) NULL,
	[promotion_value] [float] NULL,
	[tot_occdis] [float] NULL,
	[tot_perstr] [float] NULL,
	[tot_display] [float] NULL,
	[tot_ltyprg] [float] NULL,
	[has_occdis] [int] NULL,
	[has_perstr] [int] NULL,
	[has_occdis_and_perstr] [int] NULL,
	[has_occdis_or_perstr] [int] NULL,
	[year_id] [int] NULL,
	[month_id] [int] NULL,
	[time_key] [int] NULL
)
WITH
(
	DISTRIBUTION = HASH ( [outlet_code] ),
	CLUSTERED COLUMNSTORE INDEX
);

IF NOT EXISTS (select 'a' FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='fact_monthly_sales_agg' and TABLE_SCHEMA = 'dbo')
CREATE TABLE [dbo].[fact_monthly_sales_agg]
(
	[country_code] [varchar](100) NULL,
	[product_code] [varchar](100) NOT NULL,
	[standard_product_group_code] [varchar](100) NULL,
	[region] [varchar](100) NULL,
	[invoice_number] [varchar](100) NULL,
	[site_code_year] [varchar](100) NULL,
	[transactional_distributor_code] [varchar](100) NULL,
	[transactional_site_code] [varchar](100) NULL,
	[transactional_outlet_code] [varchar](100) NULL,
	[channel_code] [int] NULL,
	[store_size_code] [int] NULL,
	[perfect_store_status_code] [int] NULL,
	[region_code] [int] NULL,
	[banded_code] [int] NULL,
	[invoice_date] [date] NULL,
	[transactional_salesman_code] [varchar](100) NULL,
	[invoicetype] [varchar](100) NULL,
	[customer_ZRSS_flag] [varchar](100) NULL,
	[gross_sales_val] [float] NULL,
	[gross_sales_val_mn] [float] NULL,
	[net_invoice_val] [float] NULL,
	[gross_sales_return_val] [float] NULL,
	[sales_return_val] [float] NULL,
	[on_invoice_discount_val] [float] NULL,
	[value_added_tax] [float] NULL,
	[off_inv_discount_val] [float] NULL,
	[turn_over_val] [float] NULL,
	[sales_with_return_pc_qty] [bigint] NULL,
	[sales_return_pc_qty] [bigint] NULL,
	[sales_pc_qty] [bigint] NULL,
	[sales_cs_vol] [float] NULL,
	[sales_kg_vol] [float] NULL,
	[sales_lt_vol] [float] NULL,
	[free_pc_qty] [bigint] NULL,
	[salesforce] [varchar](100) NULL,
	[brand] [varchar](100) NULL,
	[category_code] [varchar](100) NULL,
	[brand_cat_core] [varchar](100) NULL,
	[banded] [varchar](100) NULL,
	[year_id] [int] NULL,
	[month_id] [int] NULL,
	[time_key] [int] NULL
)
WITH
(
	DISTRIBUTION = HASH ([transactional_outlet_code]),
	CLUSTERED COLUMNSTORE INDEX
);

GO

print('Table TTS creation complete ..')
---------------------------------------------------------
print('Executing ALTER script ..')

--fact_daily_promotions

if NOT EXISTS (SELECT NAME  from sys.stats where name =N'stats_nrmdss_month_id' 
and object_id=object_id(N'dbo.fact_daily_promotions'))
CREATE STATISTICS   [stats_nrmdss_month_id]  ON dbo.fact_daily_promotions (month_id);

if NOT EXISTS (SELECT NAME  from sys.stats where name =N'stats_nrmdss_year_id' 
and object_id=object_id(N'dbo.fact_daily_promotions'))
CREATE STATISTICS   [stats_nrmdss_year_id]  ON dbo.fact_daily_promotions (year_id);

if NOT EXISTS (SELECT NAME  from sys.stats where name =N'stats_nrmdss_time_key' 
and object_id=object_id(N'dbo.fact_daily_promotions'))
CREATE STATISTICS   [stats_nrmdss_time_key]  ON dbo.fact_daily_promotions (time_key);

if NOT EXISTS (SELECT NAME  from sys.stats where name =N'stats_nrmdss_outlet_code' 
and object_id=object_id(N'dbo.fact_daily_promotions'))
CREATE STATISTICS   [stats_nrmdss_outlet_code]  ON dbo.fact_daily_promotions (outlet_code);

if NOT EXISTS (SELECT NAME  from sys.stats where name =N'stats_nrmdss_promotion_id' 
and object_id=object_id(N'dbo.fact_daily_promotions'))
CREATE STATISTICS   [stats_nrmdss_promotion_id]  ON dbo.fact_daily_promotions (promotion_id);


--fact_monthly_promo_agg
if NOT EXISTS (SELECT NAME  from sys.stats where name =N'stats_nrmdss_agg_month_id' 
and object_id=object_id(N'dbo.fact_monthly_promo_agg'))
CREATE STATISTICS   [stats_nrmdss_agg_month_id]  ON dbo.fact_monthly_promo_agg (month_id);

if NOT EXISTS (SELECT NAME  from sys.stats where name =N'stats_nrmdss_agg_year_id' 
and object_id=object_id(N'dbo.fact_monthly_promo_agg'))
CREATE STATISTICS   [stats_nrmdss_agg_year_id]  ON dbo.fact_monthly_promo_agg (year_id);

if NOT EXISTS (SELECT NAME  from sys.stats where name =N'stats_nrmdss_agg_time_key' 
and object_id=object_id(N'dbo.fact_monthly_promo_agg'))
CREATE STATISTICS   [stats_nrmdss_agg_time_key]  ON dbo.fact_monthly_promo_agg (time_key);

if NOT EXISTS (SELECT NAME  from sys.stats where name =N'stats_nrmdss_agg_outlet_code' 
and object_id=object_id(N'dbo.fact_monthly_promo_agg'))
CREATE STATISTICS   [stats_nrmdss_agg_outlet_code]  ON dbo.fact_monthly_promo_agg (outlet_code);

if NOT EXISTS (SELECT NAME  from sys.stats where name =N'stats_nrmdss_agg_promotion_id' 
and object_id=object_id(N'dbo.fact_monthly_promo_agg'))
CREATE STATISTICS   [stats_nrmdss_agg_promotion_id]  ON dbo.fact_monthly_promo_agg (promotion_id);

--fact_monthly_sales_agg
if NOT EXISTS (SELECT NAME  from sys.stats where name =N'stats_dss_agg_month_id' 
and object_id=object_id(N'dbo.fact_monthly_sales_agg'))
CREATE STATISTICS   [stats_dss_agg_month_id]  ON dbo.fact_monthly_sales_agg (month_id);

if NOT EXISTS (SELECT NAME  from sys.stats where name =N'stats_dss_agg_year_id' 
and object_id=object_id(N'dbo.fact_monthly_sales_agg'))
CREATE STATISTICS   [stats_dss_agg_year_id]  ON dbo.fact_monthly_sales_agg (year_id);

if NOT EXISTS (SELECT NAME  from sys.stats where name =N'stats_dss_agg_time_key' 
and object_id=object_id(N'dbo.fact_monthly_sales_agg'))
CREATE STATISTICS   [stats_dss_agg_time_key]  ON dbo.fact_monthly_sales_agg (time_key);

if NOT EXISTS (SELECT NAME  from sys.stats where name =N'stats_dss_agg_txn_outlet_code' 
and object_id=object_id(N'dbo.fact_monthly_sales_agg'))
CREATE STATISTICS   [stats_dss_agg_txn_outlet_code]  ON dbo.fact_monthly_sales_agg (transactional_outlet_code);

go

print('ALTER  script completed..')


