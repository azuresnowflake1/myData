print('Creating Schema now...');

--test scehma creation

--CREATE SCHEMA DevOpsTests;

IF NOT EXISTS ( SELECT  'a'
                FROM    sys.schemas
                WHERE   name = 'DevOpsTests' )
    EXEC('CREATE SCHEMA [DevOpsTests]');
GO

print('Schema Creation complete...');


