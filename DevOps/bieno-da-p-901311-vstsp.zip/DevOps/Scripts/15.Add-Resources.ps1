Param
(
    [Parameter(Mandatory = $True, HelpMessage = 'Specify the parameter file')]
    [String]$parameterFile,

    [Parameter(HelpMessage='Specify whether to create the sql database')]
    [Switch]$SqlDb,

    [Parameter(HelpMessage='Specify whether to create the sql data warehouse')]
    [Switch]$SqlDW,

    [Parameter(HelpMessage='Specify whether to create the sql data warehouse')]
    [Switch]$KVwebapp,

    [Parameter(HelpMessage='Specify whether to create the sql data warehouse inside a subnet')]
    [Switch]$SqlDWVNet,

    [Parameter(HelpMessage='Specify whether to create the data factory')]
    [Switch]$DataFactory,

    [Parameter(HelpMessage='Specify whether to create the batch account')]
    [Switch]$Batch,
    
    [Parameter(HelpMessage='Specify whether to create the data lake analytics')]
    [Switch]$ADLAnalytics,

    [Parameter(HelpMessage='Specify whether to create the HDInsight cluster')]
    [Switch]$HDInsight,

    [Parameter(HelpMessage='Specify whether to create the HDInsight cluster with R Server')]
    [Switch]$HDInsightRServer,

    [Parameter(HelpMessage='Specify whether to create the HDInsight cluster with R Server')]
    [Switch]$HDInsightwithDataLakeStore,

    [Parameter(HelpMessage='Specify whether to create the HDInsight cluster with R Server')]
    [Switch]$HDInsightRServerWithDataLakeStore,
    
    [Parameter(HelpMessage='Specify whether to create the Analysis Services')]
    [Switch]$AnalysisServices,
    
    [Parameter(HelpMessage='Specify whether to create the Analysis Services with an OPDG')]
    [Switch]$AnalysisServicesWithOPDG,
    
    [Parameter(HelpMessage='Specify whether to create the IotHub')]
    [Switch]$IoTHub,

    [Parameter(HelpMessage='Specify whether to create the IotHub Device Provisioning')]
    [Switch]$IoTDeviceProv,
        
    [Parameter(HelpMessage='Specify whether to create the Time Series Insights')]
    [Switch]$TimeSeriesInsights,
        
    [Parameter(HelpMessage='Specify whether to create the databricks workspace')]
    [Switch]$Databricks,

    [Parameter(HelpMessage='Specify whether to create Web Apps Service')]
    [Switch]$WebApp,

    [Parameter(HelpMessage='Specify whether to create a Function Application')]
    [Switch]$Functions,

    [Parameter(HelpMessage='Specify whether to create a Machine Learning Workspace')]
    [Switch]$MachineLearning,

    [Parameter(HelpMessage='Specify whether to create a log analytics workspace')]
    [Switch]$LogAnalytics,

    [Parameter(HelpMessage='Specify whether to create a Resource Group Budget Alert')]
    [Switch]$BudgetAlerts,

    [Parameter(HelpMessage='Specify whether to create a LogicApp')]
    [Switch]$LogicApp,

    [Parameter(HelpMessage='Specify whether to create a Stream Analytics job')]
    [Switch]$StreamAnalyticsJob,

    [Parameter(HelpMessage='Specify whether to create ADLS Gen2')]
    [Switch]$AdlsGen2
)

Write-Verbose "PSScriptRoot is: $PSScriptRoot"
$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
Write-Verbose "DevOps Project Folder: $devOpsProjectFolder"
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"
$managerFolder = "{0}\{1}" -f $devOpsProjectFolder, "LandscapeManager"
Write-Verbose "Utilties folder: $utilitiesFolder"

$parameters = & "$utilitiesFolder\Get-Parameters.ps1" -parameterFile $parameterFile
$args = @{parameterFile=$parameterFile;}

$secretExpiryYears = $parameters.parameters.keyVaultSecretExpiryTerm.value

if($parameters.parameters.projectEnvironment.value -eq "d" ){
    $granteeObjectId = $parameters.parameters.appContributorGroupId.value
}else{
    $granteeObjectId = $parameters.parameters.appReaderGroupId.value
}

function Get-Cred {
    param(
        [string] $userName
    )        
    $pwdPlain = & "$utilitiesFolder\New-Password.ps1"
    $password = ConvertTo-SecureString $pwdPlain -AsPlainText -Force
    $cred = New-Object System.Management.Automation.PSCredential ($userName, $password)
    return $cred
}

if ($LogAnalytics) {
    Write-Output "Creating the log analytics workspace."
    & "$utilitiesFolder\New-Resources.ps1" -parameterFile $parameterFile -LogAnalytics

#    $granteeObjectId = $parameters.parameters.servicePrincipalId.value
#    Write-Verbose "granteeObjectId $granteeObjectId"
#    & "$utilitiesFolder\New-RoleAssignment.ps1" -parameterFile $parameterFile -roleName "Log Analytics Contributor" -granteeObjectId $granteeObjectId -LogAnalytics
}

if ($Databricks) {
    Write-Output "Creating the databricks workspace"
    & "$utilitiesFolder\New-DataBricks.ps1" -parameterFile $parameterFile
}

if ($SqlDb) {
    $args["SqlDb"] = $SqlDb
    Write-Output "Creating the SQL Data Database"
    & "$utilitiesFolder\New-Resources.ps1" -parameterFile $parameterFile -SqlDb
    & "$utilitiesFolder\Set-SqlWhitelist.ps1" -parameterFile $parameterFile -forMe
    & "$utilitiesFolder\Set-SqlWhitelist.ps1" -parameterFile $parameterFile -forRds
    & "$utilitiesFolder\Set-SqlSubnetRule.ps1" -parameterFile $parameterFile -devTestLab
    Write-Output "Provisioning the SQLDb user permissions"
    & "$managerFolder\Add-NFUserstoSql.ps1" -parameterFile $parameterFile -SqlDb
    & "$utilitiesFolder\New-SqlUserWithRole.ps1" -parameterFile $parameterFile -SqlUserName "sqldeployuser" -DbRole "db_owner" -sqlDb
    if ($AnalysisServices -or $AnalysisServicesWithOPDG) {
        & "$utilitiesFolder\New-SqlUserWithRole.ps1" -parameterFile $parameterFile -SqlUserName $parameters.parameters.analysisServicesSqlUserLogin.value -DbRole db_datareader -sqlDb
    }
    & "$utilitiesFolder\Set-SqlWhitelist.ps1" -parameterFile $parameterFile -forMe -deleteRule
}

if ($SqlDW) {
    $args["SqlDw"] = $SqlDw
    Write-Output "Creating the SQL Data Warehouse"
    & "$utilitiesFolder\New-Resources.ps1" -parameterFile $parameterFile -SqlDW
    & "$utilitiesFolder\Set-SqlWhitelist.ps1" -parameterFile $parameterFile -forMe
    & "$utilitiesFolder\Set-SqlWhitelist.ps1" -parameterFile $parameterFile -forRds
    & "$utilitiesFolder\Set-SqlSubnetRule.ps1" -parameterFile $parameterFile -devTestLab
    Write-Output "Provisioning the SQLDW user permissions"
    & "$managerFolder\Add-NFUserstoSql.ps1" -parameterFile $parameterFile
    & "$utilitiesFolder\New-SqlUserWithRole.ps1" -parameterFile $parameterFile -SqlUserName "sqldeployuser" -DbRole "db_owner"
    if ($AnalysisServices -or $AnalysisServicesWithOPDG) {
        & "$utilitiesFolder\New-SqlUserWithRole.ps1" -parameterFile $parameterFile -SqlUserName $parameters.parameters.analysisServicesSqlUserLogin.value -DbRole db_datareader
    }
    Write-Output "Provisioning the SQLDW external data sources"
    & "$utilitiesFolder\Add-ADApptoSql.ps1" -parameterFile $parameterFile
    & "$utilitiesFolder\Set-SqlWhitelist.ps1" -parameterFile $parameterFile -forMe -deleteRule
}
if ($SqlDWVNet) {
    $args["SqlDw"] = $SqlDWVNet
    Write-Output "Creating the SQL Data Warehouse inside a vnet"
    & "$utilitiesFolder\New-Resources.ps1" -parameterFile $parameterFile -SqlDW
    & "$utilitiesFolder\Set-SqlWhitelist.ps1" -parameterFile $parameterFile -forMe
    & "$utilitiesFolder\Set-SqlWhitelist.ps1" -parameterFile $parameterFile -forRds
    & "$utilitiesFolder\Set-SqlSubnetRule.ps1" -parameterFile $parameterFile -ruleName1
    & "$utilitiesFolder\Set-SqlSubnetRule.ps1" -parameterFile $parameterFile -devTestLab
    Write-Output "Provisioning the SQLDW user permissions"
    & "$managerFolder\Add-NFUserstoSql.ps1" -parameterFile $parameterFile
    & "$utilitiesFolder\New-SqlUserWithRole.ps1" -parameterFile $parameterFile -SqlUserName "sqldeployuser" -DbRole "db_owner"
    if ($AnalysisServices -or $AnalysisServicesWithOPDG) {
        & "$utilitiesFolder\New-SqlUserWithRole.ps1" -parameterFile $parameterFile -SqlUserName $parameters.parameters.analysisServicesSqlUserLogin.value -DbRole db_datareader
    }
    Write-Output "Provisioning the SQLDW external data sources"
    & "$utilitiesFolder\Add-ADApptoSql.ps1" -parameterFile $parameterFile
    & "$utilitiesFolder\Set-SqlWhitelist.ps1" -parameterFile $parameterFile -forMe -deleteRule
}

if ($ADLAnalytics) {
    $args["ADLAnalysitics"] = $ADLAnalytics
    Write-Output "Creating the Data Lake Analytics"
    & "$utilitiesFolder\New-Resources.ps1" -parameterFile $parameterFile -ADLAnalytics
}

if ($HDInsight -or $HDInsightRServer -or $HDInsightwithDataLakeStore -or $HDInsightRServerWithDataLakeStore) {
    Write-Output "Creating the Cluster Admin password"
    $contentType = "The admin password for your HDInsight cluster."
    & "$utilitiesFolder\Set-KeyVaultSecret.ps1" -parameterFile $parameterFile -secretCredential $(Get-Cred -userName $parameters.parameters.clusterAdminLogin.value) -secretExpiryTermYears $secretExpiryYears -contentType $contentType
    Write-Output "Creating the Cluster SSH user password"
    $contentType = "The SSH password for your HDInsight cluster."
    & "$utilitiesFolder\Set-KeyVaultSecret.ps1" -parameterFile $parameterFile -secretCredential $(Get-Cred -userName $parameters.parameters.clusterSSHUserName.value) -secretExpiryTermYears $secretExpiryYears -contentType $contentType
}

if ($HDInsight) {
    Write-Output "Creating the HD Insight"
    & "$utilitiesFolder\New-Resources.ps1" -parameterFile $parameterFile -HDInsight
}

if ($HDInsightRServer) {
    Write-Output "Creating the HD Insight R Server"
    & "$utilitiesFolder\New-Resources.ps1" -parameterFile $parameterFile -HDInsightRServer
}

if ($HDInsightwithDataLakeStore) {
    Write-Output "Creating the HD Insight with Data Lake Store"
    & "$utilitiesFolder\New-Resources.ps1" -parameterFile $parameterFile -HDInsightwithDataLakeStore
    & "$utilitiesFolder\Set-HDInsightUMask.ps1" -parameterFile $parameterFile
}

if ($HDInsightRServerWithDataLakeStore) {
    Write-Output "Creating the HD Insight with R Server and Data Lake Store"
    & "$utilitiesFolder\New-Resources.ps1" -parameterFile $parameterFile -HDInsightRServerWithDataLakeStore
    & "$utilitiesFolder\Set-HDInsightUMask.ps1" -parameterFile $parameterFile
}
if ($Batch) {
    $args["Batch"] = $Batch
    Write-Output "Creating the Batch Account"
    & "$utilitiesFolder\New-Resources.ps1" -parameterFile $parameterFile -Batch
}

if ($DataFactory) {
    Write-Output "Creating the Data Factory"
    & "$utilitiesFolder\New-Resources.ps1" -parameterFile $parameterFile -DataFactory
}

if ($AnalysisServices) {
    Write-Output "Creating the Analysis Services"
    & "$utilitiesFolder\New-Resources.ps1" -parameterFile $parameterFile -AnalysisServices
    & "$utilitiesFolder\Set-SSASWhitelist.ps1" -parameterFile $parameterFile -forRds
}
if ($AnalysisServicesWithOPDG) {
    Write-Output "Creating the Analysis Services With OPDG"
    & "$utilitiesFolder\New-Resources.ps1" -parameterFile $parameterFile -AnalysisServicesWithOPDG
    & "$utilitiesFolder\Set-SSASWhitelist.ps1" -parameterFile $parameterFile -forRds
}
if ($IoTHub) {
    Write-Output "Creating the IotHub"
    & "$utilitiesFolder\New-Resources.ps1" -parameterFile $parameterFile -IoTHub
}
if ($IoTDeviceProv) {
    Write-Output "Creating the Iot Dvice Provisioning"
    & "$utilitiesFolder\New-Resources.ps1" -parameterFile $parameterFile -IoTDeviceProv
}
if ($TimeSeriesInsights) {
    Write-Output "Creating the Time Series Insights"
    & "$utilitiesFolder\New-Resources.ps1" -parameterFile $parameterFile -TimeSeriesInsights
}
if ($args.Count -gt 1) {
    Write-Output "Creating the Data Factory Linked Services for requested components"
    & "$utilitiesFolder\Set-DataFactory.ps1" @args
}
if ($WebApp) {
    Write-Output "Creating Web App Service"
    $groupId = $parameters.parameters.appContributorGroupId.value
    & "$utilitiesFolder\New-Resources.ps1" -parameterFile $parameterFile -WebApp
    & "$utilitiesFolder\New-RoleAssignment.ps1" -parameterFile $parameterFile -roleName "Website Contributor" -granteeObjectId $groupId -WebApp
    & "$utilitiesFolder\New-RoleAssignment.ps1" -parameterFile $parameterFile -roleName "Web Plan Contributor" -granteeObjectId $groupId -appServicePlan
}

if ($KVwebapp) {
    Write-Output "Creating KeyVault for Web Apps"
    & "$utilitiesFolder\New-Resources.ps1" -parameterFile $parameterFile -KVwebapp
    $O = Get-AzADServicePrincipal -displayname $parameters.parameters.webAppName.value
    If (-not (Get-AzAdGroupMember -GroupObjectId $parameters.parameters.dataWriterADGroupId.value | Where-Object { $_.Id -eq $O.Id})) {
        Add-AzureADGroupMember -ObjectId $parameters.parameters.dataWriterADGroupId.value -RefObjectId $O.Id
    }
    & "$managerFolder\Set-KeyVaultAccess.ps1" -parameterFile $parameterFile -WebApp
}

if ($Functions) {
    Write-Output "Creating Function Application"
    $groupId = $parameters.parameters.appContributorGroupId.value
    & "$utilitiesFolder\New-Resources.ps1" -parameterFile $parameterFile -Functions
    & "$utilitiesFolder\New-RoleAssignment.ps1" -parameterFile $parameterFile -roleName "Website Contributor" -granteeObjectId $groupId -functions
    & "$utilitiesFolder\New-RoleAssignment.ps1" -parameterFile $parameterFile -roleName "Web Plan Contributor" -granteeObjectId $groupId -appServicePlan
}

if ($MachineLearning) {
    Write-Output "Creating Machine Learning Workspace"
    & "$utilitiesFolder\New-Resources.ps1" -parameterFile $parameterFile -MachineLearning
    & "$managerFolder\Set-KeyVaultAccess.ps1" -parameterFile $parameterFile -MachineLearning
}

if ($BudgetAlerts) {
    Write-Output "Creating Resource group Budget alert"
    & "$utilitiesFolder\New-Resources.ps1" -parameterFile $parameterFile -budgetAlert
}

if ($StreamAnalyticsJob) {
    Write-Output "Creating Stream Analytics Job"
    & "$utilitiesFolder\New-Resources.ps1" -parameterFile $parameterFile -StreamAnalyticsJob
}

if ($Adlsgen2) {
    Write-Output "Creating ADLS Gen2 Storage"
    & "$managerFolder\New-DataLakeStore.ps1" -parameterFile $parameterFile
}

if ($LogicApp) {
    Write-Output "Creating Logic app"
    & "$utilitiesFolder\New-LogicApp.ps1" -parameterFile $parameterFile -SqlDb:$SqlDb -SqlDW:$SqlDW -LogAnalytics:$LogAnalytics -ADLStore:$AdlsGen2 -ADLStoreGen1:$ADLStoreGen1 -Permissions
}
