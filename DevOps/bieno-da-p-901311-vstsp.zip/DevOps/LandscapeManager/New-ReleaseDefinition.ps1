param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$parameterFile,

    [Parameter(Mandatory = $True, HelpMessage='The personal access token used to authorize vsts requests')]
    [String]$personalAccessToken,    

    [Parameter(Mandatory = $True, HelpMessage='The parameter file for deploying the Azure Resources')]
    [String]$resourceParameterFile,

    [Parameter(Mandatory = $False, HelpMessage='Specify the parameter file')]
    [String]$releaseDefinitionFile = "release.definition.template.json"            
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"
$managerFolder = "{0}\{1}" -f $devOpsProjectFolder, "LandscapeManager"

$parameters = & "$utilitiesFolder\Get-Parameters.ps1" -parameterFile $parameterFile
$devOpsParameters = & "$utilitiesFolder\Get-Parameters.ps1" -parameterFile $resourceParameterFile

# Need to workout the name of the dev ADF
$tokens = $devOpsParameters.parameters.developerADGroupName.value.Split("-")
$devProjectEnvironment = $tokens[3]
$devItsg = $tokens[4]
$devAdfName = "{0}-da{1}-{2}-{3}-adf-01" -f $global:CtxBootStrap.NamePrefix, $global:CtxBootStrap.SubscriptionNumberDev, $devProjectEnvironment, $devItsg
$vstsAccountName = $parameters.parameters.vstsAccountName.value
$vstsTeamProjectName = $parameters.parameters.vstsTeamProjectName.value
$vstsSourceControlDevBranch = $parameters.parameters.vstsSourceControlDevBranch.value

$vstsTeamProjectCIBuildDefinitionName = $parameters.parameters.vstsTeamProjectCIBuildDefinitionName.value
$vstsTeamProjectCIReleaseDefinitionName = $parameters.parameters.vstsTeamProjectCIReleaseDefinitionName.value

$vstsHostedAgentName = $parameters.parameters.vstsHostedAgentName.value
function Add-Release
{
    param
    (
        [String]$vstsTeamProjectBuildDefinitionName,
        [String]$vstsTeamProjectReleaseDefinitionName
    )
    $patString = "{0}:{1}" -f "", $personalAccessToken
    $base64PatString =  [System.Convert]::ToBase64String([System.Text.Encoding]::ASCII.GetBytes($patString))
    try 
    {
        $vstsURL = "https://{0}.visualstudio.com/DefaultCollection/{1}/_apis/distributedtask/queues?api-version=3.0-preview.1" -f $vstsAccountName, $vstsTeamProjectName
        $params = @{    
            ContentType = 'application/json'
            Headers = @{
                'Authorization'="Basic $base64PatString"
            }
            Method = 'Get'    
            URI = $vstsURL
        }
        Write-Verbose "Getting the queue definitions for team project $vstsTeamProjectName"
        $authZResponse =  Invoke-RestMethod @params
        $vstsQueue = $authZResponse.value | Where-Object {$_.name -eq $vstsHostedAgentName}
        $vstsQueueId = $vstsQueue.id
        Write-Verbose "Hosted Queue Id for $vstsTeamProjectName is $vstsQueueId"  

        $vstsURL = "https://{0}.visualstudio.com/DefaultCollection/{1}/_apis/build/definitions?api-version=2.0" -f $vstsAccountName, $vstsTeamProjectName
        $params = @{    
            ContentType = 'application/json'
            Headers = @{
                'Authorization'="Basic $base64PatString"
            }
            Method = 'Get'    
            URI = $vstsURL
        }
        Write-Verbose "Getting the build definitions for team project $vstsTeamProjectName"
        $authZResponse =  Invoke-RestMethod @params
        $vstsBuildDefinition = $authZResponse.value | Where-Object {$_.name -eq $vstsTeamProjectBuildDefinitionName}
        $vstsTeamProjectId = $vstsBuildDefinition.project.id
        Write-Verbose "Project id for $vstsTeamProjectName is $vstsTeamProjectId"     
        $vstsTeamProjectBuildDefinitionId = $vstsBuildDefinition.id
        Write-Verbose "Build Definition id for build $vstsTeamProjectBuildDefinitionName is $buildDefinitionId"        

        $sourceId = "{0}:{1}" -f $vstsTeamProjectId, $vstsTeamProjectBuildDefinitionId

        Write-Verbose "PSScriptRoot is: $PSScriptRoot"
        $teamProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
        Write-Verbose "Team Project Folder: $teamProjectFolder" 

        $vstsURL = "https://{0}.vsrm.visualstudio.com/DefaultCollection/{1}/_apis/release/definitions?api-version=3.0-preview.1" -f $vstsAccountName, $vstsTeamProjectName
        $params = @{    
            ContentType = 'application/json'
            Headers = @{
                'Authorization'="Basic $base64PatString"
            }
            body = $body
            Method = 'Get'    
            URI = $vstsURL
        }
        Write-Verbose "Getting release definition $vstsTeamProjectReleaseDefinitionName for team project $vstsTeamProjectName"
        $authZResponse =  Invoke-RestMethod @params
        $releaseDef = ($authZResponse.value | Where-Object {$_.name -eq $vstsTeamProjectReleaseDefinitionName})
        
        $vstsURL = "https://{0}.visualstudio.com/DefaultCollection/{1}/_apis/distributedtask/serviceendpoints?api-version=3.0-preview.1" -f $vstsAccountName, $vstsTeamProjectName
        $params = @{    
            ContentType = 'application/json'
            Headers = @{
                'Authorization'="Basic $base64PatString"
            }
            Method = 'Get'    
            URI = $vstsURL
        }
        Write-Verbose "Getting the service point definitions for team project $vstsTeamProjectName"
        $authZResponse =  Invoke-RestMethod @params    
        $vstsProjectARMServiceEndPointName = $parameters.parameters.vstsProjectARMServiceEndPointName.value
        $vstsProjectARMServiceEndPoint = $authZResponse.value | Where-Object {$_.name -eq $vstsProjectARMServiceEndPointName}
        $vstsTargetAzurePs = $parameters.parameters.vstsTargetAzurePs.value
        $vstsCustomTargetAzurePs = $parameters.parameters.vstsCustomTargetAzurePs.value
        $resourcesToDeploy = '-xmlaCubeFilesDirectory $(System.DefaultWorkingDirectory)/{0}/Drop/DevOps/Custom/AAS' -f $vstsTeamProjectBuildDefinitionName
        if (!$releaseDef)
        {
            $releaseDefinitionFilePath = "{0}\Templates\{1}" -f $teamProjectFolder, $releaseDefinitionFile
            $releaseDefinition = Get-Content -Path $releaseDefinitionFilePath -Raw | ConvertFrom-Json
            $releaseDefinition.name = $vstsTeamProjectReleaseDefinitionName
            $releaseDefinition.environments[0].name = $vstsSourceControlDevBranch
            $releaseDefinition.environments[0].queueId = $vstsQueueId
            $releaseDefinition.environments[0].variables.parameterFile.value = $resourceParameterFile

            $scriptName = '$(System.DefaultWorkingDirectory)/{0}/Drop/DevOps/Utilities/Deploy-SSASCube.ps1' -f $vstsTeamProjectBuildDefinitionName
            $workingFolder = '$(System.DefaultWorkingDirectory)/{0}/Drop' -f $vstsTeamProjectBuildDefinitionName
            $arguments = '-parameterFile $(parameterFile) {0} -whitelist -Verbose' -f $resourcesToDeploy
            $releaseDefinition.environments[0].deployStep.tasks[0].name = "DeployAASCube"
            $releaseDefinition.environments[0].deployStep.tasks[0].inputs.ConnectedServiceNameARM = $vstsProjectARMServiceEndPoint.id
            $releaseDefinition.environments[0].deployStep.tasks[0].inputs.ScriptPath = $scriptName
            $releaseDefinition.environments[0].deployStep.tasks[0].inputs.workingFolder = $workingFolder
            $releaseDefinition.environments[0].deployStep.tasks[0].inputs.ScriptArguments = $arguments
            $releaseDefinition.environments[0].deployStep.tasks[0].inputs.TargetAzurePs = $vstsTargetAzurePs
            $releaseDefinition.environments[0].deployStep.tasks[0].inputs.CustomTargetAzurePs = $vstsCustomTargetAzurePs

            $scriptName = '$(System.DefaultWorkingDirectory)/{0}/Drop/DevOps/Utilities/Deploy-SqlDw.ps1' -f $vstsTeamProjectBuildDefinitionName
            $workingFolder = '$(System.DefaultWorkingDirectory)/{0}/Drop' -f $vstsTeamProjectBuildDefinitionName
            $arguments = '-parameterFile $(parameterFile) -filePath $(System.DefaultWorkingDirectory)/{0}/Drop/DevOps/Custom/SqlDw -whitelist' -f $vstsTeamProjectBuildDefinitionName            
            $releaseDefinition.environments[0].deployStep.tasks[1].name = "DeploySqlDwSchema"
            $releaseDefinition.environments[0].deployStep.tasks[1].inputs.ConnectedServiceNameARM = $vstsProjectARMServiceEndPoint.id
            $releaseDefinition.environments[0].deployStep.tasks[1].inputs.ScriptPath = $scriptName
            $releaseDefinition.environments[0].deployStep.tasks[1].inputs.workingFolder = $workingFolder
            $releaseDefinition.environments[0].deployStep.tasks[1].inputs.ScriptArguments = $arguments
            $releaseDefinition.environments[0].deployStep.tasks[1].inputs.TargetAzurePs = $vstsTargetAzurePs
            $releaseDefinition.environments[0].deployStep.tasks[1].inputs.CustomTargetAzurePs = $vstsCustomTargetAzurePs

            $scriptName = '$(System.DefaultWorkingDirectory)/{0}/Drop/DevOps/Utilities/Set-DataFactory-TriggerState.ps1' -f $vstsTeamProjectBuildDefinitionName
            $workingFolder = '$(System.DefaultWorkingDirectory)/{0}/Drop' -f $vstsTeamProjectBuildDefinitionName
            $arguments = '-parameterFile $(parameterFile) -disableTriggers'         
            $releaseDefinition.environments[0].deployStep.tasks[2].name = "DisableADFTriggerState"
            $releaseDefinition.environments[0].deployStep.tasks[2].inputs.ConnectedServiceNameARM = $vstsProjectARMServiceEndPoint.id
            $releaseDefinition.environments[0].deployStep.tasks[2].inputs.ScriptPath = $scriptName
            $releaseDefinition.environments[0].deployStep.tasks[2].inputs.workingFolder = $workingFolder
            $releaseDefinition.environments[0].deployStep.tasks[2].inputs.ScriptArguments = $arguments
            $releaseDefinition.environments[0].deployStep.tasks[2].inputs.TargetAzurePs = $vstsTargetAzurePs
            $releaseDefinition.environments[0].deployStep.tasks[2].inputs.CustomTargetAzurePs = $vstsCustomTargetAzurePs
            
            $scriptName = '$(System.DefaultWorkingDirectory)/{0}/Drop/DevOps/Utilities/New-AdfArmDeployment.ps1' -f $vstsTeamProjectBuildDefinitionName
            $workingFolder = '$(System.DefaultWorkingDirectory)/{0}/Drop' -f $vstsTeamProjectBuildDefinitionName
            $arguments = '-parameterFile $(parameterFile) -publishFolderPath $(System.DefaultWorkingDirectory)/{0}/Drop/{1}' -f $vstsTeamProjectBuildDefinitionName, $devAdfName         
            $releaseDefinition.environments[0].deployStep.tasks[3].name = "DeployADFArmTemplate"
            $releaseDefinition.environments[0].deployStep.tasks[3].inputs.ConnectedServiceNameARM = $vstsProjectARMServiceEndPoint.id
            $releaseDefinition.environments[0].deployStep.tasks[3].inputs.ScriptPath = $scriptName
            $releaseDefinition.environments[0].deployStep.tasks[3].inputs.workingFolder = $workingFolder
            $releaseDefinition.environments[0].deployStep.tasks[3].inputs.ScriptArguments = $arguments
            $releaseDefinition.environments[0].deployStep.tasks[3].inputs.TargetAzurePs = $vstsTargetAzurePs
            $releaseDefinition.environments[0].deployStep.tasks[3].inputs.CustomTargetAzurePs = $vstsCustomTargetAzurePs

            $scriptName = '$(System.DefaultWorkingDirectory)/{0}/Drop/DevOps/Utilities/Set-DataFactory-TriggerState.ps1' -f $vstsTeamProjectBuildDefinitionName
            $workingFolder = '$(System.DefaultWorkingDirectory)/{0}/Drop' -f $vstsTeamProjectBuildDefinitionName
            $arguments = '-parameterFile $(parameterFile)'         
            $releaseDefinition.environments[0].deployStep.tasks[4].name = "EnableADFTriggerState"
            $releaseDefinition.environments[0].deployStep.tasks[4].inputs.ConnectedServiceNameARM = $vstsProjectARMServiceEndPoint.id
            $releaseDefinition.environments[0].deployStep.tasks[4].inputs.ScriptPath = $scriptName
            $releaseDefinition.environments[0].deployStep.tasks[4].inputs.workingFolder = $workingFolder
            $releaseDefinition.environments[0].deployStep.tasks[4].inputs.ScriptArguments = $arguments
            $releaseDefinition.environments[0].deployStep.tasks[4].inputs.TargetAzurePs = $vstsTargetAzurePs
            $releaseDefinition.environments[0].deployStep.tasks[4].inputs.CustomTargetAzurePs = $vstsCustomTargetAzurePs

            $scriptName = '$(System.DefaultWorkingDirectory)/{0}/Drop/DevOps/Utilities/New-LogicAppDeployment.ps1' -f $vstsTeamProjectBuildDefinitionName
            $workingFolder = '$(System.DefaultWorkingDirectory)/{0}/Drop' -f $vstsTeamProjectBuildDefinitionName
            $arguments = '-parameterFile $(parameterFile) -armFolderName LogicApp -armTemplateFileName logicapp.template.json'         
            $releaseDefinition.environments[0].deployStep.tasks[5].name = "DeployLogicApp"
            $releaseDefinition.environments[0].deployStep.tasks[5].inputs.ConnectedServiceNameARM = $vstsProjectARMServiceEndPoint.id
            $releaseDefinition.environments[0].deployStep.tasks[5].inputs.ScriptPath = $scriptName
            $releaseDefinition.environments[0].deployStep.tasks[5].inputs.workingFolder = $workingFolder
            $releaseDefinition.environments[0].deployStep.tasks[5].inputs.ScriptArguments = $arguments
            $releaseDefinition.environments[0].deployStep.tasks[5].inputs.TargetAzurePs = $vstsTargetAzurePs
            $releaseDefinition.environments[0].deployStep.tasks[5].inputs.CustomTargetAzurePs = $vstsCustomTargetAzurePs

            $releaseDefinition.artifacts[0].sourceId = $sourceId
            $releaseDefinition.artifacts[0].alias = $vstsTeamProjectBuildDefinitionName
            $releaseDefinition.artifacts[0].definitionReference.definition.id = $vstsTeamProjectBuildDefinitionId.ToString()
            $releaseDefinition.artifacts[0].definitionReference.definition.name = $vstsTeamProjectBuildDefinitionName
            $releaseDefinition.artifacts[0].definitionReference.project.id = $vstsTeamProjectId
            $releaseDefinition.artifacts[0].definitionReference.project.name = $vstsTeamProjectName
            $releaseDefinition.triggers[0].artifactAlias = $vstsTeamProjectBuildDefinitionName        
                        
            $body = $releaseDefinition | ConvertTo-JSON -Depth 10

            $vstsURL = "https://{0}.vsrm.visualstudio.com/DefaultCollection/{1}/_apis/release/definitions?api-version=3.0-preview.1" -f $vstsAccountName, $vstsTeamProjectName
            $params = @{    
                ContentType = 'application/json'
                Headers = @{
                    'Authorization'="Basic $base64PatString"
                }
                body = $body
                Method = 'Post'    
                URI = $vstsURL
            }
            Write-Verbose "Adding release definition $vstsTeamProjectReleaseDefinitionName for team project $vstsTeamProjectName"
            $authZResponse =  Invoke-RestMethod @params
            $releaseDefinitionId = $authZResponse.id
            Write-Verbose "Release Definition Id: $releaseDefinitionId"
            Write-Output "Release Definition Id: $releaseDefinitionId"
        }
        else 
        {
            Write-Verbose "Release Definition exists with Id: $releaseDefinitionId"
            Write-Output "Release Definition exists with Id: $releaseDefinitionId"
        }
    }
    catch
    {
        Write-Host "StatusCode:" $_.Exception.Response.StatusCode.value__ 
        Write-Host "StatusDescription:" $_.Exception.Response.StatusDescription
        throw
    }
}

Add-Release -vstsTeamProjectBuildDefinitionName $vstsTeamProjectCIBuildDefinitionName -vstsTeamProjectReleaseDefinitionName $vstsTeamProjectCIReleaseDefinitionName
#Add-Release -vstsTeamProjectBuildDefinitionName $vstsTeamProjectScheduledBuildDefinitionName -vstsTeamProjectReleaseDefinitionName $vstsTeamProjectScheduledReleaseDefinitionName