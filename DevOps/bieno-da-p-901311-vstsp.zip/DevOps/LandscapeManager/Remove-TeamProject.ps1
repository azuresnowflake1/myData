param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$parameterFile,
    
    [Parameter(Mandatory = $True, HelpMessage='The personal access token used to authorize vsts requests')]
    [String]$personalAccessToken
)

$teamProjectProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $teamProjectProjectFolder, "Utilities"
$parameters = & "$utilitiesFolder\Get-Parameters.ps1" -parameterFile $parameterFile

$vstsAccountName = $parameters.parameters.vstsAccountName.value
$vstsTeamProjectName = $parameters.parameters.vstsTeamProjectName.value


$patString = "{0}:{1}" -f "", $personalAccessToken
$base64PatString =  [System.Convert]::ToBase64String([System.Text.Encoding]::ASCII.GetBytes($patString))

try 
{
    $vstsURL = "https://{0}.visualstudio.com/DefaultCollection/_apis/projects/{1}?api-version=1.0" -f $vstsAccountName, $vstsTeamProjectName
    $params = @{    
        ContentType = 'application/json'
        Headers = @{
            'Authorization'="Basic $base64PatString"
        }
        Method = 'Get'    
        URI = $vstsURL
    }
    Write-Verbose "Getting the project id for team project $vstsTeamProjectName"
    $authZResponse =  Invoke-RestMethod @params
    $prjId = $authZResponse.id
    Write-Verbose "Project id is : $prjId"
    $vstsURL = "https://{0}.visualstudio.com/DefaultCollection/_apis/projects/{1}?api-version=1.0" -f $vstsAccountName, $prjId

    $params = @{    
        ContentType = 'application/json'
        Headers = @{
            'Authorization'="Basic $base64PatString"
        }
        Method = 'Delete'    
        URI = $vstsURL
    }
    Write-Verbose "Deleting the team project $vstsTeamProjectName"
    Invoke-RestMethod @params
    Write-Verbose "Deleted the team project $vstsTeamProjectName"
}
catch
{
    if ($_.Exception.Response.StatusCode -ne "NotFound") { 
        Write-Warning "StatusCode:" $_.Exception.Response.StatusCode.value__ 
        Write-Warning "StatusDescription:" $_.Exception.Response.StatusDescription
        throw 
    }
}


