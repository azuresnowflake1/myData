Param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$parameterFile
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

$reader = $parameters.parameters.appReaderGroupId.value
$contributor = $parameters.parameters.appContributorGroupId.value
$dataReader = $parameters.parameters.dataReaderADGroupId.value
$dataWriter = $parameters.parameters.dataWriterADGroupId.value
$spn = $parameters.parameters.deploymentServicePrincipalId.value

$contributorRoleName = "InA Tech Contributor"
$readerRoleName = "InA Tech Reader"

& "$utilitiesFolder\New-RoleAssignment.ps1" -parameterFile $parameterFile -roleName $contributorRoleName -granteeObjectId $contributor -resourceGroup
& "$utilitiesFolder\New-RoleAssignment.ps1" -parameterFile $parameterFile -roleName $readerRoleName -granteeObjectId $reader -resourceGroup
& "$utilitiesFolder\New-RoleAssignment.ps1" -parameterFile $parameterFile -roleName "InA Tech Data Reader" -granteeObjectId $dataReader -resourceGroup
& "$utilitiesFolder\New-RoleAssignment.ps1" -parameterFile $parameterFile -roleName "InA Tech Data Writer" -granteeObjectId $dataWriter -resourceGroup
& "$utilitiesFolder\New-RoleAssignment.ps1" -parameterFile $parameterFile -roleName "Contributor" -granteeObjectId $spn -resourceGroup