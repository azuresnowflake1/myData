param(

    [object]
    $WebhookData    
)

.\Login-AzureRMAutomation.ps1 -WebHookData $WebhookData

$resourceGroups = Get-AzureRMResourceGroup

$ctx = Get-AzureRMContext
$subscriptionId = $ctx.Subscription.Id

if($subscriptionId -eq "105fbd8d-388f-4b19-9fda-d56f44121122"){
    $env = "Dev"
}elseif ($subscriptionId -eq "43046d94-2b34-46fa-8b8b-4a3a72b53df6"){
    $env = "QA"
}elseif ($subscriptionId -eq "8b4fb847-3b45-410f-a6e7-3247c9d459b7"){
    $env = "PPD"
}elseif ($subscriptionId -eq "e2b0e829-5210-40ae-b73f-20805aa01351"){
    $env = "Prod"
}elseif ($subscriptionId -eq "c70cf1d8-50bd-486d-b921-b910ffb03a70"){
    $env = "Dev" # DS
}else {
    throw "unsupported subscriptionId: $subscriptionId"
}


foreach($resourceGroup in $resourceGroups){

    $rgArr = $($resourceGroup.ResourceGroupName).split("-")
    $ArrayEnvironments =@("d","q","b","u","p")
    if($ArrayEnvironments -NotContains $rgArr[2]){
        Write-Output "Resource group name $($resourceGroup.ResourceGroupName) does not follow agreed format or environment letter" 
        continue
    }

    $adbs = Get-AzureRMResource -ResourceGroupName $resourceGroup.ResourceGroupName -ResourceType "Microsoft.Databricks/workspaces"
    if($null -eq $adbs){
        continue
    }

    $adb = $adbs[0].Name

    $adbArr = $adb.split("-")

    if($adbArr.Length -ne 6){
        Write-Output "Databricks workspace does not follow standard naming convention : $adb " 
        continue
    }

    $webhookData = "{`"WebhookName`":`"WebHook-SyncAADtoADB`",`"RequestBody`":`"$adb`"}"

    Write-Output "updating cluster admins of : $adb " 
    if($env -eq "Dev"){
        .\sync-AADGroupsWithADBWorkspace.ps1 -webhookData $webhookData -developer -tester -devOps
    }elseif ($env -eq "QA"){
        .\sync-AADGroupsWithADBWorkspace.ps1 -webhookData $webhookData -developer -tester -devOps
    }elseif ($env -eq "PPD"){
        .\sync-AADGroupsWithADBWorkspace.ps1 -webhookData $webhookData -devOps
    }elseif ($env -eq "Prod"){
        .\sync-AADGroupsWithADBWorkspace.ps1 -webhookData $webhookData -devOps
    }
}
