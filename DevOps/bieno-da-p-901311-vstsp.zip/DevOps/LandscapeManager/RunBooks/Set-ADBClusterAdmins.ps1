Param
(
    [object]$webhookData,
    [Parameter(Mandatory = $False, HelpMessage='Specify array of the AAD group members you want to sync to')]
    $aadGroupMembers,
    [Parameter(Mandatory = $False, HelpMessage='Specify array of the Landscape AAD group members you want to sync to')]
    $landscapeAdGroupMembers,
    [Parameter(Mandatory = $False, HelpMessage='Specify the region')]
    [String]$region="westeurope"
)

$parameters = .\Get-AllParametersWithoutADFAuthentication.ps1 -WebHookData $WebhookData

if (-not $parameters)
{
    # request is not valid
    return
}

#.\Login-AzureRMAutomation-AAD.ps1 -WebHookData $WebhookData

$keyVaultName = $parameters.parameters.keyVaultName.value
$tokenSecretName = $parameters.parameters.databricksTokenSecretName.value

if (-not $tokenSecretName)
{
    $tokenSecretName = "DatabricksAccessToken"
}
$secret = Get-AzureKeyVaultSecret -VaultName $keyVaultName -Name $tokenSecretName
$accessToken = $secret.SecretValueText

$uriBase = "https://$region.azuredatabricks.net/api/2.0"

add-type @"
using System.Net;
using System.Security.Cryptography.X509Certificates;
public class TrustAllCertsPolicy : ICertificatePolicy {
    public bool CheckValidationResult(
        ServicePoint srvPoint, X509Certificate certificate,
        WebRequest request, int certificateProblem) {
        return true;
    }
}
"@
$AllProtocols = [System.Net.SecurityProtocolType]'Ssl3,Tls,Tls11,Tls12'
[System.Net.ServicePointManager]::SecurityProtocol = $AllProtocols
#[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPoli 

function Get-Users {
        $uri = "$uriBase/preview/scim/v2/Users"
        $head = @{authorization = "Bearer $accessToken" }
        
    Invoke-RestMethod -Uri $uri -Method 'GET' -Headers $head -ContentType "application/scim+json"
}

function New-User {
    param([string]$principal)
        $uri = "$uriBase/preview/scim/v2/Users"
        $head = @{authorization = "Bearer $accessToken" }
        $body = @"
        {
            "schemas":[
              "urn:ietf:params:scim:schemas:core:2.0:User"
            ],
            "userName":"$principal",
            "groups":[],
            "entitlements":[
                {
                "value":"allow-cluster-create"
                }                
            ]
          }
"@
    Invoke-RestMethod -Uri $uri -Body $Body -Method 'POST' -Headers $head -ContentType "application/scim+json"
}

function Remove-User {
    param([string]$memberID)
        $uri = "$uriBase/preview/scim/v2/Users/$memberID"
        $head = @{authorization = "Bearer $accessToken" }
    Invoke-RestMethod -Uri $uri -Body $Body -Method 'DELETE' -Headers $head -ContentType "application/json"
}
  
$existingMembers = Get-Users
if($null -eq $existingMembers)
{
    Write-Output "error occured while retrieving users from workspace"
    return
}

$new = @{}

# remove adb members that are no long in the AAD group
foreach($member in $existingMembers.resources)
{
    $new.Add($member.userName, $member.userName)
    $userExists =  $aadGroupMembers.UserPrincipalName -Contains $member.userName
    if($false -eq $userExists){
        $isLandscapeUser = $landscapeAdGroupMembers.UserPrincipalName -Contains $member.userName
        if($isLandscapeUser -eq $false){
            Write-Output "User $($member.userName) is no longer a member of the AAD groups and will be removed."
            Remove-User -memberID $member.id    
        }
    }
}

# Add new members
foreach($member in $aadGroupMembers)
{
    if (-not $new[$member.UserPrincipalName]) {
        Write-Output "Adding user $($member.UserPrincipalName) to the workspace"
        New-User -principal $member.UserPrincipalName
    } else {
        #Write-Output "User $($member.UserPrincipalName) is already a member of workspace"
    }
}

Write-Output "Databricks workspace $($parameters.parameters.databricksWorkspaceName.value) users synced"