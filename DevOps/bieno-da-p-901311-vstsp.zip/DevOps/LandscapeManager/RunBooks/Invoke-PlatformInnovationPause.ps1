###########################################################################################
# Pause all landscape test components
###########################################################################################

$runningLocally = $false
try {
    $region = Get-AutomationVariable -Name 'newFoundationRegion' -ErrorAction Stop
    # if the variable was defined then assume this is running in an automation account
    $localPath = "."
    .\Import-PlatformDataCore.ps1
} catch {
 # The variable wasn't defined so assume it's running locally.
 $localPath = (Get-Item -Path $PSScriptRoot).FullName
 & "$localPath\Import-PlatformAutomationClientCore.ps1"
}

if (-not $PSPrivateMetadata.JobId) {
    # running in locally
    $runningLocally = $true
}
# Depending on the component type, pause or down scale the compute
function Set-ComponentState {
    param([string]$subscriptionNumber, [Microsoft.Azure.Commands.ResourceManager.Cmdlets.SdkModels.PSResource]$component,
    [Microsoft.Azure.Commands.Profile.Models.Core.PSAzureContext]$ctx)

    if ($component.ResourceType -eq "Microsoft.Sql/servers") {
        # SQLDW or DB
        foreach($database in Get-AzSqlDatabase -ResourceGroupName $component.ResourceGroupName -ServerName $component.ResourceName -DefaultProfile $ctx) {
            if ($database.DatabaseName -eq "master") {
                continue
            } elseif ($database.Edition -eq "Datawarehouse" -and $status.status -eq 'Online') {
                Suspend-AzSqlDatabase -ResourceGroupName $component.ResourceGroupName -DatabaseName $database.Databasename -ServerName $component.ResourceName -DefaultProfile $ctx
            } elseif ($database.Edition -eq "Standard") {
                # SqlDb Scale down
                $NewPricingTier = "S0"
                Set-AzSqlDatabase -ResourceGroupName $component.ResourceGroupName -DatabaseName $database.Databasename -ServerName $component.ResourceName -Edition "Standard" -RequestedServiceObjectiveName $NewPricingTier -DefaultProfile $ctx
            }
        }
    } elseif ($component.ResourceType -eq "Microsoft.AnalysisServices/servers") {
        # AAS
        $status = Get-AzAnalysisServicesServer -Name $component.ResourceName -DefaultProfile $ctx
        if($status.State -ne 'Paused')
        {
            Suspend-AzAnalysisServicesServer -Name $component.ResourceName -ResourceGroupName $component.ResourceGroupName -DefaultProfile $ctx
        }
    } elseif ($component.ResourceType -eq "Microsoft.Web/serverFarms") {
        # Service Plan e.g. bnlwe-da04-d-10018-serviceplan-01
        Set-AzAppServicePlan -Name $component.ResourceName -ResourceGroupName $component.ResourceGroupName -Tier "Free" -WorkerSize "Small"

    }
    elseif ($component.ResourceType -eq "Microsoft.ContainerService/managedClusters") {
        # Kubernetes e.g.  aks-01098398790390b

    }
}

if (-not $runningLocally) {
    # Login using the platform automation credential
    $webhookData = Get-WebhookDataSample -subscriptionNumber $subNumber
    $bootstrap = Login-AzCore -WebhookData $webhookData -aad
}
$subs = Get-Subscriptions -all
foreach($subNumber in $subs.Keys) {
    $ctx = $subs[$subNumber].DefaultProfile
    
    # if ($subNumber -ne "04") {
    #     continue
    # }
    $rgs = Get-AzResourceGroup -DefaultProfile $ctx | Where-Object { $_.Tags -and $_.Tags["ServiceName"] -eq "Azure Landscape Innovation" }
    foreach($rg in $rgs) {
    
        foreach($resource in Get-AzResource -ResourceGroupName $rg.ResourceGroupName -DefaultProfile $ctx) {
            if ($resource.ResourceType.Contains("Microsoft.Compute") -or $resource.ResourceType.Contains("Microsoft.DevTestLab") -or $resource.ResourceType.Contains("Microsoft.Network")) {
                continue
            }
            Write-Output "Processing $($resource.ResourceName)" 
            Set-ComponentState -subscriptionNumber $subNumber -component $resource -ctx $ctx
        }    
    }
}