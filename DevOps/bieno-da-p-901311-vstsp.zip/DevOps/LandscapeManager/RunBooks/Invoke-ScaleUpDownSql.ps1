param(
    [object]
    $WebhookData
)

.\Import-PlatformCore.ps1
$bootStrap = Login-AzCore -WebHookData $WebhookData
$parameters = Get-Parameters -bootstrap $bootStrap

$isError=$false
$outputStream =[System.Collections.ArrayList]@()
$outputStream.Add($WebhookData) | Out-Null

$NewEdition = $bootStrap["arg0"]
$NewPricingTier = $bootStrap["arg1"]
$callbackFunction = $bootStrap["callbackPipeline"]
$ResourceGroupName = $parameters.parameters.sqlServerResourceGroupName.value
$sqlServerName = $parameters.parameters.sqlServerName.value

if($NewEdition -eq "DataWarehouse"){
    $sqlDbToScale =  $parameters.parameters.sqlDataWarehouseName.value
    $sqlType="DW"
}elseif ($NewEdition){
    $sqlDbToScale = $parameters.parameters.sqlDatabaseName.value
    $sqlType="DB"
}else{
    throw "Please provide Edition details eg. 'DataWarehouse' for SQLDw and 'Standard' for SqlDb) in arg0"

}
$bootStrap["ResourceGroupName"] = $ResourceGroupName
$bootStrap["SqlServerName"] = $sqlServerName
$bootStrap["DatabaseName"] = $sqlDbToScale
$bootStrap["NewEdition"] = $NewEdition
$bootStrap["NewPricingTier"] = $NewPricingTier

$outputStream.Add("Processing environment:") | Out-Null
$outputStream.Add($bootstrap) | Out-Null

try {
    if (-not ($NewEdition -and $NewPricingTier)) {
        throw "You must pass a value for NewEdition and Pricing Tier in your CSV string."
    }
    $fileName = "{0}_ScaleSql_{1}" -f $bootstrap.runId, (get-date -Format s)
    $outputStream.Add("Scaling Db $sqlDbToScale to $NewPricingTier") | Out-Null
    $result = Set-AzSqlDatabase -DatabaseName $sqlDbToScale -ServerName $sqlServerName -ResourceGroupName $ResourceGroupName -Edition $NewEdition -RequestedServiceObjectiveName $NewPricingTier -ErrorAction Stop
    $outputStream.Add($result) | Out-Null
    $outputStream.Add("SQL Service scaled to $NewEdition & $NewPricingTier") | Out-Null
   
    if ($callbackFunction) {
        $result = Invoke-AdfPipeline -bootStrap $bootstrap -parameters $parameters
        $outputStream.Add($result) | Out-Null
    }
}
catch {
    $isError=$true
    $outputStream.Add($_) | Out-Null
    throw
 }
 finally {
    # Write log file to app storage account
    Set-LogfileContent -parameters $parameters -stream $outputStream -fileName $fileName
    
    if ($isError) {
        foreach($s in $outputStream)
        {
            if (($s.GetType().Name) -eq "Hashtable") {
                $s = $s | Out-String
            }
            Write-Error $s
        }
        throw "An unexpected error was detected"
    } else {
        $outputStream | Write-Output
    }
 }