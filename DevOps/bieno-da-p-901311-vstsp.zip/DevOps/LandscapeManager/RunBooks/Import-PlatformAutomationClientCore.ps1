# mimic the environment inside an automation account so runbooks can be debugged locally.
function global:Get-AutomationConnection {
    param([string]$Name)

    $cts = @{"svc-b-da00-ina-automation-aad"=@{
        TenantId="f66fae02-5d36-495b-bfe0-78a6ff9f8e6e"
        ApplicationId="d0f394e7-a998-422d-af05-67b8a76f26a1"
        CertificateThumbprint="4F779F992FFB69331522A752BFCFFDE2001D11CD"}
        "svc-b-da00-ina-automation" = @{
            TenantId="f66fae02-5d36-495b-bfe0-78a6ff9f8e6e"
            ApplicationId="610a4530-2b38-406e-9cda-f826950a043f"
            CertificateThumbprint="F7A1BF8DD2D7862A9D075013E424CBBE70413544"}
        "svc-b-da01-ina-automation" = @{
                TenantId="f66fae02-5d36-495b-bfe0-78a6ff9f8e6e"
                ApplicationId="0af27cfb-8e9e-4983-96a9-6d1cfedc2b1a"
                CertificateThumbprint="4504A8E1EA4455A34280CB9483D4CDCA1F7C5633"}
        "svc-b-da02-ina-automation" = @{
                TenantId="f66fae02-5d36-495b-bfe0-78a6ff9f8e6e"
                ApplicationId="1f13bd6b-92d5-4a5c-a624-8f44d24e718d"
                CertificateThumbprint="5287E98A09F8BEB1753C4447040B36FF1988ED4D"}
        "svc-b-da03-ina-automation" = @{
                TenantId="f66fae02-5d36-495b-bfe0-78a6ff9f8e6e"
                ApplicationId="bb44f594-eb25-4a72-9d5d-bd38cef74187"
                CertificateThumbprint="C62499410121361863013ADBD347F12D7C42C205"}
        "svc-b-da04-ina-automation" = @{
                TenantId="f66fae02-5d36-495b-bfe0-78a6ff9f8e6e"
                ApplicationId="56fd3b88-7ff7-42e4-892f-c29489cec4d9"
                CertificateThumbprint="E06516AF4FBAD9722194131C857BF7A56365803A"}
        "svc-b-da05-ina-automation" = @{
                TenantId="f66fae02-5d36-495b-bfe0-78a6ff9f8e6e"
                ApplicationId="955744c5-8a61-4188-880e-38fc0916b00d"
                CertificateThumbprint="5CB73C007773477CCB0B9B019AFDCF8F3F683C27"}
        "svc-b-da06-ina-automation" = @{
                TenantId="f66fae02-5d36-495b-bfe0-78a6ff9f8e6e"
                ApplicationId="d873ec5c-5982-48e4-a8c8-420a32d15510"
                CertificateThumbprint="3C4C17C379264BCECAC7396CF8C692082F000086"}
        "svc-b-da09-ina-automation" = @{
                TenantId="f66fae02-5d36-495b-bfe0-78a6ff9f8e6e"
                ApplicationId="bbeb5ebf-e3ee-40ae-a583-225639753b56"
                CertificateThumbprint="DF99D1FA6EA3C538F37BF6035D69D29D570653B0"}
        "svc-b-da10-ina-automation" = @{
                TenantId="f66fae02-5d36-495b-bfe0-78a6ff9f8e6e"
                ApplicationId="65dacd2c-9505-46bd-a6c5-a75fc4bb1592"
                CertificateThumbprint="E683DB673FD446552798F16DA7A2172AC1216BED"}
        "svc-b-da11-ina-automation" = @{
                TenantId="f66fae02-5d36-495b-bfe0-78a6ff9f8e6e"
                ApplicationId="bf43b64f-8a5d-49e2-9b7d-581ec74eea35"
                CertificateThumbprint="8862059FA55A0477598DD4AB44C47B8589FD6260"}                        
        "svc-b-da12-ina-automation" = @{
                TenantId="f66fae02-5d36-495b-bfe0-78a6ff9f8e6e"
                ApplicationId="bb5db76e-9d36-497d-a36d-c4ee42819aaa"
                CertificateThumbprint="031B1BDAF7036A4273FC4F18DA507D4EF6A996BA"}
        "svc-b-da13-ina-automation" = @{
                TenantId="f66fae02-5d36-495b-bfe0-78a6ff9f8e6e"
                ApplicationId="2b0842aa-b4bc-49f8-b2dd-320c1ee757e0"
                CertificateThumbprint="4C3EAC0331FB2B645F17905898D4C20F2F87C319"}
        "svc-b-da14-ina-automation" = @{
                TenantId="f66fae02-5d36-495b-bfe0-78a6ff9f8e6e"
                ApplicationId="e9188628-3522-41c3-8a64-8a2ae9baf25b"
                CertificateThumbprint="C033C9E6C7B3D28DB68422E80B349B605116065C"}
        "svc-b-da15-ina-automation" = @{
                TenantId="f66fae02-5d36-495b-bfe0-78a6ff9f8e6e"
                ApplicationId="efeed0a3-cc00-4f1b-b042-a25297da2157"
                CertificateThumbprint="0B8D5FC3792D70B220D97C3F644D589CA8EAE042"}
        "svc-b-da16-ina-automation" = @{
                TenantId="f66fae02-5d36-495b-bfe0-78a6ff9f8e6e"
                ApplicationId="6a45a6df-030a-483d-b890-daa83932819a"
                CertificateThumbprint="F934B1EAC7BC547E4FDA9EC3C13C72B98071D0D9"}
        "svc-b-da17-ina-automation" = @{
                TenantId="f66fae02-5d36-495b-bfe0-78a6ff9f8e6e"
                ApplicationId="19a0a945-993d-4b5a-88ac-26b869e44b4e"
                CertificateThumbprint="AE3C4E9BFBC288B256D19A139ED3CA0A47240463"}
        "svc-b-da18-ina-automation" = @{
                TenantId="f66fae02-5d36-495b-bfe0-78a6ff9f8e6e"
                ApplicationId="6526856d-402c-4b40-b042-c2b097d19029"
                CertificateThumbprint="0FA470A890BA5E7D55A9B5E16B0ECFB035811C09"}
}

    return $cts[$Name]
} 

function global:Get-AutomationVariable {
    param([string]$Name)

    if ($Name -eq "isProdAutomationAccount") {
        return $false
    }

    if ($Name -eq "newFoundationRegion") {
        return $true
    }
} 