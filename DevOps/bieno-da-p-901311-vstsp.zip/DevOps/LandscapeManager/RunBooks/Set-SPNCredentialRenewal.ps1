param(
    [object]
    $WebhookData
)

#.\Import-PlatformCore.ps1

$bootstrap = Login-AzCore -webhookData $webHookData 

$certStartDate = (Get-Date).Date
$itsg = $bootstrap.itsg
$isError=$false
$outputStream =[System.Collections.ArrayList]@()
$fileName = "SPNAutoRenew_{1}_{0}.log" -f (get-date -Format s), $itsg

try {

        $parameters = Get-Parameters -bootstrap $bootstrap -anonymous
        $outputStream.Add("ParameterFile Name : $($bootstrap.parameterfile)")
        $numberofYearsforClientSecret = $parameters.parameters.numberofYearsforClientSecret.value
        $outputStream.Add("Number Of Years For Client Secret: $($numberofYearsforClientSecret)")
        $certEndDate = ($certStartDate).AddYears(2)
        
        Login-AzCore -webhookdata $webhookData -aad        
        $certFolder = [System.IO.Path]::GetTempPath()
        #MM/DD/YYYY
        #$certEndDate = "04/30/2020 23:30:00"
        $landscapeSubscriptionId = $parameters.parameters.landscapeAdfSubscriptionId.value 
        $applicationName = $parameters.parameters.adApplicationName.value
        $deploymentName = $parameters.parameters.deploymentAdApplicationName.value
        $keyVaultName = $parameters.parameters.keyVaultName.value
         
        $certName = "HDI-ADLS-SPI-ecosystem-{0}.pfx" -f $parameters.parameters.projectNumber.value
        $appicationIdentityCertificateName = $parameters.parameters.applicationIdentityCertificateName.value
        
        $outputStream.Add("Application Identity Certificate Name : $($appicationIdentityCertificateName)")

        $applicationIdentityCertificatePassword = "{0}-Password" -f $appicationIdentityCertificateName  
        $certpassword = New-Password
        $certPasswordSecureString = ConvertTo-SecureString -AsPlainText $certPassword -Force    
        $certStoreLocation = "cert:\currentuser\My"
        $certFilePath = "$certFolder$certName"
        $landscapeAutomationAccountName = $parameters.parameters.landscapeAutomationAccountName.value
        $landscapeAutomationResourceGroupName = $parameters.parameters.landscapeAutomationResourceGroupName.value
        $landscapeKeyVaultName = $parameters.parameters.landscapeKeyVaultName.value


        $cert = New-SelfSignedCertificate -DnsName $certName -CertStoreLocation $certStoreLocation -KeySpec KeyExchange -NotAfter $certEndDate -NotBefore $certStartDate
        $certThumbprint = $cert.Thumbprint
        $cert = (Get-ChildItem -Path $certStoreLocation\$certThumbprint)

        Export-PfxCertificate -Cert $cert -FilePath $certFilePath -Password $certPasswordSecureString -Force | Out-Null

        $certificatePFX = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2($certFilePath, $certPasswordSecureString)
        $credential = [System.Convert]::ToBase64String($certificatePFX.GetRawCertData())

        #Remove-Item $certStoreLocation\$certThumbprint

        $keyId = [guid]::NewGuid().ToString("N")
        $objectid = (Get-AzureADApplication -SearchString $applicationName).ObjectId

        $outputStream.Add("Object ID for Application $($applicationName) is $($objectId)")
    
        New-AzureADApplicationKeyCredential -ObjectId $objectid -CustomKeyIdentifier $keyId `
                -StartDate $certStartDate -EndDate $certEndDate -Type AsymmetricX509Cert -Usage Verify -Value $credential | Out-Null
        $props = @{
            FilePath = $certFilePath
            Password = $certPassword
            Thumbprint = $certThumbprint
        }
        $output = new-object psobject -Property $props

        #Certificate
        $rawCert = [System.Convert]::ToBase64String((Get-Content $output.FilePath -Encoding Byte))
        $identityCertificate = ConvertTo-SecureString -AsPlainText $rawCert -Force
        $secretCredential = New-Object System.Management.Automation.PSCredential ($certName, $identityCertificate)

        #$secretCredential
        Set-AzKeyVaultSecret -VaultName $keyVaultName -Name $appicationIdentityCertificateName -SecretValue $identityCertificate -Expires $certEndDate | Out-Null 
        $outputStream.Add("Certificate Added to Key Vault $($keyVaultName)")

        #Password
        $identityCertificateSecurePassword = ConvertTo-SecureString -AsPlainText $output.Password -Force
        $secretCredential = New-Object System.Management.Automation.PSCredential ($applicationIdentityCertificatePassword, $identityCertificateSecurePassword)
        Set-AzKeyVaultSecret -VaultName $keyVaultName -Name $applicationIdentityCertificatePassword -SecretValue $certPasswordSecureString -Expires $certEndDate.DateTime | Out-Null 
        $outputSTream.Add("Certificate Password Added to Key Vault $($KeyVaultName)")

        Get-ChildItem $certFilePath
        #$output.Password


        #SPN Application Credential refresh
        $appSpn = Get-AzADServicePrincipal -DisplayName $applicationName
        $cred = New-AzADSpCredential -ObjectId $appSpn.Id -StartDate $certStartDate -EndDate $certEndDate.DateTime
        $secretCredential = New-Object System.Management.Automation.PSCredential ($applicationName, $cred.Secret)
        Set-AzKeyVaultSecret -VaultName $keyVaultName -Name $secretCredential.UserName -SecretValue $secretCredential.Password -Expires $certEndDate.DateTime
        $outputStream.Add("Application SPN $($secretCredential.UserName) updated password added to Key Vault $($KeyVaultName)")
        #SPN Deployment Credential refresh
        $depSpn = Get-AzADServicePrincipal -DisplayName $deploymentName
        $cred = New-AzADSpCredential -ObjectId $depSpn.Id -StartDate $certStartDate -EndDate $certEndDate.DateTime
        $secretCredential = New-Object System.Management.Automation.PSCredential ($deploymentName, $cred.Secret)


        Login-AzCore -webHookData $webhookData 

        Set-AzKeyVaultSecret -VaultName $landscapeKeyVaultName -Name $secretCredential.UserName -SecretValue $secretCredential.Password -Expires $certEndDate
        $outputStream.Add("Deployment SPN $($secretCredential.userName) updated password added to Key Vault $($KeyVaultName)")
        

        if(Get-AzAutomationCertificate -AutomationAccountName $landscapeAutomationAccountName -Name $certName `
        -ResourceGroupName $landscapeAutomationResourceGroupName -DefaultProfile $Global:CtxMaster -ErrorAction SilentlyContinue)

        {
            Set-AzAutomationCertificate -AutomationAccountName $landscapeAutomationAccountName -Name $certName -Path $certFilePath `
                -Password $identityCertificateSecurePassword -ResourceGroupName $landscapeAutomationResourceGroupName -DefaultProfile $Global:CtxMaster
        }

        else {
            New-AzAutomationCertificate -AutomationAccountName $landscapeAutomationAccountName -Name $certName -Path $certFilePath `
                -Password $identityCertificateSecurePassword -ResourceGroupName $landscapeAutomationResourceGroupName -DefaultProfile $Global:CtxMaster
            }
        $outputStream.Add("Automation Account $($landscapeAutomationAccountName) Certificate Installed $($certName) ")
        $outputStream.Add("SPN Credntials Completed : $((Get-Date).DateTime)")
        }
catch {
    $isError=$true
    $outputStream.Add($_) | Out-Null
}
finally {
    # Write log file to storage account
    # Needs to write into landscapes private storage account not the projects - switch to landscape context
    $webhookDataAudit = Get-WebhookDataSample -subscriptionNumber $bootstrap.SubscriptionNumber 
    $bootstrapAudit = Login-AzCore -webhookData $webHookDataAudit 
    $parametersAudit = Get-Parameters -bootstrap $bootstrapAudit -anonymous
    Set-LogfileContent -parameters $parametersAudit -stream $outputStream -fileName $fileName -landscape
    
    if ($isError) {
        foreach($s in $outputStream)
        {
            if (($s.GetType().Name) -eq "Hashtable") {
                $s = $s | Out-String
            }
            Write-Error $s
        }
        throw "An unexpected error was detected"
    } else {
        $outputStream | Write-Output
    }
}