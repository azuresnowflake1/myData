Param
(
    [object]$webhookData,
    [Parameter(Mandatory = $False, HelpMessage='Specify to synch the developer ad group membership')]
    [switch]$developer,
    [Parameter(Mandatory = $False, HelpMessage='Specify to synch the tester ad group membership')]
    [switch]$tester,
    [Parameter(Mandatory = $False, HelpMessage='Specify to synch the dev ops ad group membership')]
    [switch]$devOps
)

$parameters = .\Get-AllParametersWithoutADFAuthentication.ps1 -WebHookData $WebhookData
if (-not $parameters)
{
    # request is not valid
    return
}

$devAdGroupName = $parameters.parameters.developerADGroupName.value
$supportAdGroupName = $parameters.parameters.supportADGroupName.value
$testerAdGroupName = $parameters.parameters.testerADGroupName.value
$supportLevel1AdGroupName = "$($supportAdGroupName){0}" -f "Level1"

$allAADGroupMembers = @()

.\Login-AzureRMAutomation-AAD.ps1 -WebHookData $WebhookData

$landscapeAdGroup = Get-AzureRmADGroup -DisplayName "SEC-ES-DA-p-56728-landscape" 
$landscapeAdGroupMembers = Get-AzureRmADGroupMember -GroupObjectId $landscapeAdGroup.Id
$supportLevel1AdGroupMembers = Get-AzureRmADGroup -DisplayName $supportLevel1AdGroupName


if ($developer) {
    $devAdGroup = Get-AzureRmADGroup -DisplayName $devAdGroupName 
    if (-not $devAdGroup) {
        Write-Error "The specified AAD group '$devAdGroupName' was not found.  Cannot sync to this unknown group."
    }else{
        $devAdGroupMembers = Get-AzureRmADGroupMember -GroupObjectId $devAdGroup.Id
        $allAADGroupMembers += $devAdGroupMembers
    }
}
if ($devOps) {
    $supportAdGroup = Get-AzureRmADGroup -DisplayName $supportAdGroupName 
    if (-not $supportAdGroup) {
        Write-Error "The specified AAD group '$supportAdGroupName' was not found.  Cannot sync to this unknown group."
    }else{
        $supportAdGroupMembers = Get-AzureRmADGroupMember -GroupObjectId $supportAdGroup.Id
        $allAADGroupMembers += $supportAdGroupMembers
        if ($supportLevel1AdGroupMembers) {
            $allAADGroupMembers += $supportLevel1AdGroupMembers
        }
    }    
}
if ($tester) {
    $testerAdGroup = Get-AzureRmADGroup -DisplayName $testerAdGroupName 
    if (-not $testerAdGroup) {
        Write-Error "The specified AAD group '$testerAdGroupName' was not found.  Cannot sync to this unknown group."
    }else{
        $testerAdGroupMembers = Get-AzureRmADGroupMember -GroupObjectId $testerAdGroup.Id
        $allAADGroupMembers += $testerAdGroupMembers
        if ($supportLevel1AdGroupMembers) {
            $allAADGroupMembers += $supportLevel1AdGroupMembers
        }
    }    
}

.\Set-ADBClusterAdmins.ps1 -aadGroupMembers $allAADGroupMembers -landscapeAdGroupMembers $landscapeAdGroupMembers -webhookData $WebhookData 
.\Login-AzureRMAutomation.ps1 -WebHookData $WebhookData
