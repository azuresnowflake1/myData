param
(
    # if you want to add some fake message
    [switch]$addMessages,
    [switch]$clearMessages
)
# create a dummy webhook data that will point us at subscription 04
$WebhookDataString = .\Get-WebhookDataSample.ps1 -Environment d -SubscriptionNumber "04"
.\Login-AzureRmAutomation-AAD.ps1 -webhookData $WebhookDataString
#$ctx = Get-AzureRmContext -ListAvailable |  Where-Object { $_.Subscription.Name -eq "core data ecosystem-04" }
Set-AzureRmContext -Subscription "core data ecosystem-04"
$webhookParams = .\Get-WebhookData.ps1 -webhookData $WebhookDataString

function Set-LogFile {
    param(
    [hashtable]$parameters,
    [array]$stream,
    [string]$fileName)
    
    $resourceGroupName = $parameters.landscapeResourceGroupName
    $storageAccountName = $parameters.landscapeStorageAccountName
    $containerName = "automation"
    $logFilePath = New-TemporaryFile
    $accountKeys = Get-AzureRMStorageAccountKey -ResourceGroupName $resourceGroupName -Name $storageAccountName
    $storageContext = New-AzureStorageContext -StorageAccountName $storageAccountName -StorageAccountKey $accountKeys[0].Value 

    if(-not(Get-AzureStorageContainer -Name $containerName -Context $storageContext -ErrorAction SilentlyContinue)) 
    {
        New-AzureStorageContainer -Name $containerName -Context $storageContext
        Start-Sleep -Seconds 5
    }
    try
    {   
        # Rm storage commandlets don't support appending to existing files so we will have to get the existing log file if it exists, append to it and then
        # update the storage account
        Get-AzureStorageBlobContent -Container $containerName -Blob $fileName -Destination $logFilePath -Context $storageContext -Force -ErrorAction Stop | out-null
    }
    catch [Microsoft.WindowsAzure.Commands.Storage.Common.ResourceNotFoundException]
    {
        # ignore this
    }
    # Append new log entries
    foreach($str in $stream) {
        $str | Out-File -FilePath $logFilePath -Append
    }
    $args = @{
        File=$logFilePath;
        Container=$containerName;
        Blob=$fileName;
        Context=$storageContext;
        Force=$true
    }
    # Update the log file
    Set-AzureStorageBlobContent @args -outvariable $out
}
# Get the objectId of the principal that is the subject of an elevation/revoke request
function Get-ElevatePrincipalId {
    param([PSCustomObject]$message)

    if ($message.body.typeProperties.principalId) {
        return $message.body.typeProperties.principalId
    } elseif ($message.body.typeProperties.principalName) {
        # Look up the group. 
        $group = Get-AzureADUser -SearchString $message.body.typeProperties.principalName
        if ($group) {
            $message.body.typeProperties.principalId = $group.ObjectId
            return $group.ObjectId
        } else {
            throw "The specified user '{0}' was not found in AAD.  Unable to elevate permissions" -f $message.body.typeProperties.principalName
        }
        throw "Unsupported request.  Unable to lookup the objectId for principalName $($message.body.typeProperties.principalName)"
    } else {
        throw ("Unexpected Error: Unable to determine a principal Id for specified message" + (ConvertTo-Json -InputObject $message -Depth 20))
    }
}
# Get the objectId of the security group that is the subject of an elevation/revoke request
function Get-ElevateGroupId {
    param([PSCustomObject]$message)

    if ($message.body.typeProperties.groupId) {
        return $message.body.typeProperties.groupId
    } elseif ($message.body.typeProperties.groupName) {
        # Look up the group. 
        $group = Get-AzureADGroup -SearchString $message.body.typeProperties.groupName
        if ($group) {
            $message.body.typeProperties.groupId = $group.ObjectId
            return $group.ObjectId
        } else {
            throw "The specified group '{0}' was not found in AAD.  Unable to elevate permissions" -f $message.body.typeProperties.groupName
        }
        
    } else {
        throw ("Unexpected Error: Unable to process elevate permissions, couldn't determine the groupId from the specified message: " + (ConvertTo-Json -InputObject $message -Depth 20))
    }
}
function Add-Messages {
    param($queue)


    $msg1 = @"
{
        "requestedBy":"philip.elliott",
        "actionAfter":"2020-01-01 13:51",
        "respondTo":"",
        "body": {
            "type":"elevate", 
            "typeProperties": {
                "groupName":"SEC-ES-DA-d-10018-azure-developer",
                "groupId":"d2d446b6-84fc-463f-b54b-f3fa1bb8af3a",
                "principalId":"be34648f-eecd-4854-8c95-7ece109ec946",
                "principalName":"ronald.tweedie@unilever.com"
            }
        }
    }
"@
$msg2 = @"
{
        "requestedBy":"philip.elliott",
        "actionAfter":"2020-01-06 15:18",
        "respondTo":"",
        "body": {
            "type":"revoke", 
            "typeProperties": {
                "groupName":"SEC-ES-DA-d-10018-azure-developer",
                "groupId":"d2d446b6-84fc-463f-b54b-f3fa1bb8af3a",
                "principalId":"be34648f-eecd-4854-8c95-7ece109ec946",
                "principalName":"ronald.tweedie@unilever.com"
            }
        }
    }
"@
    Add-AzureRmStorageQueueMessage -queue $queue -message $msg1
    Add-AzureRmStorageQueueMessage -queue $queue -message $msg2
}
function Delete-Messages{
    param($queue)
    Clear-AzureRmStorageQueue -queue $queue
}
function Read-Message {
    param([object]$msg)
    $message = ($msg.AsString) | ConvertFrom-Json
    Add-Member -InputObject $message -TypeName "String" -NotePropertyName "ProcessedAt" -NotePropertyValue ((Get-Date).ToUniversalTime()).ToString("yyyy:MM:dd HH:mm:ss") | out-null
    
    # Always use/assume UTC for the actionAfter value :(Get-Date).ToUniversalTime()
    # When posting a message use this to format "actionAfter" Get-Date -Format "yyyy-MM-dd HH:mm"
    return $message
}

$queueName = "landscape-automation"
$outputStream =@()
$dt = (Get-Date).ToUniversalTime()
$fileName = "{0}_queue_{1}_{2}.log" -f "landscape_automation", $dt.Year, $dt.Month.ToString("00")

$queue = Get-AzureRmStorageQueueQueue -resourceGroup $webhookParams.landscapeResourceGroupName -storageAccountName $webhookParams.landscapeStorageAccountName -queueName $queueName
if ($addMessages) {
    Add-Messages -queue $queue
    return
} elseif ($clearMessages) {
    Clear-AzureRmStorageQueue -queue $queue
    return
}

# Some messages aren't ready to be processed so we ignore them but we must make them visible again otherwise the next invocation won't be able
# to see them
$ignored = [System.Collections.ArrayList]@()

try {
    # Pop a message off the queue
    $message = Invoke-AzureRmStorageQueueGetMessage -queue $queue
    while ($message) {
        $msg = Read-Message -msg $message
        
        if ($msg.actionAfter -and [datetime]($msg.actionAfter) -lt (Get-Date).ToUniversalTime()) {
            $outputStream += ($msg | ConvertTo-Json -Depth 10)
            try {
                if ($msg.body -and $msg.body.type -eq "elevate") {
                    $groupId = Get-ElevateGroupId -message $msg
                    $userId = Get-ElevatePrincipalId -message $msg
                    #Write-Output "Elevate $groupId and $userId"
                    # Actually need to handle existing member condition
                    Add-AzureADGroupMember -RefObjectId $userId -ObjectId $groupId
                } elseif ($msg.body -and $msg.body.type -eq "revoke") {
                    $groupId = Get-ElevateGroupId -message $msg
                    $userId = Get-ElevatePrincipalId -message $msg
                    #Write-Output "Revoke $groupId  and $userId"
                    Remove-AzureADGroupMember -MemberId $userId -ObjectId $groupId
                } else {
                    throw ("Unsupported message type for landscape queue.  Message was ignored: " + (ConvertTo-Json -InputObject $msg -Depth 10))
                }
            } catch {
                # write to the error log.  Need to alert landscape too.
                $outputStream += $_
                Remove-AzureRmStorageQueueMessage -queue $queue -message $message
    
            } finally {
                
            }
            
        } else {
            # Need to leave this in the queue
            #Write-Output "Skip Message"
            $ignored.Add($message)
        }
        # Get the next
        $message = Invoke-AzureRmStorageQueueGetMessage -queue $queue
    }
}
catch {
    throw $_
}
finally {
    if ($outputStream.count -gt 0) {
        Set-LogFile -parameters $webhookParams -stream $outputStream -fileName $fileName
    }
    
    # make all ignored messages visible. i.e. add back to the queue
    foreach ($msg in $ignored) {
        Update-AzureRmStorageQueueMessage -queue $queue -message $msg -visibilityTimeout 0
    }
}