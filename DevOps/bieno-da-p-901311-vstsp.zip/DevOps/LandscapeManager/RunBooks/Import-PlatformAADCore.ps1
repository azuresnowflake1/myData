# Logic for syncing AAD groups owners

try {
    $region = Get-AutomationVariable -Name 'newFoundationRegion' -ErrorAction Stop
    # if the variable was defined then assume this is running in an automation account
    .\Import-PlatformDataCore.ps1
    } catch {
        # The variable wasn't defined so assume it's running locally.
        $folder = (Get-Item -Path $PSScriptRoot).FullName
        & "$($folder)\Import-PlatformDataCore.ps1"
        }

# This function splits the array into required partitions
function global:Set-ArrayPartitions {
param(
    [array]$inputArray,
    [int]$numberOfPartitions
    )

    if ($inputArray) {
        $parts = if($numberOfPartitions){$numberOfPartitions} else {1}
        $partitionSize = [math]::Ceiling($inputArray.Length / $parts)
        $outputArray = @()

        # Splitting the input array into chunks of the same size
            for($i=0; $i -lt $parts; $i++) {
                $start = $i*$partitionSize
                $end = (($i+1)*$partitionSize)-1
                $outputArray += ,@($inputArray[$start..$end])
                }
            $outputArray
        }
    else {
        throw "Set-ArrayPartitions failed because no value was provided for the parameter inputArray"
        }
}

# This function gets all the relevant I&A AAD Groups
function global:Get-AADGroupsCore {
param(
    [string]$GroupNameStartsWith,
    [array]$filterOutGroups,
    [array]$validITSGs,
    [switch]$FunctionalGroups,
    [switch]$nonFunctionalGroups
    )
    
    if (-not $GroupNameStartsWith) {
        throw "Get-AADGroupNamesCore failed because this function expects value to be provided for the parameter GroupNameStartsWith"
        }
    
    $defaultGroupNameStartsWith = "sec-es-da-"
    $groupNamesMatch = "$($defaultGroupNameStartsWith)[a-z]-[0-9][0-9][0-9][0-9][0-9]-azure"
    $coreGroupNamesMatch = "$($groupNamesMatch)-"
    $nonFuncMatch = "$($defaultGroupNameStartsWith)[a-z]-[0-9][0-9][0-9][0-9][0-9]-azure[cr][oe]"
    $projectAdmin = "$($defaultGroupNameStartsWith)[a-z]-[0-9][0-9][0-9][0-9][0-9]-ProjectAdmins"
    $func = "developer","devops","tester","support"
    $nonFunc = "data","land"

    # Get aadGroups
    if ($GroupNameStartsWith) {
        if (($FunctionalGroups -and $nonFunctionalGroups) -or (-not $FunctionalGroups -and -not $nonFunctionalGroups)) {
            $aadGroupsOrig = Get-AzADGroup -DisplayNameStartsWith $GroupNameStartsWith|Where-Object {$_.DisplayName -match $groupNamesMatch -or $_.DisplayName -match $projectAdmin}
            }
        if ($FunctionalGroups -and -not $nonFunctionalGroups) {
            $aadGroupsOrig = Get-AzADGroup -DisplayNameStartsWith $GroupNameStartsWith|Where-Object {$_.DisplayName -match $coreGroupNamesMatch -and $_.DisplayName.substring(24,$_.DisplayName.length-24) -in $Func}
            }
        if ($nonFunctionalGroups -and -not $FunctionalGroups) {
            $aadGroupsOrig = Get-AzADGroup -DisplayNameStartsWith $GroupNameStartsWith|Where-Object {($_.DisplayName -match $nonFuncMatch -or ($_.DisplayName -match $coreGroupNamesMatch -and $_.DisplayName.substring(24,4) -in $nonFunc) -or $_.DisplayName -match $projectAdmin)}
            }
        }

    if ($validITSGs) {
            $aadGroups = $aadGroupsOrig | Where-Object {$_.DisplayName.Substring(12,5) -in $validITSGs}
            $invalidAADGroups = $aadGroupsOrig.DisplayName | Where-Object {$_.Substring(12,5) -notin $validITSGs}
            if ($invalidAADGroups) {
                ForEach($invalidGroup in $invalidAADGroups) {
                        Write-Warning "Following AAD Group is not part of a relevant ITSG Number: $($invalidGroup)"
                    }
            }
        } else {
            $aadGroups = $aadGroupsOrig
        }

    # filter aadGroups
    if (-not $filterOutGroups) {
        $aadGroups
        }
        else {
            $aadGroups|Where-Object {$_ -notin $filterOutGroups}
            }
}

# This function syncs all source members to the target AAD group owners
function global:Set-AADMembersToOwners {
param(
    [Parameter(Mandatory = $true)]
    [array]$sourceMembers,
    [Parameter(Mandatory = $true)]
    [array]$targetGroups,
    [array]$sourceGroupNames
    )

if ($sourceGroupNames) {
        $sourceGroups = Get-AzADGroup -DisplayNameStartsWith "sec-es-da-" | Where-Object {$_.DisplayName -in $SourceGroupNames}
        $sourceGroupMembers = ForEach($srcGroup in $sourceGroups) {
                                    Get-AzADGroupMember -GroupDisplayName $srcGroup.DisplayName | Where-Object  Type -in "User"
                                    }
        $srcMembers = ($sourceMembers + $sourceGroupMembers)|Sort-Object -Property DisplayName -Unique
    } else {
        $srcMembers = $sourceMembers
    }

if ($targetGroups.DisplayName) {
        $trgtGroups = $targetGroups
    } else {
        $trgtGroups = ForEach ($trgtGroup in $targetGroups) {
                            Get-AzADGroup -DisplayNameStartsWith "sec-es-da-" | Where-Object {$_.DisplayName -in $trgtGroup}
                            }
    }

if (-not $srcMembers) {
    throw "Set-AADMembersToOwners failed because no matching value was detected for the variable - sourceMembers"
    }
if (-not $trgtGroups) {
    throw "Set-AADMembersToOwners failed because no matching value was detected for the parameter - targetGroups"
    }
if ($srcMembers -and $trgtGroups) {
    ForEach($member in $srcMembers) {
        ForEach($trgtGrp in $trgtGroups) {
                $targetOwners = Get-AzureADGroupOwner -ObjectId $trgtGrp.Id
                $match = $false
                    ForEach($tgpo in $targetOwners) {
                        if ($tgpo.ObjectId -eq $member.Id) {
                            # nothing to do
                            $match = $true
                            break
                            }
                        }
                    if (-not $match) {
                        try {
                            #group is in the source but not the target group.  Need to add it.
                            Write-Output "Adding Owner $($member.DisplayName) to $($trgtGrp.DisplayName)"
                            Add-AzureADGroupOwner -ObjectId $trgtGrp.Id -RefObjectId $member.Id
                            } catch {
                                $errors = $true
                                Write-Error "An error occurred in Set-AADMembersToOwners while adding a Member $($member.DisplayName) to $($trgtGrp.DisplayName)."
                                Write-Error $_
                                }
                        }
            }
        }
    ForEach($targetGroup in $trgtGroups) {
        $targetGroupOwners = Get-AzureADGroupOwner -ObjectId $targetGroup.Id|Sort-Object DisplayName
        ForEach($owner in $targetGroupOwners) {
            if ($owner.ObjectId -notin $srcMembers.Id) {
                try {
                    #Member is not in the source but in the target group.  Need to remove it.
                    Write-Output "Removing owner $($owner.DisplayName) from $($targetGroup.DisplayName)"
                    Remove-AzureADGroupOwner -ObjectId $targetGroup.Id -OwnerId $owner.ObjectId
                    } catch {
                        $errors = $true
                        Write-Error "An error occurred in Set-AADMembersToOwners while removing a Member $($Member.DisplayName) from $($targetGroup.DisplayName)"
                        Write-Error $_
                        }
                }
            }
        }
    }
}

# This function syncs all source members to the target AAD group members
function global:Set-AADMembersToMembers {
param(
    [Parameter(Mandatory = $true)]
    [array]$sourceMembers,
    [Parameter(Mandatory = $true)]
    [array]$targetGroups,
    [array]$sourceGroupNames
    )

if ($sourceGroupNames) {
        $sourceGroups = Get-AzADGroup -DisplayNameStartsWith "sec-es-da-" | Where-Object {$_.DisplayName -in $SourceGroupNames}
        $sourceGroupMembers = ForEach($srcGroup in $sourceGroups) {
                                    Get-AzADGroupMember -GroupDisplayName $srcGroup.DisplayName | Where-Object  Type -in "User"
                                    }
        $srcMembers = ($sourceMembers + $sourceGroupMembers)|Sort-Object -Property DisplayName -Unique
    } else {
        $srcMembers = $sourceMembers
    }

if ($targetGroups.DisplayName) {
        $trgtGroups = $targetGroups
    } else {
        $trgtGroups = ForEach ($trgtGroup in $targetGroups) {
                            Get-AzADGroup -DisplayNameStartsWith "sec-es-da-" | Where-Object {$_.DisplayName -in $trgtGroup}
                            }
    }

if (-not $srcMembers) {
    throw "Set-AADMembersToMembers failed because no matching value was detected for the variable - sourceMembers"
    }
if (-not $trgtGroups) {
    throw "Set-AADMembersToMembers failed because no matching value was detected for the parameter - targetGroups"
    }
if ($srcMembers -and $trgtGroups) {
    ForEach($member in $srcMembers) {
        ForEach($trgtGrp in $trgtGroups) {
                $targetMembers = Get-AzureADGroupMember -ObjectId $trgtGrp.Id
                $match = $false
                    ForEach($tgpo in $targetMembers) {
                        if ($tgpo.ObjectId -eq $member.Id) {
                            # nothing to do
                            $match = $true
                            break
                            }
                        }
                    if (-not $match) {
                        try {
                            #group is in the source but not the target group.  Need to add it.
                            Write-Output "Adding Member $($member.DisplayName) to $($trgtGrp.DisplayName)"
                            Add-AzureADGroupMember -ObjectId $trgtGrp.Id -RefObjectId $member.Id
                            } catch {
                                $errors = $true
                                Write-Error "An error occurred in Set-AADMembersToMembers while adding a Member $($member.DisplayName) to $($trgtGrp.DisplayName)."
                                Write-Error $_
                                }
                        }
            }
        }
    ForEach($targetGroup in $trgtGroups) {
        $targetGroupMembers = Get-AzureADGroupMember -ObjectId $targetGroup.Id|Sort-Object DisplayName
        ForEach($Member in $targetGroupMembers) {
            if ($Member.ObjectId -notin $srcMembers.Id) {
                try {
                    #Member is not in the source but in the target group.  Need to remove it.
                    Write-Output "Removing Member $($Member.DisplayName) from $($targetGroup.DisplayName)"
                    Remove-AzureADGroupMember -ObjectId $targetGroup.Id -MemberId $Member.ObjectId
                    } catch {
                        $errors = $true
                        Write-Error "An error occurred in Set-AADMembersToMembers while removing a Member $($Member.DisplayName) from $($targetGroup.DisplayName)"
                        Write-Error $_
                        }
                }
            }
        }
    }
}

# Retrieve valid ITSG's or ProjectAdmins from blob.
function global:Get-AADBlobContent {
param(
    [switch]$itsg,
    [switch]$projectAdmin
    )

if ($itsg) {
    $fileName = "ResourceGroups.csv"
} elseif ($projectAdmin) {
            $fileName = "ProjectAdmins.csv"
        }

$subBootstrap = Get-SubscriptionBootstrap -subscriptionNUmber "04"
$landscapeStorageAccountName = "bnlwestgunileverda56731"
$landscapeResourceGroupName = "bnlwe-da04-d-56731-rg"

$containerName = "subscriptiondata"
$accountKeys = Get-AzStorageAccountKey -ResourceGroupName $landscapeResourceGroupName -Name $landscapeStorageAccountName -DefaultProfile $subBootstrap.DefaultProfile
$storageContext = New-AzStorageContext -StorageAccountName $landscapeStorageAccountName -StorageAccountKey $accountKeys[0].Value

# Download the file then join them
$parent = [System.IO.Path]::GetTempPath()
[string] $name = [System.Guid]::NewGuid()
$tempDir = (Join-Path $parent $name)
$filePath = Join-Path $tempDir $fileName

New-Item -Path $tempDir -ItemType "directory" | Out-Null
Write-Verbose "Getting the file $fileName from $landscapeStorageAccountName."
Get-AzStorageBlob -Blob $fileName -container $containerName -Context $storageContext | Get-AzStorageBlobContent -Destination $tempDir | Out-Null

if ($itsg) {
    $resourceGroups = Import-Csv $filePath | Select ResourceGroupName
    $itsgString = [regex]::matches($resourceGroups.ResourceGroupName ,'-\d\d\d\d\d-').value | Sort-Object -Property $_ -Unique
    $itsgString.Substring(1,5)
} elseif ($projectAdmin) {
            $projectAdminGroups = Import-Csv $filePath | Where-Object {$_.AADGroupName -match "sec-es-da-[a-z]-[0-9][0-9][0-9][0-9][0-9]-ProjectAdmins"} | Select AADGroupName
            $projectAdminGroups.AADGroupName
        }
}

####################### Azure Databricks AAD ##################################
function global:Get-AdbUsers {
    param([string]$uriBase, [string]$accessToken)
    $uri = "$uriBase/preview/scim/v2/Users"
    $head = @{authorization = "Bearer $accessToken" }
    
    Invoke-RestMethod -Uri $uri -Method 'GET' -Headers $head -ContentType "application/scim+json" -ErrorAction Stop
}

function global:New-AdbUser {
param([string]$uriBase, [string]$accessToken, [string]$principal)
    $uri = "$uriBase/preview/scim/v2/Users"
    $head = @{authorization = "Bearer $accessToken" }
    $body = @"
    {
        "schemas":[
          "urn:ietf:params:scim:schemas:core:2.0:User"
        ],
        "userName":"$principal",
        "groups":[],
        "entitlements":[]
      }
"@
    Invoke-RestMethod -Uri $uri -Body $Body -Method 'POST' -Headers $head -ContentType "application/scim+json"
}

function global:Remove-AdbUser {
param([string]$uriBase, [string]$accessToken, [string]$memberID)
    $uri = "$uriBase/preview/scim/v2/Users/$memberID"
    $head = @{authorization = "Bearer $accessToken" }
    Invoke-RestMethod -Uri $uri -Body $Body -Method 'DELETE' -Headers $head -ContentType "application/json" -ErrorAction Stop | Out-Null
}
function global:Get-AadUser {
    param ($users, $username)

    foreach($user in $users) {
        if ($user.UserPrincipalName -and $user.UserPrincipalName -eq $username) {
            return $true
        }
    }
    return $false
}
function global:Set-AdbWorkspaceUsers {
param
(
    [Parameter(Mandatory = $true, HelpMessage='Parameters from the parameter file')]
    [object]$parameters,
    [Parameter(Mandatory = $true, HelpMessage='Bootstrap for the current subscription.')]
    [hashtable]$bootStrap,
    [Parameter(Mandatory = $true, HelpMessage='The workspace object from Get-AzResource')]
    [Microsoft.Azure.Commands.ResourceManager.Cmdlets.SdkModels.PSResource]$workspace,
    [Parameter(Mandatory = $true, HelpMessage='Specify array of the AAD group members you want to sync to')]
    $aadMembers,
    [Parameter(Mandatory = $true, HelpMessage='Specify array of landscape members you want to ignore')]
    $landscapeMembers,
    [string]$tokenSecretName,
    [System.Collections.ArrayList]$outputStream
)
    $errors = $false
    $keyVaultName = $parameters.parameters.keyVaultName.value
    if (-not $tokenSecretName)
    {
        $tokenSecretName = "DatabricksAccessToken"
    }
    $secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $tokenSecretName -DefaultProfile $bootStrap.DefaultProfile
    $accessToken = $secret.SecretValueText

    $uriBase = "https://$($bootStrap.Location).azuredatabricks.net/api/2.0"

    add-type @"
    using System.Net;
    using System.Security.Cryptography.X509Certificates;
    public class TrustAllCertsPolicy : ICertificatePolicy {
        public bool CheckValidationResult(
            ServicePoint srvPoint, X509Certificate certificate,
            WebRequest request, int certificateProblem) {
            return true;
        }
    }
"@
    $AllProtocols = [System.Net.SecurityProtocolType]'Ssl3,Tls,Tls11,Tls12'
    [System.Net.ServicePointManager]::SecurityProtocol = $AllProtocols
    
    try {
        $existingMembers = Get-AdbUsers -uriBase $uriBase -accessToken $accessToken
    }
    catch {
        $errors = $true
        $outputStream.Add("Error occured while retrieving exsisting users from workspace $($workspace.Name) : $($_.Exception.Message)") | Out-Null
    }
    
    $new = @{}

    # remove adb members that are no long in the AAD group
    foreach($member in $existingMembers.resources)
    {
        try{
            $new.Add($member.userName, $member.userName)
            $userExists = Get-AadUser -users $aadMembers -username $member.userName
            $isLandscape = Get-AadUser -users $landscapeMembers -username $member.userName
            if(-not $userExists -and -not $isLandscape){
                $outputStream.Add("User $($member.userName) is no longer a member of the AAD groups and will be removed from $($workspace.Name).") | Out-Null
                Remove-AdbUser -uriBase $uriBase -accessToken $accessToken -memberID $member.id | Out-Null
            }
        } catch {
            $outputStream.Add("Error occured while removing user $($member.userName) from $($workspace.Name) : $($_.Exception.Message)") | Out-Null
            $errors=$true
        }
    }

    # Add new members
    foreach($member in $aadMembers)
    {
        try{
            if ($member.Type -eq "Group") {
                Write-Warning "ADB Synchronisation cannot add AD group principal $($member.DisplayName) to $($workspace.Name).  Only user principals are supported."
                $outputStream.Add("WARNING: ADB Synchronisation cannot add AD group principal $($member.DisplayName) to $($workspace.Name).  Only user principals are supported.") | Out-Null
                continue
            }
            if ($member.ObjectType -eq "ServicePrincipal") {
                Write-Warning "ADB Synchronisation cannot add SPN $($member.DisplayName) to $($workspace.Name).  Only user principals are supported."
                $outputStream.Add("WARNING: ADB Synchronisation cannot add SPN $($member.DisplayName) to $($workspace.Name).  Only user principals are supported.") | Out-Null
                continue
            }
            $isLandscape = Get-AadUser -users $landscapeMembers -username $member.userName
            if (-not $new[$member.UserPrincipalName] -and -not $isLandscape) {
                $outputStream.Add("Adding user $($member.UserPrincipalName) to $($workspace.Name)") | Out-Null
                New-AdbUser -uriBase $uriBase -accessToken $accessToken -principal $member.UserPrincipalName | Out-Null
            } else {
                #Write-Output "User $($member.UserPrincipalName) is already a member of workspace"
            }
        }catch{
            $ErrorMessage = $_.Exception.Message
            $outputStream.Add("Error occured while adding user $($member.UserPrincipalName) to $($workspace.Name) : $ErrorMessage") | Out-Null
            $errors=$true
        }
    }
    if ($errors) {
        $outputStream.Add("Databricks workspace $($workspace.Name) users was synced but errors were detected.") | Out-Null
        throw "Databricks workspace $($workspace.Name) users was synced but errors were detected."
    }
    else {
        $outputStream.Add("Databricks workspace $($workspace.Name) users was synced.") | Out-Null
    }
}
# Sync a single ADB workspace
function global:New-AdbWorkspaceSync {
param
(
    [Parameter(Mandatory = $true, HelpMessage='Parameters from the parameter file')]
    [object]$parameters,
    [Parameter(Mandatory = $true, HelpMessage='Bootstrap for the current subscription.')]
    [hashtable]$bootStrap,
    [Parameter(Mandatory = $true, HelpMessage='From AdbPermissions.csv in landscapes''s subscriptiondata container.  Overrides default permissions for a particular workspace')]
    [object]$metaData,
    [Parameter(Mandatory = $true, HelpMessage='The workspace from Get-AzResource')]
    [Microsoft.Azure.Commands.ResourceManager.Cmdlets.SdkModels.PSResource]$workspace,
    [Parameter(Mandatory = $true, HelpMessage='Specify array of landscape members you want to ignore')]
    $landscapeMembers,
    [string]$tokenSecretName
)
    $isError=$false
    $outputStream = [System.Collections.ArrayList]@()
    $outputStream.Add("Begin ADB user synchronisation of $($workspace.Name) at {0}" -f (Get-Date)) | Out-Null
    # See if we have any meta data for this workspace
    $metaDatas = $metaData | Where-Object { $_.WorkSpaceName -eq $workspace.Name }
    
    if (-not $metaDatas) {
        $outputStream.Add("User synchronisation will use default settings.") | Out-Null
        # Create default meta data
        $env = $parameters.parameters.ProjectEnvironment.value
        if ($env -eq "d") {
            $groups = "{0}|{1}|{2}" -f $parameters.parameters.developerADGroupName.value,$parameters.parameters.testerADGroupName.value,$parameters.parameters.supportADGroupName.value
        } elseif ($env -eq "q") {
            $groups = "{0}|{1}|{2}" -f $parameters.parameters.developerADGroupName.value,$parameters.parameters.testerADGroupName.value,$parameters.parameters.supportADGroupName.value
        } elseif ($env -eq "u") {
            $groups = "{0}" -f $parameters.parameters.supportADGroupName.value
        } elseif ($env -eq "b") {
            $groups = "{0}" -f $parameters.parameters.supportADGroupName.value
        } elseif ($env -eq "p") {
            $groups = "{0}" -f $parameters.parameters.supportADGroupName.value
        } elseif ($env -eq "x") {
            $groups = "{0}|{1}|{2}|{3}" -f $parameters.parameters.developerADGroupName.value,$parameters.parameters.testerADGroupName.value,$parameters.parameters.supportADGroupName.value
        } elseif ($env -eq "r") {
            $groups = "{0}" -f $parameters.parameters.supportADGroupName.value
        } 

        $csv = @"
WorkSpaceName,Role,GroupNames
$($workspace.Name),,$groups
"@
        $metaDatas = $csv | ConvertFrom-Csv
    } else {
        $outputStream.Add("User synchronisation settings have been overriden.  Custom settings will be used.") | Out-Null
    }
    $outputStream.Add($metaDatas) | Out-Null

    try {
        foreach($wsMeta in $metaDatas) {
            if (-not $wsMeta.GroupNames) {
                # There is a meta entry for the workspace but no groups are listed.  Treat this as an ignore switch
                $outputStream.Add("Sync of workspace $($workspace.Name) skipped. No AD groups are specified.") | Out-Null
                continue
            }
            $groups = $wsMeta.GroupNames.Split("|")
            $users = @()
            foreach($group in $groups) {
                if ($group) {
                    $users += Get-AzAdGroupMember -GroupDisplayName $group -ErrorAction Stop
                }
            }
            Set-AdbWorkspaceUsers -parameters $parameters -bootStrap $bootStrap -aadMembers $users -landscapeMembers $landscapeMembers -tokenSecretName $tokenSecretName -workspace $workspace -outputStream $outputStream
        }
    }
    catch {
        $isError=$true
        $outputStream.Add($_) | Out-Null
        #throw
     }
     finally {
        # Write log file to app storage account
        $fileName = "syncusers_{0}.log" -f (get-date -Format s)
        if ($isError) {
            $fileName = "syncusers_{0}_error.log" -f (get-date -Format s)
        }
        $fileName = Join-Path -Path $workspace.Name -Child $fileName
        Set-LogfileContent -parameters $parameters -stream $outputStream -fileName $fileName -containerName "adbusersync" -bootstrap $bootstrap -purgeThresholdDays 14
        
        if ($isError) {
            foreach($s in $outputStream)
            {
                if (($s.GetType().Name) -eq "Hashtable") {
                    $s = $s | Out-String
                }
                if ($s.ToString().Contains("error")) {
                    Write-Error $s
                }
            }
        } else {
            $outputStream | Write-Output
        }
     }
 }