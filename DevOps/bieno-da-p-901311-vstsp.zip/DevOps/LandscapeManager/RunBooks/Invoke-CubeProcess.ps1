param(
    [object]
    $WebhookData
)

$isError=$false
$outputStream =@()
$outputStream+=$WebhookData
$parameters = .\Get-AllParameters.ps1 -webhookData $WebhookData
$args = .\Get-WebhookData.ps1 -WebHookData $WebhookData
$fileName = "{0}_tmsl_{1}" -f $args.runId, (get-date -Format s)
try {
    if (-not $parameters)
    {
        # request is not valid
        $message = "Cube processing failed. Unable to get parameters for Webhook body: `r`n" + $WebhookData
        Throw $message
    } 
    else {
         $args = .\Get-WebhookData.ps1 -WebhookData $WebhookData
         $outputStream+= "Processing environment:"
         $outputStream += $args

        # By conventions we extract details about how to process the cube
        $tmsl = $args["arg0"]
        if ([String]::IsNullOrEmpty($tmsl)) {
            throw "You must pass your TMSL code in the 5th csv column."
        }
        # validate the sript only cube refresh commands are allowed
        $validateFailed = $false
        $oTmsl = ConvertFrom-Json -InputObject $tmsl;
        foreach($member in Get-Member -InputObject $oTmsl | Where-Object {$_.MemberType -eq "NoteProperty"})
        {
            if ($member.Name -ne "refresh") {
                $outputStream+="Illegal TMSL command '$($member.Name)' detected."
                $validateFailed = $true
            }
        }
        if ($validateFailed) {
            throw "Unable to process your TMSL request.  Only cube refresh operations are supported."
        }
        else {
            $outputStream += "TMSL:"
            $outputStream += $tmsl
        }
    }
    $applicationId = $parameters.parameters.applicationId.value
    $region = ($parameters.parameters.location.value).Replace(" ", "").ToLower()
    $server = "asazure://{0}.asazure.windows.net/{1}" -f $region, $parameters.parameters.analysisServicesName.value
    $thumbprint = $parameters.parameters.applicationCertThumprint.value
    $outputStream += .\Test-Set-SSASWhiteList.ps1 -parameters $parameters

    $outputStream += "Processing TMSL on AAS Server $server" 
    $processing += Invoke-ASCmd -Server $server -ServicePrincipal -ApplicationId $applicationId -CertificateThumbprint $thumbprint -Query $tmsl -ErrorAction Stop -Verbose

    #work out if an error occurred
    if ($processing -and $processing.GetType().Name -eq "String") {
        if ($processing.contains("errorCode") -or $processing.contains("exception")) {
            $isError=$true
        }
    }
    $outputStream += $processing
    
    if ($args["callbackPipeline"]) {
        $callbackParameters = @{
            exitStatus=(-not $isError)
            logFileName=$fileName
        }
        $args["callbackParameters"]=$callbackParameters
        $outputStream += .\Invoke-AdfPipeline.ps1 -WebHookData $args -parameters $parameters
    }
 }
 catch {
    $isError=$true
    $outputStream += $_
    throw
 }
 finally {
    # Write log file to app storage account
    .\Set-LogfileContent.ps1 -parameters $parameters -stream $outputStream -fileName $fileName
    
    if ($isError) {
        foreach($s in $outputStream)
        {
            if (($s.GetType().Name) -eq "Hashtable") {
                $s = $s | Out-String
            }
            Write-Error $s
        }
        throw "An unexpected error was detected"
    } else {
        $outputStream | Write-Output
    }
 }