# AzureRunAsConnection is parameter value
Param(
    [Parameter(Mandatory=$true)]
    [string]$connectionName = 'AzureRunAsConnection',
    [Parameter(Mandatory=$true)]
    [string]$dataLakeStoreName = 'bnlweda04d80183stgadls.azuredatalakestore.net',
    [Parameter(Mandatory=$true)]
    [string]$subscriptionname = 'Prod'
)
try
{
	$servicePrincipalConnection=Get-AutomationConnection -Name $connectionName
	"Logging in to Azure..."
	Add-AzAccount `
	-ServicePrincipal `
	-TenantId $servicePrincipalConnection.TenantId `
	-ApplicationId $servicePrincipalConnection.ApplicationId `
	-CertificateThumbprint $servicePrincipalConnection.CertificateThumbprint
}
catch {
	if (!$servicePrincipalConnection)
	{
		$ErrorMessage = "Connection $connectionName not found."
		throw $ErrorMessage
	} else{
		Write-Error -Message $_.Exception
		throw $_.Exception
	}
}



try{

$outputfile = "IntegrationRuntimeStatus$($subscriptionname.Replace(' ','-'))$(get-date -f yyyyMMddHHmmss).csv"
$dashboardfilename = "irdashboard$($subscriptionname.Replace(' ','-')).csv"
$header1 = "Time,Resource Group,Data Factory,Integration Runtime,Version,Creation Time,Status,Type,Node Name"

$myrootdir = '/'
$dlsfolder = 'irstatusdashboards'
$archivefolder='archive'


Write-Output $header1

Add-Content $outputfile $header1

}catch{
    
} 

"Start script..."
try
{
    $subscription = Select-AzSubscription $subscriptionname
	
    $resourcegroups = Get-AzResourceGroup | select resourcegroupname

    "Got resource groups..."
	#$resourcegroups = Get-AzResourceGroup "bieno-da-d-56001-app-rg" | select resourcegroupname
	foreach ($resourcegroup in $resourcegroups) 
	{
		"Resource Group..."
        #$resourcegroup.resourcegroupname
		try
		{
            #$resourcesADF = Get-AzResource -ResourceGroupName "bieno-da-d-56001-app-rg" -ResourceType "Microsoft.DataFactory/factories" | Select Name, ResourceName, ResoruceGroupName, ResourceID, Location
			$resourcesADF = Get-AzResource -ResourceGroupName $resourcegroup.resourcegroupname -ResourceType "Microsoft.DataFactory/factories" | select Name, resourcename,ResoruceGroupName,resourceid,location
			foreach ($resourceADF in $resourcesADF)
			{
                #"Resorce name " 
                #$resourceADF.name
				try
				{
					$integrationRuntimes = Get-AzDataFactoryV2IntegrationRuntime -ResourceGroupName $resourcegroup.resourcegroupname -DataFactoryName $resourceADF.Name -Status | select Name, Type
					#$integrationRuntimes = Get-AzDataFactoryV2IntegrationRuntime -ResourceGroupName "bieno-da-d-56001-app-rg" -DataFactoryName "bieno-da-d-56001-adf-01" -Status | select Name, State, Version, CreateTime, AutoUpdate
					
                    foreach ($integrationRuntime in $integrationRuntimes)
					{
						#"Integraiton Runtime ..."
                        #$integrationRuntime.Name
						try
						{
							$integrationRuntimeStatus = Get-AzDataFactoryV2IntegrationRuntime -ResourceGroupName $resourcegroup.resourcegroupname -DataFactoryName $resourceADF.Name -Name $integrationRuntime.Name -Status | Select State, Version, CreateTime, AutoUpdate
							#$integrationRuntimeStatus = Get-AzDataFactoryV2IntegrationRuntime -ResourceGroupName "bieno-da-b-80066-app-rg" -DataFactoryName "bieno-da-b-80066-adf-01" -Name "bieno-da-b-80066-dfgw-01" -Status | Select State, Version, CreateTime, AutoUpdate, DataFactoryName
							$datetime = Get-Date
							$outputtext = "$($datetime),$($resourcegroup.resourcegroupname),$($resourceADF.Name),$($integrationRuntime.Name),$($integrationRuntimeStatus.Version),$($integrationRuntimeStatus.CreateTime),$($integrationRuntimeStatus.State),$($integrationRuntime.Type)"
                            "Integration Runtime Status $($integrationRuntimeStatus.State)"
							#if ($integrationRuntimeStatus.State -ne "Online")
							#{	 
								try{
									$nodes = Get-AzDataFactoryV2IntegrationRuntimeMetric -ResourceGroupName $resourcegroup.resourcegroupname -DataFactoryName $resourceADF.Name  -Name $integrationRuntime.Name
									if($nodes.Nodes.Count -gt 1){
        								Add-Content $outputfile $outputtext 
        								Write-Output $outputtext
                                        foreach ($node in $nodes.Nodes){
                                            $outputtext = ",,,,,,,,$($node.NodeName)"
                                            Add-Content $outputfile $outputtext 
            								Write-Output $outputtext
                                        }
                                    }else
                                    {
                                        $outputtext = "$($outputtext),$($nodes.Nodes[0].NodeName)"
        								Add-Content $outputfile $outputtext 
        								Write-Output $outputtext
                                    }
								}catch{
		                            Write-Error $ErrorMessage
								}		
							#}else
							#{
							#	Write-Output $outputtext
							#	Add-Content $outputfile $outputtext 
							#}
						} catch
						{
                            Write-Error $ErrorMessage
						}					
					}
				}catch
				{
                    Write-Error $ErrorMessage
				}
			}
		}catch
		{
            Write-Error $ErrorMessage
		}
	}
}catch{
    Write-Error $ErrorMessage
}

try{

    Import-AzDataLakeStoreItem `
    -AccountName $dataLakeStoreName `
    -Path $outputfile `
    -Destination $myrootdir\$dlsfolder\$dashboardfilename `
    -Force

    Import-AzDataLakeStoreItem `
    -AccountName $dataLakeStoreName `
    -Path $outputfile `
    -Destination $myrootdir\$dlsfolder\$archivefolder\$outputfile `
    -Force

} catch{
    Write-Error $ErrorMessage    
}