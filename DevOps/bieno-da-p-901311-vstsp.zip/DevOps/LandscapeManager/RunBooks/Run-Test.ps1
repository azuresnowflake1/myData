<#param
(
    # The request body
    [object]
    $WebhookData
)

$json = @"
{"WebhookName":"WebHookTest1234","RequestBody":"bnlwe-da01-d-10018-adf-01,8494c3bc-bf35-48ea-9012-33a5fc784cc0,","RequestHeader":{"Connection":"Keep-Alive","Expect":"100-continue","Host":"s2events.azure-automation.net","x-ms-request-id":"b436d542-a0d0-4303-a0c6-a27ae5c40ee2"}}
"@
$WebhookData = ConvertFrom-Json $json
#>
#.\Set-DatabricksClusterTerminate.ps1 -webhookData $WebhookData


.\Import-PlatformAutomationClientCore.ps1
.\Import-PlatformDataCore.ps1

Get-Bootstrap -subscriptionNumber 8