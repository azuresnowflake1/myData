param
(
    # The parameter file json object
    [object]
    $parameters,
    [hashtable]$webhookData
)
if (-not $parameters) {
    Write-Error "Invoke-AdfV2Pipeline failed.  The passed parameter file object was null."
    return
}
if (-not $webhookData) {
    Write-Error "Invoke-AdfV2Pipeline failed.  The passed webhookData parameter was null."
    return
}
try {
    $resourceGroupName = $parameters.parameters.dataFactoryResourceGroupName.value
    $dataFactoryName = $parameters.parameters.dataFactoryName.value
    $pipelineName = $webhookData["callbackPipeline"]
    if ([string]::IsNullOrEmpty($pipelineName)) {
        Write-Error "Invoke-AdfV2Pipeline failed.  The passed webhookData csv string didn't contain a callback name in the 4th column."
        return
    }
    $args = @{
        resourceGroupName=$resourceGroupName
        dataFactoryName=$dataFactoryName
        pipelineName=$pipelineName
    }
    if ($webhookData["callbackParameters"]) {
        $args["parameter"] = $webhookData["callbackParameters"]
    }
    # Get data factory object
    $df=Get-AzureRmDataFactoryV2 -ResourceGroupName $resourceGroupName -Name $dataFactoryName
 
    #If exists - run it
    If($df) {
               Write-Output "Connected to data factory $dataFactoryName on $resourceGroupName"
               Write-Output "Running callback pipeline: $pipelineName"
 
               $RunID = Invoke-AzureRmDataFactoryV2Pipeline @args
               $RunInfo = Get-AzureRmDataFactoryV2PipelineRun -ResourceGroupName $resourceGroupName -DataFactoryName $dataFactoryName -PipelineRunId $RunID
 
               Write-Output "`nCallback pipeline was triggered!"
               Write-Output "RunID: $($RunInfo.RunId)"
               Write-Output "Started: $($RunInfo.RunStart)`n"
    }
}
Catch{
    Throw
}