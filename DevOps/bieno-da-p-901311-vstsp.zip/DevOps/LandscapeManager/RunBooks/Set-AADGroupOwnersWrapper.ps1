param
(
    [string]$sourceGroupName ="sec-es-da-p-56728-azure-landscape"
    #,[string]$WebhookData = '{"WebhookName":"WebHook-SqlDwResume","RequestBody":"bnlwe-da04-d-99999-adf-01,31e4d879-203b-4afa-83db-20021cc889d9,","RequestHeader":{"Connection":"Keep-Alive","Expect":"100-continue","Host":"s2events.azure-automation.net","x-ms-request-id":"8b188be3-a238-4c00-8c26-e2a5f65d428e"}}'
)


$runbookFolder = (Get-Item -Path $PSScriptRoot)
$managerFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$devopsFolder = (Get-Item -Path $managerFolder).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devopsFolder , "Utilities"

<#
.\Import-PlatformCore.ps1
#.\Import-PlatformDataCore.ps1

# Login to azure using our turnkey SPN IANDProdSPN.  The cert must be installed on your machine for this to work
$bootStrap = Login-AzCore -WebHookData $WebhookData -aad

"successfully connected to AD"
$sourceGroup = Get-AzADGroup -SearchString $sourceGroupName

#>

function Set-GroupOwners{
    param( 
        [string]$targetGroupName
    )
    $sourceGroup = Get-AzADGroup -SearchString $sourceGroupName
    $sourceMembers = Get-AzADGroupMember -GroupObjectId $sourceGroup.Id
    $targetGroup = Get-AzADGroup -SearchString $targetGroupName
    #$targetOwners = Get-AzureADGroupOwner -ObjectId $targetGroup.Id -All $True
    $members = @{}

    foreach($member in $sourceMembers) {
        $match = $false
        foreach($gp in $targetOwners) {
            if ($gp.ObjectId -eq $member.ObjectId) {
                # nothing to do
                $match = $true
                break
            }
        }
        if (-not $match) {
            #if($member.) if Service account
            # group is in the source but not the target group.  Need to add it.
            Write-Output "Adding Owner $($member.DisplayName) to $targetGroupName"
            Add-AzADGroupMember -MemberObjectId $member.ObjectId -TargetGroupObjectId $targetGroup.Id
        }
    }

    foreach($towner in $targetOwners) {
        $match = $false
        foreach($gp in $sourceMembers) {
            if ($gp.ObjectId -eq $towner.ObjectId) {
                # nothing to do
                $match = $true
                break
            }
        }
        if (-not $match) {
            # group is in the source but not the target group.  Need to add it.
            Write-Output "Removing owner $($towner.DisplayName) from $targetGroupName"
            Remove-AzureADGroupOwner -ObjectId $targetGroup.Id -OwnerId $towner.ObjectId
        }   
    }

    #add svc-b-da04-ina-automation as owner of group
    $spn = Get-AzADServicePrincipal -DisplayName "svc-b-da04-ina-automation"
    Add-AzADGroupMember -MemberObjectId $spn.ObjectId -TargetGroupObjectId $targetGroup.Id
    Write-Output "Added owner svc-b-da04-ina-automation to $targetGroupName"
}

$resourcegroups = Get-AzResourceGroup | select resourcegroupname
foreach ($resourcegroup in $resourcegroups)
{

    $resourcegroupName = $resourcegroup.resourcegroupname
<#
    if($resourcegroupName -ne "bnlwe-da04-d-00018-rg")
    {
        continue
    }
#>
<#
    $resourcesADF = Get-AzResource -ResourceGroupName $resourcegroupName -ResourceType "Microsoft.DataFactory/factories" | select Name, resourcename,ResoruceGroupName,resourceid,location
    foreach ($resourceADF in $resourcesADF)
    {
        $WebhookData = '{"WebhookName":"WebHook-SqlDwResume","RequestBody":"'+$($resourceADF.Name)+',31e4d879-203b-4afa-83db-20021cc889d9,","RequestHeader":{"Connection":"Keep-Alive","Expect":"100-continue","Host":"s2events.azure-automation.net","x-ms-request-id":"8b188be3-a238-4c00-8c26-e2a5f65d428e"}}'
        break
    }
    $parameters = .\Get-AllParameters.ps1 -webhookData $WebhookData
#>
    try{
        $approvedEnvironments = "d", "q", "b", "u", "p"
        $splitresourcegroupName = $resourcegroupName.Split("-")
        $environmentvar = $splitresourcegroupName[2]
        $itsg = $splitresourcegroupName[3]
        Write-Output "Source group $sourceGroupName"
        
        if ($environmentvar -in $approvedEnvironments)
        {
            try {
                $parameters = & "$utilitiesFolder\Get-Parameters.ps1" -parameterFile "$environmentvar.$itsg"    
            }
            catch {
                continue            
            }    
        }else {
            continue
        }

        Set-GroupOwners -sourceGroupName $sourceGroupName -targetGroupName $($parameters.parameters.appContributorGroupName.value)    
        Set-GroupOwners -sourceGroupName $sourceGroupName -targetGroupName $($parameters.parameters.appReaderGroupName.value)    
        
        Set-GroupOwners -sourceGroupName $sourceGroupName -targetGroupName $($parameters.parameters.dataReaderADGroupName.value)    
        Set-GroupOwners -sourceGroupName $sourceGroupName -targetGroupName $($parameters.parameters.dataWriterADGroupName.value)    
        Set-GroupOwners -sourceGroupName $sourceGroupName -targetGroupName $($parameters.parameters.dataOwnerADGroupName.value)  

        if($environmentvar -eq  "d"){
            Set-GroupOwners -sourceGroupName $sourceGroupName -targetGroupName $($parameters.parameters.developerSharepointADGroupName.value)    
            Set-GroupOwners -sourceGroupName $sourceGroupName -targetGroupName $($parameters.parameters.developerADGroupName.value)    
            Set-GroupOwners -sourceGroupName $sourceGroupName -targetGroupName $($parameters.parameters.testerADGroupName.value)    
            Set-GroupOwners -sourceGroupName $sourceGroupName -targetGroupName $($parameters.parameters.supportADGroupName.value)    
        }
    }catch{
            Write-Error $_.Exception.Message
    }
}