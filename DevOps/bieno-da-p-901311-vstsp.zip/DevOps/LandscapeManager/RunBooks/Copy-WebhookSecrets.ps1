param(
    [Parameter(Mandatory=$true)] [string]$parameterFile,
    [Parameter(Mandatory=$true)] [string]$parameterFileTarget
)
# Copy the webhook secrets from one key vault to another. Used for a one off copy when we decided to use dev autoamtion account for all non prod envs

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

if ($parameterFile -eq $parameterFileTarget)
{
	Write-Error "You cannot copy secrets to and from the same key vault."
	return
}
$parameters = & "$utilitiesFolder\Get-Parameters.ps1" -parameterFile $parameterFile
$parametersT = & "$utilitiesFolder\Get-Parameters.ps1" -parameterFile $parameterFileTarget

$subscriptionId = $parameters.parameters.subscriptionId.value
$sub = Select-AzSubscription -SubscriptionId $subscriptionId
Write-Verbose $sub

$rgName = $parameters.parameters.keyVaultResourceGroupName.value;
$kvName = $parameters.parameters.keyVaultName.value;

$rgNameT = $parametersT.parameters.keyVaultResourceGroupName.value;
$kvNameT = $parametersT.parameters.keyVaultName.value;

$secrets = Get-AzKeyVaultSecret -VaultName $kvName
foreach($secret in $secrets)
{
	$secret = Get-AzKeyVaultSecret -VaultName $kvName -Name $secret.Name
	
	$keyName = $secret.name
	#$keyValue = ConvertTo-SecureString -AsPlainText $secret.SecretValueText -Force
	$keyValue = $secret.SecretValue
	if ($keyName.Substring(0, 7) -eq "Webhook") {
		Write-Host "Adding secret $keyName to $kvNameT"
		$secretCredential = New-Object System.Management.Automation.PSCredential ($keyName, $keyValue)
		& "$utilitiesFolder\Set-KeyVaultSecret.ps1" -parameterFile $parameterFileTarget -secretCredential $secretCredential -updateSecret $true -secretExpiryDate $secret.Expires -contentType $secret.ContentType
	}
	else {
		Write-Host "Skipping secret $keyName"
	}
	
}
Write-Host "Secret copy is completed."