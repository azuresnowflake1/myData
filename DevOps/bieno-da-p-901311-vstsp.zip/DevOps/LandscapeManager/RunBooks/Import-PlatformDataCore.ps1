###########################################################################################
# Define reusable logic that supports the platform meta data extraction process.  We use
# this data to drive the platform dashboard
###########################################################################################

try {
    $region = Get-AutomationVariable -Name 'newFoundationRegion' -ErrorAction Stop
    # if the variable was defined then assume this is running in an automation account
    .\Import-PlatformCore.ps1
}
catch {
    # The variable wasn't defined so assume it's running locally.
    $folder = (Get-Item -Path $PSScriptRoot).FullName
    & "$folder\Import-PlatformCore.ps1"
}

function global:Set-SubscriptionMetaData {
    param(
        [hashtable]$subscriptionBootstrap, # From platform core Get-SubscriptionBootstrap
        [switch]$dataResourceGroup,
        [switch]$dataService,
        [switch]$dataSubscription,
        [switch]$dataResource,
        [switch]$dataKeyVault,
        [switch]$dataRbac,
        [switch]$dataDatabricks,
        [switch]$dataGit,
        [switch]$dataDTL,
        [string]$mergedDataFolderName # The container name where merged data files are stored.
    )
    if (-not $subscriptionBootstrap) {
        throw "Set-SubscriptionMetaData failed because the value passed for subscriptionBootstrap was null."
    }

    # Create a local working directory
      $parent = [System.IO.Path]::GetTempPath()
      [string] $name = [System.Guid]::NewGuid()
      $tempDir = (Join-Path $parent $name)
     New-Item -Path $tempDir -ItemType "directory" | Out-Null       
    if ($dataSubscription) {
        try {
            Write-Verbose "Writing Subscription data for subscription $($subscriptionBootstrap.SubscriptionNumber)"
            $fileName = "Subscriptions.{0}.csv" -f $subscriptionBootstrap.SubscriptionNumber
            $filePath = Join-Path $tempDir $fileName
            Set-SubscriptionData -filePath $filePath -subscriptionBootstrap $subscriptionBootstrap
            Set-BlobContentRaw -filePath $filePath
        }
        catch {
            $errors = $true
            Write-Error "An error occurred in Set-SubscriptionData for subscription $($subscriptionBootstrap.SubscriptionNumber)."
            Write-Error $_.Exception
        }
    }
    if ($dataService) {
        try {
            Write-Verbose "Writing Service data for subscription $($subscriptionBootstrap.SubscriptionNumber)"
            $fileName = "Services.{0}.csv" -f $subscriptionBootstrap.SubscriptionNumber
            $filePath = Join-Path $tempDir $fileName
            Set-ServiceData -filePath $filePath -defaultProfile $subscriptionBootstrap.DefaultProfile -subscriptionNumber $subscriptionBootstrap.SubscriptionNumber
            Set-BlobContentRaw -filePath $filePath
        }
        catch {
            $errors = $true
            Write-Error "An error occurred in Set-ServiceData for subscription $($subscriptionBootstrap.SubscriptionNumber)."
            Write-Error $_.Exception
        }
    }
    if ($dataResourceGroup) {
        try {
            Write-Verbose "Writing resource group data for subscription $($subscriptionBootstrap.SubscriptionNumber)"
            $fileName = "ResourceGroups.{0}.csv" -f $subscriptionBootstrap.SubscriptionNumber
            $filePath = Join-Path $tempDir $fileName
            Set-ResourceGroupData -filePath $filePath -subscriptionBootstrap $subscriptionBootstrap
            Set-BlobContentRaw -filePath $filePath
        }
        catch {
            $errors = $true
            Write-Error "An error occurred in Set-ResourceGroupData for subscription $($subscriptionBootstrap.SubscriptionNumber)."
            Write-Error $_.Exception
        }
    }
    if ($dataRbac) {
        #Disable this.  Commandlet doesn't work
        try {
            Write-Verbose "Writing RBAC data for subscription $($subscriptionBootstrap.SubscriptionNumber)"
            $fileName = "Rbac.{0}.csv" -f $subscriptionBootstrap.SubscriptionNumber
            $filePath = Join-Path $tempDir $fileName
            Set-RbacData -filePath $filePath -defaultProfile $subscriptionBootstrap.DefaultProfile
            Set-BlobContentRaw -filePath $filePath
        }
        catch {
            $errors = $true
            Write-Error "An error occurred in Set-RbacData for subscription $($subscriptionBootstrap.SubscriptionNumber)."
            Write-Error $_.Exception
        }
    }
    if ($dataResource) {
        try {
            Write-Verbose "Writing resource data for subscription $($subscriptionBootstrap.SubscriptionNumber)"
            $fileName = "Resources.{0}.csv" -f $subscriptionBootstrap.SubscriptionNumber
            $filePath = Join-Path $tempDir $fileName
            Set-ResourceData -filePath $filePath -defaultProfile $subscriptionBootstrap.DefaultProfile
            Set-BlobContentRaw -filePath $filePath
        }
        catch {
            $errors = $true
            Write-Error "An error occurred in Set-ResourceData for subscription $($subscriptionBootstrap.SubscriptionNumber)."
            Write-Error $_.Exception
        }
    }
    if ($dataKeyVault) {
        try {
            Write-Verbose "Writing key vault secret data for subscription $($subscriptionBootstrap.SubscriptionNumber)"
            $fileName = "KeyvaultSecrets.{0}.csv" -f $subscriptionBootstrap.SubscriptionNumber
            $filePath = Join-Path $tempDir $fileName
            Set-KeyVaultData -filePath $filePath -subscriptionBootstrap $subscriptionBootstrap
            Set-BlobContentRaw -filePath $filePath
        }
        catch {
            $errors = $true
            Write-Error "An error occurred in Set-KeyVaultData for subscription $($subscriptionBootstrap.SubscriptionNumber)."
            Write-Error $_.Exception
        }
    }
    if ($dataDatabricks) {
        try {
            Write-Verbose "Writing databricks data for subscription $($subscriptionBootstrap.SubscriptionNumber)"
            $fileName = "AdbCluster.{0}.csv" -f $subscriptionBootstrap.SubscriptionNumber
            $filePath = Join-Path $tempDir $fileName
            Set-DatabricksClusterData -filePath $filePath -subscriptionBootstrap $subscriptionBootstrap -mergedDataFolderName $mergedDataFolderName
            Set-BlobContentRaw -filePath $filePath
        }
        catch {
            $errors = $true
            Write-Error "An error occurred in Set-DatabricksClusterData for subscription $($subscriptionBootstrap.SubscriptionNumber)."
            Write-Error $_.Exception
        }
    }
    if ($dataGit) {
        try {
            Write-Verbose "Writing Git log data for subscription $($subscriptionBootstrap.SubscriptionNumber)"
            $fileName = "GitCommits.{0}.csv" -f $subscriptionBootstrap.SubscriptionNumber
            $filePath = Join-Path $tempDir $fileName
            global:Set-GitCommitData -filePath $filePath -defaultProfile $subscriptionBootstrap.DefaultProfile
            Set-BlobContentRaw -filePath $filePath
        }
        catch {
            $errors = $true
            Write-Error "An error occurred in Set-GitCommitData for subscription $($subscriptionBootstrap.SubscriptionNumber)."
            Write-Error $_.Exception
        }
    }
    if ($dataDTL) {
        try {
            if ("04.12".Contains($subscriptionBootstrap.SubscriptionNumber)) {
                # We only have 2 instances of DTL
                Write-Verbose "Writing DTL data for subscription $($subscriptionBootstrap.SubscriptionNumber)"
                $fileName = "DevTestLab.{0}.csv" -f $subscriptionBootstrap.SubscriptionNumber
                $filePath = Join-Path $tempDir $fileName
                Set-DTLData -filePath $filePath -subscriptionBootstrap $subscriptionBootstrap
                Set-BlobContentRaw -filePath $filePath
            }
        }
        catch {
            $errors = $true
            Write-Error "An error occurred in Set-DTL for subscription $($subscriptionBootstrap.SubscriptionNumber)."
            Write-Error $_.Exception
        }
    }
     Remove-Item -Path $tempDir -Recurse -force
}
# This includes new and old foundation data in a single call
function global:Set-AADMetaData {
    param(
        [string]$mergeDataFolderName # The name of the storage account folder that holds merged raw files. This is blank for live
    )
    # Create a local working directory
    $parent = [System.IO.Path]::GetTempPath()
    [string] $name = [System.Guid]::NewGuid()
    $tempDir = (Join-Path $parent $name)
    New-Item -Path $tempDir -ItemType "directory" | Out-Null

    # Get AAD data last since it requires a context switch into to access AAD
    try {
        Write-Verbose "Writing Global AAD data for all subscriptions"
        $fileName = "AdGroups.00.csv"
        $filePathGroups = Join-Path $tempDir $fileName
        $fileName = "AdGroupMembers.00.csv"
        $filePathMembers = Join-Path $tempDir $fileName
        Set-AADData -filePathGroups $filePathGroups -filePathMembers $filePathMembers -mergedDataFolderName $mergeDataFolderName
        Set-BlobContentRaw -filePath $filePathGroups
        Set-BlobContentRaw -filePath $filePathMembers
    }
    catch {
        Write-Error "Error ocurred in Set-AADMetaData: $($_.Exception)"
    }
    Remove-Item -Path $tempDir -Recurse -force
}
# Get a list of RGs that belong to our platform with tag values as columns. Works for new and old foundation
function global:Get-PlatformResourceGroup {
    param([Microsoft.Azure.Commands.Profile.Models.Core.PSAzureContext]$defaultProfile)
  
    if (-not $defaultProfile) {
        $defaultProfile = Get-AzContext 
    }
    $subscriptionId = $defaultProfile.Subscription.Id
    $subscriptionName = $defaultProfile.Subscription.Name
    $params = @{
        "DefaultProfile" = $defaultProfile
    }
    if ($defaultProfile.Subscription.Name.Contains("PROD")) {
        $params["ResourceGroupName"] = "*-da-*"
    }
    Get-AzResourceGroup @params | Select-Object ResourceGroupName, Location, ProvisioningState, ResourceId, @{l = "SubscriptionId"; e = { "$subscriptionId" } }, @{name = "ServiceName"; expression = { $(if ($_.Tags -and $_.Tags["ServiceName"]) { $_.Tags["ServiceName"] } else { if ($_.Tags -and $_.Tags["serviceName"]) { $_.Tags["serviceName"] } else { "" } }) } }, @{name = "CostCentre"; expression = { $_.Tags["CostCentre"] } }, @{name = "Icc"; expression = { $_.Tags["Icc"] } }, @{name = "Platform"; expression = { $_.Tags["Platform"] } }, @{name = "Environment"; expression = { $_.Tags["Environment"] } }, @{name = "DeliveryDirector"; expression = { $(if ($_.Tags -and $_.Tags["DeliveryDirector"]) { $_.Tags["DeliveryDirector"] } else { "" }) } }, @{name = "ProvisionedBy"; expression = { $(if ($_.Tags -and $_.Tags["ProvisionedBy"]) { $_.Tags["ProvisionedBy"] } else { "" }) } }, @{name = "ProvisionedOn"; expression = { $(if ($_.Tags -and $_.Tags["ProvisionedOn"]) { $_.Tags["ProvisionedOn"] } else { "" }) } }, @{name = "DataScience"; expression = { $(if ($_.Tags -and $_.Tags["DataScience"]) { $_.Tags["DataScience"] } else { "" }) } }, @{name = "ExpiryDate"; expression = { $(if ($_.Tags -and $_.Tags["ExpiryDate"]) { $_.Tags["ExpiryDate"] } else { "" }) } }, @{name = "Market"; expression = { $(if ($_.Tags -and $_.Tags["Market"]) { $_.Tags["Market"] } else { "" }) } },@{l="SubscriptionName";e={"$subscriptionName"}},@{name="Requestor";expression={$(if ($_.Tags -and $_.Tags["Requestor"]) {$_.Tags["Requestor"]} else {""})}}
}
# Get a list of resources that belong to our platform. Works for new and old foundation
function global:Get-PlatformResource {
    param([Microsoft.Azure.Commands.Profile.Models.Core.PSAzureContext]$defaultProfile, [string]$resourceType)
  
    if (-not $defaultProfile) {
        $defaultProfile = Get-AzContext 
    }
    $params = @{
        "DefaultProfile" = $defaultProfile
    }
    if ($defaultProfile.Subscription.Name. ToUpper().Contains("PROD")) {
        $params["ResourceGroupName"] = "*-da-*"
    }
    if ($resourceType) {
        $params["ResourceType"] = $resourceType
    }
    Get-AzResource @params
}
# This can be used for new and old foundation
function global:Set-ResourceGroupData {
    param([string]$filePath, [hashtable]$subscriptionBootstrap)
 
    [Microsoft.Azure.Commands.Profile.Models.Core.PSAzureContext]$defaultProfile = $subscriptionBootstrap.DefaultProfile
    if (-not $defaultProfile) {
        $defaultProfile = Get-AzContext 
    }
    # Handle databricks managed RGs.  We need to include them with the tag values of the parent RG.  To do this construct a hash that
    # maps ADB workspace name to resource group name, then use that to look up the actual RG and get its tags.
    $adbHash = @{}
    $rgHash = @{}
    Get-PlatformResource -DefaultProfile $defaultProfile -ResourceType Microsoft.Databricks/workspaces | foreach-Object { $adbHash[$_.Name] = $_.ResourceGroupName }
    Get-PlatformResourceGroup -DefaultProfile $defaultProfile | foreach-Object { $rgHash[$_.ResourceGroupName] = $_ }

    $rgHash.Values | where-object { -not $_.ResourceGroupName.StartsWith("databricks-rg-") } | Select-Object ResourceGroupName, Location, ProvisioningState, ResourceId, SubscriptionId, ServiceName, DeliveryDirector, ProvisionedBy, ProvisionedOn, DataScience, ExpiryDate, Market,SubscriptionName,Environment,Requestor  | Export-Csv -NoTypeInformation -Encoding utf8 -Path $filePath
    # Append ADB managed RGS but lookup the service tags.  We assume the ADB RG name convention:
    # databricks-rg-<workspace_name>-<random chars>
    # Chop the managed resource group name into a workspace name, use that to lookup the parent resource group name in $adbHash, then use that RG name
    # to lookup the resource group object in $rgHash.  Once you have the RG the ServiceName can be read off.
    $rgHash.Values | where-object { $_.ResourceGroupName.StartsWith("databricks-rg-") }  | Select-Object ResourceGroupName, Location, ProvisioningState, ResourceId, subscriptionId, @{name = "ServiceName"; expression = { $(if ($adbHash[$_.ResourceGroupName.substring(14, $_.ResourceGroupName.Length - 28)]) { $rgHash[$adbhash[$_.ResourceGroupName.substring(14, $_.ResourceGroupName.Length - 28)]].ServiceName } else { "" }) } }, DeliveryDirector, ProvisionedBy, ProvisionedOn, DataScience, ExpiryDate, Market,SubscriptionName,Environment,Requestor | Export-Csv -NoTypeInformation -Encoding utf8 -Path $filePath -Append
}
function global:Set-DTLData {
    param([string]$filePath, [hashtable]$subscriptionBootstrap)
 
    [Microsoft.Azure.Commands.Profile.Models.Core.PSAzureContext]$defaultProfile = $subscriptionBootstrap.DefaultProfile
    if (-not $defaultProfile) {
        $defaultProfile = Get-AzContext 
    }
    $resourceGroups = @{}
    [System.Collections.ArrayList]$vms = @()
    # Get the current complete resource group data file
    $path = Get-BlobContentFinal -mergedFileName "ResourceGroups.csv" -sourceFolder ""
    $rgs = Import-csv -Path $path 
    foreach ($rg in $rgs) {
        if (-not $rg.ResourceGroupName.StartsWith("databricks-rg-")) {
            $tokens = $rg.ResourceGroupName.Split("-")
            if ($tokens.Count -ge 4) {
                # Assume the itsg is available
                $resourceGroups[$tokens[3]] = $rg.ServiceName
            }
        }
    }
    $resourceGroupName = "{0}-da{1}-p-00000-dtl-rg" -f (Get-NamePrefix -Region $subscriptionBootstrap.Region), $subscriptionBootstrap.SubscriptionNumber
    foreach ($vm in (Get-AzVM -ResourceGroupName $resourceGroupName -DefaultProfile $defaultProfile)) {
        [int]$rtn = 0
        if ($vm.Name.Contains("BNLWED") -and ([Int32]::TryParse($vm.Name.substring(12, 1), [ref]$rtn)) -and $vm.Name.substring(12, 1) -ne "0") {
            # We know for sure it's a 6 digit ITSG
            $itsg = $vm.Name.substring(7, 6)
        }
        else {
            # could be a five digit ITSG or a six digit that ends in zero
            if ($resourceGroups[$vm.Name.substring(7, 6)]) {
                # found a match on 6 digits
                $itsg = $vm.Name.substring(7, 6)
            }
            elseif ($resourceGroups[$vm.Name.substring(7, 5)]) {
                # found a match on 5 digit
                $itsg = $vm.Name.substring(7, 5)
            }
            else {
                $itsg = "56731"
                Write-Warning "Unable to determine the Service Name for DTL VM '$($vm.Name)'.  Defaulting to central platform cost centre."
            }
        }
        if ($itsg) {
            $serviceName = $resourceGroups[$itsg]
        }
        else {
            # Default to the platform cost centre
            $serviceName = "Global I&A IR/OPDG/VSTS/Reports"
        }
        [PSCustomObject]$vmObject = @{
            "ServiceName"       = $serviceName
            "ResourceId"        = $vm.Id
            "VMName"            = $vm.Name
            "VMSize"            = $vm.HardwareProfile.VMSize
            "Location"          = $vm.Location
            "ProvisioningState" = $vm.ProvisioningState
        }
        $vms.Add($vmObject) | Out-Null
    }
    $vms | Select-Object @{name = "ServiceName"; expression = { $_.ServiceName } }, @{name = "ResourceId"; expression = { $_.ResourceId } }, @{name = "VMName"; expression = { $_.VMName } }, @{name = "VMSize"; expression = { $_.VMSize } }, @{name = "Location"; expression = { $_.Location } }, @{name = "ProvisioningState"; expression = { $_.ProvisioningState } } | Export-Csv -NoTypeInformation -Encoding utf8 -Path $filePath
}
# This can be used for new and old foundation
function global:Set-ServiceData {
    param([string]$filePath, [Microsoft.Azure.Commands.Profile.Models.Core.PSAzureContext]$defaultProfile,
        [string]$subscriptionNumber)
    
    if (-not $defaultProfile) {
        $defaultProfile = Get-AzContext
    }
    $itsgDev = @{name = "ITSGDev"; expression = { $(if ($_.ResourceGroupName.Split("-")[3] -match "^\d+$" -and $_.Environment -eq "Development") { $_.ResourceGroupName.Split("-")[3] } else { "" }) } } 
    $itsgQA = @{name = "ITSGQA"; expression = { $(if ($_.ResourceGroupName.Split("-")[3] -match "^\d+$" -and $_.Environment -eq "QA") { $_.ResourceGroupName.Split("-")[3] } else { "" }) } } 
    $itsgPPD = @{name = "ITSGPPD"; expression = { $(if ($_.ResourceGroupName.Split("-")[3] -match "^\d+$" -and $_.Environment -eq "PreProd") { $_.ResourceGroupName.Split("-")[3] } else { "" }) } } 
    $itsgUAT = @{name = "ITSGUAT"; expression = { $(if ($_.ResourceGroupName.Split("-")[3] -match "^\d+$" -and $_.Environment -eq "Acceptance") { $_.ResourceGroupName.Split("-")[3] } else { "" }) } } 
    $itsgProd = @{name = "ITSGProd"; expression = { $(if ($_.ResourceGroupName.Split("-")[3] -match "^\d+$" -and $_.Environment -eq "Production") { $_.ResourceGroupName.Split("-")[3] } else { "" }) } } 
    $itsgDR = @{name = "ITSGDR"; expression = { $(if ($_.ResourceGroupName.Split("-")[3] -match "^\d+$" -and $_.Environment -eq "DR") { $_.ResourceGroupName.Split("-")[3] } else { "" }) } } 
    $itsgExp = @{name = "ITSGExp"; expression = { $(if ($_.ResourceGroupName.Split("-")[3] -match "^\d+$" -and ($_.Environment -eq "Experiment" -or $_.Environment -eq "Data Science")) { $_.ResourceGroupName.Split("-")[3] } else { "" }) } } 
    $subDev = @{name = "SubDev"; expression = { $(if ($_.ResourceGroupName.Split("-")[3] -match "^\d+$" -and $_.Environment -eq "Development") { $subscriptionNumber } else { "" }) } }
    $subQA = @{name = "SubQA"; expression = { $(if ($_.ResourceGroupName.Split("-")[3] -match "^\d+$" -and $_.Environment -eq "QA") { $subscriptionNumber } else { "" }) } }
    $subPPD = @{name = "SubPPD"; expression = { $(if ($_.ResourceGroupName.Split("-")[3] -match "^\d+$" -and $_.Environment -eq "PreProd") { $subscriptionNumber } else { "" }) } }
    $subUAT = @{name = "SubUAT"; expression = { $(if ($_.ResourceGroupName.Split("-")[3] -match "^\d+$" -and $_.Environment -eq "Acceptance") { $subscriptionNumber } else { "" }) } }
    $subProd = @{name = "SubProd"; expression = { $(if ($_.ResourceGroupName.Split("-")[3] -match "^\d+$" -and $_.Environment -eq "Production") { $subscriptionNumber } else { "" }) } }
    $subDR = @{name = "SubDR"; expression = { $(if ($_.ResourceGroupName.Split("-")[3] -match "^\d+$" -and $_.Environment -eq "DR") { $subscriptionNumber } else { "" }) } }
    $subExp = @{name = "SubExp"; expression = { $(if ($_.ResourceGroupName.Split("-")[3] -match "^\d+$" -and ($_.Environment -eq "Experiment" -or $_.Environment -eq "Data Science")) { $subscriptionNumber } else { "" }) } }
    Get-PlatformResourceGroup -DefaultProfile $defaultProfile | Where-Object { (-not $_.ResourceGroupName.StartsWith("databricks-rg-")) -and (-not $_.ResourceGroupName.StartsWith("NetworkWatcherRG"))-and (-not $_.ResourceGroupName.StartsWith("bnlwe-p-DA-alerts-rg"))  } | `
        Select-Object ServiceName, CostCentre, Icc, Platform, $itsgDev, $itsgQA , $itsgPPD, $itsgUAT, $itsgProd, $itsgDR, $itsgExp, $subDev, $subQA, $subPPD, $subUAT, $subProd, $subDR, $subExp | `
        Sort-Object -Property ServiceName -Unique | `
        Export-Csv -NoTypeInformation -Encoding utf8 -Path $filePath 
}
function global:Get-ServiceDataITSG {
    param([string]$processingFolderName, [string]$containerName)
    # Create a local working directory
    $parent = [System.IO.Path]::GetTempPath()
    [string] $name = [System.Guid]::NewGuid()
    $tempDir = (Join-Path $parent $name)
    New-Item -Path $tempDir -ItemType "directory" | Out-Null
    
    $path = Get-BlobContentFinal -mergedFileName "ServicesITSG.csv" -sourceFolder $processingFolderName
    $data = Import-Csv $path
    $fileName = "Services.csv"
    #$tempDir = "C:\temp\Services\"
    $filePathServices = Join-Path $tempDir $fileName
    
    $data | Group-Object -Property ServiceName | `
        Select-Object @{N = 'ServiceName'; E = { ($_.Group | Measure-Object -Property ServiceName -Maximum).Maximum } }, `
    @{N = 'CostCentre'; E = { ($_.Group | Measure-Object -Property CostCentre -Maximum).Maximum } }, `
    @{N = 'Icc'; E = { ($_.Group | Measure-Object -Property Icc -Maximum).Maximum } }, `
    @{N = 'Platform'; E = { ($_.Group | Measure-Object -Property Platform -Maximum).Maximum } }, `
    @{N = 'ITSGDev'; E = { ([string]($_.Group | Measure-Object -Property ITSGDev -Maximum).Maximum) } }, `
    @{N = 'ITSGQA'; E = { ([string]($_.Group | Measure-Object -Property ITSGQA -Maximum).Maximum) } }, `
    @{N = 'ITSGPPD'; E = { ([string]($_.Group | Measure-Object -Property ITSGPPD -Maximum).Maximum) } }, `
    @{N = 'ITSGUAT'; E = { ([string]($_.Group | Measure-Object -Property ITSGUAT -Maximum).Maximum) } }, `
    @{N = 'ITSGProd'; E = { ([string]($_.Group | Measure-Object -Property ITSGProd -Maximum).Maximum) } }, `
    @{N = 'ITSGDR'; E = { ([string]($_.Group | Measure-Object -Property ITSGDR -Maximum).Maximum) } }, `
    @{N = 'ITSGExp'; E = { ([string]($_.Group | Measure-Object -Property ITSGExp -Maximum).Maximum) } }, `
    @{N = 'SubDev'; E = { ([string]($_.Group | Measure-Object -Property SubDev -Maximum).Maximum).PadLeft(2, "0") } }, `
    @{N = 'SubQA'; E = { ([string]($_.Group | Measure-Object -Property SubQA  -Maximum).Maximum).PadLeft(2, "0") } }, `
    @{N = 'SubPPD'; E = { ([string]($_.Group | Measure-Object -Property SubPPD -Maximum).Maximum).PadLeft(2, "0") } }, `
    @{N = 'SubUAT'; E = { ([string]($_.Group | Measure-Object -Property SubUAT -Maximum).Maximum).PadLeft(2, "0") } }, `
    @{N = 'SubProd'; E = { ([string]($_.Group | Measure-Object -Property SubProd -Maximum).Maximum).PadLeft(2, "0") } }, `
    @{N = 'SubDR'; E = { ([string]($_.Group | Measure-Object -Property SubDR -Maximum).Maximum).PadLeft(2, "0") } }, `
    @{N = 'SubExp'; E = { ([string]($_.Group | Measure-Object -Property SubExp -Maximum).Maximum).PadLeft(2, "0") } } | `
        Export-Csv -NoTypeInformation -Encoding utf8 -Path $filePathServices

    Set-BlobContentRaw -filePath $filePathServices -targetFolder "."
    
}
# This can be used for new and old foundation
function global:Set-SubscriptionData {
    param([string]$filePath, [hashtable]$subscriptionBootstrap)
 
    if (-not $subscriptionBootstrap.DefaultProfile) {
        $defaultProfile = Get-AzContext
    }
    else {
        $defaultProfile = $subscriptionBootstrap.DefaultProfile
    }
    $subscriptionUsage = "Old Foundation (northeurope)"
    $tokens = $defaultProfile.Subscription.Name.Split("-")
    if ($tokens.count -eq 2) {
        $subscriptionUsage = "{0} ({1})" -f $subscriptionBootstrap.EnvironmentUsage, $subscriptionBootstrap.Region
    }
 
    $defaultProfile.Subscription | Select-Object Id, Name, TenantId, State, @{name = "SubscriptionUsage"; expression = { $subscriptionUsage } } | Export-Csv -NoTypeInformation -Path $filePath 
}
# This can be used for new and old foundation
function global:Set-ResourceData {
    param([string]$filePath, [Microsoft.Azure.Commands.Profile.Models.Core.PSAzureContext]$defaultProfile)
 
    if (-not $defaultProfile) {
        $defaultProfile = Get-AzContext
    }
    Get-PlatformResource -DefaultProfile $defaultProfile | Select-Object ResourceId, Name, @{name = "ResourceGroupId"; expression = { "{0}/{1}/{2}/{3}/{4}" -f $_.ResourceId.Split('/') } }, ResourceType, Location | Export-Csv -NoTypeInformation -Encoding utf8 -Path $filePath 
}

# This can be used for new and old foundation
function global:Set-KeyVaultData {
    param([string]$filePath, [hashtable]$subscriptionBootstrap)
 
    [Microsoft.Azure.Commands.Profile.Models.Core.PSAzureContext]$defaultProfile = $subscriptionBootstrap.DefaultProfile
    if (-not $defaultProfile) {
        $defaultProfile = Get-AzContext
    }
    $bootStrap = Get-Bootstrap -subscriptionNumber $subscriptionBootstrap.SubscriptionNumber
    $i = 0
    $skip = 0
 
    foreach ($keyVault in Get-PlatformResource -defaultProfile $defaultProfile -resourceType "Microsoft.KeyVault/vaults") {
        if ($i -gt 0) {
            # Don't output CSV headers
            $skip = 1
        }
        try {
            $keyVault | Get-AzKeyVaultSecret -DefaultProfile $defaultProfile -ErrorAction Stop | where-Object { $null -eq $_.expires -or $_.expires -gt (Get-date).addMonths(-3) } | Select-Object VaultName, @{name = "VaultResourceId"; expression = { $keyVault.ResourceId } }, Name, Id, @{name = "Expires"; expression = { $_.Expires.ToString("yyyy-MM-dd HH:mm") } }, @{name = "NotBefore"; expression = { $_.NotBefore.ToString("yyyy-MM-dd HH:mm") } }, @{name = "Created"; expression = { $_.Created.ToString("yyyy-MM-dd HH:mm") } }, @{name = "Updated"; expression = { $_.Updated.ToString("yyyy-MM-dd HH:mm") } }, @{name = "ServiceName"; expression = { $(if ($keyVault.Tags -and $keyVault.Tags["ServiceName"]) { $keyVault.Tags["ServiceName"] } else { if ($keyVault.Tags -and $keyVault.Tags["serviceName"]) { $keyVault.Tags["serviceName"] } else { "" } })  } }, ContentType | ConvertTo-Csv -NoTypeInformation | Select-Object -skip $skip | Add-Content -Path $filePath 
            $i++            
        }
        catch [Microsoft.Azure.Keyvault.Models.KeyvaultErrorException] {
            # Assume the autpomation SPN doesn't have key vault access.  Grant it.
            #$spnName = "http://{0}{1}-ina-automation" -f $bootStrap.NamePrefix, $bootstrap.SubscriptionNumber
            $spnName = "http://bnlweda00-ina-automation" # this is the AAD SPN
         
            Write-Error "Failed to get key vault secrets for $($keyVault.Name) $($_) using $spnName"
            Set-AzKeyVaultAccessPolicy -DefaultProfile $defaultProfile -VaultName $keyVault.Name -ResourceGroupName $keyVault.ResourceGroupName -ServicePrincipalName $spnName -PermissionsToSecrets get, list, set  


            $objectId = Get-AzAdGroup -DisplayName "SEC-ES-DA-p-56728-azure-landscape" -defaultProfile $defaultProfile
            if ($objectId) {
                Set-AzKeyVaultAccessPolicy -VaultName $keyVault.Name -ResourceGroupName $keyVault.ResourceGroupName -ObjectId $objectId.Id -DefaultProfile $defaultProfile -PermissionsToSecrets get, list, set, delete, backup, restore, recover, purge -PermissionsToKeys decrypt, encrypt, unwrapKey, wrapKey, verify, sign, get, list, update, create, import, delete, backup, restore, recover, purge
            }
            $aadSPN = Get-AzAdApplication -DisplayName IANDASPNProd -DefaultProfile $defaultProfile
            if ($aadSPN) {
                Set-AzKeyVaultAccessPolicy  -VaultName $keyVault.Name -ResourceGroupName $keyVault.ResourceGroupName -ObjectId $aadSPN.ObjectId -DefaultProfile $defaultProfile -PermissionsToSecrets Get, List, Set
            }

        } 
    }
}
# This can be used for new and old foundation
function global:Set-RBACData {
    param([string]$filePath, [Microsoft.Azure.Commands.Profile.Models.Core.PSAzureContext]$defaultProfile)
 
    if (-not $defaultProfile) {
        $defaultProfile = Get-AzContext
    }
    $subscriptionId = $defaultProfile.Subscription.Id
    Get-AzRoleAssignMent -DefaultProfile $defaultProfile -ErrorAction Stop | Where-Object { $_.Scope.StartsWith("/subscriptions/") } | Select-Object @{name = "SubscriptionId"; expression = { $subscriptionId } }, RoleAssignmentId, Scope, DisplayName, SignInName, RoleDefinitionName, RoleDefinitionId, ObjectId, ObjectType, CanDelegate | Export-Csv -NoTypeInformation -Encoding utf8 -Path $filePath 
}
function global:Get-Clusters {
    param(
        $uriBase,
        $accessToken,
        $uri = "$uriBase/clusters/list")

    $head = @{authorization = "Bearer $accessToken" }
    $clusters = Invoke-RestMethod -Uri $uri -Method 'GET' -Headers $head -ContentType "application/json" -ErrorAction Stop
    return $clusters
}

# This can be used for new and old foundation
function global:Set-DatabricksClusterData {
    param([string]$filePath, [hashtable]$subscriptionBootstrap, [string]$mergedDataFolderName)
 
    [Microsoft.Azure.Commands.Profile.Models.Core.PSAzureContext]$defaultProfile = $subscriptionBootstrap.DefaultProfile
    $region = $subscriptionBootstrap.Region
 
    if (-not $defaultProfile) {
        $defaultProfile = Get-AzContext
    }
    $subscriptionId = $defaultProfile.Subscription.Id
    $uriBase = "https://$region.azuredatabricks.net/api/2.0"
    $header = '"cluster_id","cluster_name","SubscriptionId","ServiceName", "ResourceGroupId","spark_version","node_type_id","driver_node_type_id","autotermination_minutes","cluster_source","creator_user_name","ProjectSupportTeam","Purpose"'
    add-type @"
using System.Net;
using System.Security.Cryptography.X509Certificates;
public class TrustAllCertsPolicy : ICertificatePolicy {
 public bool CheckValidationResult(
     ServicePoint srvPoint, X509Certificate certificate,
     WebRequest request, int certificateProblem) {
     return true;
 }
}
"@
    $AllProtocols = [System.Net.SecurityProtocolType]'Ssl3,Tls,Tls11,Tls12'
    [System.Net.ServicePointManager]::SecurityProtocol = $AllProtocols

    $path = Get-BlobContentFinal -mergedFileName "KeyvaultSecrets.csv" -sourceFolder $mergedDataFolderName
    $secrets = Import-csv -Path $path

    $i = 0
    $skip = 0
    # Filter so that we only consider secrets for the current subscription
    foreach ($secret in $secrets | Where-Object { $_.VaultResourceId.Contains($subscriptionId) }) { 
  
        if ($secret.Name.ToLower().Contains("databricks") -and $secret.Name.ToLower().Contains("token")) {
            # Assume the itsg is available
            $resourceGroup = ((($secret.VaultName).split("-", 6) | Select-Object -Index 0, 1, 2, 3) -join "-") , "rg" -join "-"
            $resourceGroupId = ((($secret.VaultResourceId).split("/", 6) | Select-Object -Index 0, 1, 2, 3) -join "/") , $resourceGroup -join "/"
            try {
                $sec = Get-AzKeyVaultSecret -DefaultProfile $defaultProfile -VaultName $secret.VaultName -Name $secret.Name -ErrorAction Stop
                $response = Get-Clusters -uriBase $uriBase -accessToken $sec.SecretValueText
                $clusters = $response.clusters
                if ($clusters) {
                    $clusters | Select-Object cluster_id, cluster_name, @{name = "SubscriptionId"; expression = { $subscriptionId } }, @{name = "ServiceName"; expression = { $secret.ServiceName } }, @{name = "ResourceGroupId"; expression = { $resourceGroupId } }, spark_version, node_type_id, driver_node_type_id, autotermination_minutes, cluster_source, creator_user_name, @{name = "ProjectSupportTeam"; expression = { $(if ($_.custom_tags -and $_.custom_tags.ProjectSupportTeam) { $_.custom_tags.ProjectSupportTeam } else { "" }) } }, @{name = "Purpose"; expression = { $(if ($_.custom_tags -and $_.custom_tags.Purpose) { $_.custom_tags.Purpose } else { "" }) } } | ConvertTo-Csv -NoTypeInformation | Select-Object -skip $skip | Add-Content -Path $filePath
                    $i++
                }
            }
            catch {
                if ($i -eq 0) {
                    # Export headers
                    $header | Add-Content -Path $filePath
                }
                $csv = """$($secret.VaultName)"",""Error Occurred"",""{0}"",""{1}"",""{2}"",,,,,,,," -f $subscriptionId, $secret.ServiceName, $resourceGroupId
                $csv | Add-Content -Path $filePath
                Write-Warning "ADB Cluster Error: $($secret.VaultName): $($secret.Name) $_"
                $i++
            }
            finally {
                if ($i -gt 0) {
                    $skip = 1
                }
            }
        }
    }
    # Get cluster info from ondemand ADF linked services
    foreach ($adf in Get-AzDataFactoryV2 -DefaultProfile $defaultProfile) {
        $resourceGroup = Get-AzResourceGroup -DefaultProfile $defaultProfile -Name $adf.ResourceGroupName
        foreach ($link in Get-AzDataFactoryV2LinkedService -DefaultProfile $defaultProfile -resourcegroupName $adf.ResourceGroupName -DataFactoryName $adf.DataFactoryName ) {
            if ($link.properties.GetType().Name -ne "AzureDatabricksLinkedService") {
                # this isn't an ADB linked service
                continue
            }
            elseif ($link.properties.ExistingClusterId) {
                # this ADF link is pointing at an existing cluster so ignore it
                continue
            }
            else {
                if ($i -eq 0) {
                    # Export headers
                    $header | Add-Content -Path $filePath
                }
                if ($resourceGroup.Tags -and $resourceGroup.Tags.Contains("ServiceName")) {
                    $serviceName = $resourceGroup.Tags["ServiceName"] 
                }
                else {
                    $serviceName = ""
                }
             
                $csv = """$($adf.DataFactoryName).$($link.Name)"",""On Demand Cluster"",""{0}"",""{1}"",""{2}"",""$($link.properties.NewClusterVersion)"",""$($link.properties.NewClusterNodeType)"",,,""$($adf.DataFactoryName)"",""$(if ($link.properties.NewClusterCustomTags -and $link.properties.NewClusterCustomTags.ProjectSupportTeam) {$link.properties.NewClusterCustomTags.ProjectSupportTeam})"",""$(if ($link.properties.NewClusterCustomTags -and $link.properties.NewClusterCustomTags.Purpose) {$link.properties.NewClusterCustomTags.Purpose} )""" -f $subscriptionId, $serviceName, $ResourceGroup.ResourceId
                $csv | Add-Content -Path $filePath 
                $i++
            }
        }
    }
}

# This is a global extraction.  Works for all envionments but depended on the merged resource group file.
# It should be a called after this extraction completes
function global:Set-AADData {
    param([string]$filePathGroups, [string]$filePathMembers, [string]$mergedDataFolderName)
    # Note that this is a global extraction.  No need to run for each subscription
    # Logic tries to match resource group names to AAD user group names using the ITSG
    $resourceGroups = @{}
    # Get the current complete resource group data file
    $path = Get-BlobContentFinal -mergedFileName "ResourceGroups.csv" -sourceFolder $mergedDataFolderName
    $rgs = Import-csv -Path $path 
    foreach ($rg in $rgs) {
        $tokens = $rg.ResourceGroupName.Split("-")
        if ($tokens.Count -ge 4) {
            # Assume the itsg is available
            $resourceGroups[$tokens[3]] = $rg.ServiceName    
        }
    }
 
    if ($resourceGroups.count -eq 0) {
        throw "The current resource group master file has zero resource groups.  No AAD group to service match is possible."
    }
    # We need to map each AD group to a service.  Do this by artifically calculating itsg from the group name
    $groups = Get-AzureADGroup -All $true -SearchString "SEC-ES-DA-" | Where-Object { $_.DisplayName -match "(-azure-developer|-azure-tester|-azure-devops|-ProjectAdmins|-azure-support|-developer|-tester|-support |-supportlevel1)$" } 
    # Filter out groups that have no service name
    $groups = $groups | Select-Object @{name = "GroupId"; expression = { $_.ObjectId } }, DisplayName, Description, @{name = "ServiceName"; expression = { $resourceGroups[$_.DisplayName.Split("-")[4]] } } | Where-Object { $_.ServiceName -ne $null } 
    if ($groups.count -eq 0) {
        # Didn't match AD groups to resource groups.  RGs must be none turnkey
        Write-Warning "Didn't match AD groups to resource groups using the current master resource group file"
        return
    }
    else {
        $groups | ConvertTo-Csv -NoTypeInformation | Add-Content -Path $filePathGroups 
    }
 
    # Repeat for group members
    $i = 0
    $skipLocal = 0
    foreach ($group in $groups) {
        if ($i -gt 0) {
            $skipLocal = 1
        }
        $members = Get-AzureADGroupMember -All $true -ObjectId $group.GroupId
        if ($members.count -gt 0) {
            Get-AzureADGroupMember -All $true -ObjectId $group.GroupId | Select-Object ObjectId, DisplayName, @{name = "GroupId"; expression = { $group.GroupId } } | ConvertTo-Csv -NoTypeInformation | Select-Object -Skip $skipLocal | Add-Content -Path $filePathMembers 
            $i++
        }
    }
}
function global:Set-GitCommitData {
    param([string]$filePath, [Microsoft.Azure.Commands.Profile.Models.Core.PSAzureContext]$defaultProfile)

    $header1 = "ServiceName,VSTSProject,Repository,LastCommitEmail,LastCommitDate,LastCommitComment,TotalCommitsInLast30Days"

    Add-Content $filePath $header1

    $landscapeResourceKVName = "bnlwe-da04-d-56731-kv-01"
    $secret = Get-AzKeyVaultSecret -VaultName $landscapeResourceKVName -Name "PersonalAccessToken" -DefaultProfile $defaultProfile -ErrorAction Stop
    if ($secret) {
        $personalAccessToken = $secret.SecretValueText
    }
    else {
        Write-Error "Failed to access a valid VSTS personal access token.  Please add one to landscape's development key vault and try again."
        return
    }

    $resourceGroupPath = Get-BlobContentFinal -mergedFileName "ResourceGroups.csv" -sourceFolder ""
    $resourceGroups = Import-csv -Path $resourceGroupPath

    try {
        #get VSTS Git repositories
        $accountUrl = "https://bnlwe-p-56728-ia-01-unilevercom-vsts.visualstudio.com/_apis/git/repositories/"
        $base64AuthInfo = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(("{0}:{1}" -f "", $personalAccessToken)))
        $result = Invoke-RestMethod -Method Get -Uri $accountUrl -Headers @{Authorization = ("Basic {0}" -f $base64AuthInfo) } -ContentType "application/json"
    
        #get Commit details from VSTS
        $fromDate = ((Get-Date).Date.AddMonths(-1))
        $toDate = (Get-Date).Date
        foreach ($resultValue in $result.value) {
            $values = $resultValue.project.name.split('-')
            $itsg = $values[3]
            # Handle known exception
            if (-not $itsg -or $itsg -eq "00000" -or $itsg -eq "54330" -or $itsg -notmatch "^\d+$") {
                continue
            }
            $serviceName = ($resourceGroups | Where-Object { $_.ResourceGroupName.Contains("-$($itsg)-") -and (-not $_.ResourceGroupName.ToLower().Contains("databricks")) -and $_.ServiceName } | Select-Object -First 1).ServiceName

            if (-not $serviceName) {
                Write-Warning "Unable to determine a service name for DevOps project $($resultValue.project.name)"
                $serviceName = ""
            }

            $projectUrl = "$($resultValue.url)/commits/?searchCriteria.fromDate=$fromDate&searchCriteria.toDate=$toDate&$('searchCriteria.$top')=1000000"
            $resultCommits = Invoke-RestMethod -Method Get -Uri $projectUrl -Headers @{Authorization = ("Basic {0}" -f $base64AuthInfo) } -ContentType "application/json"
            if ($null -ne $resultCommits) {
                $comment = if ($resultCommits.value[0].comment) { $resultCommits.value[0].comment.Replace(',', '') }
                $outputtext = "$($serviceName),$($resultValue.project.name),$($resultValue.name),$($resultCommits.value[0].committer.email),$($resultCommits.value[0].committer.date),$($comment),$($resultCommits.count)"
            }
            else {
                $outputtext = "$serviceName,$($resultValue.name),,,,,,"
            }
            Add-Content $filePath $outputtext                     
        }
    }
    catch {
        Write-Error "Error ocurred in Set-GitCommitData: $($_.Exception.Message)"
    }  
}

# Loop over all the matching raw files of a particular type and combine them into a single CSV file
function global:Set-BlobContentFinal {
    param([string]$fileNameMatch, [string]$sourceFolder = "raw", [string]$mergedFileName, [string]$targetFolder = "Az", [string]$distinctColumnName)
 
    # distinctColumnName, pass this if you want to remove duplicates
    $subBootstrap = Get-SubscriptionBootstrap -subscriptionNUmber "04"
    $landscapeStorageAccountName = "bnlwestgunileverda56731"
    $landscapeResourceGroupName = "bnlwe-da04-d-56731-rg"

    $containerName = "subscriptiondata"
    $accountKeys = Get-AzStorageAccountKey -ResourceGroupName $landscapeResourceGroupName -Name $landscapeStorageAccountName -DefaultProfile $subBootstrap.DefaultProfile
    $storageContext = New-AzStorageContext -StorageAccountName $landscapeStorageAccountName -StorageAccountKey $accountKeys[0].Value

    $fileNameMatch = Join-Path -Path $sourceFolder -ChildPath "$fileNameMatch"
    $fileNameMatch = $fileNameMatch.Replace("\", "/")
    Write-Verbose "Merging files $fileNameMatch in $landscapeStorageAccountName"

    # Download all matching files then join them
    $parent = [System.IO.Path]::GetTempPath()
    [string] $name = [System.Guid]::NewGuid()
    $tempDir = (Join-Path $parent $name)
    $tempDirRaw = (Join-Path $tempDir "raw")
    $mergedFilePath = Join-Path $tempDir $mergedFileName
    $stagedFilePath = Join-Path $tempDir "All$mergedFileName"
    New-Item -Path $tempDirRaw -ItemType "directory" | Out-Null
    Get-AzStorageBlob -Blob $fileNameMatch -container $containerName -Context $storageContext | Get-AzStorageBlobContent -Destination $tempDir | Out-Null
 
    $i = 0
    # all files will contain column headers but we only want the first one
    foreach ($file in Get-ChildItem $tempDirRaw) {
        if ($i -eq 0) {
            # Copy the first file including headers
            Get-Content $file.FullName | out-file -FilePath $stagedFilePath -Encoding utf8
        }
        else {
            # Append subsequent files but skip the headers
            Get-Content $file.FullName | Select-Object -skip 1 | Out-File -FilePath $stagedFilePath -Append -Encoding utf8
        }
        $i++
    }
    if ($distinctColumnName) {
        Import-Csv -Path $stagedFilePath | Sort-Object -Property $distinctColumnName -Unique | Export-Csv -NoTypeInformation -Encoding utf8 -Path $mergedFilePath
    }
    else {
        Rename-Item -Path $stagedFilePath -NewName $mergedFileName
    }
    # Place the merged file into the live folder for PBI to pick up
    if ($targetFolder) {
        $mergedFileName = join-path $targetFolder $mergedFileName
    }
    if ($i -gt 0) {
        Set-AzStorageBlobContent -File $mergedFilePath -Container $containerName -Blob $mergedFileName -Context $storageContext -Force
    }
    else {
        # No raw files were found to merge
        Write-Warning "Set-BlobContentFinal -fileNameMatch $fileNameMatch didn't find any raw files to merge."
    }
 
    Remove-Item -Path $tempDir -Recurse -force
}
# Retrieve the current version of a merged file.
function global:Get-BlobContentFinal {
    param([string]$mergedFileName, [string]$sourceFolder = "Az")
 
    $subBootstrap = Get-SubscriptionBootstrap -subscriptionNUmber "04"
    $landscapeStorageAccountName = "bnlwestgunileverda56731"
    $landscapeResourceGroupName = "bnlwe-da04-d-56731-rg"

    $containerName = "subscriptiondata"
    $accountKeys = Get-AzStorageAccountKey -ResourceGroupName $landscapeResourceGroupName -Name $landscapeStorageAccountName -DefaultProfile $subBootstrap.DefaultProfile
    $storageContext = New-AzStorageContext -StorageAccountName $landscapeStorageAccountName -StorageAccountKey $accountKeys[0].Value

    if ($sourceFolder) {
        $fileNameMatch = Join-Path -Path $sourceFolder -ChildPath "$mergedFileName"
    }
    else {
        $fileNameMatch = $mergedFileName
    }
    $fileNameMatch = $fileNameMatch.Replace("\", "/")


    # Download all matching files then join them
    $parent = [System.IO.Path]::GetTempPath()
    [string] $name = [System.Guid]::NewGuid()
    $tempDir = (Join-Path $parent $name)
    $mergedFilePath = Join-Path $tempDir $fileNameMatch
 
    New-Item -Path $tempDir -ItemType "directory" | Out-Null
    Write-Verbose "Getting merged file $fileNameMatch from $landscapeStorageAccountName."
    Get-AzStorageBlob -Blob $fileNameMatch -container $containerName -Context $storageContext | Get-AzStorageBlobContent -Destination $tempDir | Out-Null
    return $mergedFilePath
}
# Upload a raw platform meta data file to the raw directory.  These are the files used as the data source
# for landscape's platform dashboard.
function global:Set-BlobContentRaw {
    param([string]$filePath, [string]$targetFolder = "raw")
 
 
    $subBootstrap = Get-SubscriptionBootstrap -subscriptionNUmber "04"
    $landscapeStorageAccountName = "bnlwestgunileverda56731"
    $landscapeResourceGroupName = "bnlwe-da04-d-56731-rg"

    $fileName = Split-Path -Path $filePath -Leaf
    $containerName = "subscriptiondata"
    $accountKeys = Get-AzStorageAccountKey -ResourceGroupName $landscapeResourceGroupName -Name $landscapeStorageAccountName -DefaultProfile $subBootstrap.DefaultProfile
    $containerName = "subscriptiondata"
    $storageContext = New-AzStorageContext -StorageAccountName $landscapeStorageAccountName -StorageAccountKey $accountKeys[0].Value
    if (-not(Get-AzStorageContainer -Name $containerName -Context $storageContext -ErrorAction SilentlyContinue)) {
        New-AzStorageContainer -Name $containerName -Context $storageContext
        Start-Sleep -Seconds 5
    }
 
    # move the files to the storage account; MAke sure the connection is pointing at the correct subscription i.e. 04
    $args = @{
        Container = $containerName;
        Blob      = Join-Path $targetFolder -ChildPath $fileName;
        Context   = $storageContext;
    }

    if (Test-Path -LiteralPath $filePath -PathType Leaf) {
        Write-Verbose "Uploading file $fileName to $landscapeStorageAccountName"
        $args.File = $filePath;
        $args.Force = $true
        Set-AzStorageBlobContent @args | Out-Null
     
    }
    else {
        Write-Verbose "Newly generated file $fileName is empty, deleting from raw folder in $landscapeStorageAccountName"
        $args.ErrorAction = "Ignore"
        Get-AzStorageBlob @args | Remove-AzStorageBlob
    }
}
function global:Get-Service {
    param([string]$filePath, [string]$serviceName)
    # search through the service.csv file and return the specified service.

    $service = Import-Csv $filePath | where-Object { $_.ServiceName -eq $serviceName }
    if (-not $service) {
        return $null
    }
    elseif ($service.Count -gt 1) {
        Write-Warning "Multiple service records were found for service '$serviceName'"
        Write-Output $service[0]
    }
    else {
        Write-Output $service
    } 
}

#Merge costmaster resource groups with newly extracted resource groups
function global:Merge-ResourceGroups{
    param([string]$sourceFolder="raw")
    
    # distinctColumnName, pass this if you want to remove duplicates
    $subBootstrap = Get-SubscriptionBootstrap -subscriptionNUmber "04"
    $landscapeStorageAccountName = "bnlwestgunileverda56731"
    $landscapeResourceGroupName = "bnlwe-da04-d-56731-rg"
   
    $containerName = "subscriptiondata"
    $accountKeys = Get-AzStorageAccountKey -ResourceGroupName $landscapeResourceGroupName -Name $landscapeStorageAccountName -DefaultProfile $subBootstrap.DefaultProfile
    $storageContext = New-AzStorageContext -StorageAccountName $landscapeStorageAccountName -StorageAccountKey $accountKeys[0].Value
   
    # Create a local working directory
    $parent = [System.IO.Path]::GetTempPath()
    [string] $name = [System.Guid]::NewGuid()
    $tempDir = (Join-Path $parent $name)
    New-Item -Path $tempDir -ItemType "directory" | Out-Null
   
    $mergedFileName="ResourceGroupMaster.csv"
    $costMasterResourceGroupPath = Get-BlobContentFinal -mergedFileName "CostMasterResourceGroups.csv" -sourceFolder $sourceFolder
    $sandboxResourceGroupPath = Get-BlobContentFinal -mergedFileName "SanboxRGMetadata.csv" -sourceFolder $sourceFolder
    $experimentationResourceGroupPath = Get-BlobContentFinal -mergedFileName "ExperimentationRGMetadata.csv" -sourceFolder $sourceFolder
   
    $costMasterResourceGroups= Import-csv -Path $costMasterResourceGroupPath
    $sandboxResourceGroups= Import-csv -Path $sandboxResourceGroupPath
    $experimentationResourceGroups= Import-csv -Path $experimentationResourceGroupPath
   
    $resourceGroupPath = Get-BlobContentFinal -mergedFileName "ResourceGroups.csv" -sourceFolder ""

    $subscriptionsPath = Get-BlobContentFinal -mergedFileName "Subscriptions.csv" -sourceFolder ""
   
    $resourceGroups= Import-csv -Path $resourceGroupPath

    $subscriptions= Import-csv -Path $subscriptionsPath
   
    $resourceGroupMasterFilePath = Join-Path $tempDir $mergedFileName
   
    $inScopeResourceGroups=New-Object Collections.Generic.List[string]

   #Merge resourcegroup Data
   
   #Add new properties
   foreach($resourceGroup in $resourceGroups){
       if(-not [bool]($resourceGroup.PSobject.Properties.name -match "Environment")){
       Add-Member -InputObject $resourceGroup -MemberType NoteProperty -Name "Environment" -Value ""
       }
       Add-Member -InputObject $resourceGroup -MemberType NoteProperty -Name "DecommissionedDate" -Value ""
       Add-Member -InputObject $resourceGroup -MemberType NoteProperty -Name "ApplicationStatus" -Value ""  
       if(-not [bool]($resourceGroup.PSobject.Properties.name -match "SubscriptionName")){
            Add-Member -InputObject $resourceGroup -MemberType NoteProperty -Name "SubscriptionName" -Value ""
       }
       if(-not [bool]($resourceGroup.PSobject.Properties.name -match "Requestor")){
       Add-Member -InputObject $resourceGroup -MemberType NoteProperty -Name "Requestor" -Value ""
       }
     }   
   
     foreach($costMasterResourceGroup in $costMasterResourceGroups){   
       $inScopeResourceGroups.Add($costMasterResourceGroup."Resource Group")
       $existingresourceGroupCount=$resourceGroups | Where-Object { $_.ResourceGroupName.Equals($costMasterResourceGroup."Resource Group") }   
       if(-not $existingresourceGroupCount){          
               $missingResourceGroup = New-Object System.Management.Automation.PSObject
               $missingResourceGroup | Add-Member -MemberType NoteProperty -Name ResourceGroupName -Value $costMasterResourceGroup."Resource Group"
               $missingResourceGroup | Add-Member -MemberType NoteProperty -Name ServiceName -Value $costMasterResourceGroup."Application"
               $missingResourceGroup | Add-Member -MemberType NoteProperty -Name DeliveryDirector -Value $costMasterResourceGroup."Delivery Director"
               $missingResourceGroup | Add-Member -MemberType NoteProperty -Name Environment -Value $costMasterResourceGroup."Environment"
               $missingResourceGroup | Add-Member -MemberType NoteProperty -Name DecommissionedDate -Value $costMasterResourceGroup."Decommissioned Date"
               $missingResourceGroup | Add-Member -MemberType NoteProperty -Name ApplicationStatus -Value $costMasterResourceGroup."Application Status"
               $missingResourceGroup | Add-Member -MemberType NoteProperty -Name SubscriptionName -Value $costMasterResourceGroup."Subscription Name"

                $subscription=$subscriptions | Where-Object { $_.Name.Equals($costMasterResourceGroup."Subscription Name")}|Select-Object  -First 1
                  $missingResourceGroup | Add-Member -MemberType NoteProperty -Name SubscriptionId -Value $subscription.Id
               
               $resourceGroups += $missingResourceGroup            
       }
     }
   
     foreach($sandboxResourceGroup in $sandboxResourceGroups){
       $inScopeResourceGroups.Add($sandboxResourceGroup."Resource Group")
       $existingResourceGroup=$resourceGroups | Where-Object { $_.ResourceGroupName.Equals($sandboxResourceGroup."Resource Group") }   
       if(-not $existingResourceGroup){
             
               $missingResourceGroup = New-Object System.Management.Automation.PSObject
               $missingResourceGroup | Add-Member -MemberType NoteProperty -Name ResourceGroupName -Value $sandboxResourceGroup."Resource Group"    
               $missingResourceGroup | Add-Member -MemberType NoteProperty -Name ServiceName -Value $sandboxResourceGroup."Resource Group"              
               $missingResourceGroup | Add-Member -MemberType NoteProperty -Name DeliveryDirector -Value $sandboxResourceGroup."Director"
               $missingResourceGroup | Add-Member -MemberType NoteProperty -Name ExpiryDate -Value $sandboxResourceGroup."Expiry Date"
               $missingResourceGroup | Add-Member -MemberType NoteProperty -Name Requestor -Value $sandboxResourceGroup."Requestor"
               $missingResourceGroup | Add-Member -MemberType NoteProperty -Name ApplicationStatus -Value $sandboxResourceGroup."Environment Status "
               $missingResourceGroup | Add-Member -MemberType NoteProperty -Name SubscriptionName -Value $sandboxResourceGroup."Subscription Name"
               $missingResourceGroup | Add-Member -MemberType NoteProperty -Name Environment -Value "s"

                $subscription=$subscriptions | Where-Object { $_.Name.Equals($sandboxResourceGroup."Subscription Name")}|Select-Object  -First 1
                $missingResourceGroup | Add-Member -MemberType NoteProperty -Name SubscriptionId -Value $subscription.Id

               $resourceGroups += $missingResourceGroup            
       }
       else {
           $existingResourceGroup.ExpiryDate = $sandboxResourceGroup."Expiry Date"
           $existingResourceGroup.Requestor= $sandboxResourceGroup."Requestor"

           if([string]::IsNullOrEmpty($existingResourceGroup.ServiceName)){
            $existingResourceGroup.ServiceName= $existingResourceGroup.ResourceGroupName
           }
       }
     }
   
     foreach($experimentationResourceGroup in $experimentationResourceGroups){
       $inScopeResourceGroups.Add($experimentationResourceGroup."Resource Group")
       $existingResourceGroup= $resourceGroups | Where-Object { $_.ResourceGroupName.Equals($experimentationResourceGroup."Resource Group") }
   
       if(-not $existingResourceGroup){
             
               $missingResourceGroup = New-Object System.Management.Automation.PSObject
               $missingResourceGroup | Add-Member -MemberType NoteProperty -Name ResourceGroupName -Value $experimentationResourceGroup."Resource Group"              
               $missingResourceGroup | Add-Member -MemberType NoteProperty -Name ServiceName -Value $experimentationResourceGroup."Application"
               $missingResourceGroup | Add-Member -MemberType NoteProperty -Name DeliveryDirector -Value $experimentationResourceGroup."Delivery Director"
               $missingResourceGroup | Add-Member -MemberType NoteProperty -Name ExpiryDate -Value $experimentationResourceGroup."Expiry Date"
               $missingResourceGroup | Add-Member -MemberType NoteProperty -Name Requestor -Value $experimentationResourceGroup."Requestor"
               $missingResourceGroup | Add-Member -MemberType NoteProperty -Name ApplicationStatus -Value $experimentationResourceGroup."Environment Status "
               $missingResourceGroup | Add-Member -MemberType NoteProperty -Name SubscriptionName -Value $experimentationResourceGroup."Subscription Name"

                $subscription=$subscriptions | Where-Object { $_.Name.Equals($experimentationResourceGroup."Subscription Name")}|Select-Object  -First 1
                $missingResourceGroup | Add-Member -MemberType NoteProperty -Name SubscriptionId -Value $subscription.Id

               $missingResourceGroup | Add-Member -MemberType NoteProperty -Name Environment -Value "x"
               $resourceGroups += $missingResourceGroup            
       }
       else{
           $existingResourceGroup.ExpiryDate = $experimentationResourceGroup."Expiry Date"
           $existingResourceGroup.Requestor= $experimentationResourceGroup."Requestor"
       }
     }
   
    $platFormResourceGroup=New-Object Collections.Generic.List[PSObject]
    #Filter unwanted resource groups from the Old foundation
     foreach($resourceGroup in $resourceGroups){
        # if (($resourceGroup.SubscriptionName -and $resourceGroup.SubscriptionName.Contains("Prod")) -or $resourceGroup.SubscriptionId -eq '50327adb-f8a0-4908-8d31-aa182df19f02' -or $resourceGroup.SubscriptionId -eq '204671af-5130-4ef5-819c-e314b65f9d06' -or $resourceGroup.SubscriptionId -eq '9abbdd30-3391-4dfc-bfb6-217a40627488') {
            if($inScopeResourceGroups.Contains($resourceGroup.ResourceGroupName)){
                if($resourceGroup.Environment){
                    switch($resourceGroup.Environment.ToLower())
                    {
                        'dev' {$resourceGroup.Environment='d'}
                        'development' {$resourceGroup.Environment='d'}
                        'qa' {$resourceGroup.Environment='q'}
                        'production' {$resourceGroup.Environment='p'}
                        'prod' {$resourceGroup.Environment='p'}
                        'acceptance' {$resourceGroup.Environment='b'}
                        'preprod' {$resourceGroup.Environment='u'}
                        'ppd' {$resourceGroup.Environment='u'}
                        'experiment' {$resourceGroup.Environment='x'}
                        'staging' {$resourceGroup.Environment='x'}
                        'sandbox' {$resourceGroup.Environment='s'}
                    }
                }
                if(-not [bool]($resourceGroup.PSobject.Properties.name -match "ResourceId")){
                    Add-Member -InputObject $resourceGroup -MemberType NoteProperty -Name "ResourceId" -Value "$($resourceGroup.ResourceGroupName)_$($resourceGroup.SubscriptionName)"
               }elseif([string]::IsNullOrEmpty($resourceGroup.ResourceId)){
                    $resourceGroup.ResourceId= "$($resourceGroup.ResourceGroupName)_$($resourceGroup.SubscriptionName)"
                }
                $platFormResourceGroup.Add($resourceGroup)
            }
        # }
        # else{
        #     $platFormResourceGroup.Add($resourceGroup)
        # }
     }

     $platFormResourceGroup | Select-Object ResourceGroupName,Location,ProvisioningState,ResourceId,SubscriptionId,SubscriptionName,ServiceName,DeliveryDirector,ProvisionedBy,ProvisionedOn,DataScience,ExpiryDate,Market,Requestor,Environment,DecommissionedDate,ApplicationStatus | ConvertTo-Csv -NoTypeInformation |  Add-Content -Path $resourceGroupMasterFilePath 
   
     Write-Information "Resource Group Merged."
   
     Set-AzStorageBlobContent -File $resourceGroupMasterFilePath -Container $containerName -Blob $mergedFileName -Context $storageContext -Force
     Remove-Item -Path $tempDir -Recurse -force
   }
