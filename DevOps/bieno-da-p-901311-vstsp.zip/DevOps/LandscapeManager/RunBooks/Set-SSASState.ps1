param(
    [object]
    $WebhookData,
    [bool]$Pause=$false,
    [bool]$Resume=$false
)

.\Import-PlatformCore.ps1
$bootStrap = Login-AzCore -WebHookData $WebhookData
$parameters = Get-Parameters -bootstrap $bootStrap

$isError=$false
$outputStream =[System.Collections.ArrayList]@()
$outputStream.Add($WebhookData) | Out-Null


$outputStream.Add("Processing environment:") | Out-Null
$outputStream.Add($bootstrap) | Out-Null

try {
    if($Pause) {
        $fileName = "{0}_{1}AAS_{2}" -f $bootstrap.runId, "Pause", (get-date -Format s)
        $status = Get-AzAnalysisServicesServer -Name $parameters.parameters.analysisServicesName.value
        if($status.State -ne 'Paused')
        {
            $outputStream.Add("AAS Pause Initiated...") | Out-Null
            $db=Suspend-AzAnalysisServicesServer -Name $parameters.parameters.analysisServicesName.value -ResourceGroupName $parameters.parameters.analysisServicesResourceGroupName.value -ErrorAction Stop
            $outputStream.Add($db) | Out-Null
            $outputStream.Add("Azure Analysis Service `"$($parameters.parameters.analysisServicesName.value)`" was paused.") | Out-Null
        }
        else 
        {
            $outputStream.Add("$($parameters.parameters.analysisServicesName.value) is already paused.") | Out-Null
        }
        return
    }
    if($Resume) {
        $fileName = "{0}_{1}AAS_{2}" -f $bootstrap.runId, "Resume", (get-date -Format s)
        
        $status = Get-AzAnalysisServicesServer -Name $parameters.parameters.analysisServicesName.value
        if($status.State -ne 'Succeeded')
        {
            $outputStream.Add("AAS Resume Initiated...") | Out-Null
            $db=Resume-AzAnalysisServicesServer -Name $parameters.parameters.analysisServicesName.value -ResourceGroupName $parameters.parameters.analysisServicesResourceGroupName.value -ErrorAction Stop
            $outputStream.Add($db) | Out-Null
            $outputStream.Add("Azure Analysis Service `"$($parameters.parameters.analysisServicesName.value)`" was resumed.") | Out-Null
        }
        else 
        {
            $outputStream.Add("$($parameters.parameters.analysisServicesName.value) is already Online.") | Out-Null
        }
        if (-not [String]::IsNullOrEmpty($bootstrap["callbackPipeline"])) {
            $result = Invoke-AdfPipeline -bootStrap $bootstrap -parameters $parameters
            $outputStream.Add($result) | Out-Null
        }
        return
    }
}
catch {
    $isError=$true
    $outputStream.Add($_) | Out-Null
    throw
 }
 finally {
    # Write log file to app storage account
    Set-LogfileContent -parameters $parameters -stream $outputStream -fileName $fileName
    
    if ($isError) {
        foreach($s in $outputStream)
        {
            if (($s.GetType().Name) -eq "Hashtable") {
                $s = $s | Out-String
            }
            Write-Error $s
        }
        throw "An unexpected error was detected"
    } else {
        $outputStream | Write-Output
    }
 }