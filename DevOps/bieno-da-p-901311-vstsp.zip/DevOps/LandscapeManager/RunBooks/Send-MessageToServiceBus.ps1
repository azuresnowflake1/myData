param
(
    # The request body
    [object]
    $WebhookData,
    [Parameter(Mandatory=$true)]
    [string]$servicebusQueueURI = 'https://bnlwe-da04-d-56731-sb-01.servicebus.windows.net/dataforsendmail/messages',
    [Parameter(Mandatory=$true)]
    [string]$jsonDataToQueue = @'
{
	"member":{
			"CertificateName":"cert-1",
			"SPNName": "spn-1",
			"MailTo": "santosh.gaikwad3@unilever.com"
	}
}
'@
)
.\Import-PlatformCore.ps1
# Login to azure using our turnkey SPN IANDProdSPN.  The cert must be installed on your machine for this to work
$bootStrap = Login-AzCore -WebHookData $WebhookData

Get-AzContext
#$parameters = .\Get-AllParameters.ps1 -webhookData $WebhookData
<#
$jsonDataToQueue=@'
{{    
    "CertificateName":"cert-1",
    "SPN Name": "spn-1"
}}
'@
#>

$method='Post'

$encodedURI = [System.Web.HttpUtility]::UrlEncode($servicebusQueueURI)
$keyname = "sendmail" # SAS Key Name of Message Queue
$key = "pLlU6ms8Wjfq3T33cG3T4ACnSEXVb3hR2JyWyCOIaxk=" # SAS Primary Key of Message Queue
$startDate = [datetime]”01/01/1970 00:00”
$hour = New-TimeSpan -Hours 1

# Calculate expiry value one hour ahead
$sinceEpoch = NEW-TIMESPAN –Start $startDate –End ((Get-Date) + $hour)
$expiry = [Math]::Floor([decimal]($sinceEpoch.TotalSeconds + 3600))

# Create the signature
$stringToSign = $encodedURI + "`n" + $expiry
$hmacsha = New-Object System.Security.Cryptography.HMACSHA256
$hmacsha.key = [Text.Encoding]::ASCII.GetBytes($key)
$signature = $hmacsha.ComputeHash([Text.Encoding]::ASCII.GetBytes($stringToSign))
$signature = [System.Web.HttpUtility]::UrlEncode([Convert]::ToBase64String($signature))

[System.Net.ServicePointManager]::ServerCertificateValidationCallback = {$true}
[System.Net.ServicePointManager]::Expect100Continue = $false

$cookies = New-Object System.Net.CookieContainer

$request = [System.Net.HttpWebRequest]::Create($servicebusQueueURI)
$data = [System.Text.Encoding]::ASCII.GetBytes($jsonDataToQueue)
$request.ContentLength = $data.Length
$request.Method = 'POST'
$authheader = "SharedAccessSignature sr=" + $encodedURI + "&sig=" + $signature + "&se=" + $expiry + "&skn=" + $keyname;
$contentType ="application/json"
$request.Headers.Add("Authorization", $authheader)
$request.ContentType= $contentType
$request.CookieContainer = $cookies
$request.ContentLength = $data.Length
$requestStream = $request.GetRequestStream()
$requestStream.Write($data, 0, $data.Length)
$requestStream.Close()

$response = [System.Net.HttpWebResponse]$request.GetResponse()
$responseStream = $response.GetResponseStream()

(New-Object System.IO.StreamReader($responseStream)).ReadToEnd()
