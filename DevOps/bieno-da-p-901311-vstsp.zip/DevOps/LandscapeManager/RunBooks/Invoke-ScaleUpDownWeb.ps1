param(
    [object]
    $WebhookData
)

.\Import-PlatformCore.ps1
$bootStrap = Login-AzCore -WebHookData $WebhookData
$parameters = Get-Parameters -bootstrap $bootStrap

$isError=$false
$outputStream =[System.Collections.ArrayList]@()
$outputStream.Add($WebhookData) | Out-Null

$newPricingTier = $bootStrap["arg0"]
$callbackFunction = $bootStrap["callbackPipeline"]
$webAppResourceGroupName = $parameters.parameters.webAppResourceGroupName.value
$appServicePlanName = $parameters.parameters.appServicePlanName.value

$bootStrap["webAppResourceGroupName"] = $webAppResourceGroupName
$bootStrap["appServicePlanName"] = $appServicePlanName
$bootStrap["newPricingTier"] = $newPricingTier

$outputStream.Add("Processing environment:") | Out-Null
$outputStream.Add($bootstrap) | Out-Null

try {
    if (-not ($newPricingTier)) {
        throw "You must pass a value for Pricing Tier in your CSV string."
    }
    $fileName = "{0}_ScaleWebApp_{1}" -f $bootstrap.runId, (get-date -Format s)
    $outputStream.Add("Scaling App service plan $appServicePlanName to $newPricingTier") | Out-Null

    $result = Set-AzAppServicePlan -Name $appServicePlanName -ResourceGroupName $webAppResourceGroupName -Tier $newPricingTier

    $outputStream.Add($result) | Out-Null
    $outputStream.Add("$appServicePlanName scaled to $newPricingTier") | Out-Null
   
    if ($callbackFunction) {
        $result = Invoke-AdfPipeline -bootStrap $bootstrap -parameters $parameters
        $outputStream.Add($result) | Out-Null
    }
}
catch {
    $isError=$true
    $outputStream.Add($_) | Out-Null
    throw
 }
 finally {
    # Write log file to app storage account
    Set-LogfileContent -parameters $parameters -stream $outputStream -fileName $fileName
    
    if ($isError) {
        foreach($s in $outputStream)
        {
            if (($s.GetType().Name) -eq "Hashtable") {
                $s = $s | Out-String
            }
            Write-Error $s
        }
        throw "An unexpected error was detected"
    } else {
        $outputStream | Write-Output
    }
 }
