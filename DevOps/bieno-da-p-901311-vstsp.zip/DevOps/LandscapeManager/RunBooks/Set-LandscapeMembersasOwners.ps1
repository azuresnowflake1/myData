param
(
    [string]$sourceGroupName ="sec-es-da-p-56728-azure-landscape",
    [string]$WebhookData = '{"WebhookName":"WebHook-SqlDwResume","RequestBody":"bnlwe-da04-d-99999-adf-01,31e4d879-203b-4afa-83db-20021cc889d9,","RequestHeader":{"Connection":"Keep-Alive","Expect":"100-continue","Host":"s2events.azure-automation.net","x-ms-request-id":"8b188be3-a238-4c00-8c26-e2a5f65d428e"}}'
)

.\Login-AzureRmAutomation-AAD.ps1 -webhookData $WebhookData

function Set-GroupOwners{

    $sourceGroup = Get-AzureADGroup -SearchString $sourceGroupName
    $sourceMembers = Get-AzureADGroupMember -ObjectId 5f43d762-65cd-4fc6-a065-0232e6952a50
    $targetgroup =  Get-AzureADGroup -All $true -SearchString "SEC-ES-DA-" | Where-Object { $_.DisplayName -match "(SEC-ES-DA-d-80227-azure-developer)$" }
    #$targetgroup = Get-AzureADGroup -All $true -SearchString "SEC-ES-DA-" | Where-Object { $_.DisplayName -match "(-azure-developer|-azure-tester|-azure-devops|-ProjectAdmins)$" }
    foreach($group in $targetgroup ){
    $targetOwners = Get-AzureADGroupOwner -ObjectId $group.ObjectId -All $True
    $members = @{}

    foreach($member in $sourceMembers) {
        $match = $false
        foreach($gp in $targetOwners) {
            if ($gp.ObjectId -eq $member.ObjectId) {
                # nothing to do
                $match = $true
                break
            }
        }
        if (-not $match) {
            #if($member.) if Service account
            # group is in the source but not the target group.  Need to add it.
            Write-Output "Adding Owner $($member.DisplayName) to $targetGroupName"
            Add-AzureADGroupOwner -ObjectId $targetGroup.ObjectId -RefObjectId $member.ObjectId
        }
    }

    foreach($towner in $targetOwners) {
        $match = $false
        foreach($gp in $sourceMembers) {
            if ($gp.ObjectId -eq $towner.ObjectId) {
                # nothing to do
                $match = $true
                break
            }
        }
        if (-not $match) {
            # group is in the source but not the target group.  Need to add it.
            Write-Output "Removing owner $($towner.DisplayName) from $targetGroupName"
            Remove-AzureADGroupOwner -ObjectId $targetGroup.ObjectId -OwnerId $towner.ObjectId
        }   
    }

   
}

}
Set-GroupOwners