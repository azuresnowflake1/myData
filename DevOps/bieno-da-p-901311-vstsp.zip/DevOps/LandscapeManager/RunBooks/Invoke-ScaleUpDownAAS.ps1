param(
    [object]
    $WebhookData
)

.\Import-PlatformCore.ps1
$bootStrap = Login-AzCore -WebHookData $WebhookData
$parameters = Get-Parameters -bootstrap $bootStrap

$isError=$false
$outputStream =[System.Collections.ArrayList]@()
$outputStream.Add($WebhookData) | Out-Null


$outputStream.Add("Processing environment:") | Out-Null
$outputStream.Add($bootstrap) | Out-Null

try {
    $ResourceGroupName = $parameters.parameters.analysisServicesResourceGroupName.value
    $AASName = $parameters.parameters.analysisServicesName.value
    $sku = $bootstrap["arg0"]
    $callbackFunction = $bootstrap["callbackPipeline"]
    $fileName = "{0}_ScaleAAS_{1}" -f $bootstrap.runId, (get-date -Format s)

    if ($sku) {
        $outputStream.Add("Scaling AAS $AASName to $sku") | Out-Null
        $x = Set-AzAnalysisServicesServer -Name $AASName -ResourceGroupName $ResourceGroupName -Sku $sku -ErrorAction Stop
        $outputStream.Add($x) | Out-Null
    }
   
    if (-not [String]::IsNullOrEmpty($bootstrap["callbackPipeline"])) {
        $result = Invoke-AdfPipeline -bootStrap $bootstrap -parameters $parameters
        $outputStream.Add($result) | Out-Null
    }
}
catch {
    $isError=$true
    $outputStream.Add($_) | Out-Null
    throw
 }
 finally {
    # Write log file to app storage account
    Set-LogfileContent -parameters $parameters -stream $outputStream -fileName $fileName
    
    if ($isError) {
        foreach($s in $outputStream)
        {
            if (($s.GetType().Name) -eq "Hashtable") {
                $s = $s | Out-String
            }
            Write-Error $s
        }
        throw "An unexpected error was detected"
    } else {
        $outputStream | Write-Output
    }
 }