add-type @"
using System.Net;
using System.Security.Cryptography.X509Certificates;
public class TrustAllCertsPolicy : ICertificatePolicy {
    public bool CheckValidationResult(
        ServicePoint srvPoint, X509Certificate certificate,
        WebRequest request, int certificateProblem) {
        return true;
    }
}
"@
$AllProtocols = [System.Net.SecurityProtocolType]'Ssl3,Tls,Tls11,Tls12'
[System.Net.ServicePointManager]::SecurityProtocol = $AllProtocols

function global:Adb-New-SecretScope {
    param( [string]$scopeName="Landscape", [string]$principal="LandscapeGroup")
        $uri = "$uriBase/secrets/scopes/create"
        $head = @{authorization = "Bearer $accessToken" }
        $body = @"
        {
            "scope": "$scopeName",
            "initial_manage_principal": "users"
        }
"@
    Invoke-RestMethod -Uri $uri -Body $Body -Method 'POST' -Headers $head -ContentType "application/json"
}

function global:Adb-Get-SecretScope {
    param( [string]$scopeName="Landscape")
        $uri = "$uriBase/secrets/scopes/list"
        $head = @{authorization = "Bearer $accessToken" }

    $scopes = Invoke-RestMethod -Uri $uri -Method 'GET' -Headers $head -ContentType "application/json"
    if ($scopes)
    {
        foreach($scope in $scopes.scopes)
        {
            if ($scope.name -eq $scopeName){
                Write-Output "Secret scope '$scopeName' already exists."
                return $scope
            }
        }
    }
    return $null
}

function global:Adb-Get-Secrets {
    param([string]$scopeName="RuntimeKeyVault")
        $uri = "$uriBase/secrets/list?scope=$scopeName"
        $head = @{authorization = "Bearer $accessToken" }
        
    Invoke-RestMethod -Uri $uri -Method 'GET' -Headers $head -ContentType "application/json"
}

function global:Adb-Add-Secret {
    param([string]$scopeName="Landscape", [string]$secretName, [string]$secretValue)
        $uri = "$uriBase/secrets/put"
        $head = @{authorization = "Bearer $accessToken" }
        $body = @"
        {
            "scope": "$scopeName",
            "key": "$secretName",
            "string_value":"$secretValue"
        }
"@
    Invoke-RestMethod -Uri $uri -Body $Body -Method 'POST' -Headers $head -ContentType "application/json"
}

function global:Add-SecretAcl {
    param([string]$scopeName="Landscape", [string]$principal, [string]$permission)
        $uri = "$uriBase/secrets/acls/put"
        $head = @{authorization = "Bearer $accessToken" }
        $body = @"
        {
            "scope": "$scopeName",
            "principal": "$principal",
            "permission":"$permission"
        }
"@
    Invoke-RestMethod -Uri $uri -Body $Body -Method 'POST' -Headers $head -ContentType "application/json"
}

function global:Adb-Remove-SecretScope {
    param( [string]$scopeName="Landscape")
        $uri = "$uriBase/secrets/scopes/delete"
        $head = @{authorization = "Bearer $accessToken" }
        $body = @"
        {
            "scope": "$scopeName"
        }
"@
    Invoke-RestMethod -Uri $uri -Body $Body -Method 'POST' -Headers $head -ContentType "application/json"
}
function global:Adb-Create-AccessToken {
    param([string]$accessTokenName="Landscape")
    $uri = "$uriBase/token/create"

    $head = @{"authorization" = "Bearer $($databricksToken.AccessToken)"}
    $head.Add("X-Databricks-Azure-SP-Management-Token",$managementToken.AccessToken)
    $head.Add("X-Databricks-Azure-Workspace-Resource-Id",$databricksId) 

    $body = @"
    {
        "comment": "$($accessTokenName)"
    }
"@
    $output = Invoke-RestMethod -Uri $uri -Method 'POST' -Headers $head -Body $body -ContentType "application/json"
    return $output
}

function global:Adb-New-Directory {
    param( [string]$path="/MyNotebooks")
        $uri = "$uriBase/workspace/mkdirs"
        $head = @{authorization = "Bearer $accessToken" }
        $body = @"
    {
        "path": "$path"
    }
"@

    Invoke-RestMethod -Uri $uri -Body $Body -Method 'POST' -Headers $head -ContentType "application/json"
}

function global:Adb-New-Group {
    param([string]$groupName="LandscapeGroup")
        $uri = "$uriBase/groups/create"
        $head = @{authorization = "Bearer $accessToken" }
        $body = @"
        {
            "group_name":"$groupName"
        }
"@
    Invoke-RestMethod -Uri $uri -Body $Body -Method 'POST' -Headers $head -ContentType "application/json"
}


function global:Adb-Get-Group {
    param( [string]$groupName="LandscapeGroup")
        $uri = "$uriBase/groups/list"
        $head = @{authorization = "Bearer $accessToken" }

    $groups = Invoke-RestMethod -Uri $uri -Method 'GET' -Headers $head -ContentType "application/json"
    if ($groups)
    {
        foreach($group in $groups.group_names)
        {
            if ($group -eq $groupName){
                Write-Output "Group '$groupName' already exists."
                return $group
            }
        }
    }
    return $null
}


function global:Adb-Remove-Group {
    param([string]$groupName="LandscapeGroup")
        $uri = "$uriBase/groups/delete"
        $head = @{authorization = "Bearer $accessToken" }
        $body = @"
        {
            "group_name":"$groupName"
        }
"@
    Invoke-RestMethod -Uri $uri -Body $Body -Method 'POST' -Headers $head -ContentType "application/json" -ErrorAction SilentlyContinue
}

function global:Adb-Add-Member {
    param([string]$groupName="LandscapeGroup", [string]$principal)
        $uri = "$uriBase/groups/add-member"
        $head = @{authorization = "Bearer $accessToken" }
        $body = @"
        {
            "user_name":"$principal",
            "parent_name":"$groupName"
        }
"@
    Invoke-RestMethod -Uri $uri -Body $Body -Method 'POST' -Headers $head -ContentType "application/json"
}

function global:Adb-Add-GroupMembersAsMembers {
    param([string]$memberGroupId)
    $newMembers = Get-AzADGroupMember -GroupObjectId $memberGroupId
    foreach($newMember in $newMembers) {
        #Add if not already a member
        Adb-Add-Member -principal $newMember.UserPrincipalName -accessToken $accessToken
    }
    
}

function global:Adb-New-Directory {
    param( [string]$path="/")
        $uri = "$uriBase/workspace/mkdirs"
        $head = @{authorization = "Bearer $accessToken" }
        $body = @"
    {
        "path": "$path"
    }
"@

    Invoke-RestMethod -Uri $uri -Body $Body -Method 'POST' -Headers $head -ContentType "application/json"
}
function global:Adb-New-ImportNb {
    param( [string]$path="/", [string]$ifile="")
        $uri = "$uriBase/workspace/import"
        $head = @{authorization = "Bearer $accessToken" }
    
        $BinaryContents = [System.IO.File]::ReadAllBytes("$ifile")
        $EncodedContents = [System.Convert]::ToBase64String($BinaryContents)
       
            $Body = @"
    {
        "format": "SOURCE",
        "content": "$EncodedContents",
        "path": "$path",
        "overwrite": "true",
        "language": "PYTHON"
    }
"@
    $params = @{    
        ContentType = 'application/json'
        Headers = $head
        body = $body
        Method = 'Post'    
        URI = $uri
    }
    $response = Invoke-RestMethod -Uri $uri -Body $Body -Method 'POST' -Headers $head -ContentType "application/json"
}
function global:Adb-New-Job {
    param( [string]$path="/",[string]$jname="jobname")
    
        $uri = "$uriBase/jobs/create"
        $head = @{authorization = "Bearer $accessToken" }
    
            $Body = @"
    {
      "name": "$jname",
       "new_cluster": {
          "spark_conf": {
            "spark.databricks.delta.preview.enabled": "true"
          },
          "spark_version": "6.4.x-scala2.11",
          "node_type_id": "Standard_DS3_v2",
          "enable_elastic_disk": true,
          "num_workers": 2
        },
        "notebook_task": {
          "notebook_path": "$path",
          "revision_timestamp": 0
        }
    }
"@
    
        $params = @{    
            ContentType = 'application/json'
            Headers = $head
            body = $body
            Method = 'Post'    
            URI = $uri
        }
        $job = Invoke-RestMethod @params
        return $job
    }

function global:Adb-New-JobExistingCluster {
        param( [string]$path="/", [string]$jname="jobname", [string]$clsId)
        
            $uri = "$uriBase/jobs/create"
            $head = @{authorization = "Bearer $accessToken" }
        
                $Body = @"
        {
          "name": "$jname",
          "existing_cluster_id": "$clsId",
          "notebook_task": {
               "notebook_path": "$path",
               "revision_timestamp": 0
            }
        }
"@
    $params = @{    
        ContentType = 'application/json'
        Headers = $head
        body = $body
        Method = 'Post'    
        URI = $uri
    }
    $job = Invoke-RestMethod @params
    return $job
}

function global:Adb-New-RunJob {
    param( [string]$jobno="0")
    
        $uri = "$uriBase/jobs/run-now"
        $head = @{authorization = "Bearer $accessToken" }
    
        $bodyR = @{job_id = $jobno}
        $bodyJ = ConvertTo-Json $bodyR
        
        $contentType = 'application/json'
        $run = Invoke-WebRequest -Uri $uri -Method Post -ContentType $contentType -Body $bodyJ -Headers $head
        return ConvertFrom-Json -InputObject $run
    }
function global:Adb-Get-Run {
        param( [string]$runId="0")
        
            $uri = "$uriBase/jobs/runs/get?run_id=$runId"
            $head = @{authorization = "Bearer $accessToken" }
        
            $params = @{    
                ContentType = 'application/json'
                Headers = $head
                Method = 'Get'    
                URI = $uri
            }
            $run = Invoke-RestMethod @params
            return $run
    }
function global:Adb-Get-RunOutput {
        param( [string]$runId="0")
        
            $uri = "$uriBase/jobs/runs/get-output?run_id=$runId"
            $head = @{authorization = "Bearer $accessToken" }
        
            $params = @{    
                ContentType = 'application/json'
                Headers = $head
                Method = 'Get'    
                URI = $uri
            }
            $run = Invoke-RestMethod @params
            return $run
    }
function global:Adb-Remove-Directory {
        param( [string]$path="/")
            $uri = "$uriBase/workspace/delete"
            $head = @{authorization = "Bearer $accessToken" }
            $body = @"
        {
            "path": "$path",
            "recursive": true
        }
"@
        Invoke-RestMethod -Uri $uri -Body $Body -Method 'POST' -Headers $head -ContentType "application/json"
    }
function global:Adb-New-Cluster {
        param( [string]$config)
            $uri = "$uriBase/clusters/create"
            $head = @{authorization = "Bearer $accessToken" }
            $body = $config
    
            $clusterId = Invoke-RestMethod -Uri $uri -Body $Body -Method 'POST' -Headers $head -ContentType "application/json"
        return $clusterId
    }
function global:Adb-Remove-Cluster {
        param( [string]$clsId="$clusterId")
            $uri = "$uriBase/clusters/permanent-delete"
            $head = @{authorization = "Bearer $accessToken" }
            $Body = @"
    {
        "cluster_id": "$clsId"
    }
"@
        $params = @{    
            ContentType = 'application/json'
            Headers = $head
            body = $body
            Method = 'Post'    
            URI = $uri
        }
        $clusterId = Invoke-RestMethod -Uri $uri -Body $Body -Method 'POST' -Headers $head -ContentType "application/json"
        return $clusterId
    }
function global:Adb-Get-Clusters {
        param()
            $uri = "$uriBase/clusters/list"
            $head = @{authorization = "Bearer $accessToken" }
    
        $clusters = Invoke-RestMethod -Uri $uri -Method 'GET' -Headers $head -ContentType "application/json"
        return $clusters
    }
function global:Adb-Start-Cluster {
        param( [string]$clsId="$clusterId")
            $uri = "$uriBase/clusters/start"
            $head = @{authorization = "Bearer $accessToken" }
            $Body = @"
    {
        "cluster_id": "$clsId"
    }
"@
        $params = @{    
            ContentType = 'application/json'
            Headers = $head
            body = $body
            Method = 'Post'    
            URI = $uri
        }
        Invoke-RestMethod -Uri $uri -Body $Body -Method 'POST' -Headers $head -ContentType "application/json"
    }
function global:Adb-Remove-Cluster {
        param( [string]$clsId="$clusterId")
            $uri = "$uriBase/clusters/delete"
            $head = @{authorization = "Bearer $accessToken" }
            $Body = @"
    {
        "cluster_id": "$clsId"
    }
"@
        $params = @{    
            ContentType = 'application/json'
            Headers = $head
            body = $body
            Method = 'Post'    
            URI = $uri
        }
        $clusterId = Invoke-RestMethod -Uri $uri -Body $Body -Method 'POST' -Headers $head -ContentType "application/json"
        return $clusterId
    }
function global:Adb-Get-Directory {
    param( [string]$path)
    # list the folders in the parent folder and look for a match
    $head = @{authorization = "Bearer $accessToken" }
    $path = $path -replace "\\", "/"
    $parentPath = Split-Path -Path $path -Parent
    $parentPath = $parentPath -replace "\\", "/"

    $uri = "$uriBase/workspace/list?path=$parentPath"
    $directories = Invoke-RestMethod -Uri $uri -Method 'GET' -Headers $head -ContentType "application/json"
    if ($directories)
    {
        foreach($dir in $directories.objects)
        {
            if ($dir.object_type -eq "DIRECTORY" -and $dir.path -eq $path){
                Write-Output "Target workspace directory '$path' already exists."
                return $dir
            }
        }
    }
    return $null
}
function global:Adb-Remove-Directory {
    param( [string]$path="/")
        $uri = "$uriBase/workspace/delete"
        $head = @{authorization = "Bearer $accessToken" }
        $body = @"
    {
        "path": "$path",
        "recursive": true
    }
"@
    Invoke-RestMethod -Uri $uri -Body $Body -Method 'POST' -Headers $head -ContentType "application/json"
}

function global:Adb-New-ImportDbc {
    param( [string]$path="/", [string]$ifile="")
        $uri = "$uriBase/workspace/import"
        $head = @{authorization = "Bearer $accessToken" }
    
        $BinaryContents = [System.IO.File]::ReadAllBytes("$ifile")
        $EncodedContents = [System.Convert]::ToBase64String($BinaryContents)
       
            $Body = @"
    {
        "format": "DBC",
        "content": "$EncodedContents",
        "path": "$path"
    }
"@
    $params = @{    
        ContentType = 'application/json'
        Headers = $head
        body = $body
        Method = 'Post'    
        URI = $uri
    }
    Invoke-RestMethod -Uri $uri -Body $Body -Method 'POST' -Headers $head -ContentType "application/json"
}
function global:Adb-New-Library {
    param( [string]$clsId, [string]$libraryList )
        $uri = "$uriBase/libraries/install"
        $head = @{authorization = "Bearer $accessToken" }
        $body = @"
        {
            "cluster_id": "$clsId",
            "libraries": [
              $libraryList
            ]
          }
"@
    Invoke-RestMethod -Uri $uri -Body $Body -Method 'POST' -Headers $head -ContentType "application/json"
}
function global:Adb-Get-allUserWorkspaces{
    param(
         [string]$path="/"
    )

    $uri = "$uriBase/workspace/list?path=$path"
    $pathObjects = Invoke-RestMethod -Uri $uri -Method 'GET' -Headers $head
    return $pathObjects
}
function global:Adb-export-notebook{
    param( 
        [string]$path="/"
    )

    $uri = "$uriBase/workspace/export?path=$path&format=SOURCE"
    $fileContent = Invoke-RestMethod -Uri $uri -Method 'GET' -Headers $head
    return $fileContent
}
function global:Adb-import-notebook{
    param(
        [object]$content,
        [string]$path,
        [string]$language
    )


$Body = @"
    {
        "format": "SOURCE",
        "content": "$content",
        "path": "$path",
        "overwrite": "false",
        "language": "$language"
    }
"@
    
    $uri = "$uriBase/workspace/import"
    $response = Invoke-RestMethod -Uri $uri -Body $Body -Method 'POST' -Headers $head -ContentType "application/json" -ErrorAction stop
    
}
function global:Adb-read-WorkspaceContent{
    param(
        [object]$userWorkspaces
    )
    $userWorkspaces.path
    $subobjects = Adb-get-allUserWorkspaces -path $userWorkspaces.path

    foreach($object in  $subobjects.objects){
        $object_type = $object.object_type
        $object_path = $object.path
        Write-Output "$object_type : $object_path"
        $destination_path = ""
        for($backupcount=0 ; $backupcount -lt 99; $backupcount++){
            if($object_path.Contains("-backup-$backupcount")){
                $destination_path = $object_path.replace("-backup-$backupcount","")
                break
            }
        }
        #$destination_path = $object_path.replace("-backup-1","")
        try {            
            if($object_type -eq "DIRECTORY"){
                Adb-New-directory -path $destination_path
                Adb-read-WorkspaceContent -userWorkspaces $object
            }else{
                $language = $object.language
                $fileContent = Adb-export-notebook -path $object_path
                Adb-import-notebook -content $fileContent.content -language $language -path $destination_path    

                $itemDetails = [PSCustomObject] @{    
                    object_type = $object_type
                    path = $object_path
                }
                $logcontent += $itemDetails 
            }    
        }
        catch {
            Write-Verbose $_.ErrorDetails.Message        
        }
}
}
function global:Adb-Get-Workspace {
    param([string]$uriManagement)
    $header = @{authorization = "Bearer $($managementToken.AccessToken)"}

    $workspaces = Invoke-RestMethod -Uri $uriManagement -Headers $header -Method 'GET'

    return $workspaces
}
