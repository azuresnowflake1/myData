Param(
    # The request body
    [object]
    $WebhookData,
    [string]$environmentLetter = 'd',
    [string]$subscriptionname = 'Prod',
    [switch]$autoUpdateOn ='false',
    [switch]$autoUpdateOff ='false',
    [switch]$invokeUpgrade = 'false'
)
.\Import-PlatformCore.ps1
#.\Import-PlatformDataCore.ps1

# Login to azure using our turnkey SPN IANDProdSPN.  The cert must be installed on your machine for this to work
$bootStrap = Login-AzCore -WebHookData $WebhookData -aad
$subscriptionname
Get-AzContext
#$parameters = .\Get-AllParameters.ps1 -webhookData $WebhookData

#get versions of IR
function get-InstalledAndPushedVersions {
    param (
        [string]$subscriptionId,
        [string]$resourcegroupName,
        [string]$dataFactoryName,
        [string]$integrationRuntimeName,
        $accessToken
    )
    $DebugPreference = "Continue"
    
    $uri="https://management.azure.com/subscriptions/{0}/resourceGroups/{1}/providers/Microsoft.DataFactory/factories/{2}/integrationRuntimes/{3}/getStatus?api-version=2018-06-01" -f $subscriptionId, $resourcegroupName , $dataFactoryName, $integrationRuntimeName

    Write-Debug $uri
    
    $response = Invoke-RestMethod -Method Post `
                      -Uri $uri `
                      -Headers @{ "Authorization" = "Bearer " + $accessToken }

    Write-Debug "Datafactory:$dataFactoryName IR:$integrationRuntimeName Pushed Version: $($response.properties.typeProperties.pushedVersion) Installed Version: $($response.properties.typeProperties.version) Latest Version: $($response.properties.typeProperties.latestVersion)"

    return $($response.properties.typeProperties.pushedVersion), $($response.properties.typeProperties.version), $($response.properties.typeProperties.latestVersion)
}

Write-Output "Start script..."
try{
    $rmAccountContext = Get-AzContext

    #"#Get subscription details"
    Select-AzSubscription $subscriptionname | Out-Null
    $subscription = Get-AzSubscription -SubscriptionName $subscriptionname
    $subscriptionId = $subscription.Subscription.Id
    
    #"#get Logged in user context and access bearer token"
    $tokenCache = $rmAccountContext.TokenCache

    $cachedTokens = $tokenCache.ReadItems() `
            | Sort-Object -Property ExpiresOn -Descending

    $accessToken = $cachedTokens[0].AccessToken
  
    #"#Store log file"
    $StorageAccountName = '070bienobrunilevercomstg' #ITSG 56728
    $containerName = 'integrationruntimeupgradestatus'
    $keyvault = 'bieno-da-p-56728-appk-01'
    $sastokenkey = '070bienobrunilevercomstg-sastoken-irupgradestatslog'
    $sastoken = Get-AzKeyVaultSecret -VaultName $keyvault -Name $sastokenkey    
    $StorageContext = New-AzStorageContext $StorageAccountName -SasToken $sastoken.SecretValueText
    if($invokeUpgrade){
        $outputfile = "IntegrationRuntimeUpgrade-$environmentLetter-$subscriptionname.csv"
        $header1 = "Upgrade Date,Subscription,Resource Group,Data Factory,Integration Runtime,Installed Version,Pushed Version,Latest Version,IR Type"
    }elseif($autoUpdateOff){
        $outputfile = "IntegrationRuntimeAutoupdateOff-$environmentLetter-$subscriptionname.csv"
        $header1 = "Date,Subscription,Resource Group,Data Factory,Integration Runtime,IR Type"
    }elseif($autoUpdateOn){
        $outputfile = "IntegrationRuntimeAutoupdateOn-$environmentLetter-$subscriptionname.csv"
        $header1 = "Date,Subscription,Resource Group,Data Factory,Integration Runtime,IR Type"
    }
    Add-Content $outputfile $header1

}catch{
    Write-Output $_.Exception.Message
    throw
    return
}

try
{	
    $resourcegroups = Get-AzResourceGroup | Select-Object resourcegroupname

    Write-Output "Got resource groups..."
	foreach ($resourcegroup in $resourcegroups) 
	{
        $resourcegroupName = $resourcegroup.resourcegroupname
        $splitArray = $resourcegroupName.Split("-")

        if($splitArray[2] -ne $environmentLetter)
        {
            continue
        }

        try
		{
			$resourcesADF = Get-AzResource -ResourceGroupName $resourcegroupName -ResourceType "Microsoft.DataFactory/factories" | Select-Object Name, resourcename,ResoruceGroupName,resourceid,location
			foreach ($resourceADF in $resourcesADF)
			{
				try
				{
					$integrationRuntimes = Get-AzDataFactoryV2IntegrationRuntime -ResourceGroupName $resourcegroupName -DataFactoryName $resourceADF.Name -Status | Select-Object Name, Type
                    foreach ($integrationRuntime in $integrationRuntimes)
					{                        
						try
						{
                            $integrationRuntimeStatus = Get-AzDataFactoryV2IntegrationRuntime -ResourceGroupName $resourcegroupName -DataFactoryName $resourceADF.Name -Name $integrationRuntime.Name -Status | Select-Object Version, Type
                            if($integrationRuntimeStatus.Type -ne "SelfHosted"){
                                Write-Output "IntegrationRuntime:$($integrationRuntime.Name) Type:$($integrationRuntimeStatus.Type) is not supported for autoupdate setting changes"
                                continue
                            }
							$datetime = Get-Date
                            if($autoUpdateOff -And $integrationRuntimeStatus.Type -eq "SelfHosted") {
                                $status = Update-AzDataFactoryV2IntegrationRuntime -AutoUpdate Off -Name $integrationRuntime.Name -DataFactoryName $resourceADF.Name -ResourceGroupName $resourcegroupName -Verbose
    							$outputtext = "$($datetime),$subscriptionname,$($resourcegroupName),$($resourceADF.Name),$($integrationRuntime.Name),$($integrationRuntimeStatus.Type)"
                                Write-Output "Autoupdate Off:$($integrationRuntime.Name) Datafactory:$($resourceADF.Name)"                                
                            }
                            if ($autoUpdateOn -And $integrationRuntimeStatus.Type -eq "SelfHosted") {
                                $status = Update-AzDataFactoryV2IntegrationRuntime -AutoUpdate On -Name $integrationRuntime.Name -DataFactoryName $resourceADF.Name -ResourceGroupName $resourcegroupName -Verbose                               
    							$outputtext = "$($datetime),$subscriptionname,$($resourcegroupName),$($resourceADF.Name),$($integrationRuntime.Name),$($integrationRuntimeStatus.Type)"
                                Write-Output "Autoupdate On:$($integrationRuntime.Name) Datafactory:$($resourceADF.Name)"                                
                            }
                            if ($invokeUpgrade -And $integrationRuntimeStatus.Type -eq "SelfHosted") {
                                $dataFactoryName = $resourceADF.Name
                                $integrationRuntimeName = $integrationRuntime.Name

                                $IRVersions = get-InstalledAndPushedVersions -subscriptionId $subscriptionId -resourcegroupName $resourcegroupName -dataFactoryName $dataFactoryName -integrationRuntimeName $integrationRuntimeName -accessToken $accessToken
                                $pushedVersion = $IRVersions[0]
                                $installedVersion = $IRVersions[1]
                                $latestVersion = $IRVersions[2]

                                $status = Invoke-AzDataFactoryV2IntegrationRuntimeUpgrade -Name $integrationRuntimeName `
                                -DataFactoryName $dataFactoryName -ResourceGroupName $resourcegroupName -Verbose

                                Write-Output "Upgraded IR:$integrationRuntimeName DF:$dataFactoryName IR:$resourcegroupName to version ($pushedVersion) from ($installedVersion)"
        						$outputtext = "$($datetime),$subscriptionname,$($resourcegroupName),$($resourceADF.Name),$($integrationRuntime.Name),$($installedVersion),$($pushedVersion),$($latestVersion),$($integrationRuntimeStatus.Type)"
                            }
                            Add-Content $outputfile $outputtext                        
                        }catch
						{
                            #throw
                            Write-Output $_.Exception.Message
						}					
					}
				}catch
				{
                    #throw
                    Write-Output $_.Exception.Message
				}
			}
		}catch
		{
            #throw
            Write-Output $_.Exception.Message
		}
	}
}catch{
    #throw
    Write-Output $_.Exception.Message
}

try{
    Set-AzStorageBlobContent -File $outputfile -Container $containerName -Context $StorageContext `
    -Blob $outputfile -Force -WarningAction SilentlyContinue
    Write-Output "Log file: $outputfile generated at storage $StorageAccountName in container $containerName"
    Remove-Item $outputfile -Force
}catch{
    #throw
    Write-Output $_.Exception.Message
}