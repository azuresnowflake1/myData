###########################################################################################
# Define reusable logic that supports the platform but doesn't need to be in its own runbook
###########################################################################################
# WARNING: Don't edit this code in situ as misakes can break the entire platform
###########################################################################################

# Pass this to get all New Foundation subscriptions
function global:Get-Subscriptions {
    param([switch]$all, [switch]$includeOldFoundation,[switch]$includeMSEnterprise) 

    try {
        if (-not $all) {
            $isProd = Get-AutomationVariable -Name 'isProdAutomationAccount' -ErrorAction Stop
            $region = Get-AutomationVariable -Name 'newFoundationRegion' -ErrorAction Stop
        }
    } catch {
        $message = @"
"The automation account isn't configured correctly. You must define the following global variables:
    [bool]isProdAutomationAccount
    [string]newFoundationRegion
Or pass the -all switch
"@
        Write-Error $message
        throw $message
    }
    
    # r = DR; x = experiment
    $subscriptions = @{
        "01" = @{"SubscriptionId" = "e2b0e829-5210-40ae-b73f-20805aa01351"; "EnvironmentUsage"="PDS Prod"; "ProjectEnvironment"="p"; "ProjectNumber"="56728"; "Region"="westeurope"; "SubscriptionNumber"="01" }
        "02" = @{"SubscriptionId" = "8b4fb847-3b45-410f-a6e7-3247c9d459b7"; "EnvironmentUsage"="PDS PreProd & Acceptance"; "ProjectEnvironment"="u"; "ProjectNumber"="56732"; "Region"="westeurope"; "SubscriptionNumber"="02" }
        "03" = @{"SubscriptionId" = "43046d94-2b34-46fa-8b8b-4a3a72b53df6"; "EnvironmentUsage"="PDS QA"; "ProjectEnvironment"="q"; "ProjectNumber"="56730"; "Region"="westeurope"; "SubscriptionNumber"="03" }
        "04" = @{"SubscriptionId" = "105fbd8d-388f-4b19-9fda-d56f44121122"; "EnvironmentUsage"="PDS Dev"; "ProjectEnvironment"="d"; "ProjectNumber"="56731"; "Region"="westeurope"; "SubscriptionNumber"="04" }
        "05" = @{"SubscriptionId" = "b3c4d044-fa50-40d7-a7da-554df6dcd693"; "EnvironmentUsage"="UDL Prod"; "ProjectEnvironment"="p"; "ProjectNumber"="56728"; "Region"="northeurope"; "SubscriptionNumber"="05" }
        "06" = @{"SubscriptionId" = "7796e2b1-1c51-4a77-accf-3c035b59a22e"; "EnvironmentUsage"="UDL UAT"; "ProjectEnvironment"="u"; "ProjectNumber"="56732"; "Region"="northeurope"; "SubscriptionNumber"="06" }
        "07" = @{"SubscriptionId" = "5205d638-1940-450e-82ab-210e70dfd24b"; "EnvironmentUsage"="UDL QA"; "ProjectEnvironment"="q"; "ProjectNumber"="56730"; "Region"="northeurope"; "SubscriptionNumber"="07" }
        "08" = @{"SubscriptionId" = "8e017cde-1d7c-4842-a4a5-18f6c115cae3"; "EnvironmentUsage"="UDL Dev"; "ProjectEnvironment"="d"; "ProjectNumber"="56731"; "Region"="northeurope"; "SubscriptionNumber"="08" }
        "09" = @{"SubscriptionId" = "291887e7-fc87-453a-ba96-5f2386363348"; "EnvironmentUsage"="PDS Prod"; "ProjectEnvironment"="p"; "ProjectNumber"="56728"; "Region"="northeurope"; "SubscriptionNumber"="09" }
        "10" = @{"SubscriptionId" = "cc50b059-7825-4502-b372-4a82621f0824"; "EnvironmentUsage"="PDS PreProd $ Acceptance"; "ProjectEnvironment"="u"; "ProjectNumber"="56732"; "Region"="northeurope"; "SubscriptionNumber"="10" }
        "11" = @{"SubscriptionId" = "b699fc9e-47e8-4268-8b1a-f6f14757dd06"; "EnvironmentUsage"="PDS QA"; "ProjectEnvironment"="q"; "ProjectNumber"="56730"; "Region"="northeurope"; "SubscriptionNumber"="11" }
        "12" = @{"SubscriptionId" = "c9462478-f3d6-4345-acd0-feb25ebe28ca"; "EnvironmentUsage"="PDS Dev"; "ProjectEnvironment"="d"; "ProjectNumber"="56731"; "Region"="northeurope"; "SubscriptionNumber"="12" }
        "13" = @{"SubscriptionId" = "65c24fb4-4567-43b8-a31f-d06f8f1d0dd7"; "EnvironmentUsage"="PDS DR"; "ProjectEnvironment"="r"; "ProjectNumber"="56728"; "Region"="westeurope"; "SubscriptionNumber"="13" }
        "14" = @{"SubscriptionId" = "fb99e2dd-0915-4ae7-9f69-68076d8a1d65"; "EnvironmentUsage"="UDL DR"; "ProjectEnvironment"="r"; "ProjectNumber"="56728"; "Region"="westeurope"; "SubscriptionNumber"="14" }
        "15" = @{"SubscriptionId" = "979c83a5-77cd-4100-8d86-24158a5fb05f"; "EnvironmentUsage"="BDL DR"; "ProjectEnvironment"="r"; "ProjectNumber"="56728"; "Region"="westeurope"; "SubscriptionNumber"="15" }
        "16" = @{"SubscriptionId" = "c70cf1d8-50bd-486d-b921-b910ffb03a70"; "EnvironmentUsage"="Experimentation"; "ProjectEnvironment"="d"; "ProjectNumber"="56731"; "Region"="westeurope"; "SubscriptionNumber"="16" }
        "17" = @{"SubscriptionId" = "01ae14d9-fe46-4fc1-b494-cb4cdea69385"; "EnvironmentUsage"="PDS DR"; "ProjectEnvironment"="r"; "ProjectNumber"="56728"; "Region"="northeurope"; "SubscriptionNumber"="17" }
        "18" = @{"SubscriptionId" = "23c97e5c-d961-43fd-8653-5a528cb5a2f5"; "EnvironmentUsage"="BDL Prod"; "ProjectEnvironment"="p"; "ProjectNumber"="56728"; "Region"="northeurope"; "SubscriptionNumber"="18" }
        "19" = @{"SubscriptionId" = "dc1d755b-b3f2-48af-9e29-c604787b6fca"; "EnvironmentUsage"="BDL UAT"; "ProjectEnvironment"="b"; "ProjectNumber"="56732"; "Region"="northeurope"; "SubscriptionNumber"="19" }
        "20" = @{"SubscriptionId" = "bdc1b740-de49-4c42-84b9-9617ff3f16ba"; "EnvironmentUsage"="BDL PreProd"; "ProjectEnvironment"="u"; "ProjectNumber"="56732"; "Region"="northeurope"; "SubscriptionNumber"="20" }
        "21" = @{"SubscriptionId" = "105cc892-0276-4b01-b5ff-426df8be49e2"; "EnvironmentUsage"="BDL QA"; "ProjectEnvironment"="q"; "ProjectNumber"="56730"; "Region"="northeurope"; "SubscriptionNumber"="21" }
        "22" = @{"SubscriptionId" = "e1d1de9f-a503-4330-86fb-88f5f6fc3107"; "EnvironmentUsage"="BDL Dev"; "ProjectEnvironment"="d"; "ProjectNumber"="56731"; "Region"="northeurope"; "SubscriptionNumber"="22" }
        "23" = @{"SubscriptionId" = "b1b30958-7fef-44ce-a340-6a68b6f95e96"; "EnvironmentUsage"="Experimentation"; "ProjectEnvironment"="d"; "ProjectNumber"="56731"; "Region"="northeurope"; "SubscriptionNumber"="23" }
        "24" = @{"SubscriptionId" = "27da6244-9548-48cd-813f-d742d780055b"; "EnvironmentUsage"="MS POC"; "ProjectEnvironment"="d"; "ProjectNumber"="56731"; "Region"="northeurope"; "SubscriptionNumber"="24" }
   }
    
    $filteredSubscriptions = @{}
    if ($all) {
        $keys = $subscriptions.Keys
    } else {
        # Filter on region and type
        if ($isProd) {
            $keys = $subscriptions.Keys | Where-Object {$subscriptions[$_].ProjectEnvironment -eq "p"}
        } else {
            $keys = $subscriptions.Keys | Where-Object {$subscriptions[$_].ProjectEnvironment -ne "p"}
        } 
        $subscriptions.keys.where{
            $PSItem -in $keys
        }.foreach{
            $filteredSubscriptions[$PSItem] = $subscriptions[$PSItem]
        }
        $subscriptions = $filteredSubscriptions.Clone()
        $keys = $subscriptions.Keys | Where-Object {$subscriptions[$_].Region -eq $region}
        $filteredSubscriptions = @{}
    }
    $subscriptions.keys.where{
        $PSItem -in $keys
    }.foreach{
        $filteredSubscriptions[$PSItem] = $subscriptions[$PSItem]
    }
    if ($includeOldFoundation) {
            $filteredSubscriptions["Prod"] = @{"SubscriptionId" = "50327adb-f8a0-4908-8d31-aa182df19f02"; "EnvironmentUsage"="o"; "ProjectEnvironment"="p"; "ProjectNumber"="56728"; "Region"="westeurope"; "SubscriptionNumber"="Prod" }
            $filteredSubscriptions["Prod2"] = @{"SubscriptionId" = "204671af-5130-4ef5-819c-e314b65f9d06"; "EnvironmentUsage"="o"; "ProjectEnvironment"="p"; "ProjectNumber"="56728"; "Region"="westeurope"; "SubscriptionNumber"="Prod2" }
            $filteredSubscriptions["Prod3"] = @{"SubscriptionId" = "9abbdd30-3391-4dfc-bfb6-217a40627488"; "EnvironmentUsage"="o"; "ProjectEnvironment"="p"; "ProjectNumber"="56728"; "Region"="westeurope"; "SubscriptionNumber"="Prod3" }
    }
    if($includeMSEnterprise){
        $filteredSubscriptions["Microsoft Azure Enterprise"] = @{"SubscriptionId" = "bc41a9ef-b853-4107-aa12-cc8d592c8e91"; "EnvironmentUsage"=""; "ProjectEnvironment"=""; "ProjectNumber"=""; "Region"=""; "SubscriptionNumber"="Microsoft Azure Enterprise" }
    }
    # If we are currently logged into Azure try to get a context for each subscription
    # We need to distinguish between the runtime host.  IF this is running on a windows client i.e someone is running the turnkey,
    # we want to filter out contexts that aren't connected using the current user's account i.e. filter out
    # those accounts belonging to SPNs
    if ($PSPrivateMetadata.JobId) {
        # running in Automation
        $contexts = Get-AzContext -ListAvailable -ErrorAction SilentlyContinue
    }
    else {
        # Running locally
        $contexts = Get-AzContext -ListAvailable -ErrorAction SilentlyContinue | Where-Object { $_.Account.Type -eq "user" }
    }

    if ($contexts) {
        foreach($ctx in $contexts)
        { 
            $tokens = $ctx.Subscription.Name.Split("-")
            if ($tokens.Count -eq 2) {
                # Assume this is new foundation
                if ($filteredSubscriptions[$tokens[1]]) {
                    $filteredSubscriptions[$tokens[1]].DefaultProfile = $ctx
                }
            } elseif ((IsOldFoundation -subscriptionNumber $ctx.Subscription.Name) -and $includeOldFoundation) {
                # Assume old foundation
                $filteredSubscriptions[$ctx.Subscription.Name].DefaultProfile = $ctx
            }elseif ($ctx.Subscription.Name.Contains("Microsoft Azure Enterprise") -and $includeMSEnterprise) {
                $filteredSubscriptions[$ctx.Subscription.Name].DefaultProfile = $ctx
            }        
        }
    }
    return $filteredSubscriptions
}
function global:IsOldFoundation{
    param([string]$subscriptionNumber)
    return $subscriptionNumber.ToUpper().Contains("PROD")
}
function global:Get-SubscriptionBootstrap {
    param([string]$subscriptionNumber,
            [string]$subscriptionId)

    $subscriptionNumber = $subscriptionNumber.PadLeft(2,'0')
    $args = @{"All" = $true }
    if ((IsOldFoundation -subscriptionNumber $subscriptionNumber)){
        $args["includeOldFoundation"] = $true
    }
    if ($subscriptionNumber -eq 'Microsoft Azure Enterprise'){
        $args["includeMSEnterprise"] = $true
    }
    $subscriptions = Get-Subscriptions @args

    if($subscriptionId) {
        foreach($subscription in $subscriptions.Keys) {
            if($subscriptions[$subscription].SubscriptionId -eq $subscriptionId) {
                $subscriptionNumber = $subscription
            }
        }
    }



    if ($subscriptionNumber) {
        return $subscriptions[$subscriptionNumber]
    }
}


function global:Get-Bootstrap {
Param
(
    [Parameter(Mandatory = $False, HelpMessage = 'Specify the parameter file name')]
    [String]$parameterFile,
    [Parameter(Mandatory = $False, HelpMessage = 'Specify the name of a new foundation component')]
    [String]$componentName,
    [Parameter(Mandatory = $False, HelpMessage = 'Specify the number of a new foundation component')]
    [String]$subscriptionNumber
)
    if ($componentName) {
        $subscriptionNumber = $componentName.Split("-")[1].Substring(2)
    }
    if ($subscriptionNumber){
        $subscriptionNumber = $subscriptionNumber.PadLeft(2,'0')
        $boot = Get-SubscriptionBootstrap -subscriptionNumber $subscriptionNumber
        $namePrefix = Get-NamePrefix -region $boot["Region"]
        $componentName = "{0}-da{1}-{2}-00000-adf-01" -f $namePrefix, $subscriptionNumber, $boot["ProjectEnvironment"]
    }
    # We also need to support bootstraping when there is no current Az connection available to determine the subscription
    if ($parameterFile) {
        # Assume we are already connected to an Az context
        $ctx = Get-AzContext
        if (-not $ctx) {
            throw "Please call Login-AzAccount and select your target subscription."
        }
        $tenantId = $ctx.Tenant.TenantId
        $subscriptionId = $ctx.subscription.subscriptionId
        $subscriptionName = $ctx.subscription.Name
        $subscriptionNumber = $subscriptionName.Split("-")[1]
        $subs = Get-Subscriptions -all
        $sub = $subs[$subscriptionNumber]
        
        if (-not $sub){
            throw "Global bootstrap context unset - Unable to bootstrap your environment!"
        }
        $location = $sub.Region
        $namePrefix = Get-NamePrefix -Region $sub.Region
        $tokens = $parameterFile.Split(".")
        if ($tokens.Count -eq 2) {
            # Assume a compressed parameter file name was passed.
            $parameterFile = "{0}.$parameterFile.json" -f "parameters"
            $projectEnvironment = $tokens[0]
        }
        else {
            $projectEnvironment = $tokens[1]
        }
        $tokens = $parameterFile.Split(".")
        $projectNumber = $tokens[2]
    }
    else {
        $tenantId = "f66fae02-5d36-495b-bfe0-78a6ff9f8e6e"
        # map the subscription number to a subscriptionId
        $tokens = $componentName.Split("-")
        if ($tokens.Count -lt 3) {
            throw "The specified component name '$componentName' cannot be used to bootstap the environment.  Use this format bnlwe-da04-d-xxxxx."
        }
        $namePrefix = $tokens[0]
        $projectEnvironment = $tokens[2]
        $projectNumber = $tokens[3]
        $subscriptionNumber = $tokens[1].Substring(2)
        $locations = @{
            "bnlwe"="westeurope"
            "bieno"="northeurope"
        }
        $location = $locations[$namePrefix]
        $subscriptions = Get-Subscriptions -All -includeOldFoundation

        $subscriptionId = $subscriptions[$subscriptionNumber]["SubscriptionId"]
    }
    
    switch ($projectEnvironment) {
        "d" { 
            $environment = "Development"
            $landscapeItsg = "56731"
        }
        "x" { 
            $environment = "Experiment"
            $landscapeItsg = "56731"
        }
        "u" { 
            $environment = "Pre-Prod"
            $landscapeItsg = "56732"
        }
        "q" {
            $environment = "QA"
            $landscapeItsg = "56730"
        }
        "b" {
            $environment = "UAT"
            $landscapeItsg = "56732"
        }
        "p" {
            $environment = "Production"
            $landscapeItsg = "56728"
        }
        "r" {
            $environment = "DR"
            $landscapeItsg = "56728"
        }
    }
    

    ###########################################################
    # Subscriptions are added in a few differrent scenarios:
    #   1. Bank of 4. Dev, Qa, PPPD & Prod
    #   2. Bank of 5. Dev, Qa, PPD, UAT & Prod
    #   3. DR
    #   4. Experimentation
    ###########################################################
    # The following decisions affect this bootstrap code.  In fact, the bootstrap is
    # designed to encapsulate all these decisions so that we don't need to write any more
    # code that takes them into account:
    # D1. Where subs are part of a bank, shared services like self hosted IRs, automation accounts, webhooks are 
    #   provisioned as either prod or non prod. Non prod services are always hosted in the dev sub, prod services
    #   are always hosted in the prod sub
    # D2. Landscape's Eco Master application is installed into every subscription using the approprate ITSG.
    #    56731 Dev, 56730 QA, 56732 PPD, 56732 UAT, 56728 PROD
    # D3. Shared services from one bank are not shared with any other bank
    # D4. DR environments use production shared services
    # D5. Experimentation environments use dev shared services
    ##########################################################
    if ($subscriptionId -eq "e2b0e829-5210-40ae-b73f-20805aa01351") {
        # Core Data Ecosystem-01 Production
        $landscapeAdfResourceGroupName = "{0}-da01-p-56728-rg" -f $namePrefix
        $landscapeAdfName = "{0}-da01-p-56728-adf-01" -f $namePrefix
        $devSubscriptionId = "105fbd8d-388f-4b19-9fda-d56f44121122"
        $storageAccountName = "bnlwestgunileverda56728"
        $subscriptionNumberDev = "04"
    } elseif ($subscriptionId -eq "8b4fb847-3b45-410f-a6e7-3247c9d459b7") {
        # Core Data Ecosystem-02 Pre-Prod and UAT
        $landscapeAdfResourceGroupName = "{0}-da04-d-56731-rg" -f $namePrefix
        $landscapeAdfName = "{0}-da04-d-56731-adf-01" -f $namePrefix
        $devSubscriptionId = "105fbd8d-388f-4b19-9fda-d56f44121122"
        $storageAccountName = "bnlwestgunileverda56732"
        $subscriptionNumberDev = "04"
    } elseif ($subscriptionId -eq "43046d94-2b34-46fa-8b8b-4a3a72b53df6") {
        # Core Data Ecosystem-03 QA
        $landscapeADFResourceGroupName = "{0}-da04-d-56731-rg" -f $namePrefix
        $landscapeAdfName = "{0}-da04-d-56731-adf-01" -f $namePrefix
        $devSubscriptionId = "105fbd8d-388f-4b19-9fda-d56f44121122"
        $storageAccountName = "bnlwestgunileverda56730"
        $subscriptionNumberDev = "04"
    } elseif ($subscriptionId -eq "105fbd8d-388f-4b19-9fda-d56f44121122") {
        # Core Data Ecosystem-04 Development
        $landscapeADFResourceGroupName = "{0}-da04-d-56731-rg" -f $namePrefix
        $landscapeAdfName = "{0}-da04-d-56731-adf-01" -f $namePrefix
        $devSubscriptionId = $subscriptionId
        $storageAccountName = "bnlwestgunileverda56731"
        $subscriptionNumberDev = "04"
    #------------------------------------------------------------------------
    } elseif ($subscriptionId -eq "b3c4d044-fa50-40d7-a7da-554df6dcd693") {
        # Core Data Ecosystem-05 UDL Prod
        $devSubscriptionId = "8e017cde-1d7c-4842-a4a5-18f6c115cae3"
        $landscapeAdfResourceGroupName = "{0}-da05-p-56728-rg" -f $namePrefix
        $landscapeAdfName = "{0}-da05-p-56728-adf-01" -f $namePrefix
        $subscriptionNumberDev = "08"
    } elseif ($subscriptionId -eq "7796e2b1-1c51-4a77-accf-3c035b59a22e") {
        # Core Data Ecosystem-06 UDL UAT
        $devSubscriptionId = "8e017cde-1d7c-4842-a4a5-18f6c115cae3"
        $landscapeAdfResourceGroupName = "{0}-da08-d-56731-rg" -f $namePrefix
        $landscapeAdfName = "{0}-da08-d-56731-adf-01" -f $namePrefix
        $subscriptionNumberDev = "08"
    } elseif ($subscriptionId -eq "5205d638-1940-450e-82ab-210e70dfd24b") {
        # Core Data Ecosystem-07 UDL QA
        $devSubscriptionId = "8e017cde-1d7c-4842-a4a5-18f6c115cae3"
        $landscapeAdfResourceGroupName = "{0}-da08-d-56731-rg" -f $namePrefix
        $landscapeAdfName = "{0}-da08-d-56731-adf-01" -f $namePrefix
        $subscriptionNumberDev = "08"
    } elseif ($subscriptionId -eq "8e017cde-1d7c-4842-a4a5-18f6c115cae3") {
        # Core Data Ecosystem-08 UDL Dev
        $devSubscriptionId = $subscriptionId
        $landscapeAdfResourceGroupName = "{0}-da08-d-56731-rg" -f $namePrefix
        $landscapeAdfName = "{0}-da08-d-56731-adf-01" -f $namePrefix
        $subscriptionNumberDev = "08"
    #------------------------------------------------------------------------
    } elseif ($subscriptionId -eq "291887e7-fc87-453a-ba96-5f2386363348") {
        # Core Data Ecosystem-09 New-Foundation Dublin Prod
        $devSubscriptionId = "c9462478-f3d6-4345-acd0-feb25ebe28ca"
        $landscapeAdfResourceGroupName = "{0}-da09-p-56728-rg" -f $namePrefix
        $landscapeAdfName = "{0}-da09-p-56728-adf-01" -f $namePrefix
        $subscriptionNumberDev = "12"
    } elseif ($subscriptionId -eq "cc50b059-7825-4502-b372-4a82621f0824") {
        # Core Data Ecosystem-10 New-Foundation Dublin UAT
        $devSubscriptionId = "c9462478-f3d6-4345-acd0-feb25ebe28ca"
        $landscapeAdfResourceGroupName = "{0}-da12-d-56731-rg" -f $namePrefix
        $landscapeAdfName = "{0}-da12-d-56731-adf-01" -f $namePrefix
        $subscriptionNumberDev = "12"
    } elseif ($subscriptionId -eq "b699fc9e-47e8-4268-8b1a-f6f14757dd06") {
        # Core Data Ecosystem-11 New-Foundation Dublin QA
        $devSubscriptionId = "c9462478-f3d6-4345-acd0-feb25ebe28ca"
        $landscapeAdfResourceGroupName = "{0}-da12-d-56731-rg" -f $namePrefix
        $landscapeAdfName = "{0}-da12-d-56731-adf-01" -f $namePrefix
        $subscriptionNumberDev = "12"
    } elseif ($subscriptionId -eq "c9462478-f3d6-4345-acd0-feb25ebe28ca") {
        # Core Data Ecosystem-12 New-Foundation Dublin Dev
        $devSubscriptionId = $subscriptionId
        $landscapeAdfResourceGroupName = "{0}-da12-d-56731-rg" -f $namePrefix
        $landscapeAdfName = "{0}-da12-d-56731-adf-01" -f $namePrefix
        $subscriptionNumberDev = "12"
    #------------------------------------------------------------------------
    } elseif ($subscriptionId -eq "65c24fb4-4567-43b8-a31f-d06f8f1d0dd7") {
        # Core Data Ecosystem-13 Dublin PDS DR (i.e. Hosted in Amsterdam)
        $devSubscriptionId = "c9462478-f3d6-4345-acd0-feb25ebe28ca"
        $landscapeAdfResourceGroupName = "{0}-da01-p-56728-rg" -f $namePrefix
        $landscapeAdfName = "{0}-da01-p-56728-adf-01" -f $namePrefix
        $subscriptionNumberDev = "12"
    } elseif ($subscriptionId -eq "fb99e2dd-0915-4ae7-9f69-68076d8a1d65") {
        # Core Data Ecosystem-14 UDL DR (Amsterdam)
        $devSubscriptionId = "8e017cde-1d7c-4842-a4a5-18f6c115cae3"
        $landscapeAdfResourceGroupName = "{0}-da01-p-56728-rg" -f $namePrefix
        $landscapeAdfName = "{0}-da01-p-56728-adf-01" -f $namePrefix
        $subscriptionNumberDev = "08"
    } elseif ($subscriptionId -eq "979c83a5-77cd-4100-8d86-24158a5fb05f") {
        # Core Data Ecosystem-15 BDL DR (Amsterdam)
        $devSubscriptionId = "e1d1de9f-a503-4330-86fb-88f5f6fc3107"
        $landscapeAdfResourceGroupName = "{0}-da01-p-56728-rg" -f $namePrefix
        $landscapeAdfName = "{0}-da01-p-56728-adf-01" -f $namePrefix
        $subscriptionNumberDev = "22"
    #------------------------------------------------------------------------
    } elseif ($subscriptionId -eq "c70cf1d8-50bd-486d-b921-b910ffb03a70") {
        # Core Data Ecosystem-16 Experimentation
        $devSubscriptionId = "c70cf1d8-50bd-486d-b921-b910ffb03a70"
        $landscapeAdfResourceGroupName = "{0}-da04-d-56731-rg" -f $namePrefix
        $landscapeAdfName = "{0}-da04-d-56731-adf-01" -f $namePrefix
        $subscriptionNumberDev = "16"
    #------------------------------------------------------------------------
    } elseif ($subscriptionId -eq "01ae14d9-fe46-4fc1-b494-cb4cdea69385") {
        # Core Data Ecosystem-17 Amsterdam PDS DR (i.e. Hosted in Dublin)
        # This is CDE17 subscription, currently it shares shared IT with CDE01
        $landscapeAdfResourceGroupName = "{0}-da09-p-56728-rg" -f $namePrefix
        $landscapeAdfName = "{0}-da09-p-56728-adf-01" -f $namePrefix
        $devSubscriptionId = "105fbd8d-388f-4b19-9fda-d56f44121122"
        $subscriptionNumberDev = "04"
    #------------------------------------------------------------------------
    } elseif ($subscriptionId -eq "23c97e5c-d961-43fd-8653-5a528cb5a2f5") {
        # Core Data Ecosystem-18 BDL Prod
        $devSubscriptionId = "e1d1de9f-a503-4330-86fb-88f5f6fc3107"
        $landscapeAdfResourceGroupName = "{0}-da18-p-56728-rg" -f $namePrefix
        $landscapeAdfName = "{0}-da18-p-56728-adf-01" -f $namePrefix
        $subscriptionNumberDev = "22"
    } elseif ($subscriptionId -eq "dc1d755b-b3f2-48af-9e29-c604787b6fca") {
        # Core Data Ecosystem-19 BDL UAT
        $devSubscriptionId = "e1d1de9f-a503-4330-86fb-88f5f6fc3107"
        $landscapeAdfResourceGroupName = "{0}-da22-d-56731-rg" -f $namePrefix
        $landscapeAdfName = "{0}-da22-d-56731-adf-01" -f $namePrefix
        $subscriptionNumberDev = "12"
    } elseif ($subscriptionId -eq "bdc1b740-de49-4c42-84b9-9617ff3f16ba") {
        # Core Data Ecosystem-20 BDL PPD
        $devSubscriptionId = "e1d1de9f-a503-4330-86fb-88f5f6fc3107"
        $landscapeAdfResourceGroupName = "{0}-da22-d-56731-rg" -f $namePrefix
        $landscapeAdfName = "{0}-da22-d-56731-adf-01" -f $namePrefix
        $subscriptionNumberDev = "12"
    } elseif ($subscriptionId -eq "105cc892-0276-4b01-b5ff-426df8be49e2") {
        # Core Data Ecosystem-21 BDL QA
        $devSubscriptionId = "e1d1de9f-a503-4330-86fb-88f5f6fc3107"
        $landscapeAdfResourceGroupName = "{0}-da22-d-56731-rg" -f $namePrefix
        $landscapeAdfName = "{0}-da22-d-56731-adf-01" -f $namePrefix
        $subscriptionNumberDev = "12"
    } elseif ($subscriptionId -eq "e1d1de9f-a503-4330-86fb-88f5f6fc3107") {
        # Core Data Ecosystem-22 BDL Dev
        $devSubscriptionId = $subscriptionId
        $landscapeAdfResourceGroupName = "{0}-da22-d-56731-rg" -f $namePrefix
        $landscapeAdfName = "{0}-da22-d-56731-adf-01" -f $namePrefix
        $subscriptionNumberDev = "12"
    }
    #------------------------------------------------------------------------
    elseif ($subscriptionId -eq "b1b30958-7fef-44ce-a340-6a68b6f95e96") {
        # Core Data Ecosystem-23 Experimentation North Europe
        $devSubscriptionId = "b1b30958-7fef-44ce-a340-6a68b6f95e96"
        $landscapeAdfResourceGroupName = "{0}-da12-d-56731-rg" -f $namePrefix
        $landscapeAdfName = "{0}-da12-d-56731-adf-01" -f $namePrefix
        $subscriptionNumberDev = "23"
    } elseif ($subscriptionId -eq "27da6244-9548-48cd-813f-d742d780055b") {
            # Core Data Ecosystem-24 MS POC North Europe
            $devSubscriptionId = "b1b30958-7fef-44ce-a340-6a68b6f95e96"
            $landscapeAdfResourceGroupName = "{0}-da12-d-56731-rg" -f $namePrefix
            $landscapeAdfName = "{0}-da12-d-56731-adf-01" -f $namePrefix
            $subscriptionNumberDev = "24"
        #------------------------------------------------------------------------
    } elseif (IsOldFoundation -subscriptionNumber $subscriptionNumber) {
        # This is meaningless but we need the bootstrap to return without throwing an exception
        # Point at PROD
        $devSubscriptionId = "50327adb-f8a0-4908-8d31-aa182df19f02"
        $landscapeAdfResourceGroupName = "{0}-da-d-56731-rg" -f $namePrefix
        $landscapeAdfName = "bieno-da-d-56731-adf-01" -f $namePrefix
    } else {
        # Unsupported
        throw "Subscription $subscriptionId in not currently supported."
    }

    switch ($namePrefix) {
        "bieno" 
        {
            if ("pr".Contains($projectEnvironment))  {
                $automationAccount = "bieno-da09-p-56728-auto-01"
                $automationAccountResourceGroup = "bieno-da09-p-56728-rg"
                $automationSubscriptionId = "291887e7-fc87-453a-ba96-5f2386363348"
                $automationKeyVaultName = "bieno-da09-p-56728-kv-01"
            }
            else {
                $automationAccount = "bieno-da12-d-56731-auto-01"
                $automationAccountResourceGroup = "bieno-da12-d-56731-rg"
                $automationSubscriptionId = "c9462478-f3d6-4345-acd0-feb25ebe28ca"
                $automationKeyVaultName = "bieno-da12-d-56731-kv-01"
            }
        }
        "bnlwe"
        {
            if ("pr".Contains($projectEnvironment))  {
                $automationAccount = "bnlwe-da01-p-56728-auto-01"
                $automationAccountResourceGroup = "bnlwe-da01-p-56728-rg"
                $automationSubscriptionId = "e2b0e829-5210-40ae-b73f-20805aa01351"
                $automationKeyVaultName = "bnlwe-da01-p-56728-kv-01"
            }
            else {
                $automationAccount = "bnlwe-da04-d-56731-auto-01"
                $automationAccountResourceGroup = "bnlwe-da04-d-56731-rg"
                $automationSubscriptionId = "105fbd8d-388f-4b19-9fda-d56f44121122"
                $automationKeyVaultName = "bnlwe-da04-d-56731-kv-01"
            }
        }
    }
    # The landscape environment that host shared services
    $landscapeParameterFile = "parameters.da{0}.{1}.{2}.json" -f $subscriptionNumber, $projectEnvironment, $landscapeItsg
    if (-not $storageAccountName) {
        $storageAccountName = "{0}stunileverda{1}{2}" -f $namePrefix, $subscriptionNumber, $landscapeItsg
    }

    $arg = @{
        TenantId                      = $tenantId
        SubscriptionId                = $subscriptionId
        SubscriptionNumber            = $subscriptionNumber
        LandscapeAdfResourceGroupName = $landscapeADFResourceGroupName
        LandscapeAdfName              = $landscapeAdfName
        LandscapeProjectNumber        = $landscapeItsg
        ProjectNumber                 = $projectNumber
        ProjectEnvironment            = $projectEnvironment
        LandscapeResourceGroupName    = "{0}-da{1}-{2}-{3}-rg" -f $namePrefix, $subscriptionNumber, $projectEnvironment, $landscapeItsg
        LandscapeStorageAccountName   = $storageAccountName
        LandscapeParameterFile        = $landscapeParameterFile
        KeyVaultName                  = "{0}-da{1}-{2}-{3}-kv-01" -f $namePrefix, $subscriptionNumber, $projectEnvironment, $landscapeItsg
        CostCentre                    = "A956001690"
        Icc                           = "ICC13333"
        Environment                   = $environment
        Platform                      = "Core Data Ecosystem"
        ServiceName                   = "EcoMaster"
        DevSubscriptionId             = $devSubscriptionId
        NamePrefix                    = $namePrefix
        Location                      = $location
        AutomationAccount             = $automationAccount
        AutomationResourceGroupName   = $automationAccountResourceGroup
        AutomationSubscriptionId      = $automationSubscriptionId
        AutomationKeyVaultName        = $automationKeyVaultName
    }
    if ($boot) {
        $arg.DefaultProfile = $boot.DefaultProfile
    } elseif ($ctx) {
        $arg.DefaultProfile = $ctx
    }
    if ($subscriptionNumberDev){
        $arg.SubscriptionNumberDev = $subscriptionNumberDev
    }
    return $arg
}

function global:Get-RequestAuthentication {
    param
    (
        # Request parameters passed from the client ADF.
        [object]
        $parameters,

        # The production ITSG number to create the parameter file
        [string]
        $runId
    )
    
    if ($parameters)
    {    
        $run = Get-AzDataFactoryV2PipelineRun -ResourceGroupName $parameters.parameters.dataFactoryResourceGroupName.value `
            -DataFactoryName $parameters.parameters.dataFactoryName.value -PipelineRunId $runId -ErrorAction SilentlyContinue
        if ($run) {
            return $true
        } else {
            return $false
        }
        
    } else {
        return $false
    }
}

function global:Get-WebhookData {
    param
    (
        # Pay load passed from the client ADF.
        [object]
        $WebhookData
    )
    # You must call Login-AzCore before calling this.
    # Extract the data passed to a runbook from ADF.  We assume this is via a web hook called from a standard
    # ADF web task where the request body is populated by an ADF expression.
    # The expression must include the data factory name and runId like this: @concat(pipeline().DataFactory,',',pipeline().RunId)
    # An optional 3rd item can be passed to control which override parameter file is used
    if ($WebhookData)
    {
        $typ = $WebhookData.GetType()
        if ($typ.Name -eq "String") {
            $WebhookData = ConvertFrom-Json $WebhookData
        }
        # We support two formats here: legacy and current.  The current was introduced so that we can pass JSON objects which doesn't work
        # with the legacy CSV approach   
        if ($WebhookData.RequestBody.GetType().Name -eq "String" -and $WebhookData.RequestBody.Contains("csv")) {
            $WebhookData.RequestBody = ConvertFrom-Json $WebhookData.RequestBody
        }
        if ($WebhookData.RequestBody.csv) {
            # this is the new approach.  the exisitng csv is passed in a child property called csv
            $hookTokens = $WebhookData.RequestBody.csv.Split(",")
            if ($WebhookData.RequestBody.object) {
                $hookTokens += ConvertTo-Json -InputObject $WebhookData.RequestBody.object -Depth 10
            }
        } else {
            $hookTokens = $WebhookData.RequestBody.Split(",")
        }
        $result = @{
            dataFactoryName=$hookTokens[0]; # actually this doesn't have to be a data factory
            runId=$hookTokens[1];
            overrideFile="";
            parameterFile="";
            itsg="";
            landscapeItsg="";
            resourceGroupName="";
            landscapeStorageAccountName="";
            landscapeResourceGroupName="";
            runAsConnectionName="AzureRunAsConnection";
        }
        # workout the RunAs credential name.  This must be installed in the automation account
        if ($result.dataFactoryName){
            $dataFactoryTokens = $result.dataFactoryName.Split("-")
            if ($dataFactoryTokens -and $dataFactoryTokens.count -ge 2) {
                $result.runAsConnectionName = "svc-b-{0}-ina-automation" -f $dataFactoryTokens[1] 
            } else { 
                throw "Get-WebhookData: Unable to determine the subscription run as connection using component $($result.dataFactoryName)."
            }
        }
        # Provide support for custom tokens passed from the caller.  These must be passed as extra columns in the single csv row
        $i = 4
        $arg = 0
        while ($i -lt $hookTokens.Count) {
            $result["arg$arg"] = $hookTokens[$i]
            $arg++
            $i++
        }

        $tokens = $result.dataFactoryName.Split("-")
        if ($tokens.count -lt 4) {
            Write-Warning "The named datafactory '$($result.dataFactoryName)' didn't not follow supported naming."
            return
        }
        $platform = $tokens[1]
        $platformG = $platform.SubString(0,2)
        
        $itsg = $tokens[3]
        $environment = $tokens[2]

        
        if ($hookTokens.Count -gt 2 -and $hookTokens[2] -eq "" ) {
            # Here we don't want to use an override file
            $result["overrideFile"]=""
        } elseif ($hookTokens.Count -gt 2 -and $hookTokens[2].length -gt 0 ) {
            # Here we want to use the specified override file
            $result["overrideFile"]=$hookTokens[2]
        }
        if ($hookTokens.Count -gt 3 -and $hookTokens[3] -ne "" ) {
            # This is the reserved ADF pipeline call back.  When this is passed the run book should trigger
            # the pipeline once it completes
            $result["callbackPipeline"]=$hookTokens[3]
        }
        $parameterFile = "parameters.{0}.{1}.json" -f $environment, $itsg
        $bootStrap = Get-BootStrap -componentName $result["dataFactoryName"]

        if ($itsg -eq $bootstrap.landscapeItsg) {
            # The request originated from a landscape ITSG so we need to get a landscape parameter file name
            $parameterFile = $bootstrap.LandscapeParameterFile
        }
        $result["parameterFile"] = $parameterFile
        $result["itsg"] = $itsg
        $result["platform"] = $platform
        $result["landscapeItsg"] = $bootStrap.LandscapeProjectNumber
        $result["resourceGroupName"] = "{0}-{1}-{2}-{3}-rg" -f $bootStrap.NamePrefix, $platform, $environment, $itsg
        $result["landscapeStorageAccountName"] = $bootstrap.LandscapeStorageAccountName
        $result["landscapeResourceGroupName"] = $bootstrap.LandscapeResourceGroupName
        $result["SubscriptionNumber"] = $bootstrap.SubscriptionNumber
        $result["NamePrefix"] = $bootstrap.NamePrefix
        $result["Location"] = $bootstrap.Location
        $result["DefaultProfile"] = $bootStrap.DefaultProfile

        return $result
    } else {
        return $null
    }
}

# Login to Az using the correct connection.  Use this when the invoking client is determining which context to use
# E.g. when called from ADF via a webhook
function global:Login-AzCore {
    param
(
    # Pay load passed from the client.  This is a json string with a body
    [object]
    $WebhookData,
    [switch]$aad
)

    $connectionName = "AzureRunAsConnection"
    if ($WebhookData) {
        $bootStrap = Get-WebhookData -webHookData $WebhookData
        $connectionName = $bootStrap.runAsConnectionName
    } else {
        $bootStrap = @{}
    }
    if ($aad) {
        $connectionName = "svc-b-da00-ina-automation-aad"
    }

    try
    {
        # Get the connection "AzureRunAsConnection "    
        $connection=Get-AutomationConnection -Name $connectionName         
        Add-AzAccount -ServicePrincipal -TenantId $connection.TenantId -ApplicationId $connection.ApplicationId -CertificateThumbprint $connection.CertificateThumbprint | Out-Null
        $ctx = Get-AzContext
        if ($ctx) {
            $bootStrap["subscriptionName"] = $ctx.subscription.Name
        }
        if ($aad) {
            # Also connect to AD
            Connect-AzureAD -TenantId $connection.TenantId -ApplicationId $connection.ApplicationId -CertificateThumbprint $connection.CertificateThumbprint | Out-Null
        }
        # return the bootstrap
        Write-Output $bootStrap
    }
    catch {
        if (!$connection)
        {
            $ErrorMessage = "Connection $connectionName not found."
            throw $ErrorMessage
        } else{
            Write-Error -Message $_.Exception
            throw $_.Exception
        }
    }
}

function global:Get-Parameters {
    param
    (
        # The hash table return by Login-AzCore
        [hashtable]$bootstrap,
        [switch]$anonymous # Pass this if you don't want to authenticate against an ADF pipeline runId
    )

    function Copy-Property{
        param($InputObject,
            $SourceObject,
            [string[]]$Property,
            [switch]$Passthru)
        
            $passthruHash=@{Passthru=$passthru.IsPresent}
            
            $propHash=@{}
            $property | Foreach-Object {
                            $propHash+=@{$_=$SourceObject.$_}
                        }
            $inputObject | Add-Member -NotePropertyMembers $propHash @passthruHash
    }
    
    $containerName = "parameterfiles"
    $storageAccount = Get-AzStorageAccount -ResourceGroupName $bootstrap.landscapeResourceGroupName -Name $bootstrap.landscapeStorageAccountName -DefaultProfile $bootstrap.DefaultProfile
    if(Get-AzStorageContainer -Name $containerName -Context $storageAccount.Context -ErrorAction SilentlyContinue)
    {
        $tmp = New-TemporaryFile
        Get-AzStorageBlobContent -Container $containerName -Blob $bootstrap.parameterFile -Destination $tmp -Context $storageAccount.Context -Force | Out-Null
        $parameters = Get-Content -Path $tmp -Raw | ConvertFrom-JSON

        if ($bootstrap.overrideFile -ne "") {
            Get-AzStorageBlobContent -Container $containerName -Blob $bootstrap.overrideFile -Destination $tmp -Context $storageAccount.Context -Force
            $overrideParameters = Get-Content -Path $tmp -Raw | ConvertFrom-JSON

            $properties = $overrideParameters.parameters | Get-Member -MemberType Properties | Select-Object
            ForEach($property in $properties) {
                $parameters.parameters.psobject.properties.remove($property.Name)
                Copy-Property -InputObject $parameters.parameters -Property $property.Name -SourceObject $overrideParameters.parameters
            }
        }
        if (-not $anonymous -and -not (Get-RequestAuthentication -parameters $parameters -runId $bootstrap.runId)) {
            $message = @"
Authentication failed.  You are not authorised to make this request!
    ResourceGroup: {0}
    DataFactory: {1}
    RunId: {2}
"@
            $message = $message -f $parameters.parameters.dataFactoryResourceGroupName.value, $parameters.parameters.dataFactoryName.value, $bootStrap.runId
            throw $message
        }
        return $parameters
    } else {
        $message= "Unable to see landscapes parameter file repository in storage account $storageAccountName using connection $($bootStrap.runAsConnectionName)"
        Write-Error $message
        throw $message
    }
}

function global:Get-WebhookDataSample {
    param([string]$subscriptionNumber, [string]$componentName)

    # use this to mimic invoking a runbook via a webhook
    # pass either a component name or subscriptionnumer & environment e.g. 04, d

    if ($componentName) {
        if ($componentName.Split("-").Count -lt 4) {
            # The component isn't named properly
            return $null
        }
        $webhookData = @"
        {{"WebhookName":"WebHook-Dummy","RequestBody":"{0},c75751e2-74e7-489d-8679-35c63938f4d4,","RequestHeader":{{"Connection":"Keep-Alive","Expect":"100-continue","Host":"s2events.azure-automation.net","x-ms-request-id":"19389eb0-7622-4be8-ad14-fb5e9dbdaf67"}}}}
"@
        Write-output ($webhookData -f $componentName)
    } else {
        $subscription = Get-SubscriptionBootstrap -subscriptionNumber $subscriptionNumber
        $webhookData = @"
        {{"WebhookName":"WebHook-Dummy","RequestBody":"{2}-da{0}-{1}-{3}-adf-01,c75751e2-74e7-489d-8679-35c63938f4d4,","RequestHeader":{{"Connection":"Keep-Alive","Expect":"100-continue","Host":"s2events.azure-automation.net","x-ms-request-id":"19389eb0-7622-4be8-ad14-fb5e9dbdaf67"}}}}
"@
        $namePrefix = Get-NamePrefix -region $subscription["Region"]
        Write-output ($webhookData -f $subscriptionNumber, $subscription["ProjectEnvironment"], $namePrefix, $subscription["ProjectNumber"])
    }
}

# Write a log file back to a project's storage account
function global:Set-LogFileContent {
    param(
    [PSCustomObject]$parameters,
    [array]$stream,
    [string]$fileName,
    [switch]$landscape,
    [hashtable]$bootstrap, 
    [string]$containerName,
    [int]$purgeThresholdDays
)
    $resourceGroupName = $parameters.parameters.dataFactoryResourceGroupName.value
    $storageAccountName = $parameters.parameters.storageAccountName.value
    if ($bootstrap -and $bootstrap.DefaultProfile) {
        $ctx = $bootstrap.DefaultProfile
    }
    else {
        $ctx = Get-AzContext
    }
    if ($landscape) {
        $resourceGroupName = $parameters.parameters.landscapeResourceGroupName.value
        $storageAccountName = $parameters.parameters.landscapeStorageAccountName.value
    }
    if (-not $containerName) {
        $containerName = $parameters.parameters.dataFactoryName.value
    }
    $filePath = New-TemporaryFile

    foreach($str in $stream) {
        $str | Out-File -FilePath $filePath -Append
    }

    $accountKeys = Get-AzStorageAccountKey -ResourceGroupName $resourceGroupName -Name $storageAccountName -DefaultProfile $ctx -ErrorAction SilentlyContinue
    if (-not $accountKeys) {
        # Assume storage account doesn't exist
        Write-Warning "Cannot write a log file to $resourceGroupName $storageAccountName because the storage account was not found."
        return
    }
    $storageContext = New-AzStorageContext -StorageAccountName $storageAccountName -StorageAccountKey $accountKeys[0].Value 

    if(-not(Get-AzStorageContainer -Name $containerName -Context $storageContext -ErrorAction SilentlyContinue)) 
    {
        New-AzStorageContainer -Name $containerName -Context $storageContext
        Start-Sleep -Seconds 5
    }
    $args = @{
        File=$filePath;
        Container=$containerName;
        Blob=$fileName;
        Context=$storageContext;
        Force=$true
    }
    Set-AzStorageBlobContent @args -outvariable $out

    if ($purgeThresholdDays -gt 0) {
        # clean old files from the container
        $threshold = (Get-Date).AddDays($purgeThresholdDays*-1)
        foreach($blob in Get-AzStorageBlob -Container $containerName -Context $storageContext) 
        {
            if($blob.LastModified -lt $threshold) {
                $blob | Remove-AzStorageBlob -Force
            }
        }
    }
}

function global:New-Password {
    param
( 
    [int] $numchars = 22,
    [string] $chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#"
)
    do {
        $bytes = new-object "System.Byte[]" $numchars
        $rnd = new-object System.Security.Cryptography.RNGCryptoServiceProvider
        $rnd.GetBytes($bytes)
        $result = ""
        $repeat = $false
        for ( $i = 0; $i -lt $numchars; $i++ ) {
            $result += $chars[ $bytes[$i] % $chars.Length ]   
        }
        if (-Not $result.Contains("@") -or -Not $result.Contains("#")) {
            $repeat = $true;
        }
            if (-Not ($result -match "[0-9]")) {
            $repeat = $true;
        }
    } while ($repeat)
    return $result
}

function global:Invoke-AdfPipeline {
param
(
    # The parameter file json object
    [object]
    $parameters,
    [hashtable]$bootStrap
)
    if (-not $parameters) {
        throw "Invoke-AdfV2Pipeline failed.  The passed parameter file object was null."
    }
    if (-not $bootStrap) {
        throw "Invoke-AdfV2Pipeline failed.  The passed webhookData parameter was null."
    }
    try {
        $resourceGroupName = $parameters.parameters.dataFactoryResourceGroupName.value
        $dataFactoryName = $parameters.parameters.dataFactoryName.value
        $pipelineName = $bootStrap["callbackPipeline"]
        if ([string]::IsNullOrEmpty($pipelineName)) {
            throw "Invoke-AdfV2Pipeline failed.  The passed webhookData csv string didn't contain a callback name in the 4th column."
        }
        $args = @{
            resourceGroupName=$resourceGroupName
            dataFactoryName=$dataFactoryName
            pipelineName=$pipelineName
        }
        if ($bootStrap["callbackParameters"]) {
            $args["parameter"] = $bootStrap["callbackParameters"]
        }
        # Get data factory object
        $df=Get-AzDataFactoryV2 -ResourceGroupName $resourceGroupName -Name $dataFactoryName
    
        #If exists - run it
        If($df) {
                Write-Output "Connected to data factory $dataFactoryName on $resourceGroupName"
                Write-Output "Running callback pipeline: $pipelineName"
    
                $RunID = Invoke-AzDataFactoryV2Pipeline @args
                $RunInfo = Get-AzDataFactoryV2PipelineRun -ResourceGroupName $resourceGroupName -DataFactoryName $dataFactoryName -PipelineRunId $RunID
    
                Write-Output "`nCallback pipeline was triggered!"
                Write-Output "RunID: $($RunInfo.RunId)"
                Write-Output "Started: $($RunInfo.RunStart)`n"
        }
    }
    Catch{
        Throw
    }
}

function global:Set-SSASWhiteList {
Param
(
    [PSCustomObject]$parameters,
    [string]$ruleName="automation",
    [switch]$deleteRule
)

    try {
        $subscriptionId = $parameters.parameters.subscriptionId.value

        $ipAddressStart = Invoke-RestMethod http://ipinfo.io/json | Select -exp ip
        $ipAddressEnd = $ipAddressStart
        $ruleUpdated = $false
        
        $server = Get-AzAnalysisServicesServer -ResourceGroupName $parameters.parameters.analysisServicesResourceGroupName.value -Name $parameters.parameters.analysisServicesName.value
        if ($server.state -eq "Paused"){
            throw "Add your IP address to AAS failed because AAS $($parameters.parameters.analysisServicesName.value) was in the paused state."
        }
        
        if ($server -and $server.FirewallConfig)
        {
            foreach($rule in $server.FirewallConfig.FirewallRules){
                if ($rule.FirewallRuleName -eq $ruleName) {
                    if ($deleteRule) {
                        $ruleToDelete = $rule
                    } else {
                        Write-Output "Updating existing firewall rule $ruleNAme in AAS $($parameters.parameters.analysisServicesName.value)."
                        $rule.RangeEnd = $ipAddressEnd
                        $rule.RangeStart = $ipAddressStart
                        $ruleUpdated = $true
                        break
                    }
                }
            }
        } elseif ($server -and -not $server.FirewallConfig) {
            Write-Warning "The firewall for $($parameters.parameters.analysisServicesName.value) is disabled."
            return
        }
        else {
            Throw "Add your IP address to AAS failed because AAS $($parameters.parameters.analysisServicesName.value) was not found.  Please create AAS and try again."
        }
        if ($deleteRule -and $ruleToDelete) {
            Write-Output "The specified firewall rule to delete '$ruleNAme' was removed from the whitelist for AAS $($parameters.parameters.analysisServicesName.value)."
            $server.FirewallConfig.FirewallRules.Remove($ruleToDelete)
        }
        elseif ($deleteRule -and -not $ruleToDelete) {
            Write-Warning "The specified firewall rule to delete '$ruleNAme' was not found in the whitelist for AAS $($parameters.parameters.analysisServicesName.value)."
        } elseif (-not $ruleUpdated) {
            # Existing rule wasn't updated so add it
            Write-Output "White-listing your IP $ipAddressStart : $ipAddressEnd in AAS $($parameters.parameters.analysisServicesName.value) as rule name '$ruleNAme'"
            $rule = New-AzAnalysisServicesFirewallRule -FirewallRuleName $ruleName -RangeStart $ipAddressStart -RangeEnd $ipAddressEnd
            $server.FirewallConfig.FirewallRules.Add($rule)
        }
        
        Set-AzAnalysisServicesServer -Name $parameters.parameters.analysisServicesName.value -ResourceGroupName $parameters.parameters.analysisServicesResourceGroupName.value `
            -FirewallConfig $server.FirewallConfig
    }
    catch {
        throw
    }
}
function global:Get-NamePrefix {
    param($region)

    $regions = @{
        "westeurope"="bnlwe"
        "northeurope"="bieno"
    }
    if ($region) {
        return $regions[$region]
    }
}
function global:Set-Delay	{
	param (
	    [Parameter(Mandatory=$true)][string]$command, 
	    [Parameter(Mandatory=$true)][hashtable]$args, 
	    [Parameter(Mandatory=$false)][int]$retries = 5, 
	    [Parameter(Mandatory=$false)][int]$secondsDelay = 2
	    )
	
	# Setting ErrorAction to Stop is important. This ensures any errors that occur in the command are 
	# treated as terminating errors, and will be caught by the catch block.
	$args.ErrorAction = "Stop"
	
	$retrycount = 0
	$completed = $false
	
	while (-not $completed) {
	    try {
	        & $command @args
	        Write-Verbose ("Command [{0}] succeeded." -f $command)
	        $completed = $true
	        } catch {
	            if ($retrycount -ge $retries) {
	                Write-Verbose ("Command [{0}] failed the maximum number of {1} times." -f $command, $retrycount)
	            throw
	            } else {
	                Write-Verbose ("Command [{0}] failed. Retrying in {1} seconds." -f $command, $secondsDelay)
	                Start-Sleep $secondsDelay
	                $retrycount++
	            }
	        }
	    }
    }

function global:Get-Geobackup {
    param (
        [string]$resourceGroupName,
        [string]$serverName,
        [string]$databaseName,
        [Microsoft.Azure.Commands.Profile.Models.Core.PSAzureContext]$defaultProfile
    )
    
    $geoBackup = Get-AzSqlDatabaseGeoBackup -ResourceGroupName $resourceGroupName `
                                -ServerName $serverName `
                                -DatabaseName $databaseName `
                                -DefaultProfile $defaultProfile

    return $geoBackUp
}

function global:New-SQLServer {
    param (
        [hashtable]$bootstrap,
        [string]$resourceGroupName,
        [string]$location,
        [string]$serverName,
        [string]$databaseName,
        [switch]$landscape
    )

    if($landscape) {
        $resourceGroupName = $bootstrap.LandscapeResourceGroupName
        $location = $bootstrap.Location
        $serverName =  ((($resourceGroupName).split("-",5) | Select-Object -Index 0,1,2,3) -join "-"), "unilevercom-restore-01" -join "-"
       
    }

    $password = New-Password
    $credPassword = ConvertTo-SecureString $password -AsPlainText -Force
    $sqlAdminCred = New-Object System.Management.Automation.PSCredential ("sqlgeoadmin", $credPassword)

    $sqlServer = Get-AzSqlServer -ResourceGroupName $resourceGroupName `
        -ServerName $serverName `
        -DefaultProfile $bootstrap.DefaultProfile `
        -ErrorAction SilentlyContinue
    
    if(-not($sqlServer)) 
            {
            $sqlServer = New-AzSqlServer -ResourceGroupName $resourceGroupName `
                                 -Location $location `
                                 -ServerName $serverName `
                                 -SqlAdministratorCredentials $sqlAdminCred 
                
            Write-Host "Sql Server $($sqlServer.ServerName) created"
            return $sqlServer
            }
    else {
            Write-Host "Sql Server $($sqlServer.ServerName) already exists" 
    }    

     return $sqlServer
}

function global:New-SqlRestorePoint {
    param (
        [string]$resourceGroupName,
        [string]$serverName,
        [string]$databaseName,
        [Microsoft.Azure.Commands.Profile.Models.Core.PSAzureContext]$defaultProfile
    )

    $RestorePointLabel = (New-Guid).Guid
    $restorePoint = New-AzSqlDatabaseRestorePoint -ResourceGroupName $resourceGroupName -ServerName $serverName -DatabaseName $databaseName -RestorePointLabel $RestorePointLabel -DefaultProfile $defaultProfile

    return $restorePoint
}

function global:Restore-SQLGeoBackUp {
    param (
        [hashtable]$bootstrap,
        [Microsoft.Azure.Commands.Sql.Backup.Model.AzureSqlDatabaseGeoBackupModel]$geoBackup,
        [string]$location,
        [switch]$landscape
    )

    if($landscape) {
        $resourceGroupName = $bootstrap.LandscapeResourceGroupName
        $location = $bootstrap.Location
        $serverName =  ((($resourceGroupName).split("-",5) | Select-Object -Index 0,1,2,3) -join "-"), "unilevercom-restore-01" -join "-"
       
    }
   
    $targetSqlName = ($geoBackup.DatabaseName),"geo", ($geoBackup.LastAvailableBackupDate.ToString("yyyyMMddHHmmss")) -join "-"
    $restoredSql = Restore-AzSqlDatabase -FromGeoBackup -ResourceGroupName $resourceGroupName -ServerName $serverName -TargetDatabaseName $targetSqlName -ResourceId $GeoBackup.ResourceID -DefaultProfile $sCtx

    Write-Host "Database $($targetSqlName) restored to Server $($serverName)"

    return $restoredSql
}

function global:Move-Resource {
    param (
        [string]$targetResourceGroupName,
        [string]$resourceId,
        [Microsoft.Azure.Commands.Profile.Models.Core.PSAzureContext]$ctx
    )

    Move-AzResource -DestinationResourceGroupName $targetResourceGroupName -ResourceId $resourceId -DefaultProfile $ctx -Force

}
    
function global:Get-AquireTokenSPN {
    param (
        [string]$resourceUri,
        [Microsoft.IdentityModel.Clients.ActiveDirectory.ClientAssertionCertificate]$clientCert
    )

    $oAuthUri = "https://login.microsoftonline.com/f66fae02-5d36-495b-bfe0-78a6ff9f8e6e/oauth2/token"
    $authContext = [Microsoft.IdentityModel.Clients.ActiveDirectory.AuthenticationContext]::new($oAuthURI)
    $token = ($authContext.AcquireTokenAsync($resourceUri, $clientCert)).Result.AccessToken
    return $token

} 

