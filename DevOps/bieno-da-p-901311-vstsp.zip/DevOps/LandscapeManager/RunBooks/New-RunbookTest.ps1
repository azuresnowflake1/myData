
#Clear-AzContext
# # You can use this to execute run books from VS Code
 $WebhookData = '{"WebhookName":"WebHook-SSASResume","RequestBody":"bieno-da12-p-80234-adf-01,6caa6f0c-8ddc-4258-87f7-cdf7e74c5f1c,","RequestHeader":{"Expect":"100-continue","Host":"s9events.azure-automation.net","x-ms-request-id":"41bd6cde-1d4b-4a67-8316-350004838d09"}}'
# # Import the automation account environment
.\Import-PlatformAutomationClientCore.ps1
# .\Import-PlatformAADCore.ps1
.\Import-PlatformDataCore.ps1
.\Import-PlatformCore.ps1
# $adbName = "bnlwe-da02-u-80233-adb-01"

# $bootStrap = Login-AzCore -WebHookData $WebhookData -aad
# $prod2Ctx = Set-AzContext -SubscriptionId "204671af-5130-4ef5-819c-e314b65f9d06"
# #$subscriptionBootstrap = Get-SubscriptionBootstrap -subscriptionNumber "Prod2"
# $bootStrap.DefaultProfile = $prod2Ctx
# Set-SubscriptionMetaData -subscriptionBootstrap $bootStrap -dataResourceGroup

#Merge-ResourceGroups
$subscriptions= Get-Subscriptions -all -includeOldFoundation -includeMSEnterprise
foreach ($sub in $subscriptions.Values) {
    if($sub.SubscriptionNumber -eq 'Microsoft Azure Enterprise'){
    $subscriptionBootstrap = Get-SubscriptionBootstrap -subscriptionNumber $sub.SubscriptionNumber
    Set-SubscriptionMetaData -subscriptionBootstrap $subscriptionBootstrap -dataSubscription -dataResourceGroup -dataResource -dataRbac -dataDatabricks 
    }
}

# $subscriptionBootstrap = Get-SubscriptionBootstrap -subscriptionNumber "Microsoft Azure Enterprise"
# Set-SubscriptionMetaData -subscriptionBootstrap $subscriptionBootstrap -dataSubscription
# $tokenSecretName = "DatabricksAccessToken"
# $parameters = Get-Parameters -bootstrap $bootstrap -anonymous
# # if (-not $aadGroupMembers) {
# #     $aadGroupMembers = Get-AzAdGroupMember -GroupDisplayName "SEC-ES-DA-d-80167-azure-devops"
# # }

# if (-not $landscapeMembers) {
#     $landscapeMembers = Get-AzAdGroupMember -GroupDisplayName "SEC-ES-DA-p-56728-azure-landscape"
# }
# $workspace = $null
# if (-not $workspace) {
#     $workspace = Get-AzResource -ResourceType Microsoft.Databricks/workspaces -name $adbName -DefaultProfile $Global:CtxBootStrap.DefaultProfile
#     #$workspace = Get-AzResource -ResourceType Microsoft.Databricks/workspaces -DefaultProfile $bootStrap.DefaultProfile
# }
# #$x=Set-ArrayPartitions -inputArray $workspace -numberOfPartitions 4
# if (-not $path) {
#     $path = Get-BlobContentFinal -mergedFileName "AdbPermissions.csv" -sourceFolder ""
#     $metaData = Import-csv -Path $path 
# }

#Set-AdbWorkspaceUsers -parameters $parameters -bootStrap $bootStrap -aadMembers $aadGroupMembers -landscapeMembers $landscapeMembers -tokenSecretName $tokenSecretName -workspace $workspace
#New-AdbWorkspaceSync -parameters $parameters -bootStrap $bootStrap -metaData $metaData -landscapeMembers $landscapeMembers -tokenSecretName $tokenSecretName -workspace $workSpace
#$bootStrap = Get-SubscriptionBootstrap -subscriptionNumber "02"
#Set-SubscriptionMetaData -subscriptionBootstrap $bootStrap -dataSubscription

#Get-Subscriptions -All -IncludeOldFoundation

##$WebhookData = '{"WebhookName":"WebHook-SqlDwResume","RequestBody":"bieno-da12-d-56731-adf-01,b3f09b80-5511-4cc0-addf-792ad9e7c952z,","RequestHeader":{"Connection":"Keep-Alive","Expect":"100-continue","Host":"s9events.azure-automation.net","x-ms-request-id":"c4b5b00e-774f-4a90-9845-464db66ac359"}}'

# Login to azure using our turnkey SPN IANDProdSPN.  The cert must be installed on your machine for this to work


# Login using the subscription specific automation SPN defined by webhookData.  The cert must be installed on your machine for this to work
# $bootStrap = Login-AzCore -WebHookData $WebhookData
# $bootStrap
# # Now you can execute a run book
# $subscriptions = Get-Subscriptions -All
# $subscriptions