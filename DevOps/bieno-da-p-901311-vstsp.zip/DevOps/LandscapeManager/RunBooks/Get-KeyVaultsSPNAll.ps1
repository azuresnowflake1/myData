
$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"
$managerFolder = "{0}\{1}" -f $devOpsProjectFolder, "LandscapeManager"

& "$managerFolder\Runbooks\Import-PlatformCore.ps1"

$subscriptions = Get-Subscriptions -All

foreach ($key in $subscriptions.keys) {
    # make up a dummy component so we can bootstrap a subscription
    if ($key -ne "12") { continue }
    $webhookData = Get-WebhookDataSample -subscriptionNumber $key

    $bootStrap = Get-Bootstrap -componentName "bieno-da12-d-56731-adf-01"
    & "$managerFolder\Runbooks\Get-KeyVaultsSPN.ps1"  -bootstrap $bootstrap
    
}