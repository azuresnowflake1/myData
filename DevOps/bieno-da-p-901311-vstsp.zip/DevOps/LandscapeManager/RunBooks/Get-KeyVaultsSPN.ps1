param(
    [hashtable]$subscriptionBootstrap # From platform core Get-SubscriptionBootstrap
)

if (-not $subscriptionBootstrap) {
    throw "Set-SubscriptionMetaData failed because the value passed for subscriptionBootstrap was null."
}


$bootStrap = Get-Bootstrap -subscriptionNumber $subscriptionBootstrap.SubscriptionNumber 

#Write-Output $subscriptionBootstrap.defaultProfile.Subscription.Name

#Get-AzResourceGroup -ResourceGroupName $bootStrap.LandscapeResourceGroupName
$isError=$false
$outputStream =[System.Collections.ArrayList]@()
$fileName = "KeyVaultSecretAutoRenew_{1}_{0}.log" -f (get-date -Format s), $subscriptionBootstrap.SubscriptionNumber
try {
           
    $landscapeResourceGroup = $bootstrap.landscapeResourceGroupName
    $expiryDateCheck = ((Get-Date).AddMonths(1))
    
    $landscapeITSGs = "56728", "56730", "56731",  "56732"            
    
    $projectKeyVaults = Get-AzKeyVault -ResourceGroupName $bootstrap.landscapeResourceGroupName -DefaultProfile $subscriptionBootstrap.defaultProfile
  
    $outputStream.Add(("Log file {0} written to {1}." -f $fileName, $bootstrap.LandscapeStorageAccountName)) | Out-Null
    $outputStream.Add("Landscape Resource Group $landscapeResourceGroup") | Out-Null
    $outputStream.Add("Credential Expiries before $expiryDateCheck") | Out-Null

    foreach($projectKeyVault in $projectKeyVaults)
    {   
        
        $split = ($projectKeyVault.VaultName).split("-") 
        $itsg = $split[3]
        $platform = $split[1]
        $environment = $split[2]
        $projectKeyVault.VaultName
        if($landscapeITSGs.Contains($itsg))
        {
            #do not refresh certificates for Landscape ITSG
            #Write-Output "Skipped Landscape Key Vault:- $($projectKeyVault.VaultName)"
            $outputStream.Add("Skipped Landscape Key Vault:- $($projectKeyVault.VaultName)") | Out-Null
            continue
        }else {
            $outputStream.Add("Processing Key Vault:- $($projectKeyVault.VaultName)") | Out-Null
        }

        $secretName = "svc-b-da-{0}-{1}-ina-aadprincipal" -f $environment,$itsg 
        $secretDetail = Get-AzKeyVaultSecret -VaultName $projectKeyVault.VaultName -Name $secretName -DefaultProfile $subscriptionBootstrap.defaultProfile

        
        $outputStream.Add("Checking $($projectKeyVault.VaultName) - Secret Name - $($secretName) - Secret Expiry $($secretDetail.Expires)") | Out-Null
        if($secretDetail.Expires) {
            if($secretDetail.Expires -le $expiryDateCheck){
                $outputStream.Add("Secret Expired $($projectKeyVault.VaultName) - Updating SPN Credential") | Out-Null
                
                #[object]$WebhookDataSpn = '{"WebhookName":"WebHook-SPNRenew","RequestBody":"bieno-'+$($platform)+'-'+$($environment)+'-'+$($itsg)+'-adf-01"}'
                $webhookDataSpn = Get-WebHookDataSample -componentname $projectKeyVault.VaultName
                #Write-Output "Web Hook Call : - $($WebhookDataSpn)"
                try {
                    $region = Get-AutomationVariable -Name 'newFoundationRegion' -ErrorAction Stop
                    # if the variable was defined then assume this is running in an automation account
                    .\Set-SPNCredentialRenewal.ps1 -webHookData $WebhookDataSpn 
             } catch {
                 # The variable wasn't defined so assume it's running locally.
                 $folder = (Get-Item -Path $PSScriptRoot).FullName
                 & "$folder\Set-SPNCredentialRenewal.ps1" -webHookData $WebhookDataSpn
             }
               
                $outputStream.Add("Credentials $($secretName) Updated") | Out-Null
            }
        }
        else {
            $outputStream.Add("Secret $($secretName) doesn't exist in $($projectKeyVault.VaultName) or automation account has insufficent access") | Out-Null
        }
    }
}
catch {
    $isError=$true
    $outputStream.Add($_) | Out-Null
}
finally {
    # Write log file to storage account
    $bootstrap["parameterFile"] = $bootstrap.LandscapeParameterFile
    $bootstrap["overrideFile"] = ""
    $parameters = Get-Parameters -bootstrap $bootstrap -anonymous 
     Set-LogfileContent -parameters $parameters -stream $outputStream -fileName $fileName -landscape -bootstrap $bootstrap
    
    if ($isError) {
        foreach($s in $outputStream)
        {
            if (($s.GetType().Name) -eq "Hashtable") {
                $s = $s | Out-String
            }
            Write-Error $s
        }
        throw "An unexpected error was detected"
    } else {
        $outputStream | Write-Output
    }
}
