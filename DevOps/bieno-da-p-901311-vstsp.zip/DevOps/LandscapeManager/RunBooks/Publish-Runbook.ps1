
Param
(
    [Parameter(Mandatory = $true, HelpMessage = "Runbooks for publishing")]
    [string]$runbooksToPublish,
    [Parameter(Mandatory = $true, HelpMessage = "Target Subscriptions")]
    [string]$targetSubscriptionNumbers,
    [Parameter(Mandatory = $false, HelpMessage = "Pass this if you want to publish only")]
    [switch]$publishonly
)
$managerFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
<#
Publish Core runbooks from source automation account CDE12 and publish to 3 other automation accounts
This will overwrite target subscriptions with whatever is inside CDE-12
.\Publish-Runbook.ps1 -runbooksToPublish "Import-PlatformCore" -targetSubscriptionNumbers "09,04,01"
#>

$x = (Get-ChildItem function:) | Where-Object { $_.name -eq "Get-Bootstrap" }
if (-not $x) {
    & "$managerFolder\Runbooks\Import-PlatformCore.ps1"
}

$OutputFolder = "C:\temp\Runbooks"
$sourceSubscriptionNumber = 12

$bootStrap = Get-Bootstrap -subscriptionNumber $sourceSubscriptionNumber 
$sourceAutomationAccount = $bootstrap.AutomationAccount
$sourceAutomationAccountResourceGroup = $bootstrap.AutomationResourceGroupName
[string[]]$runBooks = $runBooksToPublish.Split(',') 

if (-not $publishonly) {

    foreach ($runBookName in $runBooks) {
 
        Write-Host "Exporting RunBook $($runBookName) from Automation Account $($sourceAutomationAccount)"
        $publishRunbook = Get-AzAutomationRunbook -AutomationAccountName $bootstrap.AutomationAccount -ResourceGroupName $sourceAutomationAccountResourceGroup -Name $runBookName -DefaultProfile $bootStrap.DefaultProfile
        $publishRunbook | Export-AzAutomationRunbook -outputFolder $OutputFolder -DefaultProfile $bootStrap.DefaultProfile -Force
    }
}

[string[]]$targetSubscriptionNums = $targetSubscriptionNumbers.Split(',')

foreach ($targetSubscriptionNumber in $targetSubscriptionNums)
{

    $tbootStrap = Get-Bootstrap -subscriptionNumber $targetSubscriptionNumber
    $targetAutomationAccount = $tbootstrap.AutomationAccount
    $targetAutomationAccountResourceGroup = $tbootstrap.AutomationResourceGroupName

    foreach ($runBookName in $runBooks) {
        
        $path = $OutputFolder + "\" + $runBookName + ".ps1"
        Write-Host "Importing RunBook $($runBookName) into Automation Account $($targetAutomationAccount)"
        Import-AzAutomationRunbook -Name $runBookName `
        -Path $path  `
        -ResourceGroupName $targetAutomationAccountResourceGroup `
        -AutomationAccountName $targetAutomationAccount `
        -Type PowerShell `
        -DefaultProfile $tbootstrap.DefaultProfile `
        -Force

        Publish-AzAutomationRunbook -Name $runBookName `
        -ResourceGroupName $targetAutomationAccountResourceGroup `
        -AutomationAccountName $targetAutomationAccount `
        -DefaultProfile $tbootstrap.DefaultProfile 
        }
}

