try {
    $subscription = Get-Subscriptions -all
}
catch {
    Write-Host "Login to Azure"
    $subscription = Login-AzAccount -ErrorAction SilentlyContinue
    if (!$subscription) {
        Write-Error "You will need to Login to Azure to complete this script."
        throw
    }
    else {
        $subscription = Get-Subscriptions -all
    }    
}
if ($subscription.Count -eq 0) {
    Write-Error "You will need a Azure Subscription to run this script."
    return
}
if ($subscription.Count -eq 1) {
    return $subscription[0]
}
if ($subscription.Count -gt 1) {
    $subCount = $subscription.Count
    Write-Host "Select the Azure Subscription to use"
    foreach($key in $subscription.Keys.GetEnumerator()  | Sort-Object) {
        Write-Host "$key - $($subscription[$key].EnvironmentUsage) $($subscription[$key].Region) ($($subscription[$key].DefaultProfile.Account))"
    }
    do {
        $selectedItem = [int](Read-Host "Select Azure Subscription") 
        if ($selectedItem -le $subCount -and $selectedItem -gt 0) {
            $key = "$selectedItem".PadLeft(2,'0')
            $subscriptionId = $subscription[$key].DefaultProfile.Subscription.Id
            Write-Verbose "Subscription selected is $subscriptionId"
            return $subscription[$key].DefaultProfile
        }
        else {
            Write-Warning "Selection must be from 1 to $subCount"            
        }
    }while ($selectedItem -gt $subCount -or $selectedItem -lt 0)
}
