param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$parameterFile,
   
    [Parameter(Mandatory = $True, HelpMessage='The personal access token used to authorize vsts requests')]
    [String]$personalAccessToken,

    [Parameter(Mandatory = $True, HelpMessage='The client secret for the service principal')]
    [String]$depClientSecret,

    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$resourceParameterFile,    
    
    [Parameter(Mandatory = $False, HelpMessage='Specify the parameter file')]
    [String]$servicePrincipalDefinitionFile = "service.endpoint.template.json"
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters.ps1" -parameterFile $parameterFile
$devOpsParameters = & "$utilitiesFolder\Get-Parameters.ps1" -parameterFile $resourceParameterFile

$teamProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$vstsAccountName = $parameters.parameters.vstsAccountName.value
$vstsTeamProjectName = $parameters.parameters.vstsTeamProjectName.value
$vstsSourceControlDevBranch = $parameters.parameters.vstsSourceControlDevBranch.value
Write-Verbose "The default source control branch is $vstsSourceControlDevBranch"

$patString = "{0}:{1}" -f "", $personalAccessToken
$base64PatString =  [System.Convert]::ToBase64String([System.Text.Encoding]::ASCII.GetBytes($patString))

& "$utilitiesFolder\Test-Login.ps1"

$vstsProjectARMServiceEndPointName = $parameters.parameters.vstsProjectARMServiceEndPointName.value
$subscriptionId = $devOpsParameters.parameters.subscriptionId.value

if (!$Global:CtxDeploy)
{
    Write-Error "Unable to determine the xurrent subscription.  Run Set-GlobalScope then retry"
    throw
}
$tenantId = $devOpsParameters.parameters.tenantId.value
$subscriptionName = $Global:CtxDeploy.Subscription.Name
$serviceprincipalid = $devOpsParameters.parameters.deploymentApplicationId.value

try 
{
    $vstsURL = "https://{0}.visualstudio.com/DefaultCollection/{1}/_apis/distributedtask/serviceendpoints?api-version=3.0-preview.1" -f $vstsAccountName, $vstsTeamProjectName
    $params = @{    
        ContentType = 'application/json'
        Headers = @{
            'Authorization'="Basic $base64PatString"
        }
        Method = 'Get'    
        URI = $vstsURL
    }
    Write-Verbose "Getting the service point definitions for team project $vstsTeamProjectName"
    $authZResponse =  Invoke-RestMethod @params    
    $vstsProjectARMServiceEndPoint = $authZResponse.value | Where-Object {$_.name -eq $vstsProjectARMServiceEndPointName}
    if (!$vstsProjectARMServiceEndPoint){
        $vstsURL = "https://{0}.visualstudio.com/DefaultCollection/{1}/_apis/distributedtask/serviceendpoints?api-version=3.0-preview.1" -f $vstsAccountName, $vstsTeamProjectName    
        $serviceprincipalFilePath = "{0}\Templates\{1}" -f $teamProjectFolder, $servicePrincipalDefinitionFile
        $servicePrincipalDefinition = Get-Content -Path $serviceprincipalFilePath -Raw | ConvertFrom-Json
        $servicePrincipalDefinition.name = $vstsProjectARMServiceEndPointName
        $servicePrincipalDefinition.data.subscriptionId = $subscriptionId
        $servicePrincipalDefinition.data.subscriptionName = $subscriptionName
        $servicePrincipalDefinition.authorization.parameters.serviceprincipalid = $serviceprincipalid
        $servicePrincipalDefinition.authorization.parameters.serviceprincipalkey = $depClientSecret
        $servicePrincipalDefinition.authorization.parameters.tenantid = $tenantId
        $body = $servicePrincipalDefinition | ConvertTo-JSON -Depth 10

        $params = @{    
            ContentType = 'application/json'
            Headers = @{
                'Authorization'="Basic $base64PatString"
            }
            body = $body
            Method = 'Post'    
            URI = $vstsURL
        }
        Write-Verbose "Adding the service end point for $vstsTeamProjectName"
        $authZResponse =  Invoke-RestMethod @params    
        Write-Output "The service end point $vstsProjectARMServiceEndPointName for $vstsTeamProjectName has been added"
    }else{
        Write-Output "The service end point $vstsProjectARMServiceEndPointName already exists for $vstsTeamProjectName"
    }
}
catch
{
    Write-Host "StatusCode:" $_.Exception.Response.StatusCode.value__ 
    Write-Host "StatusDescription:" $_.Exception.Response.StatusDescription
    throw
}
