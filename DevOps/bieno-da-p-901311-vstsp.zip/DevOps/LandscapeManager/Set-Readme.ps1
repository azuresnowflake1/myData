param(
	[Parameter(Mandatory=$true)][string]$gitDirectory,
	[Parameter(Mandatory=$true)][string]$parameterFile,
    [Parameter(Mandatory = $false)][string]$readmeFileName="readme.md"
	
)

# substitute application specific values into the team project readme.md file
# only call this from the dev environment
$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

$itsg = $parameters.parameters.projectNumber.value
$namePrefix = $Global:CtxBootstrap.NamePrefix
if ("dx".Contains($parameters.parameters.projectEnvironment.value)) {
	$magicItsg = "<ITSG>"
	$magicNamePrefix = "<regionPrefix>"
	$filePath = '{0}\{1}' -f $gitDirectory, $readmeFileName
	
	# Replace magic strings	
	$content = [string](get-content $filePath -Raw)
	$content = $content -replace $magicItsg, $itsg
	$content = $content -replace $magicNamePrefix, $namePrefix
	
	$content | Set-Content $filePath -Force
} else {
	Write-Warning "You cannot use this script in non dev environments.  You request was ignored!"
	return
}
