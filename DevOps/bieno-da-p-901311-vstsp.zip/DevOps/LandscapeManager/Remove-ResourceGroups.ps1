param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$parameterFile
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"
$managerFolder = "{0}\{1}" -f $devOpsProjectFolder, "LandscapeManager"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

$subscriptionId = $parameters.parameters.subscriptionId.value

$applicationResourceGroupName = $parameters.parameters.dataFactoryResourceGroupName.value
$sharedStorageAccountResourceGroupName = $parameters.parameters.sharedStorageAccountResourceGroupName.value
$kvRegName = $parameters.parameters.keyVaultResourceGroupName.value
$kvName = $parameters.parameters.keyVaultName.value
$applicationDataFactoryName = $parameters.parameters.dataFactoryName.value
$landscapeDataFactoryResourceGroupName = $parameters.parameters.landscapeDataFactoryResourceGroupName.value
$landscapeDataFactoryName = $parameters.parameters.landscapeDataFactoryName.value
$landscapeDataFactorySelfHostedIRName = $parameters.parameters.landscapeDataFactorySelfHostedIRName.value


# Remove Shared IR Role in Master Data Factory
$SharedIR = Get-AzDataFactoryV2IntegrationRuntime -ResourceGroupName $landscapeDataFactoryResourceGroupName -DataFactoryName $landscapeDataFactoryName `
    -Name $landscapeDataFactorySelfHostedIRName -DefaultProfile $Global:CtxMasterAdf
$factory = Get-AzDataFactoryV2 -ResourceGroupName $applicationResourceGroupName -Name $applicationDataFactoryName -ErrorAction SilentlyContinue
if ($factory) {
     Write-Host "Deleting Shared Integration Runtime Role Assignment for $applicationDataFactoryName"
     Remove-AzRoleAssignment -ObjectId $factory.Identity.PrincipalId -Scope $SharedIR.Id -RoleDefinitionId 'b24988ac-6180-42a0-ab88-20f7382dd24c' -DefaultProfile $Global.CtxMaster
}
Write-Output "Deleting resource group $applicationResourceGroupName"
if (Get-AzResourceGroup -Name $applicationResourceGroupName) {
    Remove-AzResourceGroup -Name $applicationResourceGroupName -Force
}

# Remove Key vault
$res = Get-AzResource -ResourceGroupName $kvRegName -Name $kvName
if ($res)
{
    Write-Output "Deleting key vault $kvName"
    Remove-AzResource -ResourceName $kvName -ResourceGroupName $kvRegName -ResourceType "Microsoft.KeyVault/vaults"
}
