Param
(
    [Parameter(Mandatory=$True, HelpMessage="The project environment ITSG number")]
    [string]$projectNumber,
    
    [Parameter(Mandatory = $True, HelpMessage = "The environment this parameter file maps to.d=development,q=testing,u=preprod, b=uat, p=production, r=DR, x=DS or Experiment")]
    [ValidatePattern("^(d|q|u|p|b|x|r)$")]
    [string]$projectEnvironment = "d",

    [Parameter(Mandatory=$True, HelpMessage="The project environment ITSG number for the development ITSG")]
    [string]$devProjectNumber,

    [Parameter(Mandatory = $False, HelpMessage = "The name of the project. Must be 8 characters wide and can contain only alphabets and/or numeric values.")]
    [string]$projectName,
    
    [Parameter(Mandatory = $False, HelpMessage = "The project cost centre tag. E.g. A956000702")]
    [string]$tagCostCentre,

    [Parameter(Mandatory = $False, HelpMessage = "The name of the responsible delivery director")]
    [string]$deliveryDirector,

    [Parameter(Mandatory = $False, HelpMessage = "The project international cost centre ICC tag. E.g. ICC11869.")]
    [string]$tagIcc,
    
    [Parameter(Mandatory = $False, HelpMessage = "The name of the requester of the environment for sandbox and experimentation environments")]
    [string]$requester,

    [Parameter(Mandatory = $False, HelpMessage = "Pass this is the env is a data science environment")]
    [switch]$dataScienceEnvironment,

    [Parameter(Mandatory = $False, HelpMessage = "Pass this if the environment has a fixed life span.  It's mandatory if the env is a data science environment")]
    [int]$monthsToExpiry,

    [Parameter(Mandatory = $False, HelpMessage = "Pass this if this is a market environment ")]
    [switch]$marketEnvironment,

    [Parameter(Mandatory = $False, HelpMessage = "Pass this if Azure Dev Ops is not required.")]
    [switch]$suppressTeamProject,

    [Parameter(Mandatory = $false, HelpMessage = "Pass this if you want to provision adls gen1")]
    [switch]$adlsGen1,

    [Parameter(Mandatory = $false, HelpMessage = "Pass this if your are provisioning a test environment")]
    [switch]$testEnvironment,

    [Parameter(Mandatory=$True, HelpMessage="The ITSG number used to generate the name of the devops team project")]
    [string]$vstsProjectNumber=$devProjectNumber
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$managerFolder = "{0}\{1}" -f $devOpsProjectFolder, "LandscapeManager"
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"
$runbookFolder = "{0}\{1}" -f $managerFolder, "RunBooks"

& "$runbookFolder\Import-PlatformCore.ps1"
& "$runbookFolder\Import-PlatformDataCore.ps1"

$tags = @{
    Workload="Existing"
    DeliveryDirector="Unknown"
    ProvisionedBy=[System.Security.Principal.WindowsIdentity]::GetCurrent().Name
    ProvisionedOn=(Get-Date).ToString("yyyy-MM-dd")
}

if($testEnvironment) {
    $deliveryDirector = "Jobby David"
    $tagCostCentre="A956001690"
    $tagIcc="ICC13333"
    $projectName="Azure Landscape Innovation"
}
if ($deliveryDirector) {
    $tags.DeliveryDirector = $deliveryDirector
}

if ($projectEnvironment -eq "x" ) {
    if (-not $monthsToExpiry) {
        $monthsToExpiry = 3
        Write-Warning "********************************************************************************************************"
        Write-Warning "All experiment environments must have an expiry date.  As none was specified the default 3 months will apply."
        Write-Warning "********************************************************************************************************"
    }
}
if ("qubpr".Contains($projectEnvironment)) {
    # Don't want a new Team project for non dev envs
    $suppressTeamProject = $true
}

if ($monthsToExpiry) {
    $tags.ExpiryDate = (Get-Date).AddMonths($monthsToExpiry).ToString("yyyy-MM-dd")
    Write-Warning "This environment will be tagged to expire on $($tags.ExpiryDate)"
}

$parameterFile = "parameters.{0}.{1}.json" -f $projectEnvironment, $projectNumber
$folderFile = "folders.{0}.{1}.json" -f $projectEnvironment, $projectNumber

function New-AllResources
{
    param
    (
        [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
        [String]$teamProjectParameterFile,

        [Parameter(Mandatory = $True, HelpMessage='The personal access token used to authorize vsts requests')]
        [String]$personalAccessToken,

        [Parameter(Mandatory = $True, HelpMessage='The parameter file for deploying the Azure Resources')]
        [String]$resourceParameterFile
    )
    if ("dx".Contains($projectEnvironment))
    {
        & "$managerFolder\New-TeamProject.ps1" -parameterFile $teamProjectParameterFile -personalAccessToken $personalAccessToken
        Write-Host "Team project created"
        # Wiat for VSTS to create the git repo.  We see a delay somethimes
        Start-Sleep 5
        & "$managerFolder\Set-GitProject.ps1" -parameterFile $teamProjectParameterFile -devOpsParameterFile $resourceParameterFile
        Write-Host "GIT repository created"
    } else {
        & "$managerFolder\Add-ParameterFilesToGit.ps1" -parameterFile $teamProjectParameterFile -devOpsParameterFile $resourceParameterFile
        Write-Host "Parameter files added to GIT repository"
    }
  
    $secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $deploymentApplicationName -ErrorAction SilentlyContinue
    & "$managerFolder\New-BuildDefinition.ps1" -parameterFile $teamProjectParameterFile -personalAccessToken $personalAccessToken
    Write-Host "Team project build definition created"
    & "$managerFolder\New-ServiceEndPoint.ps1" -parameterFile $teamProjectParameterFile -personalAccessToken $personalAccessToken -depClientSecret $secret.SecretValueText -resourceParameterFile $resourceParameterFile
    Write-Host "Team project service end point created"
    & "$managerFolder\New-ReleaseDefinition.ps1" -parameterFile $teamProjectParameterFile -personalAccessToken $personalAccessToken -resourceParameterFile $resourceParameterFile
    Write-Host "Team project release definition created"
    & "$managerFolder\New-Build.ps1" -parameterFile $teamProjectParameterFile -personalAccessToken $personalAccessToken
    Write-Host "Team project build triggered"
}

# Validate the args so we handle the special case for the dev environment.  This script assumes the dev environment already exists.
if ("dx".Contains($projectEnvironment)) {
    # make sure mandatory parameters are passed for a dev env spin up
    if ([String]::IsNullorEmpty($projectName))
    {
        Write-Error "You must pass a value for the projectName parameter."
        return
    }
    if ([String]::IsNullorEmpty($tagCostCentre))
    {
        Write-Error "You must pass a value for the tagCostCentre parameter."
        return
    }
    if ([String]::IsNullorEmpty($tagIcc))
    {
        Write-Error "You must pass a value for the tagIcc parameter."
        return
    }
    if ([String]::IsNullorEmpty($projectName))
    {
        Write-Error "You must pass a value for the projectName parameter."
        return
    }
    if($projectEnvironment -eq "x" -and [String]::IsNullorEmpty($requester)){
        Write-Error "You must pass a value for the requester parameter."
        return
    }
    if ([String]::IsNullorEmpty($deliveryDirector))
    {
        Write-Error "You must pass a value for the delivery director parameter."
        return
    }
    $directors = @("Nigel Issa","Pinak Pramanick","Juliana Freitas","Geetha Lakshman","Meenakshi Burra","Morgan Vawter","Rob Morgan",
    "David Milan Ruiz","Aneesh Chaudhry","Jobby David","Eric Chen - SEAA","Eric Chen - N Asia","Adriana Sudan - CD Analytics","Alan Fearn",
    "Kuldeep Sankhala","Umaparvathy K","Chris Baxter","Elena Fedosova","Eric-Francis Chen")
    if (-not $directors.Contains($deliveryDirector)) {
        Write-Warning "********************************************************************************************************"
        Write-Warning "The specified delivery director '$deliveryDirector' is not recognised.  You must use names from the offical list:"
        $directors | Write-Warning 
        Write-Warning "********************************************************************************************************"
        
        $confirm = Read-Host -Prompt "Confirm you want to continue with director name: '$deliveryDirector'.  Enter Y"
        if ($confirm -eq "Y") {
            Write-Warning "Progressing with director name: '$deliveryDirector'."
        } else {
            Write-Error "Aborting turnkey.  Please check the director name and try again"
            return
        }
    }
    $ctx = & "$managerFolder\Set-GlobalScope.ps1"
} else {
    $ctx = & "$managerFolder\Set-GlobalScope.ps1"
    # grab the mandatory values from else where
    $devBootStrap = Get-BootStrap -SubscriptionNumber $Global:CtxBootStrap.SubscriptionNumberDev
    $devParameters = & "$utilitiesFolder\Get-Parameters.ps1" -parameterFile "d.$devProjectNumber" -bootstrap $devBootStrap
    $devResourceGroup = Get-AzResourceGroup -Name $devParameters.parameters.storageAccountResourceGroupName.value -DefaultProfile $Global:CtxDev

    if ($projectEnvironment -eq "r") {
        # Don't want a new Team project for a DR env
        $suppressTeamProject = $true
        $path = Get-BlobContentFinal -mergedFileName "Services.csv" -sourceFolder $null
        $services = Import-csv -Path $path
    
        foreach($service in $services) {
            if ($service.ITSGDev -eq $devProjectNumber) {
                $productionITSG = $service.ITSGProd
                Write-Output "DR production environment found ($productionITSG)"
            }
        }
    
        if (-not($productionITSG)) {
            Write-Warning "Production ITSG number not found."
            do {
                $productionITSG = Read-Host -Prompt 'Please enter valid Production ITSG for this DR environment....'
                }
            while ($productionITSG -eq "")
            
        }
        $productionParameterFile = "parameters.p.{0}.json" -f $productionITSG
    }
    
    if ($devResourceGroup) {
        $tagIcc = $devResourceGroup.Tags["Icc"]
        $tagCostCentre = $devResourceGroup.Tags["CostCentre"]
        $projectName = $devResourceGroup.Tags["ServiceName"]
        if ($devResourceGroup.Tags["DataScience"]) {
            $dataScienceEnvironment = $true
        }
        if ($devResourceGroup.Tags["Market"]) {
            $marketEnvironment = $true
        }
    } else {
        Write-Error "Failed to access details from the development resource group $($devParameters.parameters.storageAccountResourceGroupName.value)"
        return
    }
}
if ($marketEnvironment) {
    $tags.Market = "True"
}
if ($dataScienceEnvironment) {
    $tags.DataScience = "True"
}
Write-Output "Bootstrap Configuration:"
$Global:CtxBootStrap

$secret = & "$utilitiesFolder\Get-KeyVaultSecret.ps1" -parameterFile $Global:CtxBootStrap.LandscapeParameterFile -secretName "PersonalAccessToken" -landscape
if ($secret) {
    $personalAccessToken = $secret.SecretValueText
} else {
    Write-Error "Failed to access a valid VSTS personal access token.  Please add one to landscape's development key vault da04.56731 and try again."
    return
}

$teamProjectParameterFile = & "$managerFolder\New-TeamProjectParameterFile.ps1" -projectNumber $projectNumber -projectEnvironment $projectEnvironment -vstsProjectNumber $vstsProjectNumber -platform "da"

#Create the environment parameter file
$nepFileArgs = @{
    projectNumber = $projectNumber 
    projectName = $projectName
    projectEnvironment = $projectEnvironment
    tagCostCentre = $tagCostCentre
    tagIcc = $tagIcc
    devProjectNumber = $devProjectNumber 
    subscriptionId = $ctx.Subscription.Id    
}

& "$managerFolder\New-EnvironmentParameterFile.ps1" @nepFileArgs
& "$managerFolder\Set-ParameterFileBackup" -parameterFile $parameterFile -parameterFileName $teamProjectParameterFile -Force

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile
$subscriptionId = $parameters.parameters.subscriptionId.value 
$projectNumber = $parameters.parameters.projectNumber.value
$projectName = $parameters.parameters.projectName.value
$tagCostCentre = $parameters.parameters.tagValues.value.tagCostCentre
$tagIcc = $parameters.parameters.tagValues.value.tagIcc
$developerGroupName = $parameters.parameters.developerADGroupName.value
$keyVaultName = $parameters.parameters.landscapeKeyVaultName.value

$devProjectNumber = $developerGroupName.split("-")[4]

$projectEnvironment = $parameters.parameters.projectEnvironment.value

& "$managerFolder\Add-ResourceGroups.ps1" -parameterFile $parameterFile -tags $tags
& "$managerFolder\New-KeyVault.ps1" -parameterFile $parameterFile

$params = @{ parameterFile=$parameterFile }
if ($dataScienceEnvironment) {
    $params.dataScienceEnvironment=$true
}

if ($projectEnvironment -ne "r") {
    & "$managerFolder\New-ADApplication.ps1" -parameterFile $parameterFile
    & "$managerFolder\New-AADGroups.ps1" @params
} else {
    & "$utilitiesFolder\Copy-KeyVaultSecrets.ps1" -parameterFile $productionParameterFile -parameterFileTarget $parameterFile
}
if ($projectEnvironment -eq "x" ) {
    & "$managerFolder\Add-Budget.ps1" -parameterFile $parameterFile
}

$nepFileArgs.backupParameterFile = $true
& "$managerFolder\New-EnvironmentParameterFile.ps1" @nepFileArgs

& "$managerFolder\New-FolderParameterFile.ps1" -parameterFile $parameterFile -backupParameterFile

$params = @{
    parameterFile = $parameterFile
}
$message = "Created datalake store Gen2"
if ($adlsGen1) {
    $params.adlsGen1 = $true
    $message = "Created datalake store Gen1"
}
& "$managerFolder\New-DataFactoryParameterFile.ps1"  @params

$deploymentApplicationName = $parameters.parameters.deploymentAdApplicationName.value
if (-not $suppressTeamProject) {
    # Create the team project components
    New-AllResources -teamProjectParameterFile $teamProjectParameterFile -personalAccessToken $personalAccessToken -resourceParameterFile $parameterFile
} else {
    Write-Warning "Azure Dev Ops will not be configured for this service."
}
$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

& "$managerFolder\Set-KeyVaultAccess.ps1" -parameterFile $parameterFile
Write-Host "Granted key vault access"
& "$managerFolder\Set-ResourceGroupAccess.ps1" -parameterFile $parameterFile
& "$managerFolder\New-StorageAccount.ps1" -parameterFile $parameterFile

& "$managerFolder\New-DataLakeStore.ps1" @params
Write-Host $message

& "$managerFolder\Add-PSLZDataLakeFolder.ps1" -parameterFile $parameterFile
Write-Host "Created PSLZ data lake folder"
& "$managerFolder\New-DataFactory.ps1" @params
Write-Host "Created data factory"
