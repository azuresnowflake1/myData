Param
(
    [Parameter(Mandatory = $True, HelpMessage = 'Specify the production parameter file where the ADF will be deployed. Must be prod')]
    [String]$parameterFile,
    [Parameter(Mandatory = $false, HelpMessage = 'Specify the ITSG for the dev env')]
    [String]$itsgDev,
    [Parameter(Mandatory = $false, HelpMessage = 'Specify the ITSG for the QA env')]
    [String]$itsgQA,
    [Parameter(Mandatory = $false, HelpMessage = 'Specify the ITSG for the Pre Prod env')]
    [String]$itsgPpd,
    [Parameter(Mandatory = $false, HelpMessage = 'Specify the ITSG for the UAT env')]
    [String]$itsgUAT=""
)
# Deploy a DevOps specific data factory into the prod env. The script will try to create linked services
# for ADLS and BLOB in all lower environments
$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"
$managerFolder = "{0}\{1}" -f $devOpsProjectFolder, "LandscapeManager"
$projectsFolder = "{0}\{1}" -f $devOpsProjectFolder, "Projects"

& "$managerFolder\Set-GlobalScope"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

if ($parameters.parameters.projectEnvironment.value -ne "p") {
    throw "You can only create the dev ops ADF in a production subscription!"
}
$dataFactoryContext = $Global:CtxBootStrap.DefaultProfile
$datafactoryName = $parameters.parameters.dataFactoryName.value.Replace("-adf-01", "-DevOps")
$resourceGroupName = $parameters.parameters.dataFactoryResourceGroupName.value.Replace("-rg", "-dvop-rg")
& "$devOpsProjectFolder\LandscapeManager\Runbooks\Import-PlatformDataCore.ps1"

$prodResourceGroup = Get-AzResourceGroup -Name $parameters.parameters.dataFactoryResourceGroupName.value
if (-not $prodResourceGroup) {
    throw "The production resource group was not found in the current subsription."
}
Function CreateAdlsGen2LinkedService {
    param
    (
        [Object]$parameters,
        [String]$adfResourceGroupName,
        [String]$adfName,
        [String]$lsName        
    )
    $sourcePath = "$devOpsProjectFolder\DataFactoryV2\adlstore2.json"
    $adlsLinkedService = Get-Content -Path $sourcePath -Raw | ConvertFrom-JSON
    $secureString = @"
    { 
        "type": "SecureString", 
        "value": "<accountkey>" 
    }
"@
    $secureKey = $secureString | ConvertFrom-JSON
    $dataLakeStoreUri = "https://{0}.dfs.core.windows.net" -f $parameters.parameters.adlStoreName.value
    $keyVaultName = $parameters.parameters.keyVaultName.value
    $secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $parameters.parameters.adApplicationName.value

    $securekey.value = $secret.SecretValueText
    $adlsLinkedService.name = $lsName
    $adlsLinkedService.properties.typeProperties.Url = $dataLakeStoreUri
    $adlsLinkedService.properties.typeProperties.servicePrincipalId = $parameters.parameters.applicationId.value

    $adlsLinkedService.properties.typeProperties.servicePrincipalKey = $securekey
    $adlsLinkedService.properties.typeProperties.subscriptionId = $parameters.parameters.subscriptionId.value
    $adlsLinkedService.properties.typeProperties.resourceGroupName = $parameters.parameters.adlStoreResourceGroupName.value

    $destinationPath = New-TemporaryFile
    Write-Verbose "Writing $destinationPath with link service details"
    #$adlsLinkedService | ConvertTo-JSON -Depth 10 | Write-Host
    $adlsLinkedService | ConvertTo-JSON -Depth 10 | Out-File -filepath $destinationPath -Force
    Set-AzDataFactoryV2LinkedService -ResourceGroupName  $adfResourceGroupName -DataFactoryName $adfName -Name $lsName -DefinitionFile $destinationPath -DefaultProfile $dataFactoryContext -Force
}
Function CreateAdlsGen1LinkedService {
    param
    (
        # Parameter help description
        [Object]$parameters,
        [String]$adfResourceGroupName,
        [String]$adfName,
        [String]$lsName
    )
    $sourcePath = "$devOpsProjectFolder\DataFactoryV2\adlstore.key.json"
    $adlsLinkedService = Get-Content -Path $sourcePath -Raw | ConvertFrom-JSON

    $dataLakeStoreUri = "adl://{0}.azuredatalakestore.net/" -f $parameters.parameters.adlStoreName.value
    $tenantDomainName = $parameters.parameters.tenantDomainName.value

    $appApplicationId = $parameters.parameters.applicationId.value
    $keyVaultName = $parameters.parameters.keyVaultName.value
    $secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $parameters.parameters.adApplicationName.value
    $appClientSecretText = $secret.SecretValueText
    
    $adlsLinkedService.properties.typeProperties.dataLakeStoreUri = $dataLakeStoreUri
    $adlsLinkedService.properties.typeProperties.servicePrincipalId = $appApplicationId
    $adlsLinkedService.properties.typeProperties.servicePrincipalKey.value = $appClientSecretText 
    $adlsLinkedService.properties.typeProperties.tenant = $tenantDomainName
    $adlsLinkedService.properties.typeProperties.subscriptionId = $parameters.parameters.subscriptionId.value
    $adlsLinkedService.properties.typeProperties.resourceGroupName = $parameters.parameters.adlStoreResourceGroupName.value

    $destinationPath = New-TemporaryFile
    Write-Verbose "Writing $destinationPath with link service details"
    $adlsLinkedService | ConvertTo-JSON -Depth 10 | Out-File -filepath $destinationPath -Force

    Set-AzDataFactoryV2LinkedService -ResourceGroupName  $adfResourceGroupName -DataFactoryName $adfName -Name $lsName -DefinitionFile $destinationPath -DefaultProfile $dataFactoryContext -Force
}
Function CreateStorageLinkedServiceWithKey {
    param
    (
        # Parameter help description
        [Object]$parameters,
        [String]$adfResourceGroupName,
        [String]$adfName,
        [String]$lsName
    )
    $sourcePath = "$devOpsProjectFolder\DataFactoryV2\storage.key1.json"
    $storageLinkedService = Get-Content -Path $sourcePath -Raw | ConvertFrom-JSON

    $keyVaultName = $parameters.parameters.keyVaultName.value
    $secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $parameters.parameters.storageAccountName.value
    
    $storageLinkedService.properties.typeProperties.connectionString = "DefaultEndpointsProtocol=https;AccountName={0};AccountKey={1}" -f $parameters.parameters.storageAccountName.value, $secret.SecretValueText
    $destinationPath = New-TemporaryFile
    Write-Verbose "Writing $destinationPath with link service details"
    $storageLinkedService | ConvertTo-JSON -Depth 10| Out-File -filepath $destinationPath -Force
    Set-AzDataFactoryV2LinkedService -ResourceGroupName  $adfResourceGroupName -DataFactoryName $adfName -Name $lsName -DefinitionFile $destinationPath -DefaultProfile $dataFactoryContext -Force
}

if(-not ($itsgDev -and $itsgPpd -and $itsgQA -and $itsgUAT)){
    # at least one itsg was not supplied.  Try to get it from the dashboard data
    $rg = Get-AzResourceGroup -Name $resourceGroupName -ErrorAction Continue
    if (-not $rg) {
        $rg = New-AzResourceGroup -Name $resourceGroupName -Location $prodResourceGroup.Location -Tag $prodResourceGroup.Tags -ErrorAction Stop
    }
    if (-not (Get-AzRoleAssignment -ResourceGroupName $resourceGroupName -ObjectId $parameters.parameters.supportADGroupId.value -RoleDefinitionName "InA Tech DevOps ADF Contributor")) {
        New-AzRoleAssignment -ResourceGroupName $resourceGroupName -ObjectId $parameters.parameters.supportADGroupId.value -RoleDefinitionName "InA Tech DevOps ADF Contributor" -ErrorAction Stop
    }
    $serviceName = $prodResourceGroup.Tags["ServiceName"]
    $path = Get-BlobContentFinal -mergedFileName "Services.csv" -sourceFolder ""
    $service = Get-Service -filePath $path -ServiceName $serviceName

    if (-not $itsgDev) {
        if ($service.ITSGDev -eq 0) {
            Write-Warning "Unable to work out the Dev ITSG for $serviceName using Service.csv."
        } else {
            $itsgDev = $service.ITSGDev
        }
    }
    if (-not $itsgQA) {
        if ($service.ITSGQA -eq 0) {
            Write-Warning "Unable to work out the QA ITSG for $serviceName using Service.csv."
        } else {
            $itsgQA = $service.ITSGQA
        }
    }
    if (-not $itsgPpd) {
        if ($service.ITSGPPD -eq 0) {
            Write-Warning "Unable to work out the pre prod ITSG for $serviceName using Service.csv."
        } else {
            $itsgPPD = $service.ITSGPPD
        }
    }
    if (-not $itsgUAT) {
        if ($service.ITSGUAT -eq 0) {
            Write-Warning "Unable to work out the UAT ITSG for $serviceName using Service.csv."
        } else {
            $itsgUAT = $service.ITSGUAT
        }
    }
}
$dataFactory = Get-AzDataFactoryV2 -Name $datafactoryName -ResourceGroupName $resourceGroupName -ErrorAction SilentlyContinue
if (-not $dataFactory) {
    New-AzDataFactoryV2  -Name $datafactoryName -ResourceGroupName $resourceGroupName -Location $parameters.parameters.location.value
}
# Workout of this is an ADLS gen1 project
$adlsGen1 = $false;
if (Get-AzResource -ResourceGroupName $prodResourceGroup.ResourceGroupName -ResourceType "Microsoft.DataLakeStore/accounts") {
    $adlsGen1 = $true;
}
# Allow DevOp to edit the data factory but prevent edits to linked services
$roleName = "InA Tech DevOps ADF Contributor"
$assignment = Get-AzRoleAssignment -ResourceGroupName $resourceGroupName -RoleDefinitionName $roleName -ObjectId $parameters.parameters.supportADGroupId.value
if (-not $assignment) {
    New-AzRoleAssignment -ResourceGroupName $resourceGroupName -RoleDefinitionName $roleName -ObjectId $parameters.parameters.supportADGroupId.value 
}
if ($adlsGen1) {
    CreateAdlsGen1LinkedService -parameters $parameters -adfResourceGroupName $resourceGroupName -adfName $datafactoryName -lsName "LS_ADLS_PROD"
} else {
    CreateAdlsGen2LinkedService -parameters $parameters -adfResourceGroupName $resourceGroupName -adfName $datafactoryName -lsName "LS_ADLS_PROD"
}
CreateStorageLinkedServiceWithKey -parameters $parameters -adfResourceGroupName $resourceGroupName -adfName $datafactoryName -lsName "LS_ABLB_PROD"
if ($itsgDev) {
    # Hack Alert;  Need to enhance Get-Services in the dashboard so it outputs the subscription number for each ITSG
    & "$managerFolder\Set-GlobalScope" -subscriptionNumber $service.SubDev
    $parametersDev = & "$utilitiesFolder\Get-Parameters" -parameterFile "parameters.d.$itsgDev.json" -bootstrap $Global:CtxBootStrap
    if ($adlsGen1) {
        CreateAdlsGen1LinkedService -parameters $parametersDev -adfResourceGroupName $resourceGroupName -adfName $datafactoryName -lsName "LS_ADLS_DEV"
    } else {
        CreateAdlsGen2LinkedService -parameters $parametersDev -adfResourceGroupName $resourceGroupName -adfName $datafactoryName -lsName "LS_ADLS_DEV"
    }
    CreateStorageLinkedServiceWithKey -parameters $parametersDev -adfResourceGroupName $resourceGroupName -adfName $datafactoryName -lsName "LS_ABLB_DEV"
}
if ($itsgQA) {
    & "$managerFolder\Set-GlobalScope" -subscriptionNumber $service.SubQA
    $parametersQA = & "$utilitiesFolder\Get-Parameters" -parameterFile "parameters.q.$itsgQA.json" -bootstrap $Global:CtxBootStrap
    if ($adlsGen1) {
        CreateAdlsGen1LinkedService -parameters $parametersQA -adfResourceGroupName $resourceGroupName -adfName $datafactoryName -lsName "LS_ADLS_QA"
    } else {
        CreateAdlsGen2LinkedService -parameters $parametersQA -adfResourceGroupName $resourceGroupName -adfName $datafactoryName -lsName "LS_ADLS_QA"
    }
    CreateStorageLinkedServiceWithKey -parameters $parametersQA -adfResourceGroupName $resourceGroupName -adfName $datafactoryName -lsName "LS_ABLB_QA"
}
if ($itsgPpd) {
    & "$managerFolder\Set-GlobalScope" -subscriptionNumber $service.SubPPD
    $parametersPPD = & "$utilitiesFolder\Get-Parameters" -parameterFile "parameters.u.$itsgPpd.json" -bootstrap $Global:CtxBootStrap
    if ($adlsGen1) {
        CreateAdlsGen1LinkedService -parameters $parametersPPD -adfResourceGroupName $resourceGroupName -adfName $datafactoryName -lsName "LS_ADLS_PPD"    
    } else {
        CreateAdlsGen2LinkedService -parameters $parametersPPD -adfResourceGroupName $resourceGroupName -adfName $datafactoryName -lsName "LS_ADLS_PPD"
    }
    CreateStorageLinkedServiceWithKey -parameters $parametersPPD -adfResourceGroupName $resourceGroupName -adfName $datafactoryName -lsName "LS_ABLB_PPD"
}
if ($itsgUAT) {
    & "$managerFolder\Set-GlobalScope" -subscriptionNumber $service.SubUAT
    $parametersUAT = & "$utilitiesFolder\Get-Parameters" -parameterFile "parameters.b.$itsgUAT.json" -bootstrap $Global:CtxBootStrap
    if ($adlsGen1) {
        CreateAdlsGen1LinkedService -parameters $parametersUAT -adfResourceGroupName $resourceGroupName -adfName $datafactoryName -lsName "LS_ADLS_UAT"   
    } else {
        CreateAdlsGen2LinkedService -parameters $parametersUAT -adfResourceGroupName $resourceGroupName -adfName $datafactoryName -lsName "LS_ADLS_UAT"
    }
    CreateStorageLinkedServiceWithKey -parameters $parametersUAT -adfResourceGroupName $resourceGroupName -adfName $datafactoryName -lsName "LS_ABLB_UAT"
}