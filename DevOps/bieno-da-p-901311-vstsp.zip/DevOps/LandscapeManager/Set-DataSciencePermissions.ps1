Param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$parameterFile
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

$appResourceGroupName = $parameters.parameters.dataFactoryResourceGroupName.value

$dataOwnerADGroupId = $parameters.parameters.dataOwnerADGroupId.value
$developerADGroupId = $parameters.parameters.developerADGroupId.value
$dataWriterADGroupId = $parameters.parameters.dataWriterADGroupId.value
$keyVaultName = $parameters.parameters.keyVaultName.value
$databricksWorkspaceName = $parameters.parameters.databricksWorkspaceName.value
function Remove-RoleAssignment {
    param (
        [string] $resourceGroupName,
        [string] $resourceName,
        [string] $roleName,
        [string] $grantee
    )

    $resource = Get-AzResource -Name $resourceName
    $assignment = Get-AzRoleAssignment -ResourceGroupName $appResourceGroupName -ResourceName $resourceName -RoleDefinitionName $roleName -ResourceType $resource.ResourceType -ObjectId $granteeDataOwnerId

    if($assignment) {
        Remove-AzRoleAssignment -ResourceGroupName $appResourceGroupName -ResourceName $resourceName -RoleDefinitionName $roleName -ResourceType $resource.ResourceType -ObjectId $granteeDataOwnerId
    } else {
        Write-Verbose "Role assignment already removed for $roleName on object $resourceName."
            } 
    }

$resourceName = $parameters.parameters.adlStoreName.value
$roleName = "InA Tech Data Owner"
$granteeDataOwnerId = $parameters.parameters.dataOwnerADGroupId.value
Remove-RoleAssignment -resourceGroupName $appResourceGroupName -resourceName $resourceName -roleName $roleName -grantee $granteeDataOwnerId
$resourceName = $parameters.parameters.storageAccountName.value
Remove-RoleAssignment -resourceGroupName $appResourceGroupName -resourceName $resourceName -roleName $roleName -grantee $granteeDataOwnerId


#remove from data owner group add to data writer group
$members = Get-AzADGroupMember -GroupObjectId $dataOwnerADGroupId

if ( $members | Where-Object Id -eq $developerADGroupId) {
    Remove-AzADGroupMember -MemberObjectId $developerADGroupId -GroupObjectId $dataOwnerADGroupId
    }

$members = Get-AzADGroupMember -GroupObjectId $dataWriterADGroupId
if (-not ($members | Where-Object Id -eq $developerADGroupid)) {
    Add-AzADGroupMember -MemberObjectId $developerADGroupId -TargetGroupObjectId $dataWriterADGroupId -ErrorAction SilentlyContinue
}

#Remove Key Vault Access
Remove-AzKeyVaultAccessPolicy -VaultName $keyVaultName -ObjectId $developerADGroupId


$res = Get-AzResource -ResourceGroupName $appResourceGroupName -Name $databricksWorkspaceName

if($res){
    $assignment = Get-AzRoleAssignment -ResourceGroupName $appResourceGroupName -ResourceName $databricksWorkspaceName -RoleDefinitionName "Contributor" -ResourceType $res.ResourceType -ObjectId $developerADGroupId
   
    if ($assignment) {
        Write-Output "Resource exists to be removed"
        Remove-AzRoleAssignment -ResourceGroupName $appResourceGroupName -ResourceName $databricksWorkspaceName -RoleDefinitionName "Contributor" -ResourceType $res.ResourceType -ObjectId $developerADGroupId
          } else {
        Write-Verbose "Role assignment already removed for $roleName on object $resourceName."
    }
 
}