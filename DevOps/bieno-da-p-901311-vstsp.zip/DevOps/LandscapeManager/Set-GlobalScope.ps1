[CmdletBinding()]
param
(
    [Parameter(Mandatory = $false, ParameterSetName="file", HelpMessage = "The parameter file name for the environment")]
    [string]$parameterFile,
    [string]$subscriptionNumber,
    [switch]$force
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$managerFolder = "{0}\{1}" -f $devOpsProjectFolder, "LandscapeManager"
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$x = (Get-ChildItem function:) | Where-Object { $_.name -eq "Get-Bootstrap" }
if (-not $x) {
    & "$managerFolder\Runbooks\Import-PlatformCore.ps1"
}

$contexts = Get-AzContext -ListAvailable
if (-not $contexts){
    Login-AzAccount
}
function Get-Context {
    param
    (
        [string] $subId
    ) 
    foreach ($ctx in $contexts) {
        if ($ctx.subscription.id -eq $subId) {
            return $ctx
        }
    }
    throw "Unknown subscription $subId"
}

if ($subscriptionNumber) {
    $sub = Get-SubscriptionBootstrap -subscriptionNumber $subscriptionNumber
    $sub = $sub.DefaultProfile
} elseif ($parameterFile) {
    $parameters = & "$utilitiesFolder\Get-Parameters.ps1" -parameterFile $parameterFile
    $sub = Get-AzContext
    if ($Global:CtxDeploy -and $Global:CtxDeploy -eq $sub -and $sub.subscription.id -eq $parameters.parameters.subscriptionId.value -and -not $force) {
        Write-Host "Global context is already set for $($sub.subscription.name). Use -Force to refresh."
        return $sub
    } else {
        $sub= Get-Context -subId $parameters.parameters.subscriptionId.value
    }
} else {
    $sub=& "$managerFolder\Select-Subscription.ps1"
}

if (-not $sub) {
    throw "Unable to continue.  Must must select the target subscription."
} else {
    $subNumber = $sub.Subscription.Name.Split("-")[1]
    $bootStrap = Get-SubscriptionBootstrap -subscriptionNumber $subNumber
    $namePrefix = Get-NamePrefix -region $bootStrap.Region
    $componentName = "{0}-da{1}-{2}-{3}-adf-01" -f $namePrefix, $subNumber, $bootStrap.ProjectEnvironment, $bootStrap.ProjectNumber
    $Global:CtxBootStrap = Get-BootStrap -componentName $componentName 
}

# Initialise the global scope for the turkey
Write-Host "Initialising global scope for $($sub.Subscription.Name) ...."

$Global:CtxDeploy= $sub
if ((Get-AzContext).Subscription.Id -ne $sub.Subscription.Id) {
    Set-AzContext -Context $Global:CtxDeploy | Out-Null
}
# Workout the subscription where 
$adfTokens = $Global:CtxBootStrap.LandscapeAdfName.Split("-")
$adfSubNumber = $adfTokens[1].substring(2)
$adfBootStrap = Get-SubscriptionBootstrap -subscriptionNumber $adfSubNumber

$Global:CtxMasterAdf = $adfBootStrap.DefaultProfile
$Global:CtxAuto=Get-Context -subId $Global:CtxBootStrap.automationSubscriptionId
$Global:CtxDev=Get-Context -subId $Global:CtxBootStrap.DevSubscriptionId
$Global:CtxProd=Get-Context -subId "e2b0e829-5210-40ae-b73f-20805aa01351" #used to backup parameter files

# Connect to AD and Az with the provisioning SPN
$cert = Get-ChildItem cert:\localmachine\My\ | Where-Object {$_.Subject -eq "CN=IANDASPNProdCert" }
if (-not $cert) {
    $cert = Get-ChildItem cert:\currentuser\My\ | Where-Object {$_.Subject -eq "CN=IANDASPNProdCert" }
}
if ($cert) {
    $Thumbprint = $cert.Thumbprint
    $tenentID = 'f66fae02-5d36-495b-bfe0-78a6ff9f8e6e'
    $applicationID = 'd0f394e7-a998-422d-af05-67b8a76f26a1'
    Connect-AzAccount -TenantId $tenentID -ApplicationId $applicationID -CertificateThumbprint $thumbprint | Out-Null
    $Global:CtxSPN = Get-AzContext
    $Global:ClientCert = [Microsoft.IdentityModel.Clients.ActiveDirectory.ClientAssertionCertificate]::new($applicationId, $cert)
    Connect-AzureAD -TenantId $tenentID -ApplicationId $applicationID -CertificateThumbprint $thumbprint | Out-Null
} else {
    $Global:CtxSPN = $sub
}

Set-AzContext -Context $sub | Out-Null

return $sub
