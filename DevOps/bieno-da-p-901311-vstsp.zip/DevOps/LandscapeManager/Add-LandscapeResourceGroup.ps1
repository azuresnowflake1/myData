param
(
    [Parameter(Mandatory = $False, HelpMessage='The name of a previously created landscape key vault that has global secrets we need to copy..')]
    [String]$sourceKeyVaultName="bnlwe-da04-d-56731-kv-01",
    [switch]$Force
)
# Add a private resource group for landscape
$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$managerFolder = "{0}\{1}" -f $devOpsProjectFolder, "LandscapeManager"
$runbookFolder = "{0}\{1}" -f $managerFolder, "RunBooks"

& "$runbookFolder\Import-PlatformCore.ps1"
& "$runbookFolder\Import-PlatformAutomationClientCore.ps1"
$sub = & "$managerFolder\Set-GlobalScope"
$bootStrap = $Global:CtxBootStrap
$namePrefix = $bootStrap.NamePrefix
$location=$bootstrap.Location

Write-Host "Creating landscape private resource group $($bootStrap.LandscapeResourceGroupName) in $location."

$tags = @{
    CostCentre = $bootStrap.CostCentre;
    Icc = $bootStrap.Icc;
    Environment = $bootStrap.Environment;
    Platform = $bootStrap.Platform;
    ServiceName = $bootStrap.ServiceName;
    DeliveryDirector = "Jobby David"
}
$rg3=Get-AzResourceGroup -Name $bootStrap.LandscapeResourceGroupName -Location $location -ErrorAction SilentlyContinue
if ($rg3 -and -not $force) {
    throw "The landscape resource group '$($bootStrap.LandscapeResourceGroupName)' is already created.  You must force to overwrite it."
} elseif ($rg3 -and $force) {
    $rg3 = New-AzResourceGroup -Name $bootStrap.LandscapeResourceGroupName -Location $location -tag $tags -Force
} else {
    $rg3 = New-AzResourceGroup -Name $bootStrap.LandscapeResourceGroupName -Location $location -tag $tags
}

$stgAcount = Get-AzStorageAccount -ResourceGroupName $bootStrap.LandscapeResourceGroupName -Name $bootStrap.LandscapeStorageAccountName -ErrorAction SilentlyContinue
if (-not $stgAcount) {
    $storageAccountName = $bootStrap.LandscapeStorageAccountName
    Write-Host "Creating landscape private storage account $storageAccountName in $($bootStrap.LandscapeResourceGroupName) in $location."
    $storageDeploymentName = $storageAccountName + "_depl"
    $storageTemplateFile = "$devOpsProjectFolder\Templates\storage.json"
    $depl= New-AzResourceGroupDeployment -Name $storageDeploymentName -TemplateFile $storageTemplateFile `
    -ResourceGroupName $bootStrap.LandscapeResourceGroupName `
    -storageAccountName $storageAccountName -location $location `
    -tagValues $tags
}
$keyVault = Get-AzKeyVault -ResourceGroupName $bootStrap.LandscapeResourceGroupName -VaultName $bootStrap.KeyVaultName -ErrorAction SilentlyContinue
if (-not $keyVault) {
    Write-Host "Creating landscape key vault $($bootStrap.KeyVaultName)"
    $keyVaultTemplateFile = "$devOpsProjectFolder\Templates\keyvault.json"
    $deploymentName = $bootStrap.KeyVaultName + "_depl"
    $group = Get-AzADGroup -DisplayName "sec-es-da-p-56728-azure-landscape"
    
    $depl = New-AzResourceGroupDeployment  -ResourceGroupName $bootStrap.LandscapeResourceGroupName `
    -Name $deploymentName -TemplateFile $keyVaultTemplateFile `
    -keyvaultName $bootStrap.KeyVaultName -tenantid $bootStrap.TenantId -location $location `
    -objectid $group.Id -skuName Standard `
    -enableVaultForDeployment $true -enableVaultForDiskEncryption $true `
    -enabledForTemplateDeployment $true `
    -keysPermissions "All" -secretsPermissions "All" -tagValues $tags -Force
    
    $keyVault = Get-AzKeyVault -ResourceGroupName $bootStrap.LandscapeResourceGroupName -VaultName $bootStrap.KeyVaultName
    $keyVault.enableSoftDelete
}

#Copy in secrets
Write-Host "Copying secrets from $sourceKeyVaultName to $($bootStrap.KeyVaultName)"

[System.Collections.ArrayList]$include = @("ServiceAccountName","ServiceAccountPassword","PersonalAccessToken")
$secrets = Get-AzKeyVaultSecret -VaultName $sourceKeyVaultName
foreach($secret in $secrets)
{
	if ($include.Contains($secret.Name)) {
        Write-Host "Adding secret $($secret.Name)"
        $secret = Get-AzKeyVaultSecret -VaultName $sourceKeyVaultName -Name $secret.Name
        Set-AzKeyVaultSecret -VaultName $bootStrap.KeyVaultName -Name $secret.Name -SecretValue $secret.SecretValue-Expires $secret.Expires -ContentType $secret.ContentType
	}
}
Write-Host "Create and backup the turnkey parameter file"
& "$managerFolder\New-EnvironmentParameterFile.ps1" -projectNumber $bootStrap.LandscapeProjectNumber -projectName $bootStrap.ServiceName `
    -projectEnvironment $bootStrap.ProjectEnvironment -tagCostCentre $bootStrap.CostCentre -tagIcc $bootStrap.Icc -devProjectNumber "56731" `
     -backupParameterFile -subscriptionId $bootStrap.SubscriptionId