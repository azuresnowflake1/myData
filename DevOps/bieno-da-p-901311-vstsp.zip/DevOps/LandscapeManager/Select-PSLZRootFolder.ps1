param(
    [string] $adlStoreName,
    [string] $path
)

$PSLZRootFolders = Get-AzDataLakeStoreChildItem -Account $adlStoreName -Path $path | Select Name
$PSLZRootFolders += "No PSLZ Required"


if ($PSLZRootFolders.Count -eq 0) { 
    Write-Error "There are no folders under $path in $adlStoreName."
    return
}

if ($PSLZRootFolders.Count -eq 1) {
    return $PSLZRootFolders[0]
}
if ($PSLZRootFolders.Count -gt 1) {
    $PSLZRootFoldersCount = $PSLZRootFolders.Count
    Write-Host "Select Product Specific Landing Zone to use"
    for ($index = 1; $index -le $PSLZRootFoldersCount ; $index++) {
        $name = $PSLZRootFolders[$index - 1].Name
       if ($name -eq $null) {
            $name = "No PSLZ Required"
        }
        Write-Host "$index : $name"
    }
   
    do {
        $selectedItem = [int](Read-Host "Select PSLZ root Folder") 
        if ($selectedItem -le $PSLZRootFoldersCount -and $selectedItem -gt 0) {
            $PSLZRootFolder = $PSLZRootFolders[$selectedItem - 1].Name
            Write-Verbose "PSLZ selected is $PSLZRootFolder"
            return $PSLZRootFolders[$selectedItem - 1]
        }
        else {
            Write-Warning "Selection must be from 1 to $PSLZRootFoldersCount"            
        }
    }while ($selectedItem -gt $PSLZRootFoldersCount -or $selectedItem -lt 0)
}
