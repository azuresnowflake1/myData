Param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$parameterFile,

    [Parameter(Mandatory = $False, HelpMessage='The path in the data lake store to set permissions. Default is /')]
    [string]$path = "/"
)
# This only applies for ADLS Gen1
$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

$subscriptionId = $parameters.parameters.subscriptionId.value
$applicationId = $parameters.parameters.servicePrincipalId.value

$adlStoreName = $parameters.parameters.adlStoreName.value

$groupid = $parameters.parameters.dataOwnerADGroupId.value
Set-AzDataLakeStoreItemOwner -Account $adlStoreName -Path $path -Type Group -Id $groupid -ErrorAction SilentlyContinue
Set-AzDataLakeStoreItemOwner -Account $adlStoreName -Path $path -Type User -Id $applicationId -ErrorAction SilentlyContinue
