param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$parameterFile,
    
    [Parameter(Mandatory = $True, HelpMessage='The personal access token used to authorize vsts requests')]
    [String]$personalAccessToken
)

try
{
    $jsonStr = @"
    {
        "name": "",
        "description": "",
        "capabilities": 
        {
            "versioncontrol": 
            {
                "sourceControlType": ""
            },
            "processTemplate": 
            {
                "templateTypeId": ""
            }
        }
    }
"@
    $devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
    $utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

    & "$utilitiesFolder\Test-Login.ps1"
    $parameters = & "$utilitiesFolder\Get-Parameters.ps1" -parameterFile $parameterFile

    $vstsAccountName = $parameters.parameters.vstsAccountName.value
    $vstsProjectTemplateType = $parameters.parameters.vstsProjectTemplateType.value
    $vstsTeamProjectName = $parameters.parameters.vstsTeamProjectName.value
    $vstsSourceControlType = $parameters.parameters.vstsSourceControlType.value

    $patString = "{0}:{1}" -f "", $personalAccessToken
    $base64PatString =  [System.Convert]::ToBase64String([System.Text.Encoding]::ASCII.GetBytes($patString))

    $vstsURL = "https://{0}.visualstudio.com/DefaultCollection/_apis/projects?api-version=1.0" -f $vstsAccountName

    $vstsTeamProject = $jsonStr | ConvertFrom-JSON
    $vstsTeamProject.name = $vstsTeamProjectName
    
    if ("CMMI".ToLower().Equals($vstsProjectTemplateType.ToLower()))
    {
        $templateTypeId = "27450541-8e31-4150-9947-dc59f998fc01"
    }
    elseif ("Scrum".ToLower().Equals($vstsProjectTemplateType.ToLower()))
    {
        $templateTypeId = "6b724908-ef14-45cf-84f8-768b5384da45"
    }
    elseif ("Agile".ToLower().Equals($vstsProjectTemplateType.ToLower()))
    {
        $templateTypeId = "adcc42ab-9882-485e-a3ed-7678f01f66bc"        
    }
    else 
    {
        throw "Template type $vstsProjectTemplateType is not a recognized template in VSTS. Valid template types are CMMI or Scrum or Agile."    
    }
    Write-Verbose "Using $vstsProjectTemplateType template. Id is: $templateTypeId"
    $vstsTeamProject.capabilities.processTemplate.templateTypeId = $templateTypeId

    if (
        (
            "Git".ToLower().Equals($vstsSourceControlType.ToLower()) -or 
            "Tfvc".ToLower().Equals($vstsSourceControlType.ToLower())
        ) -eq $false
        ) 
    {
        throw "Template type $vstsSourceControlType is not a recognized template in VSTS. Valid types are Git or Tfvc."
    }
    $vstsTeamProject.capabilities.versioncontrol.sourceControlType = $vstsSourceControlType

    $body = $vstsTeamProject | ConvertTo-JSON

    $vstsURL = "https://dev.azure.com/{0}/_apis/projects/{1}?api-version=5.1" -f $vstsAccountName, $vstsTeamProject.name
    $params = @{    
        ContentType = 'application/json'
        Headers = @{
            'Authorization'="Basic $base64PatString"
        }
        Method = 'Get'    
        URI = $vstsURL
    }
    try { 
        $authZResponse =  Invoke-RestMethod @params
        Write-Output "Existing Team Project $vstsTeamProjectName state is $($authZResponse.State)"
        return
    }
    catch {
        if ($_.Exception.Response.StatusCode -eq "NotFound") {
            $params = @{    
                ContentType = 'application/json'
                Headers = @{
                    'Authorization'="Basic $base64PatString"
                }
                body = $body
                Method = 'Post'    
                URI = $vstsURL
            }
            Write-Verbose "Creating team project $vstsTeamProjectName"
            $authZResponse =  Invoke-RestMethod @params
        } else {
            throw
        }
    }
    
    do{
        try { 
            $vstsURL = "https://dev.azure.com/{0}/_apis/projects/{1}?api-version=5.1" -f $vstsAccountName, $vstsTeamProject.name
            $params = @{    
                ContentType = 'application/json'
                Headers = @{
                    'Authorization'="Basic $base64PatString"
                }
                Method = 'Get'    
                URI = $vstsURL
            }
            $authZResponse =  Invoke-RestMethod @params
            $vstsProjectState = $authZResponse.State
            Write-Output "Team Project $vstsTeamProjectName state is $($authZResponse.State)"
        }
        catch {
            Write-Output "Waiting for project to be created..."
        }
        if ($vstsProjectState -ne "wellFormed") {
            Start-Sleep -s 5
        }
        
    } while ($vstsProjectState -ne "wellFormed")    
    Write-Output "Team Project $vstsTeamProjectName is ready for use"
}catch
{
    Write-Host "StatusCode:" $_.Exception.Response.StatusCode.value__
    Write-Host "StatusDescription:" $_.Exception.Response.StatusDescription
    Write-Verbose "Failed to create team projects $vstsTeamProjectName"
    throw
}