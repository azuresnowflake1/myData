param
(
    [Parameter(Mandatory = $True, HelpMessage = "The project ITSG to create the parameter file")]
    [string]$projectNumber,

    [Parameter(Mandatory = $True, HelpMessage = "The environment this parameter file maps to.d=development,q=testing,u=preprod, b=uat, p=production, r=DR, x=DS or Experiment")]
    [ValidatePattern("^(d|q|u|p|b|x|r)$")]
    [string]$projectEnvironment = "d",

    [Parameter(Mandatory = $True, HelpMessage = "The dev project# to create the AD Groups")]
    [string]$devProjectNumber = $projectNumber,

    [Parameter(Mandatory = $True, HelpMessage = "The name of the project. Must be 8 characters wide and can contain only alphabets and/or numeric values.")]
    [string]$projectName,

    [Parameter(Mandatory = $True, HelpMessage = "The project cost centre tag. E.g. A956000702")]
    [string]$tagCostCentre,

    [Parameter(Mandatory = $True, HelpMessage = "The project international cost centre ICC tag. E.g. ICC11869.")]
    [string]$tagIcc,
    
    [Parameter(Mandatory = $False, HelpMessage = "The target subscription id if known. User will be prompted to select one otherwise.")]
    [string]$subscriptionId = $null,

    [Parameter(Mandatory = $false, HelpMessage = "Store a copy of the parameter file in landscape's BLOB account")]
    [switch]$backupParameterFile,    

    [Parameter(Mandatory = $False, HelpMessage = "The companyurl used to name resources")]
    [ValidatePattern("^[A-Za-z0-9]{1,11}$")]
    [string]$companyurl = "unilevercom",
    
    [Parameter(Mandatory = $False, HelpMessage = "The source file to use to create the new file. Use an existing parameter file that works.")]
    [string]$parameterTemplateFile = "Templates\parameters.template.json",

    [Parameter(Mandatory = $False, HelpMessage = "The source file to use to create the new file. Use an existing parameter file that works.")]
    [string]$overrideTemplateFile = "Templates\overrides.template.json",

    [Parameter(Mandatory = $False, HelpMessage = "The source file to use to create a default adls folders parameter file.")]
    [string]$foldersTemplateFile = "Templates\folders.template.json",

    [Parameter(Mandatory = $false, HelpMessage = "The name of the project service name tag. Must be 8 characters wide and can contain only alphabets and/or numeric values.")]
    [string]$tagServiceName = $projectName,

    [Parameter(Mandatory = $false, HelpMessage = "The tag value for the Tech 2.0 platform that owns the service.")]
    [string]$tagPlatform = "Core Data Ecosystem"
)

$teamProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName

$devOpsProjectFolder = "{0}\DevOps" -f (Get-Item -Path $teamProjectFolder).Parent.FullName
$managerFolder = "{0}\LandscapeManager" -f (Get-Item -Path $devOpsProjectFolder).FullName
$utilitiesFolder = "{0}\Utilities" -f (Get-Item -Path $devOpsProjectFolder).FullName

if (-not $Global:CtxBootStrap) {
    throw "Your powershell session is not initialsed to run the turnkey.  Call Set-GlobalScope and try again."
}
$namePrefix = $Global:CtxBootStrap.NamePrefix
$location = $Global:CtxBootStrap.Location
$tagOptInOptOut = "In"

$tenantId = $Global:CtxDeploy.tenant.id
# Unilever has introduced the concept of a "platform" to indentify the business owner of azure resources.
# Each platform has a two letter code that is included in component naming.  For I&A Eco System applications the
# platform is called "Core Data Eco System" denoted by the code DA. A platform can also have multiple subscriptions
# and so an NN suffix is required to fully identify it.
$platformG = "DA"
$platform = "$($platformG)$($Global:CtxBootStrap.SubscriptionNumber)"
$platformL = $platform.ToLower()

$envProjectEnvironment = $projectEnvironment
$envProjectNumber = $projectNumber
$envplatformL = $platformL

# networks is divided as prod (p) or non prod (n)
$networkEnvironment = "n"
# work out the name of the landscape group.  the dev group spans dev and qa, the prod spans pre-prod and prod
# shared environment project number is required to configure audit information
$cluster1TemplateFile = "DefaultDevCluster.json"
$cluster2TemplateFile = "DefaultDevHeavyCluster.json"
# A decision has been made to point all non prod environments at UDL's UAT environment
$udlProjectNumber = "80066"
$udlProjectEnvironment = "b"
$sharedStorageAccountName = "267bienobrunilevercomstg"
$managerADGroupName = "SEC-ES-DA-p-56728-azure-landscape"
$developerSharepointADGroupName = "SEC-ES-DA-p-56728-InA-Developer"
$storageAccountType = "Standard_LRS"
$adlStoreSku = "Standard_LRS"
$landscapeAutomationAccountName = $Global:CtxBootStrap.AutomationAccount
$landscapeAutomationResourceGroupName = $Global:CtxBootStrap.AutomationResourceGroupName
$databricksPricingTier = "standard"

if (-not $subscriptionId) {
    $subscriptionId = $Global:CtxDeploy.Subscription.Id
}

# This controls the naming of AAD User group names.  These are created when the d or x env is created
$userGroupNameEnvironment = "d"
switch ($projectEnvironment) { 
    "d" {
        $tagEnvironmentName = "Development"  
        #product specific landing zone - pdlz
        $pslzSubscriptionId = "50327adb-f8a0-4908-8d31-aa182df19f02"
        $pslzStoreResourceGroupName = "bieno-da-d-80011-stg-rg"
        #$pslzStoreName = "{0}{1}{2}{3}stgadls" -f "bieno", "da", $udlProjectEnvironment, $udlProjectNumber
        $pslzStoreName = "bienodad80011stgadls"
        $pslzADGroupPrefix = "SEC-ES-DA-d-80011-PSLZ-"
    }
    "q" {
        $tagEnvironmentName = "QA"
        #product specific landing zone - pdlz
        $pslzSubscriptionId = "50327adb-f8a0-4908-8d31-aa182df19f02"
        $pslzStoreResourceGroupName = "bieno-da-q-80013-stg-rg"
        #$pslzStoreName = "{0}{1}{2}{3}stgadls" -f "bieno", "da", $udlProjectEnvironment, $udlProjectNumber
        $pslzStoreName = "bienodaq80013stgadls"
        $pslzADGroupPrefix = "SEC-ES-DA-q-80013-PSLZ-"
    }
    "b" {
        $tagEnvironmentName = "Acceptance"
        #product specific landing zone - pdlz
        $pslzSubscriptionId = "204671af-5130-4ef5-819c-e314b65f9d06"
        $pslzStoreResourceGroupName = "bieno-da-b-80066-stg-rg"
        #$pslzStoreName = "{0}{1}{2}{3}stgadls" -f "bieno", "da", $udlProjectEnvironment, $udlProjectNumber
        $pslzStoreName = "bienodab80066stgadls"
        $pslzADGroupPrefix = "SEC-ES-DA-b-80066-PSLZ-"
    }
    "u" {
        $tagEnvironmentName = "PreProd"
        #product specific landing zone - pdlz
        $pslzSubscriptionId = "204671af-5130-4ef5-819c-e314b65f9d06"
        $pslzStoreResourceGroupName = "bieno-da-b-80066-stg-rg"
        $pslzStoreName = "bienodab80066stgadls"
        $pslzADGroupPrefix = "SEC-ES-DA-b-80066-PSLZ-"
    }
    "p" {
        $udlProjectNumber = "80010"
        $udlProjectEnvironment = "p"
        $sharedStorageAccountName = "162bienobrunilevercomstg"
        $tagEnvironmentName = "Production"
        $tagOptInOptOut = "Out"
        $networkEnvironment = "p"
        $cluster1TemplateFile = "DefaultPrdCluster.json"
        $cluster2TemplateFile = "DefaultPrdHeavyCluster.json"
        #product specific landing zone - pdlz
        $pslzSubscriptionId = "50327adb-f8a0-4908-8d31-aa182df19f02"
        $pslzStoreResourceGroupName = "bieno-da-p-80010-stg-rg"
        #$pslzStoreName = "{0}{1}{2}{3}stgadls" -f "bieno", "da", $udlProjectEnvironment, $udlProjectNumber
        $pslzStoreName = "bienodap80010stgadls"
        $pslzADGroupPrefix = "SEC-ES-DA-p-80010-PSLZ-"
        $adlStoreSku = "Standard_RAGRS"
        $databricksPricingTier = "premium"
    }
    "x"{
        $udlProjectNumber = "80010"
        $udlProjectEnvironment = "p"
        $sharedStorageAccountName = "162bienobrunilevercomstg"
        $tagEnvironmentName = "Experiment"
        $tagOptInOptOut = "Out"
        $userGroupNameEnvironment = "x"
        
        #product specific landing zone - pdlz
        $pslzSubscriptionId = ""
        $pslzStoreResourceGroupName = ""
        #$pslzStoreName = "{0}{1}{2}{3}stgadls" -f "bieno", "da", $udlProjectEnvironment, $udlProjectNumber
        $pslzStoreName = ""
        $pslzADGroupPrefix = ""
    }
    "r"{
        # DR Env: Connect to prod UDL; No PSLZ
        $udlProjectNumber = "80010"
        $udlProjectEnvironment = "p"
        $sharedStorageAccountName = "162bienobrunilevercomstg"
        $tagEnvironmentName = "DR"
        $tagOptInOptOut = "Out"
        #product specific landing zone - pdlz
        $pslzSubscriptionId = "50327adb-f8a0-4908-8d31-aa182df19f02"
        $pslzStoreResourceGroupName = "bieno-da-p-80010-stg-rg"
        #$pslzStoreName = "{0}{1}{2}{3}stgadls" -f "bieno", "da", $udlProjectEnvironment, $udlProjectNumber
        $pslzStoreName = "bienodap80010stgadls"
        $pslzADGroupPrefix = "SEC-ES-DA-p-80010-PSLZ-"

        #take the DR production parameters so reuse same SPNs, security groups etc.
        $productionParameterFile = "parameters.p.{0}.json" -f $projectNumber
        $productionParameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $productionParameterFile
        $envProjectEnvironment = $productionParameters.parameters.projectEnvironment.value
        $envProjectNumber = $productionParameters.parameters.projectNumber.value
        $envPlatformL = ($productionParameters.parameters.dataFactoryResourceGroupName.value).Split("-")[1]
        
        
        $databricksPricingTier = "premium"
    }
    default {
        Write-Error "Project Environment unknown. Use d for development, q for testing, b for UAT, u for pre-prod and p for production, r for DR, x for experiment or DS"  
    }
}

if ($marketEnvironment -and -not $tagEnvironmentName -match "Market") {
    $tagEnvironmentName = "{0} ({1})" -f $tagEnvironmentName, "Market"
}

# The vnet sub net details for the platform
$virtualNetworkResourceGroupName = "{0}-{1}-p-00000-Net-rg" -f $namePrefix, $platform
$vnetName = "{0}-{1}-p-vnet01" -f $namePrefix, $platform
$subnetName = "{0}-{1}-{2}-subnet01" -f $namePrefix, $platform, $networkEnvironment

# Test the vnet in this subscription
$vnet = Get-AzVirtualNetwork -Name $vnetName -ResourceGroupName $virtualNetworkResourceGroupName -ErrorAction SilentlyContinue

if (!$vnet) {
    # must have selected a different subscription
   # Write-Warning "The vNet details for this subscription could not be determined.  You must set them manually."
   # Write-Warning "The vNet should be name: $vnetName.  Expected to find it in resource group: $virtualNetworkResourceGroupName."
    $vnetName = "";
    $virtualNetworkResourceGroupName = ""
    $subnetName = ""
}

$landscapeDataFactoryResourceGroupName = $Global:CtxBootStrap.LandscapeAdfResourceGroupName
$landscapeDataFactoryName = $Global:CtxBootStrap.LandscapeAdfName
$landscapeDataFactorySelfHostedIRName = $Global:CtxBootStrap.LandscapeAdfName.Replace("-adf-01","-dfgw-master")

$tenantDomainName = "unilever.com"

# New naming including platform code
$servicePrincipalName = "svc-b-{0}-{1}-{2}-ina-aadprincipal" -f $platformG.ToLower(), $envProjectEnvironment, $envProjectNumber
$adApplicationUri = "http://{0}{1}{2}{3}inaaadprincipal" -f $namePrefix, $platformL, $envProjectEnvironment, $envProjectNumber
$applicationIdentityCertificateName = "svc-b-{0}-{1}-{2}-ina-aadprincipalCert" -f $platformL, $envProjectEnvironment, $envProjectNumber

$deploymentAdApplicationName = "svc-b-{0}-{1}-{2}-ina-deployment" -f $platformG.ToLower(), $envProjectEnvironment, $envProjectNumber
$deploymentAdApplicationUri = "http://{0}{1}{2}{3}inadeploymentapp" -f $namePrefix, $platformL, $envProjectEnvironment, $envProjectNumber

$developerADGroupName = "SEC-ES-{0}-{1}-{2}-azure-developer" -f $platformG, $userGroupNameEnvironment, $devProjectNumber
$testerADGroupName = "SEC-ES-{0}-{1}-{2}-azure-tester" -f $platformG, $userGroupNameEnvironment, $devProjectNumber
$projectAdminADGroupName = "SEC-ES-{0}-{1}-{2}-ProjectAdmins" -f $platformG, $userGroupNameEnvironment, $devProjectNumber
$supportLevel1ADGroupName = "SEC-ES-{0}-{1}-{2}-azure-support" -f $platformG, $userGroupNameEnvironment, $devProjectNumber
$dataScientistADGroupName = "SEC-ES-{0}-{1}-{2}-azure-DataScientist" -f $platformG, $userGroupNameEnvironment, $devProjectNumber
$dataEngineerADGroupName = "SEC-ES-{0}-{1}-{2}-azure-DataEngineer" -f $platformG, $userGroupNameEnvironment, $devProjectNumber

# read access to data in all components
$dataReaderADGroupName = "SEC-ES-{0}-{1}-{2}-azure-data-reader" -f $platformG, $envProjectEnvironment, $envProjectNumber
$dataWriterADGroupName = "SEC-ES-{0}-{1}-{2}-azure-data-writer" -f $platformG, $envProjectEnvironment, $envProjectNumber
$dataOwnerADGroupName = "SEC-ES-{0}-{1}-{2}-azure-data-owner" -f $platformG, $envProjectEnvironment, $envProjectNumber
# reader access at RG level
$supportADGroupName = "SEC-ES-{0}-{1}-{2}-azure-devops" -f $platformG, $userGroupNameEnvironment, $devProjectNumber

$applicationResourceGroupName = "{0}-{1}-{2}-{3}-rg" -f $namePrefix, $platformL, $projectEnvironment, $projectNumber
$envapplicationResourceGroupName = "{0}-{1}-{2}-{3}-rg" -f $namePrefix, $envplatformL, $envProjectEnvironment, $envProjectNumber
$landscapeResourceGroupName = $Global:CtxBootStrap.LandscapeResourceGroupName
$machineLearningResourceGroupName  = "{0}-{1}-{2}-{3}-rg" -f $namePrefix, $platformL, $projectEnvironment, $projectNumber

# 24 char limit
$landscapeKeyVaultName = $Global:CtxBootStrap.KeyVaultName
$sharedStorageResourceGroupName = "{0}-{1}-{2}-{3}-stg-rg" -f "bieno", "da", $udlProjectEnvironment, $udlProjectNumber

$adlStoreName = "dbstorage{0}{1}{2}adls" -f $platformL, $projectEnvironment, $projectNumber
$adlStoreNameSecondary = "{0}-secondary" -f $adlStoreName
$adlStoreNameGen1 = "{0}stunilever{1}{2}" -f $namePrefix, $platformL, $projectNumber

# Handling for ITSG greater than 5 digits
if ($projectNumber.length -lt 6) {
    $adlStoreNameGen1 = "{0}stunilever{1}{2}" -f $namePrefix, $platformL, $projectNumber
}
else{
    $adlStoreNameGen1 = "{0}stunileve{1}{2}" -f $namePrefix, $platformL, $projectNumber
}

$adlshdinmountpoint = "/" -f $namePrefix, $platformL, $projectEnvironment, $projectNumber
$adlStoreFoldersFile = "folders.{0}.{1}.json" -f $projectEnvironment, $projectNumber
$udlAdlStoreName = "{0}{1}{2}{3}stgadls" -f $namePrefix, "da", $udlProjectEnvironment, $udlProjectNumber
$redisCacheName = "{0}-{1}-{2}-{3}-RC-01" -f $namePrefix, $platformL, $projectEnvironment, $projectNumber
# 24 char limit
# Handling for ITSG greater than 5 digits
if ($projectNumber.length -lt 6) {
    $keyVaultName = "{0}-{1}-{2}-{3}-kv-01" -f $namePrefix, $platformL, $projectEnvironment, $projectNumber
    $keyVaultNameWA = "{0}-{1}-{2}-{3}-kv-09" -f $namePrefix, $platformL, $projectEnvironment, $projectNumber
    $machineLearningKeyVaultName = "{0}-{1}-{2}-{3}-kv-02" -f $namePrefix, $platformL, $projectEnvironment, $projectNumber
}
else{
    $keyVaultName = "{0}-{1}-{2}-{3}-kv01" -f $namePrefix, $platformL, $projectEnvironment, $projectNumber
    $keyVaultNameWA = "{0}-{1}-{2}-{3}-kv09" -f $namePrefix, $platformL, $projectEnvironment, $projectNumber
    $machineLearningKeyVaultName = "{0}-{1}-{2}-{3}-kv02" -f $namePrefix, $platformL, $projectEnvironment, $projectNumber
}

$adlAnalyticsName = "{0}{1}{2}{3}appadla" -f $namePrefix, $platformL, $projectEnvironment, $projectNumber
$sqlServerName = "{0}-{1}-{2}-{3}-{4}-sql-01" -f $namePrefix, $platformL, $projectEnvironment, $projectNumber, $companyurl
$sqlDatabaseName = "{0}-{1}-{2}-{3}-{4}-sqldb-01" -f $namePrefix, $platformL, $projectEnvironment, $projectNumber, $companyurl
$sqlDataWarehouseName = "{0}-{1}-{2}-{3}-{4}-sqldw-01" -f $namePrefix, $platformL, $projectEnvironment, $projectNumber, $companyurl
$dataFactoryName = "{0}-{1}-{2}-{3}-adf-01" -f $namePrefix, $platformL, $projectEnvironment, $projectNumber
$dataFactoryRootParameterFileName = "landscape.adf.{0}.{1}.{2}.json" -f $platformL, $projectEnvironment, $projectNumber
# on prem self hosted IR name
$dataFactoryGatewayName = "dfgw-onprem"
# IaaS prem self hosted IR name
$batchAccountName = "{0}{1}{2}{3}appban" -f $namePrefix, $platformL, $projectEnvironment, $projectNumber
$batchPoolName = "{0}{1}{2}{3}appbap" -f $namePrefix, $platformL, $projectEnvironment, $projectNumber
$clusterStorageAccountResourceGroupName = $applicationResourceGroupName
$clusterResourceGroupName = $applicationResourceGroupName
$clusterName = "{0}-{1}-{2}-{3}-{4}-hdi-01" -f $namePrefix, $platformL, $projectEnvironment, $projectNumber, $companyurl
$analysisServicesName = "{0}{1}{2}{3}{4}as01" -f $namePrefix, $platformL, $projectEnvironment, $projectNumber, $companyurl
$analysisServicesResourceGroupName = $applicationResourceGroupName
$azureSSISResourceGroupName = $applicationResourceGroupName
$azureSSISName = "{0}-{1}-{2}-{3}-{4}-ssis-01" -f $namePrefix, $platformL, $projectEnvironment, $projectNumber, $companyurl
$azureSSISDBServerEndpoint = "{0}.database.windows.net" -f $sqlServerName
$iotHubResourceGroupName = $applicationResourceGroupName
$iotHubName = "{0}-{1}-{2}-{3}-{4}-iot-01" -f $namePrefix, $platformL, $projectEnvironment, $projectNumber, $companyurl
$tsInsightsResourceGroupName = $applicationResourceGroupName
$tsInsightsName = "{0}-{1}-{2}-{3}-{4}-tsi-01" -f $namePrefix, $platformL, $projectEnvironment, $projectNumber, $companyurl
$appContributorGroupName = "SEC-ES-{0}-{1}-{2}-azurecontributor" -f $platformG, $envProjectEnvironment, $envProjectNumber
$webAppResourceGroupName = $applicationResourceGroupName
$functionAppName = "{0}-{1}-{2}-{3}-{4}-funapp-01"  -f $namePrefix, $platformL, $projectEnvironment, $projectNumber, $companyurl
$logAnalyticsWorkspaceName = "{0}-{1}-{2}-{3}-loganalytics-01" -f $namePrefix, $platformL, $projectEnvironment, $projectNumber 

$machineLearningWorkspaceName = "{0}-{1}-{2}-{3}-aml-01" -f $namePrefix, $platformL, $projectEnvironment, $projectNumber 
$machineLearningComputeClusterName = "aml-compute-01"
$machineLearningComputeIdleSecondsBeforeScaleDown = "300"
$machineLearningComputeMaxNodes = "2"
$machineLearningComputeMinNodes = "0"
$machineLearningComputeVmSize = "STANDARD_DS2_V2"
$machineLearningExperimentName = "{0}-{1}-{2}-{3}-aml-experiment-01" -f $namePrefix, $platformL, $projectEnvironment, $projectNumber 
$machineLearningModelName = "aml-model-01" 
$machineLearningModelGitFolder = "Model01"
$machineLearningAKSClusterName = "aml-aks-01"
$machineLearningACIInstance = "aml-aci-01"
$applicationInsightsName = "{0}-{1}-{2}-{3}-appin-01" -f $namePrefix, $platformL, $projectEnvironment, $projectNumber 
$containerRegistryName = "{0}{1}{2}crn" -f $namePrefix, $platformL, $projectNumber

$budgetAlertName = "{0}-{1}-{2}-{3}-budget-rg" -f $namePrefix, $platformL, $projectEnvironment, $projectNumber
$logicAppName = "{0}-{1}-{2}-{3}-logicapp-01" -f $namePrefix, $platformL, $projectEnvironment, $projectNumber
$logicAppDatalakeapiConnection = "{0}-{1}-{2}-{3}-logicapp-datalake-01" -f $namePrefix, $platformL, $projectEnvironment, $projectNumber
$logicAppDatalakeapiConnectionDisplay = "{0}-{1}-{2}-{3}-logicapp-datalake-01" -f $namePrefix, $platformL, $projectEnvironment, $projectNumber
$logicAppO365apiConnection = "{0}-{1}-{2}-{3}-logicapp-o365-01" -f $namePrefix, $platformL, $projectEnvironment, $projectNumber
$logicAppSqlDWapiConnection = "{0}-{1}-{2}-{3}-logicapp-sqldw-01" -f $namePrefix, $platformL, $projectEnvironment, $projectNumber
$logicAppSqlDWapiConnectionDisplay = "{0}-{1}-{2}-{3}-logicapp-sqldw-01" -f $namePrefix, $platformL, $projectEnvironment, $projectNumber
$logicAppSqlapiConnection = "{0}-{1}-{2}-{3}-logicapp-sql-01" -f $namePrefix, $platformL, $projectEnvironment, $projectNumber
$logicAppSqlapiConnectionDisplay = "{0}-{1}-{2}-{3}-logicapp-sql-01" -f $namePrefix, $platformL, $projectEnvironment, $projectNumber
$azuremonitorlogs_name = "{0}-{1}-{2}-{3}-logicapp-monitorlogs-01" -f $namePrefix, $platformL, $projectEnvironment, $projectNumber
$azuremonitorlogs_DisplayName = "{0}-{1}-{2}-{3}-logicapp-monitorlogs-01" -f $namePrefix, $platformL, $projectEnvironment, $projectNumber
$apiconnection_adlsgen2_name = "{0}-{1}-{2}-{3}-logicapp-adlsgen2-01" -f $namePrefix, $platformL, $projectEnvironment, $projectNumber

$streamAnalyticsJobResourceGroupName  = $applicationResourceGroupName
$streamAnalyticsJobName  = "{0}-{1}-{2}-{3}-strmanlytjob-01" -f $namePrefix, $platformL, $projectEnvironment, $projectNumber
$numberOfStreamingUnits  = "1"

if ("dx".Contains($projectEnvironment)) {
    # Let Developers, DevOps and Landscape be ADAdmin
    $sqlServerAdminGroupName = $appContributorGroupName
} else {
    $sqlServerAdminGroupName = $managerADGroupName
}

$appReaderGroupName = "SEC-ES-{0}-{1}-{2}-azurereader" -f $platformG, $envprojectEnvironment, $envprojectNumber
$dataReaderGroupName = $appReaderGroupName
$stgReaderGroupName = $appReaderGroupName

$databrickWorkspaceName = "{0}-{1}-{2}-{3}-adb-01" -f $namePrefix, $platformL, $projectEnvironment, $projectNumber

$paramTemplateFile = "{0}\{1}" -f $devOpsProjectFolder, $parameterTemplateFile
$overrideTemplateFile = "{0}\{1}" -f $devOpsProjectFolder, $overrideTemplateFile
$cluster1TemplatePath = "{0}\Templates\{1}" -f $devOpsProjectFolder, $cluster1TemplateFile
$cluster2TemplatePath = "{0}\Templates\{1}" -f $devOpsProjectFolder, $cluster2TemplateFile
Write-Verbose "Parameter Template file : $paramTemplateFile"
Write-Verbose "Overrides Template file : $overrideTemplateFile"
$parameters = Get-Content -Path $paramTemplateFile -Raw | ConvertFrom-JSON
$overrides = Get-Content -Path $overrideTemplateFile -Raw | ConvertFrom-JSON
$databricksCluster1 = Get-Content -Path $cluster1TemplatePath -Raw | ConvertFrom-JSON
$databricksCluster2 = Get-Content -Path $cluster2TemplatePath -Raw | ConvertFrom-JSON
$appServicePlanName = "{0}-{1}-{2}-{3}-serviceplan-01" -f $namePrefix, $platformL, $projectEnvironment, $projectNumber 
$webAppName =  "{0}-{1}-{2}-{3}-webapi-01" -f $namePrefix, $platformL, $projectEnvironment, $projectNumber

$foldersTemplateFileFullPath = "{0}\{1}" -f $devOpsProjectFolder, $foldersTemplateFile
Write-Verbose "Parameter Template file : $foldersTemplateFileFullPath"


function Set-PSLZ {
    param (
        [string]$pPSLZPath, [string] $ppslzStoreName 
    )
    
        $PSLZRootFolder = & "$managerFolder\Select-PSLZRootFolder.ps1" -path $PSLZpath -adlStoreName $pslzStoreName
            if($PSLZRootFolder.Name -ne $null)
                {            
                $pslzFolderName = $PSLZpath + "/" + $($PSLZRootFolder.Name) + "/" + $tagServiceName.Replace(" ", "_")
                $pslzADGroupName = $pslzADGroupPrefix + $($PSLZRootFolder.Name)
                }
            else{
                #PSLZ storage folder not required - set all downstream PSLZ parameters empty strings
                $pslzFolderName = ""
                $pslzADGroupName = "Not Set"
                $pslzStoreName = ""
                $pslzStoreResourceGroupName = ""
                $pslzSubscriptionId = ""
            }
    [hashtable]$Return = @{} 
    $Return.pslzFolderName = $pslzFolderName
    $Return.pslzADGroupName = $pslzADGroupName
    $Return.pslzStoreName = $pslzStoreName
    $Return.pslzStoreResourceGroupName = $pslzStoreResourceGroupName
    $Return.pslzSubscriptionId = $pslzSubscriptionId
    return $Return
}

$PSLZpath = "/Unilever/PSLZ"
if($projectEnvironment -eq "d"){
    $PSLZ = Set-PSLZ -pPSLZPath $PSLZpath -ppslzStoreName $pslzStoreName
    $pslzFolderName = $PSLZ.pslzFolderName
    $pslzADGroupName = $PSLZ.pslzADGroupName  
    $pslzStoreName = $PSLZ.pslzStoreName
    $pslzStoreResourceGroupName = $PSLZ.pslzStoreResourceGroupName
    $pslzSubscriptionId = $PSLZ.pslzSubscriptionId
} elseif($projectEnvironment -eq "x"){ 
    # PSLZ does not apply to experiments
} else {
    $DevParameterFile = "d.$devProjectNumber"
    $DevParameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $DevParameterFile
    $pslzFolderName = $DevParameters.parameters.pslzFolderName.value
    $pslzADGroupName = $DevParameters.parameters.pslzADGroupName.value
    
    If ([string]::IsNullOrEmpty($DevParameters.parameters.pslzADGroupName.value)) {
               Write-Error "PSLZ folder not selected for development parameter file. Please regenerate the project development parameter file"
                return $null
        }
    else {
    $pslzDevADGroupName = $pslzADGroupName    
    $pslzDevADGroupArray = $pslzDevADGroupName.Split("-")
    $pzlsfunctionalarea = $pslzDevADGroupArray[$pslzDevADGroupArray.count -1 ]
    $pslzADGroupName = $pslzADGroupPrefix + $pzlsfunctionalarea
    }
}
function Get-Parameter {
    param(
        [PSCustomObject]$param, [string] $name
    )
    $x = $param.parameters | Select-Object -ExpandProperty $name
    return $x
}


function Select-ADApplication {
    param(
        [string]$appName
    )
    $adApplications = Get-AzADApplication -DisplayNameStartWith $appName -ErrorAction SilentlyContinue
    if ($adApplications.Count -eq 1) {
        $appId = $adApplications.ApplicationId
        return $appId
    }
    if ($adApplications.Count -gt 1) {
        Write-Host "Select the Azure AD Application to use"
        $subCount = $adApplications.Count
        for ($index = 1; $index -le $subCount ; $index++) {
            $name = $adApplications[$index - 1].DisplayName
            Write-Host "$index : $name"
        }
        do {
            $selectedItem = Read-Host "Select Azure AD Application" 
            if ($selectedItem -le $subCount -and $selectedItem -gt 0) {
                $appId = $adApplications[$selectedItem - 1].ApplicationId
                $displayName = $adApplications[$selectedItem - 1].DisplayName
                Write-Verbose "AD Application $displayName selected is $appId"
                return $appId
            }
            else {
                Write-Error "Selection must be from 1 to $subCount"
                return $null
            }
        }while ($selectedItem -gt $subCount -or $selectedItem -lt 0)
    }
    return $null
}

function Select-ADServicePrincipal {
    param(
        [string]$spName
    )
    $adServicePrincipals = Get-AzADServicePrincipal -SearchString $spName -ErrorAction SilentlyContinue
    if ($adServicePrincipals.Count -eq 1) {
        $spId = $adServicePrincipals.Id
        return $spId
    }
    if ($adServicePrincipals.Count -gt 1) {
        Write-Host "Select the Azure AD ServicePrincipal to use"
        $subCount = $adServicePrincipals.Count
        for ($index = 1; $index -le $subCount ; $index++) {
            $name = $adServicePrincipals[$index - 1].DisplayName
            Write-Host "$index : $name"
        }
        do {
            $selectedItem = Read-Host "Select Azure AD ServicePrincipal" 
            if ($selectedItem -le $subCount -and $selectedItem -gt 0) {
                $spId = $adServicePrincipals[$selectedItem - 1].Id
                $displayName = $adServicePrincipals[$selectedItem - 1].DisplayName
                Write-Verbose "AD ServicePrincipal $displayName selected is $appId"
                return $spId
            }
            else {
                Write-Error "Selection must be from 1 to $subCount"
                return $null
            }
        }while ($selectedItem -gt $subCount -or $selectedItem -lt 0)

    }
    return $null
}

function Copy-Property{
    [CmdletBinding()]
    param([Parameter(ValueFromPipeline=$true)]$InputObject,
          $SourceObject,
          [string[]]$Property,
          [switch]$Passthru)
     
          $passthruHash=@{Passthru=$passthru.IsPresent}
         
          $propHash=@{}
          $property | Foreach-Object {
                        $propHash+=@{$_=$SourceObject.$_}
                      }
          $inputObject | Add-Member -NotePropertyMembers $propHash @passthruHash
}

Write-Verbose "AD Application Name is $servicePrincipalName"
$applicationId = Select-ADApplication -appName $servicePrincipalName
Write-Verbose "AD Application Id is: $applicationId"
if (!$applicationId) {
    Write-Warning "The Azure AD Application Id is null. It needs to be manually added to the parameter file."
} 
$servicePrincipalId = Select-ADServicePrincipal -spName $servicePrincipalName
Write-Verbose "Service Principal Id is: $servicePrincipalId"
if (!$servicePrincipalId) {
    Write-Warning "The Service Principal Id is null. It needs to be manually added to the parameter file."
}

# Repeat for the deployment app and SPN
Write-Verbose "AD Deployment Application Name is $deploymentAdApplicationName"
$deploymentApplicationId = Select-ADApplication -appName $deploymentAdApplicationName
Write-Verbose "AD Deployment Application Id is: $deploymentApplicationId"
if (!$deploymentApplicationId) {
    Write-Warning "The Azure Deployment AD Application Id is null. It needs to be manually added to the parameter file."
}

$deploymentServicePrincipalId = Select-ADServicePrincipal -spName $deploymentAdApplicationName
Write-Verbose "Deployment Service Principal Id is: $deploymentServicePrincipalId"
if (!$deploymentServicePrincipalId) {
    Write-Warning "The Deployment Service Principal Id is null. It needs to be manually added to the parameter file."
}
$appGroups = @()
$appGroups += Get-AzADGroup -DisplayNameStartsWith ("SEC-ES-DA-{0}-{1}-azure" -f $userGroupNameEnvironment, $devProjectNumber)
$appGroups += Get-AzADGroup -DisplayNameStartsWith ("SEC-ES-DA-{0}-{1}-ProjectAdmins" -f "d", $devProjectNumber)
if ($projectEnvironment -ne "d") {
    # get the environment non functional groups
    $appGroups += Get-AzADGroup -DisplayNameStartsWith ("SEC-ES-DA-{0}-{1}-azure" -f $envProjectEnvironment, $envProjectNumber)
    $appGroups += Get-AzADGroup -DisplayNameStartsWith "SEC-ES-DA-p-56728-azure"
}

function Get-AdGroup
{
    param($DisplayName)
    foreach ($group in $appgroups){
        if ($group.DisplayName -eq $DisplayName) {
            return $group
        }
    }
    return @{
        Id=""
    }
}

$gp = Get-ADGroup -DisplayName $sqlServerAdminGroupName
$sqlServerAdminGroupObjectId = $gp.Id
$gp1 = Get-ADGroup -DisplayName $developerADGroupName
$developerADGroupId = $gp1.Id
$gp2 = Get-AzADGroup -DisplayName $managerADGroupName
$managerADGroupId = $gp2.Id
$gp3 = Get-ADGroup -DisplayName $testerADGroupName
$testerADGroupId = $gp3.Id
$gp4 = Get-ADGroup -DisplayName $dataReaderADGroupName
$dataReaderADGroupId = $gp4.Id
$gp5 = Get-ADGroup -DisplayName $dataWriterADGroupName
$dataWriterADGroupId = $gp5.Id
$gp6 = Get-ADGroup -DisplayName $supportADGroupName
$supportADGroupId = $gp6.Id
$gp7 = Get-ADGroup -DisplayName $appContributorGroupName
$appContributorADGroupId = $gp7.Id
$gp8 = Get-ADGroup -DisplayName $appReaderGroupName
$appReaderADGroupId = $gp8.Id
$gp9 = Get-ADGroup -DisplayName $dataOwnerADGroupName
$dataOwnerADGroupId = $gp9.Id
$gp10 = Get-AzADGroup -DisplayName $developerSharepointADGroupName
$developerSharepointADGroupId = $gp10.Id
$gp11 = Get-ADGroup -DisplayName $projectAdminADGroupName
$projectAdminADGroupId = $gp11.Id
$gp12 = Get-ADGroup -DisplayName $supportLevel1ADGroupName
$supportLevel1ADGroupId = $gp12.Id

$gp13 = Get-ADGroup -DisplayName $dataScientistADGroupName
$dataScientistADGroupId = $gp13.Id
$gp14 = Get-ADGroup -DisplayName $dataEngineerADGroupName
$dataEngineerADGroupId = $gp14.Id

$auto=Get-AzAutomationConnection -ResourceGroupName $landscapeAutomationResourceGroupName -AutomationAccountName $landscapeAutomationAccountName -Name "AzureRunAsConnection" -DefaultProfile $Global:CtxAuto
if ($auto) {
    $landscapeAutomationAccountApplicationId = $auto.FieldDefinitionValues["ApplicationId"]
    $autoSpn=Get-AzADServicePrincipal -ApplicationId $landscapeAutomationAccountApplicationId -First 1
    $landscapeAutomationAccountObjectId = $autoSpn.Id
} else {
    Write-Error "Unable to determine the automation account SPN credential for account: '$landscapeAutomationAccountName'"
}

$analysisServicesAdminEmailId = "obj:{0}@{1}" -f $managerADGroupId, $tenantId
$analysisServicesAdminEmailId += ",obj:{0}@{1}" -f $appContributorADGroupId, $tenantId
# include the application SPN as an AAS admin so it can process the cube
$analysisServicesAdminEmailId += ",app:{0}@{1}" -f $applicationId, $tenantId
if ($projectEnvironment -eq "q") { 
    # Let developers and tester process cubes in qa
    $analysisServicesAdminEmailId += ",obj:{0}@{1}" -f $developerADGroupId, $tenantId
    $analysisServicesAdminEmailId += ",obj:{0}@{1}" -f $testerADGroupId, $tenantId
    $analysisServicesAdminEmailId += ",obj:{0}@{1}" -f $supportADGroupId, $tenantId
} elseif ($projectEnvironment -eq "p") { 
    # Let devops process cubes in prod
    $analysisServicesAdminEmailId += ",obj:{0}@{1}" -f $supportADGroupId, $tenantId
}
function Select-AzStorageAccount {
    param(
        [string]$storageAccountResourceGroupName
    )
    $storageAccounts = Get-AzStorageAccount -ResourceGroupName $storageAccountResourceGroupName -DefaultProfile $Global:CtxBootstrap.DefaultProfile -ErrorAction SilentlyContinue | Where-Object { -not $_.StorageAccountName.Contains("adls")} 
    if ($storageAccounts.Count -eq 1) {
        return $storageAccounts.StorageAccountName
    }
    if ($storageAccounts.Count -gt 1) {
        Write-Host "Select the Azure Storage Account to use"
        $subCount = $storageAccounts.Count
        for ($index = 1; $index -le $subCount ; $index++) {
            $name = $storageAccounts[$index - 1].StorageAccountName
            Write-Host "$index : $name"
        }
        do {
            $selectedItem = Read-Host "Select Azure Storaage Account" 
            if ($selectedItem -le $subCount -and $selectedItem -gt 0) {
                $stgName = $storageAccounts[$selectedItem - 1].StorageAccountName
                Write-Verbose "Storage account selected is $stgName"
                return $stgName
            }
            else {
                Write-Warning "Selection must be from 1 to $subCount"
                # throw
            }
        }while ($selectedItem -gt $subCount -or $selectedItem -lt 0)
    }
    return $null
}
$storageAccountName = Select-AzStorageAccount -storageAccountResourceGroupName $applicationResourceGroupName
if (-not $storageAccountName) {
    $storageAccountName = "dbstorage{0}{1}{2}" -f $platformL, $projectEnvironment, $projectNumber
}
$landscapeStorageAccountName = Select-AzStorageAccount -storageAccountResourceGroupName $landscapeResourceGroupName
if (-not $landscapeStorageAccountName) {
    $storageAccountName = "{0}stunilever{1}{2}" -f $namePrefix, $platformL, $projectNumber
}

$auditStorageAccountResourceGroupName = $applicationResourceGroupName
$auditStorageAccountName = $storageAccountName
$adlStoreResourceGroupName = $envApplicationResourceGroupName
$sharedAdlStoreResourceGroupName = $sharedStorageResourceGroupName
$dataFactoryLoggingStorageAccountResourceGroupName = $applicationResourceGroupName
$dataFactoryLoggingStorageAccountName = $storageAccountName

$databricksCluster1.custom_tags.project = $projectName
$databricksCluster1.custom_tags.support_team = "SEC-ES-DA-p-56728-Landscape@unilever.com"

$clusterStorageAccountName = $storageAccountName
$tagValues = @{
    "tagCostCentre"  = $tagCostCentre;
    "tagIcc"         = $tagIcc;
    "tagEnvironment" = $tagEnvironmentName;
    "tagServiceName" = $tagServiceName;
    "tagPlatform"    = $tagPlatform;
    "tagOptInOptOut" = $tagOptInOptOut;
}

$parameters.parameters.pslzFolderName.value = $pslzFolderName
$parameters.parameters.pslzADGroupName.value = $pslzADGroupName
$parameters.parameters.subscriptionId.value = $subscriptionId
$parameters.parameters.tenantId.value = $tenantId
$parameters.parameters.location.value = $location
$parameters.parameters.tenantDomainName.value = $tenantDomainName
$parameters.parameters.applicationId.value = $applicationId
$parameters.parameters.landscapeResourceGroupName.value = $landscapeResourceGroupName
$parameters.parameters.landscapeStorageAccountName.value = $landscapeStorageAccountName
$parameters.parameters.landscapeKeyVaultName.value = $landscapeKeyvaultName
$parameters.parameters.landscapeAutomationResourceGroupName.value = $landscapeAutomationResourceGroupName
$parameters.parameters.landscapeAutomationAccountName.value = $landscapeAutomationAccountName
$parameters.parameters.landscapeAutomationAccountApplicationId.value = $landscapeAutomationAccountApplicationId
$parameters.parameters.landscapeAutomationAccountObjectId.value = $landscapeAutomationAccountObjectId

$parameters.parameters.landscapeDataFactoryResourceGroupName.value = $landscapeDataFactoryResourceGroupName
$parameters.parameters.landscapeDataFactoryName.value = $landscapeDataFactoryName
$parameters.parameters.landscapeDataFactorySelfHostedIRName.value = $landscapeDataFactorySelfHostedIRName
$parameters.parameters.keyVaultResourceGroupName.value = $landscapeResourceGroupName
$parameters.parameters.keyVaultName.value = $keyVaultName
$parameters.parameters.keyVaultNameWA.value = $keyVaultNameWA
$parameters.parameters.redisCacheName.value = $redisCacheName
$parameters.parameters.servicePrincipalId.value = $servicePrincipalId
$parameters.parameters.deploymentApplicationId.value = $deploymentApplicationId
$parameters.parameters.deploymentServicePrincipalId.value = $deploymentServicePrincipalId
$parameters.parameters.keyVaultAuditStorageAccountResourceGroupName.value = $auditStorageAccountResourceGroupName
$parameters.parameters.keyVaultAuditStorageAccountName.value = $auditStorageAccountName
$parameters.parameters.storageAccountResourceGroupName.value = $applicationResourceGroupName
$parameters.parameters.storageAccountName.value = $storageAccountName
$parameters.parameters.storageAccountType.value = $storageAccountType
$parameters.parameters.adlStoreResourceGroupName.value = $adlStoreResourceGroupName
$parameters.parameters.adlStoreName.value = $adlStoreName
$parameters.parameters.adlStoreNameSecondary.value = $adlStoreNameSecondary
$parameters.parameters.adlStoreSku.value = $adlStoreSku
$parameters.parameters.adlStoreNameGen1.value = $adlStoreNameGen1

$parameters.parameters.adlStoreFoldersFile.value = $adlStoreFoldersFile
$parameters.parameters.sharedStorageAccountResourceGroupName.value = $sharedStorageResourceGroupName
$parameters.parameters.sharedStorageAccountName.value = $sharedStorageAccountName
$parameters.parameters.sharedAdlStoreResourceGroupName.value = $sharedAdlStoreResourceGroupName
$parameters.parameters.sharedAdlStoreName.value = $udlAdlStoreName
#PSLZ
$parameters.parameters.pslzSubscriptionId.value = $pslzSubscriptionId
$parameters.parameters.pslzStoreResourceGroupName.value = $pslzStoreResourceGroupName 
$parameters.parameters.pslzStoreName.value = $pslzStoreName

$parameters.parameters.adlAnalyticsResourceGroupName.value = $applicationResourceGroupName
$parameters.parameters.adlAnalyticsName.value = $adlAnalyticsName
$parameters.parameters.sqlServerResourceGroupName.value = $applicationResourceGroupName
$parameters.parameters.sqlServerName.value = $sqlServerName
$parameters.parameters.sqlServerAdminGroupName.value = $sqlServerAdminGroupName
$parameters.parameters.sqlServerAdminGroupObjectId.value = $sqlServerAdminGroupObjectId
$parameters.parameters.sqlServerAuditStorageAccountResourceGroupName.value = $auditStorageAccountResourceGroupName
$parameters.parameters.sqlServerAuditStorageAccountName.value = $auditStorageAccountName
$parameters.parameters.sqlDatabaseName.value = $sqlDatabaseName
$parameters.parameters.sqlDataWarehouseName.value = $sqlDataWarehouseName
$parameters.parameters.dataFactoryResourceGroupName.value = $applicationResourceGroupName
$parameters.parameters.dataFactoryName.value = $dataFactoryName
$parameters.parameters.dataFactoryRootParameterFileName.value = $dataFactoryRootParameterFileName
$parameters.parameters.dataFactoryLoggingStorageAccountResourceGroupName.value = $dataFactoryLoggingStorageAccountResourceGroupName
$parameters.parameters.dataFactoryLoggingStorageAccountName.value = $dataFactoryLoggingStorageAccountName
$parameters.parameters.dataFactoryGatewayName.value = $dataFactoryGatewayName
$parameters.parameters.batchAccountResourceGroupName.value = $applicationResourceGroupName
$parameters.parameters.batchAccountName.value = $batchAccountName
$parameters.parameters.batchPoolName.value = $batchPoolName
$parameters.parameters.adApplicationName.value = $servicePrincipalName
$parameters.parameters.deploymentAdApplicationName.value = $deploymentAdApplicationName
$parameters.parameters.adApplicationUri.value = $adApplicationUri
$parameters.parameters.deploymentAdApplicationUri.value = $deploymentAdApplicationUri
$parameters.parameters.clusterResourceGroupName.value = $clusterResourceGroupName
$parameters.parameters.clusterName.value = $clusterName
$parameters.parameters.clusterStorageAccountResourceGroupName.value = $clusterStorageAccountResourceGroupName
$parameters.parameters.clusterStorageAccountName.value = $clusterStorageAccountName
$parameters.parameters.projectName.value = $projectName
$parameters.parameters.projectNumber.value = $projectNumber
$parameters.parameters.projectEnvironment.value = $projectEnvironment
$parameters.parameters.tagValues.value = $tagValues
$parameters.parameters.adlshdinmountpoint.value = $adlshdinmountpoint
$parameters.parameters.applicationIdentityCertificateName.value = $applicationIdentityCertificateName
$parameters.parameters.projectAdminADGroupName.value = $projectAdminADGroupName
$parameters.parameters.projectAdminADGroupId.value = $projectAdminADGroupId
$parameters.parameters.developerADGroupName.value = $developerADGroupName
$parameters.parameters.developerADGroupId.value = $developerADGroupId
$parameters.parameters.dataReaderADGroupName.value = $dataReaderADGroupName
$parameters.parameters.dataReaderADGroupId.value = $dataReaderADGroupId
$parameters.parameters.dataWriterADGroupName.value = $dataWriterADGroupName
$parameters.parameters.dataWriterADGroupId.value = $dataWriterADGroupId
$parameters.parameters.dataOwnerADGroupName.value = $dataOwnerADGroupName
$parameters.parameters.dataOwnerADGroupId.value = $dataOwnerADGroupId
$parameters.parameters.supportADGroupName.value = $supportADGroupName
$parameters.parameters.supportADGroupId.value = $supportADGroupId
$parameters.parameters.supportLevel1ADGroupName.value = $supportLevel1ADGroupName
$parameters.parameters.supportLevel1ADGroupId.value = $supportLevel1ADGroupId

$parameters.parameters.dataScientistADGroupName.value = $dataScientistADGroupName
$parameters.parameters.dataEngineerADGroupName.value = $dataEngineerADGroupName
$parameters.parameters.dataScientistADGroupId.value = $dataScientistADGroupId
$parameters.parameters.dataEngineerADGroupId.value = $dataEngineerADGroupId
$parameters.parameters.managerADGroupName.value = $managerADGroupName
$parameters.parameters.managerADGroupId.value = $managerADGroupId
$parameters.parameters.developerSharepointADGroupName.value = $developerSharepointADGroupName
$parameters.parameters.developerSharepointADGroupId.value = $developerSharepointADGroupId
$parameters.parameters.testerADGroupName.value = $testerADGroupName
$parameters.parameters.testerADGroupId.value = $testerADGroupId

$parameters.parameters.analysisServicesStorageAccountResourceGroupName.value = $applicationResourceGroupName
$parameters.parameters.analysisServicesStorageAccountName.value = $storageAccountName
$parameters.parameters.analysisServicesName.value = $analysisServicesName
$parameters.parameters.analysisServicesResourceGroupName.value = $analysisServicesResourceGroupName
$parameters.parameters.analysisServicesAdminEmailId.value = $analysisServicesAdminEmailId
#$parameters.parameters.analysisServicesOpdgName.value = $analysisServicesOpdgName
#$parameters.parameters.analysisServicesOpdgInstallationName.value = $analysisServicesOpdgInstallationName
$parameters.parameters.azureSSISResourceGroupName.value = $azureSSISResourceGroupName
$parameters.parameters.azureSSISName.value = $azureSSISName
$parameters.parameters.azureSSISDBServerEndpoint.value = $azureSSISDBServerEndpoint
$parameters.parameters.iotHubResourceGroupName.value = $iotHubResourceGroupName
$parameters.parameters.iotHubName.value = $iotHubName
$parameters.parameters.tsInsightsResourceGroupName.value = $tsInsightsResourceGroupName
$parameters.parameters.tsInsightsName.value = $tsInsightsName
$parameters.parameters.appContributorGroupName.value = $appContributorGroupName
$parameters.parameters.appContributorGroupId.value = $appContributorADGroupId
$parameters.parameters.appReaderGroupName.value = $appReaderGroupName
$parameters.parameters.appReaderGroupId.value = $appReaderADGroupId
$parameters.parameters.dataReaderGroupName.value = $dataReaderGroupName
$parameters.parameters.stgReaderGroupName.value = $stgReaderGroupName
$parameters.parameters.databricksResourceGroupName.value = $applicationResourceGroupName
$parameters.parameters.databricksWorkspaceName.value = $databrickWorkspaceName
$parameters.parameters.databricksCluster1.value = $databricksCluster1
$parameters.parameters.databricksCluster2.value = $databricksCluster2
$parameters.parameters.databricksPricingTier.value = $databricksPricingTier
$parameters.parameters.appServicePlanName.value = $appServicePlanName
$parameters.parameters.webAppName.value = $webAppName
$parameters.parameters.webAppResourceGroupName.value = $webAppResourceGroupName
$parameters.parameters.functionAppName.value = $functionAppName
$parameters.parameters.logAnalyticsResourceGroupName.value = $applicationResourceGroupName
$parameters.parameters.logAnalyticsWorkspaceName.value = $logAnalyticsWorkspaceName
$parameters.parameters.machineLearningWorkspaceName.value = $machineLearningWorkspaceName
$parameters.parameters.machineLearningComputeClusterName.value = $machineLearningComputeClusterName
$parameters.parameters.machineLearningComputeIdleSecondsBeforeScaleDown.value = $machineLearningComputeIdleSecondsBeforeScaleDown
$parameters.parameters.machineLearningComputeMaxNodes.value = $machineLearningComputeMaxNodes
$parameters.parameters.machineLearningComputeMinNodes.value = $machineLearningComputeMinNodes
$parameters.parameters.machineLearningComputeVmSize.value = $machineLearningComputeVmSize
$parameters.parameters.machineLearningExperimentName.value = $machineLearningExperimentName
$parameters.parameters.machineLearningModelName.value = $machineLearningModelName
$parameters.parameters.machineLearningModelGitFolder.value = $machineLearningModelGitFolder
$parameters.parameters.machineLearningLocation.value = $location
$parameters.parameters.applicationInsightsName.value = $applicationInsightsName
$parameters.parameters.containerRegistryName.value = $containerRegistryName
$parameters.parameters.machineLearningKeyVaultName.value = $machineLearningKeyVaultName
$parameters.parameters.machineLearningResourceGroupName.value = $machineLearningResourceGroupName
$parameters.parameters.machineLearningAKSClusterName.value = $machineLearningAKSClusterName
$parameters.parameters.machineLearningACIInstance.value = $machineLearningACIInstance
$parameters.parameters.budgetAlertName.value = $budgetAlertName
$parameters.parameters.budgetAlertResourceGroupName.value = $applicationResourceGroupName
$parameters.parameters.logicAppResourceGroupName.value = $applicationResourceGroupName
$parameters.parameters.logicAppName.value = $logicAppName
$parameters.parameters.logicAppDatalakeapiConnection.value = $logicAppDatalakeapiConnection 
$parameters.parameters.logicAppDatalakeapiConnectionDisplay.value = $logicAppDatalakeapiConnectionDisplay
$parameters.parameters.logicAppO365apiConnection.value = $logicAppO365apiConnection 
$parameters.parameters.logicAppSqlDWapiConnection.value = $logicAppSqlDWapiConnection 
$parameters.parameters.logicAppSqlDWapiConnectionDisplay.value = $logicAppSqlDWapiConnectionDisplay
$parameters.parameters.logicAppSqlapiConnection.value = $logicAppSqlapiConnection 
$parameters.parameters.logicAppSqlapiConnectionDisplay.value = $logicAppSqlapiConnectionDisplay
$parameters.parameters.azuremonitorlogs_name.value = $azuremonitorlogs_name
$parameters.parameters.azuremonitorlogs_DisplayName.value = $azuremonitorlogs_DisplayName
$parameters.parameters.apiconnection_adlsgen2_name.value = $apiconnection_adlsgen2_name
$parameters.parameters.streamAnalyticsJobResourceGroupName.value = $streamAnalyticsJobResourceGroupName
$parameters.parameters.streamAnalyticsJobName.value = $streamAnalyticsJobName
$parameters.parameters.numberOfStreamingUnits.value = $numberOfStreamingUnits
$parameters.parameters.virtualNetworkResourceGroupName.value = $virtualNetworkResourceGroupName
$parameters.parameters.virtualNetworkName.value = $vnetName
$parameters.parameters.sqlServerSubnetName1.value = $subnetName
$parameters.parameters.vstsTeamProjectName.value = "{0}-{1}-p-{2}-vstsp" -f $namePrefix, $platformG.ToLower(), $devProjectNumber

if (Get-AzKeyVault -VaultName $keyVaultName -ResourceGroupName $landscapeResourceGroupName) {
    $applicationIdentityCertificateName = $parameters.parameters.applicationIdentityCertificateName.value
    $applicationIdentityCertificatePassword = "{0}-Password" -f $parameters.parameters.applicationIdentityCertificateName.value
    
    $secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $applicationIdentityCertificateName -ErrorAction SilentlyContinue
    if ($secret) {
        $secretValue = $secret.SecretValueText
        $rawCert = [System.Convert]::FromBase64String($secretValue)
        
        $secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $applicationIdentityCertificatePassword -ErrorAction SilentlyContinue
        if ($secret) {
            $identityCertificatePassword = $secret.SecretValue
            $certificatePFX = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2($rawCert, $identityCertificatePassword, [System.Security.Cryptography.X509Certificates.X509KeyStorageFlags]::Exportable)
            $parameters.parameters.applicationCertThumprint.value = $certificatePFX.Thumbprint
        }
    }
}

if (Get-AzKeyVault -VaultName $Global:CtxBootStrap.AutomationKeyVaultName -ResourceGroupName $Global:CtxBootStrap.AutomationResourceGroupName -DefaultProfile $Global:CtxAuto) {
    
    $secret = Get-AzKeyVaultSecret -VaultName $Global:CtxBootStrap.AutomationKeyVaultName -Name "WebHook-SqlDwPause" -ErrorAction SilentlyContinue
    if ($secret) {
        $parameters.parameters.webhookSqlDwPause.value = $secret.SecretValueText
    }
    $secret = Get-AzKeyVaultSecret -VaultName $Global:CtxBootStrap.AutomationKeyVaultName -Name "WebHook-SqlDwResume" -ErrorAction SilentlyContinue
    if ($secret) {
        $parameters.parameters.webhookSqlDwResume.value = $secret.SecretValueText
    }
    $secret = Get-AzKeyVaultSecret -VaultName $Global:CtxBootStrap.AutomationKeyVaultName -Name "WebHook-SSASPause" -ErrorAction SilentlyContinue
    if ($secret) {
        $parameters.parameters.webhookAasPause.value = $secret.SecretValueText
    }
    $secret = Get-AzKeyVaultSecret -VaultName $Global:CtxBootStrap.AutomationKeyVaultName -Name "WebHook-SSASResume" -ErrorAction SilentlyContinue
    if ($secret) {
        $parameters.parameters.webhookAasResume.value = $secret.SecretValueText
    }
    $secret = Get-AzKeyVaultSecret -VaultName $Global:CtxBootStrap.AutomationKeyVaultName -Name "Webhook-ScaleUpDownSql" -ErrorAction SilentlyContinue
    if ($secret) {
        $parameters.parameters.webhookScaleUpDownSql.value = $secret.SecretValueText
    }
    $secret = Get-AzKeyVaultSecret -VaultName $Global:CtxBootStrap.AutomationKeyVaultName -Name "Webhook-ScaleUpDownAAS" -ErrorAction SilentlyContinue
    if ($secret) {
        $parameters.parameters.webhookScaleUpDownAAS.value = $secret.SecretValueText
    }
    $secret = Get-AzKeyVaultSecret -VaultName $Global:CtxBootStrap.AutomationKeyVaultName -Name "WebHook-SSASProcessCube" -ErrorAction SilentlyContinue
    if ($secret) {
        $parameters.parameters.webhookProcessAAS.value = $secret.SecretValueText
    }
    $secret = Get-AzKeyVaultSecret -VaultName $Global:CtxBootStrap.AutomationKeyVaultName -Name "WebHook-ScaleUpDownWeb" -ErrorAction SilentlyContinue
    if ($secret) {
        $parameters.parameters.webhookScaleUpDownWeb.value = $secret.SecretValueText
    }
} else {
    Write-Error "Unable to locate landscape key vault for webhook URIs: $landscapeResourceGroupName : $landscapeKeyVaultName"
}

# Load the override template file.  This contains populate values that ofter override e.g. pricing tier
$properties = $overrides.parameters | Get-Member -MemberType Properties | Select-Object

ForEach($property in $properties) {
    $overrides.parameters.psobject.properties.remove($property.Name)
    Copy-Property -InputObject $overrides.parameters -Property $property.Name -SourceObject $parameters.parameters
}
# Handle a special case for eco master parameter files.  Since the same ITSGs are reused in multiple
# subscriptions the parameter files default to the same name which means they get overwritten. We need
# a new naming convention for landscape parameter files to handle this
$metaProjects=":56731:56730:56732:56728:"
if ($metaProjects.Contains($projectNumber) ) {
    $parameterFile = "parameters.{0}.{1}.{2}.json" -f $platformL, $projectEnvironment, $projectNumber
    $overrideFile = "overrides.{0}.{1}.{2}.json" -f $platformL, $projectEnvironment, $projectNumber
} else {
    $parameterFile = "parameters.{0}.{1}.json" -f $projectEnvironment, $projectNumber
    $overrideFile = "overrides.{0}.{1}.json" -f $projectEnvironment, $projectNumber
}
$parameterProjectFile = "{0}\Projects\{1}" -f $devOpsProjectFolder, $parameterFile
$overridesProjectFile = "{0}\Projects\{1}" -f $devOpsProjectFolder, $overrideFile

$parameters | ConvertTo-JSON -Depth 10 | Out-File -filepath $parameterProjectFile -Force
$overrides | ConvertTo-JSON -Depth 10 | Out-File -filepath $overridesProjectFile -Force

Write-Host "Project parameter file created at: $parameterProjectFile"
Write-Host "Override parameter file created at: $overridesProjectFile"

if ($backupParameterFile) {
    & "$devOpsProjectFolder\LandscapeManager\Set-ParameterFileBackup" -parameterFile $parameterFile -Force
    & "$devOpsProjectFolder\LandscapeManager\Set-ParameterFileBackup" -parameterFile $parameterFile -parameterFileName $overrideFile -Force
}