Param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$parameterFile   
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

$location = $parameters.parameters.location.value
$tenantId = $parameters.parameters.tenantId.value
$upn = (Get-AzContext).Account.Id
$user = Get-AzADUser -UserPrincipalName $upn
$keyVaultAdmin = $user.Id

$keyVaultResourceGroupName = $parameters.parameters.keyVaultResourceGroupName.value
$keyVaultName = $parameters.parameters.keyVaultName.value
$keyVaultDeploymentName = $sqlServerName + $keyVaultName + "_depl"
$keyVaultTemplateFile = "$devOpsProjectFolder\Templates\keyvault.json"

# convert the tag values into a hash table
$tagValues = @{}
$parameters.parameters.tagValues.value.psobject.properties | ForEach-Object { $tagValues[$_.Name.Replace("tag", "")] = $_.Value }

Write-Output "Creating the Key Vault"
New-AzResourceGroupDeployment  -ResourceGroupName $keyVaultResourceGroupName `
-Name $keyVaultDeploymentName -TemplateFile $keyVaultTemplateFile `
-keyvaultName $keyVaultName -tenantid $tenantid -location $location `
-objectid $keyVaultAdmin -skuName Standard `
-enableVaultForDeployment $true -enableVaultForDiskEncryption $true `
-enabledForTemplateDeployment $true `
-keysPermissions "All" -secretsPermissions "All" `
-tagValues $tagValues -Force | Out-Null

$keyVault = Get-AzKeyVault -ResourceGroupName $keyVaultResourceGroupName -VaultName $keyVaultName
$keyVault.enableSoftDelete

# keyvault event auditing is bust.  Waiting for a fix
# See: https://github.com/Azure/azure-powershell/issues/6833
# $keyVaultAuditStorageAccountResourceGroupName = $parameters.parameters.keyVaultAuditStorageAccountResourceGroupName.value
# $keyVaultAuditStorageAccountName = $parameters.parameters.keyVaultAuditStorageAccountName.value
# $kvlogsa = Get-AzStorageAccount -ResourceGroupName $keyVaultAuditStorageAccountResourceGroupName -Name $keyVaultAuditStorageAccountName
# $diagSetting = $keyVault | Get-AzDiagnosticSetting
# Write-Verbose "Setting $($keyVault.VaultName) to log to $($kvlogsa.StorageAccountName)."
# $depl = Set-AzDiagnosticSetting -ResourceId $keyVault.ResourceId -StorageAccountId $kvlogsa.Id -Enabled $true -Categories AuditEvent

