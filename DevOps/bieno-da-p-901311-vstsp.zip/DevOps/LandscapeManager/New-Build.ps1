param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$parameterFile,
   
    [Parameter(Mandatory = $True, HelpMessage='The personal access token used to authorize vsts requests')]
    [String]$personalAccessToken
)

$jsonStr = @"
    {
        "definition": {
            "id": 0
        }
    }
"@

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters.ps1" -parameterFile $parameterFile


$vstsAccountName = $parameters.parameters.vstsAccountName.value
$vstsTeamProjectName = $parameters.parameters.vstsTeamProjectName.value
$vstsTeamProjectCIBuildDefinitionName = $parameters.parameters.vstsTeamProjectCIBuildDefinitionName.value

$patString = "{0}:{1}" -f "", $personalAccessToken
$base64PatString =  [System.Convert]::ToBase64String([System.Text.Encoding]::ASCII.GetBytes($patString))

try 
{
    $vstsURL = "https://{0}.visualstudio.com/DefaultCollection/{1}/_apis/build/definitions?api-version=2.0" -f $vstsAccountName, $vstsTeamProjectName
    $params = @{    
        ContentType = 'application/json'
        Headers = @{
            'Authorization'="Basic $base64PatString"
        }
        Method = 'Get'    
        URI = $vstsURL
    }
    Write-Verbose "Getting the build definitions for team project $vstsTeamProjectName"
    $authZResponse =  Invoke-RestMethod @params
    $vstsTeamProjectBuildDefinitionId = ($authZResponse.value | Where-Object {$_.name -eq $vstsTeamProjectCIBuildDefinitionName}).id
    Write-Verbose "Build Definition id for build $vstsTeamProjectCIBuildDefinitionName is $vstsTeamProjectBuildDefinitionId"

    $buildQueue = $jsonStr | ConvertFrom-Json
    $buildQueue.definition.id = $vstsTeamProjectBuildDefinitionId
    $body = $buildQueue | ConvertTo-JSON -Depth 5

    $vstsURL = "https://{0}.visualstudio.com/DefaultCollection/{1}/_apis/build/builds?api-version=2.0" -f $vstsAccountName, $vstsTeamProjectName
    $params = @{    
        ContentType = 'application/json'
        Headers = @{
            'Authorization'="Basic $base64PatString"
        }
        body = $body        
        Method = 'Post'    
        URI = $vstsURL
    }
    Write-Verbose "Queuing a new build for $vstsTeamProjectCIBuildDefinitionName"
    $authZResponse =  Invoke-RestMethod @params
    Write-Verbose $authZResponse
    $buildId = $authZResponse.id
    Write-Output "Build Queued with id $buildId"
}
catch
{
    Write-Host "StatusCode:" $_.Exception.Response.StatusCode.value__ 
    Write-Host "StatusDescription:" $_.Exception.Response.StatusDescription
    throw
}
