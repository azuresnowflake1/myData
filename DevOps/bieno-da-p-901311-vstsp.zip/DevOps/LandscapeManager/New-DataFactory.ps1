Param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$parameterFile,

    [Parameter(Mandatory = $false, HelpMessage = "Pass this if you want to provision adls gen1")]
    [switch]$adlsGen1 
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"
$scriptsFolder = "{0}\{1}" -f $devOpsProjectFolder, "Scripts"
$managerFolder = "{0}\{1}" -f $devOpsProjectFolder, "LandscapeManager"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

 & "$scriptsFolder\15.Add-Resources.ps1" -parameterFile $parameterFile -DataFactory
# Write-Output "Adding sample ADF pipelines for Webhooks"
& "$utilitiesFolder\Set-DataFactory-Webhook.ps1" -parameterFile $parameterFile -pipelineName PL_PAUSE_SQLDW -activityName PauseSqlDw `
 -webhookUrl $parameters.parameters.webhookSqlDwPause.value -pipelineDescription "Pause sql dw using a webhook call."

 & "$utilitiesFolder\Set-DataFactory-Webhook.ps1" -parameterFile $parameterFile -pipelineName PL_RESUME_SQLDW -activityName ResumeSqlDw `
 -webhookUrl $parameters.parameters.webhookSqlDwResume.value -pipelineDescription "Resume sql dw using a webhook call."

 & "$utilitiesFolder\Set-DataFactory-Webhook.ps1" -parameterFile $parameterFile -pipelineName PL_PAUSE_AAS -activityName PauseAnalysisServices `
 -webhookUrl $parameters.parameters.webhookAasPause.value -pipelineDescription "Pause Azure Analysis Services using a webhook call."

 & "$utilitiesFolder\Set-DataFactory-Webhook.ps1" -parameterFile $parameterFile -pipelineName PL_RESUME_AAS -activityName ResumeAnalysisServices `
 -webhookUrl $parameters.parameters.webhookAasResume.value -pipelineDescription "Resume Azure Analysis Services using a webhook call."

 $webhookExpression="@concat(pipeline().DataFactory,',',pipeline().RunId,',,PL_RESUME_AAS')"
 & "$utilitiesFolder\Set-DataFactory-Webhook.ps1" -parameterFile $parameterFile -pipelineName PL_RESUME_SQLDW_WITH_CALLBACK -activityName ResumeSqlDwWithCallback `
 -webhookUrl $parameters.parameters.webhookSqlDwResume.value -pipelineDescription "Resume sql dw using a webhook call, once resumed callback to this ADF and trigger pipeline PL_RESUME_AAS." `
 -webhookExpression $webhookExpression

 $webhookExpression="@concat(pipeline().DataFactory,',',pipeline().RunId,',,,S1')"
 & "$utilitiesFolder\Set-DataFactory-Webhook.ps1" -parameterFile $parameterFile -pipelineName PL_SCALE_AAS -activityName ScaleAnalysisServices `
 -webhookUrl $parameters.parameters.webhookScaleUpDownAAS.value -pipelineDescription "ScaleAzure Analysis Services using a webhook call." `
 -webhookExpression $webhookExpression
 
 $webhookExpression="@concat(pipeline().DataFactory,',',pipeline().RunId,',,,Standard,S1')"
 & "$utilitiesFolder\Set-DataFactory-Webhook.ps1" -parameterFile $parameterFile -pipelineName PL_SCALE_SQLDB -activityName ScaleDB `
 -webhookUrl $parameters.parameters.webhookScaleUpDownSql.value -pipelineDescription "Scale Azure Sql Database using a webhook call." `
 -webhookExpression $webhookExpression

 $webhookExpression="@concat(pipeline().DataFactory,',',pipeline().RunId,',,,DataWarehouse,DW100c')"
 & "$utilitiesFolder\Set-DataFactory-Webhook.ps1" -parameterFile $parameterFile -pipelineName PL_SCALE_SQLDW -activityName ScaleDW `
 -webhookUrl $parameters.parameters.webhookScaleUpDownSql.value -pipelineDescription "Scale Azure Sql Datawarehouse using a webhook call." `
 -webhookExpression $webhookExpression

 $webhookExpression="@concat('{`"csv`":`"',pipeline().DataFactory,',',pipeline().RunId,',,PL_PROCESS_CUBE_CALLBACK`",','`"object`":',pipeline().parameters.tmslScript,'}')"
 & "$utilitiesFolder\Set-DataFactory-Webhook.ps1" -parameterFile $parameterFile -pipelineName PL_PROCESS_CUBE -activityName ExecuteTMSL `
 -webhookUrl $parameters.parameters.webhookProcessAAS.value -pipelineDescription "Process AAS Cube using TMSL refresh command." `
 -webhookExpression $webhookExpression -pipelineTemplate "pipeline.webhook1.json"

 $webhookExpression="@concat(pipeline().DataFactory,',',pipeline().RunId,',,,F1')"
 & "$utilitiesFolder\Set-DataFactory-Webhook.ps1" -parameterFile $parameterFile -pipelineName PL_SCALE_WEB -activityName ScaleWeb `
 -webhookUrl $parameters.parameters.webhookScaleUpDownWeb.value -pipelineDescription "Scale Azure Web App using a webhook call." `
 -webhookExpression $webhookExpression
 # if ($parameters.parameters.projectEnvironment.value -eq 'd') {
#     & "$managerFolder\Set-DataFactoryRepository.ps1" -parameterFile $parameterFile
# }
& "$utilitiesFolder\Set-DataFactory-Callback.ps1" -parameterFile $parameterFile

Write-Output "Creating default data factory Linked Services"
$args = @{
    parameterFile=$parameterFile
    KeyVault=$true
    SharedADLStore=$true
    StorageWithKey=$true
    SeedDataStore=$true
    PSLZADLStore=$true
}
if ($adlsGen1) {
    $args.ADLStoreGen1=$true
} else {
    $args.ADLStore=$true
}
& "$utilitiesFolder\Set-DataFactory.ps1" @args

# Grant key vault access to the data factory MSI
$dataFactoryResourceGroupName = $parameters.parameters.dataFactoryResourceGroupName.value
$dataFactoryName = $parameters.parameters.dataFactoryName.value
$dfIdentity = (Get-AzDataFactoryV2 -ResourceGroupName $dataFactoryResourceGroupName -Name $dataFactoryName).Identity
$keyVaultResourceGroupName = $parameters.parameters.keyVaultResourceGroupName.value
$keyVaultName = $parameters.parameters.keyVaultName.value

$i=0

do {
    try {
        Set-AzKeyVaultAccessPolicy -VaultName $keyVaultName -ResourceGroupName $keyVaultResourceGroupName -ObjectId $dfIdentity.PrincipalId -PermissionsToSecrets get,list
        Write-Host "Key Vault access granted to $datafactoryName."
        return
    }
    catch {
        $message = $_.Exception.Message
        Write-Warning "Failed to grant key vault access to $dataFactoryName.  Waiting to re-try"
        Start-Sleep 5
        $i++
    }
    if ($i -ge 12) {
        Write-Error "Failed to grant key vault access to $dataFactoryName.`r`n`r`n$message"
    }
} while ($i -lt 12)
