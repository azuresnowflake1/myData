#Run this to add or remove a user as owner from all I&A AAD Groups
$ownerId = ""

if (-not $ownerId) {
    throw "You must set the id of the owner to remove."
}

$daDevADGroups = Get-AzureADGroup -SearchString "SEC-ES-DA-" -All $True
$i=0
foreach ($daDevADGroup in $daDevADGroups){
    $i++
    if($($daDevADGroup.DisplayName).contains("-azure-") -or $($daDevADGroup.DisplayName).contains("-azurereader") -or $($daDevADGroup.DisplayName).contains("-azurecontributor")){
        #$daDevADGroup.GetType() | Get-Member
        Write-Output "Cleaning group $($daDevADGroup.DisplayName)"
        Remove-AzureADGroupOwner -ObjectId $daDevADGroup.ObjectId -OwnerId $ownerId
    } else {
        Write-Output "Ingoring group $($daDevADGroup.DisplayName)"
    }
    # if ($i -gt 10) {
    #     return
    # }
}
