param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$parameterFile,

    [Parameter(Mandatory = $True, HelpMessage='Specify tags that are not part of the parameter file.')]
    [HashTable]$tags,

    [Parameter(Mandatory = $false, HelpMessage = "Pass this if your are provisioning an IaaS Resource Group")]
    [switch]$IaasResourceGroup
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

$applicationResourceGroupName = $parameters.parameters.dataFactoryResourceGroupName.value
$tokens = $applicationResourceGroupName.Split("-")
$itsg = $tokens[3]

if($IaasResourceGroup) { 
    $platform = $tokens[1]
    $environment = $tokens[$tokens.Length-4]
    $applicationResourceGroupName = "bnlwe-{0}-{1}-{2}-IS01-rg" -f $platform, $environment, $itsg
}


$location = $parameters.parameters.location.value
Write-Host "Creating resource group $applicationResourceGroupName in $location."

$tagsHash = @{
    CostCentre = $parameters.parameters.tagValues.value.tagCostCentre;
    Icc = $parameters.parameters.tagValues.value.tagIcc;
    Environment = $parameters.parameters.tagValues.value.tagEnvironment;
    Platform = $parameters.parameters.tagValues.value.tagPlatform;
    ServiceName = $parameters.parameters.tagValues.value.tagServiceName;
    ITSG = $itsg;
    Name = $parameters.parameters.tagValues.value.tagServiceName;
}
if ($tags) {
    $tagsHash += $tags
}
New-AzResourceGroup -Name $applicationResourceGroupName -Location $location -tag $tagsHash -Force | Out-Null