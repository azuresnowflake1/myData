Param
(
    [Parameter(Mandatory = $True, HelpMessage = 'Specify the parameter file')]
    [String]$parameterFile
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

$ownerId = $parameters.parameters.servicePrincipalId.value
$ownerGroupId = $parameters.parameters.dataOwnerADGroupId.value
$pslzStoreName = $parameters.parameters.pslzStoreName.value
$pslzADGroupName = $parameters.parameters.pslzADGroupName.value
$pslzFolderName = $parameters.parameters.pslzFolderName.value
$dataReaderADGroupId = $parameters.parameters.dataReaderADGroupId.value
$dataWriterADGroupId = $parameters.parameters.dataWriterADGroupId.value
$dataOwnerADGroupId = $parameters.parameters.dataOwnerADGroupId.value

if([string]::IsNullOrEmpty($pslzFolderName))
{
    return
}
function Add-InAMemberToGroup {
    param([object]$members, [string]$groupId, [string]$memberGroupId)
    #Add if not already a member    
    if (-not ($members | Where-Object Id -eq $memberGroupId)) {
        Add-AzADGroupMember -MemberObjectId $memberGroupId -TargetGroupObjectId $groupId -ErrorAction SilentlyContinue
    }
}
Try {
    if($pslzFolderName -eq ""){
        Write-Error "Product specific landing zone folder name not found"
    }

    Get-AzDataLakeStoreItem -AccountName $pslzStoreName -Path $pslzFolderName -ErrorAction Ignore
    # Create the folder so long as it doesn't already exist.
    if (!(Get-AzDataLakeStoreItem -AccountName $pslzStoreName -Path $pslzFolderName -ErrorAction Ignore)) {
        Write-Host "Creating new PSLZ folder $pslzFolderName"
        
        New-AzDataLakeStoreItem -Folder -AccountName $pslzStoreName -Path $pslzFolderName
        Set-AzDataLakeStoreItemOwner -AccountName $pslzStoreName -Path $pslzFolderName -Type User -Id $ownerId
        Set-AzDataLakeStoreItemOwner -AccountName $pslzStoreName -Path $pslzFolderName -Type Group -Id $ownerGroupId
    }
} Catch {
    Write-Error $_.Exception.Message
}
   
$adGroups = Get-AzADGroup -DisplayName $pslzADGroupName
if($($adGroups[0].Description) -eq $pslzADGroupName)
{
    Write-Host "adding members to $pslzADGroupName ($($adGroups[0].Id))"
    $members = Get-AzADGroupMember -GroupObjectId $adGroups[0].Id
    
    Add-InAMemberToGroup -members $members -groupId $adGroups[0].Id -memberGroupId $dataReaderADGroupId
    Add-InAMemberToGroup -members $members -groupId $adGroups[0].Id -memberGroupId $dataWriterADGroupId
    Add-InAMemberToGroup -members $members -groupId $adGroups[0].Id -memberGroupId $dataOwnerADGroupId
}

#Set permissions on folder to Data-Reader, Write and Owner groups
Write-Host "Setting permissions to $pslzFolderName"
Set-AzDataLakeStoreItemAclEntry -Account $pslzStoreName -Path $pslzFolderName -AceType "Group" -Id $dataReaderADGroupId -Permissions "ReadExecute"
Set-AzDataLakeStoreItemAclEntry -Account $pslzStoreName -Path $pslzFolderName -AceType "Group" -Id $dataReaderADGroupId -Permissions "ReadExecute" -Default
Set-AzDataLakeStoreItemAclEntry -Account $pslzStoreName -Path $pslzFolderName -AceType "Group" -Id $dataWriterADGroupId -Permissions "All"
Set-AzDataLakeStoreItemAclEntry -Account $pslzStoreName -Path $pslzFolderName -AceType "Group" -Id $dataWriterADGroupId -Permissions "All" -Default
Set-AzDataLakeStoreItemAclEntry -Account $pslzStoreName -Path $pslzFolderName -AceType "Group" -Id $dataOwnerADGroupId -Permissions "All"
Set-AzDataLakeStoreItemAclEntry -Account $pslzStoreName -Path $pslzFolderName -AceType "Group" -Id $dataOwnerADGroupId -Permissions "All" -Default

<#
#Enable the firewall
$adlStoreResourceGroupName = $parameters.parameters.adlStoreResourceGroupName.value
$adlStoreName = $parameters.parameters.adlStoreName.value
$adls = Get-AzDataLakeStoreAccount -ResourceGroupName $adlStoreResourceGroupName `
-Name $adlStoreName
# if ($adls.FirewallState -eq "Disabled")
# {
#     Write-Verbose "Firewall is disabled. Enabling..."
#     $null = Set-AzDataLakeStoreAccount -ResourceGroupName $adlStoreResourceGroupName `
#     -Name $adlStoreName -FirewallState Enabled 
#     $adls = Get-AzDataLakeStoreAccount -ResourceGroupName $adlStoreResourceGroupName `
#     -Name $adlStoreName  
# }
# else {
#     Write-Verbose "Firewall is already enabled."
# }
# Write-Output "Data Lake Store firewall is $($adls.FirewallState)."

#>