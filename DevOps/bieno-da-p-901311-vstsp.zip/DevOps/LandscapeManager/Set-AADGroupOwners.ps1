param
(
    [string]$groupName,
    [object]$owners # list of AD owners
)

# When constructing the list of owners do something like this:
# $coreGroup = Get-AzADGroupMember -GroupDisplayName "SEC-ES-DA-p-56728-azure-admin"
# $coreGroup += Get-AzADServicePrincipal -DisplayName "svc-b-da04-ina-automation"

$ctx = Get-AzContext
$currentUserPrincipalName = $ctx.Account.Id
$currentUser = Get-AzADUser -UserPrincipalName $currentUserPrincipalName

# Construct a distinct list of owners
$hash = @{}
$owners | ForEach-Object { $hash[$_.DisplayName] = $_ }
$owners = $hash
$distinctOwners = @()

foreach ($h in $owners.keys) {
    $distinctOwners+=$owners[$h]
    if (-not $owners[$h].Id) {
        # Make sure the object has an Id property so the comparision logic works
        $owners[$h] | Add-Member -MemberType AliasProperty -Name Id -Value ObjectId
    }
}

function Sync-Owners {
    # This is bust by PS6 because it doesnn't support AzureAD module.  However, now landscape have ApplicationAdmin role we
    # don't need to set the owners
    param( [System.Object]$owners, [Microsoft.Azure.Commands.ActiveDirectory.PSADGroup]$targetGroup )
   
    $existingOwners = Get-AzureADGroupOwner -ObjectId $targetGroup.Id -All $True
    
    foreach($owner in $owners) {
        $match = $false
        foreach($gp in $existingOwners) {
            if ($gp.ObjectId -eq $owner.Id) {
                # nothing to do
                Write-Verbose "$($gp.DisplayName) is already owner of group $($targetGroup.DisplayName)"
                $match = $true
                break
            }
        }
        if (-not $match) {
            # Principal is not currrently an owner of the target group.  Need to add it.
            Write-Verbose "Adding $($owner.DisplayName) as owner of group $($targetGroup.DisplayName)"
            Add-AzureADGroupOwner -ObjectId $targetGroup.Id -RefObjectId $owner.Id -ErrorAction SilentlyContinue
        }
    }
    foreach($existingOwner in $existingOwners) {
        $match = $false
        foreach($gp in $owners) {
            if ($gp.Id -eq $existingOwner.ObjectId) {
                # nothing to do
                $match = $true
                break
            }
        }
        if (-not $match) {
            if ($currentUser -and $currentUser.Id -ne $existingOwner.ObjectId) {
                # Principal is not specified as an owner but currently is.  Need to remove it it.
                Write-Verbose "Removing existing owner $($existingOwner.DisplayName) from group $($targetGroup.DisplayName)"
                Remove-AzureADGroupOwner -ObjectId $targetGroup.Id -OwnerId $existingOwner.ObjectId 
            }
            
        }
    }
}
$syncGroup = Get-AzADGroup -DisplayName $groupName
Sync-Owners -owners $distinctOwners -targetGroup $syncGroup

