param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$parameterFile,
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$devOpsParameterFile,
    [Parameter(Mandatory = $False, HelpMessage='Specify the name of the git repo.  This will override the value')]
    [String]$repoName
)

$rootFolder = (Get-Item -Path $PSScriptRoot).Parent.Parent.FullName
$adfARMFolder = "{0}\{1}" -f $rootFolder, "..\Adf-01"
$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$managerFolder = "{0}\{1}" -f $devOpsProjectFolder, "LandscapeManager"
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters.ps1" -parameterFile $parameterFile
$devOpsParameters = & "$utilitiesFolder\Get-Parameters.ps1" -parameterFile $devOpsParameterFile

$vstsAccountName = $parameters.parameters.vstsAccountName.value
$vstsTeamProjectName = $parameters.parameters.vstsTeamProjectName.value
$projectNumber = $devOpsParameters.parameters.projectNumber.value

if (-not $repoName) {
    $repoName = $vstsTeamProjectName
}

$vstsUrl = "https://{0}.visualstudio.com/{1}/_git/{2}" -f $vstsAccountName, $vstsTeamProjectName, $repoName

$vstsFolderName = [System.IO.Path]::GetTempPath() 
$vstsDevOpsDesitnationPath = $vstsFolderName + $repoName
$vstsDevBranch = $parameters.parameters.vstsSourceControlDevBranch.value
$vstsProjectsFolder = $vstsFolderName + $repoName + "\DevOps\Projects"
$vstsAdfARMFolder = Join-Path -Path $vstsFolderName -ChildPath $repoName
$vstsAdfARMFolder = Join-Path -Path $vstsAdfARMFolder -ChildPath "Adf"
$vstsAdfARMFolder = Join-Path -Path $vstsAdfARMFolder -ChildPath $devOpsParameters.parameters.dataFactoryName.value

$vstsSQLDWSourcePath =  "{0}\..\..\EcoSystemTemplates" -f $devOpsProjectFolder
$vstsSQLDWDestinationPath = $vstsFolderName + $repoName + "\SQLDW"
New-Item -Path $vstsSQLDWDestinationPath -ItemType Directory -Force
$vstsSQLDWSourcePath = (Get-Item -Path $vstsSQLDWSourcePath).FullName
$vstsSQLDWDestinationPath = (Get-Item -Path $vstsSQLDWDestinationPath).FullName
$include = @('*.zip')

$gitRoot = Split-Path -Path $devOpsProjectFolder -Parent
$gitRoot = Split-Path -Path $gitRoot -Parent
$vstsDevOpsSourceReadmePath = "{0}\EcoSystemProvisioning\readme.md" -f $gitroot
Write-Verbose "DevOps Readme filepath : $vstsDevOpsSourceReadmePath"
$codeSampleSourcePath = "{0}\VisualStudio" -f $gitRoot
$codeSampleDestinationPath = $vstsFolderName + $repoName + "\VisualStudio"
$gitIgnorePath =  "{0}\.gitignore" -f $devOpsProjectFolder
$gitIgnoreDestPath = $vstsFolderName + $repoName

Push-Location
try
{    
    Remove-Item $vstsDevOpsDesitnationPath -Recurse -Force -ErrorAction SilentlyContinue
    Set-Location -Path $vstsFolderName
    git clone $vstsUrl 
    Set-Location -Path $repoName
    git fetch origin
    git checkout -b master
    Copy-Item $vstsDevOpsSourceReadmePath $vstsDevOpsDestinationReadmePath -Force
    # Search and replace the readme.md file for this particular project
    & "$managerFolder\Set-Readme.ps1" -parameterFile $devOpsParameterFile -gitDirectory $vstsDevOpsDesitnationPath

    Copy-Item -Path $gitIgnorePath -Destination $gitIgnoreDestPath -Force    
    Set-Location -Path $vstsDevOpsDesitnationPath
    git add .
    git commit -am "initial commit"
    git push --set-upstream origin master    
    git checkout -B $vstsDevBranch
    git branch --set-upstream-to=origin/$vstsDevBranch
    git pull  
    Copy-Item -Path $devOpsProjectFolder -Destination $vstsDevOpsDesitnationPath -Recurse -Force
    Copy-Item -Path $adfARMFolder -Destination $vstsAdfARMFolder -Recurse -Force
    
    # Search and replace the readme.md file for this particular project
    & "$managerFolder\Set-Readme.ps1" -parameterFile $devOpsParameterFile -gitDirectory $vstsDevOpsDesitnationPath    
    # Copy the SQL DW project template file
    Get-ChildItem $vstsSQLDWSourcePath -Recurse -Include $include | copy-item -Destination (new-item -type directory -force $vstsSQLDWDestinationPath) -force -ea 0
    # Copy the Visual Studio Code Samples
    Copy-Item $codeSampleSourcePath -Destination $codeSampleDestinationPath -Recurse -Force
    
    # Tidy up the Projects folder
    $parameterFileFilter = @("*$projectNumber.json","$($devOpsParameters.parameters.dataFactoryName.value).json")
    
    Set-Location -Path $vstsProjectsFolder
    Remove-Item * -Include *.json -Exclude $parameterFileFilter -Recurse
    Remove-Item * -Include "*.teamproject.*.json" -Recurse

    Set-Location -Path $vstsDevOpsDesitnationPath
    git add .
    git commit -am "second commit"
    git push --set-upstream origin $vstsDevBranch
}
finally
{
    Pop-Location
    Remove-Item $vstsDevOpsDesitnationPath -Recurse -Force
}