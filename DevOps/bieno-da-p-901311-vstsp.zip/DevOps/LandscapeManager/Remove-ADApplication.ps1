Param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$parameterFile
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"
$managerFolder = "{0}\{1}" -f $devOpsProjectFolder, "LandscapeManager"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

$adApplicationName = $parameters.parameters.adApplicationName.value
$adSvcPrincipal = Get-AzADServicePrincipal -SearchString $adApplicationName -DefaultProfile $Global:CtxSPN  -ErrorAction SilentlyContinue
if ($adSvcPrincipal)
{
    Write-Verbose "Removing Service Principal $($adSvcPrincipal.Id)"
    Remove-AzADServicePrincipal -ObjectId $adSvcPrincipal.Id -DefaultProfile $Global:CtxSPN -Force | Out-Null
    $adApplication = Get-AzADApplication -DisplayNameStartWith $adApplicationName -ErrorAction SilentlyContinue
    Write-Verbose "Removing AD Application $($adApplication.ObjectId)"
    Remove-AzADApplication -ObjectId $adApplication.ObjectId -DefaultProfile $Global:CtxSPN -Force | Out-Null
}

$adApplicationName = $parameters.parameters.deploymentadApplicationName.value
$adSvcPrincipal = Get-AzADServicePrincipal -SearchString $adApplicationName -DefaultProfile $Global:CtxSPN -ErrorAction SilentlyContinue
if ($adSvcPrincipal)
{
    Write-Verbose "Removing Service Principal $($adSvcPrincipal.Id)"
    Remove-AzADServicePrincipal -ObjectId $adSvcPrincipal.Id -DefaultProfile $Global:CtxSPN -Force | Out-Null
    $adApplication = Get-AzADApplication -DisplayNameStartWith $adApplicationName -DefaultProfile $Global:CtxSPN -ErrorAction SilentlyContinue
    Write-Verbose "Removing AD Application $($adApplication.ObjectId)"
    Remove-AzADApplication -ObjectId $adApplication.ObjectId -DefaultProfile $Global:CtxSPN -Force | Out-Null
}