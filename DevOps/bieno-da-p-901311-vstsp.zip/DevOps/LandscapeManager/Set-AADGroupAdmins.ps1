param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$parameterFile
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$managerFolder = "{0}\{1}" -f $devOpsProjectFolder, "LandscapeManager"
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters.ps1" -parameterFile $parameterFile
$itsg = $parameters.parameters.projectNumber.value
$coreGroup = @()
$projectAdminGroup = @()
try {
    $coreGroup += Get-AzADGroupMember -GroupDisplayName "SEC-ES-DA-P-56728-Azure-Admin" # $parameters.parameters.projectAdminADGroupName.value    
    $projectAdminGroup += Get-AzADGroupMember -GroupDisplayName "SEC-ES-DA-D-$itsg-ProjectAdmins" # $parameters.parameters.projectAdminADGroupName.value    
    $projectAdminGroup += Get-AzADGroupMember -GroupDisplayName "SEC-ES-DA-P-56728-Azure-Landscape" # $parameters.parameters.projectAdminADGroupName.value    
}
catch {
    Write-Warning "Project Admins group not found"    
}
$coreGroup += Get-AzADServicePrincipal -DisplayName "svc-b-da04-ina-automation"
$ProjectAdminGroup += Get-AzADServicePrincipal -DisplayName "svc-b-da04-ina-automation"

try
{   
    #Set Project Admin as owners for Functional Groups
    $groupName = $parameters.parameters.developerADGroupName.value
    Write-Host "Assigning project admins and landscape team as group owners for $groupName"
    & "$managerFolder\Set-AADGroupOwners.ps1" -groupName $groupName -owners $projectAdminGroup
    $groupName = $parameters.parameters.testerADGroupName.value
    Write-Host "Assigning project admins  and landscape team as group owners for $groupName"
    & "$managerFolder\Set-AADGroupOwners.ps1" -groupName $groupName -owners $projectAdminGroup
    $groupName = $parameters.parameters.supportADGroupName.value
    Write-Host "Assigning project admins  and landscape team as group owners for $groupName"
    & "$managerFolder\Set-AADGroupOwners.ps1" -groupName $groupName -owners $projectAdminGroup

    #Set Core Group as owner for Non-Functional Groups
    $groupName = $parameters.parameters.dataWriterADGroupName.value
    Write-Host "Assigning core team as group owners for $groupName"
    & "$managerFolder\Set-AADGroupOwners.ps1" -groupName $groupName -owners $coreGroup
    $groupName = $parameters.parameters.dataOwnerADGroupName.value
    Write-Host "Assigning core team as group owners for $groupName"
    & "$managerFolder\Set-AADGroupOwners.ps1" -groupName $groupName -owners $coreGroup
    $groupName = $parameters.parameters.dataReaderADGroupName.value
    Write-Host "Assigning core team as group owners for $groupName"
    & "$managerFolder\Set-AADGroupOwners.ps1" -groupName $groupName -owners $coreGroup
    $groupName = $parameters.parameters.appContributorGroupName.value
    Write-Host "Assigning core team as group owners for $groupName"
    & "$managerFolder\Set-AADGroupOwners.ps1" -groupName $groupName -owners $coreGroup
    $groupName = $parameters.parameters.appReaderGroupName.value
    Write-Host "Assigning core team as group owners for $groupName"
    & "$managerFolder\Set-AADGroupOwners.ps1" -groupName $groupName -owners $coreGroup
}
catch {
    Write-Error -Message $_.Exception
    throw $_.Exception
}