Param
(
    [switch]$setScope
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"
$runbooksFolder = "{0}\{1}" -f $devOpsProjectFolder, "LandscapeManager\RunBooks"
$managerFolder = "{0}\{1}" -f $devOpsProjectFolder, "LandscapeManager"

if ($setScope -or -not $global:CtxBootStrap) {
    & "$managerFolder\Set-GlobalScope"
}

& "$runbooksFolder\Import-PlatformCore"

$certSecretName = "svc-b-da{0}-ina-automationCert" -f $global:CtxBootStrap.SubscriptionNumber
$certPwdSecretName = "{0}-Password" -f $certSecretName
$keyVaultName = $global:CtxBootStrap.KeyVaultName
$keyVaultResourceGroupName = $global:CtxBootStrap.LandscapeResourceGroupName
if (-not (Get-AzKeyVault -VaultName $keyVaultName -ResourceGroupName $keyVaultResourceGroupName)) {
    Write-Error "Key vault $keyVaultName doesn't exist."
    return $null
}

$secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $certSecretName
$secretValue = $secret.SecretValueText
$rawCert = [System.Convert]::FromBase64String($secretValue)

$secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $certPwdSecretName
$identityCertificatePassword = $secret.SecretValue
$certificatePFX = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2($rawCert, $identityCertificatePassword, [System.Security.Cryptography.X509Certificates.X509KeyStorageFlags]::Exportable)

$dd=$certificatePFX.Subject.Split("=")
$destinationPath = "{0}\{1}" -f $devOpsProjectFolder, $dd[1]
$secretValue | Out-File -filepath $destinationPath -Force
Write-Host $secret.SecretValueText

# return $certificatePFX
