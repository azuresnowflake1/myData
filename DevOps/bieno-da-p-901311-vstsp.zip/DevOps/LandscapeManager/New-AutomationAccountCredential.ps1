Param
(
    [switch]$deleteSPN
)
'''
Create an SPN for use as an automation credential in a specific subscription.  We will only grant subscription permissions on one
subscription per SPN.  Run books must decide which RunAs credential to use based on what is passed.  This logic in handled in
Get-WebhookData.ps1
'''
$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"
$managerFolder = "{0}\{1}" -f $devOpsProjectFolder, "LandscapeManager"

& "$managerFolder\Runbooks\Import-PlatformCore.ps1"
& "$managerFolder\Runbooks\Import-PlatformAutomationClientCore.ps1"
$sub = & "$managerFolder\Select-Subscription"

$subscriptionNumber = $sub.subscription.Name.Split("-")[1]
$wehookData = Get-WebhookDataSample -subscriptionNumber $subscriptionNumber
$bootStrap = Get-Bootstrap -subscriptionNumber $subscriptionNumber
$subscriptionId = $bootStrap.subscriptionId
$tenantId = $bootStrap.TenantId

$automationAccountName = $bootStrap.AutomationAccount
$automationResourceGroupName = $bootStrap.AutomationResourceGroupName
$automationSubscriptionId = $bootStrap.AutomationSubscriptionId


$applicationName = "svc-b-da{0}-ina-automation" -f $subscriptionNumber
$applicationUri = "http://{0}da{1}-ina-automation" -f $bootStrap.NamePrefix, $subscriptionNumber
$resourceGroupName = "{0}-da{1}-{2}-{3}-rg" -f "bnlwe", $subscriptionNumber, $bootStrap.ProjectEnvironment, $bootStrap.ProjectNumber
$keyVaultName = $bootStrap.KeyVaultName
$applicationIdentityCertificateName = "$($applicationName)Cert"
$applicationIdentityCertificatePassword = "$($applicationName)Cert-Password"
$adApplicationUri = "http://{0}da{1}{2}{3}inaautomation" -f $bootStrap.NamePrefix, $subscriptionNumber, $bootStrap.ProjectEnvironment, $bootStrap.ProjectNumber
$certName = "HDI-ADLS-SPI-InA-Automation-da{0}.pfx" -f $subscriptionNumber

$applicationName
$resourceGroupName
$keyVaultName
$applicationIdentityCertificateName
$adApplicationUri

function Set-KeyVaultSecret {
Param
(
    
    [Parameter(HelpMessage='Specify the secret.')]
    [PSCredential] $secretCredential,

    [Parameter(Mandatory=$False,HelpMessage='Pass this to specify the secret expiry date', ParameterSetName="expiryDate")]
    [datetime]$secretExpiryDate,
    [string]$contentType
)

    $secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $secretCredential.UserName -ErrorAction SilentlyContinue
    if (-not $secret){
        $kyvlt = Set-AzKeyVaultSecret -VaultName $keyVaultName -Name $secretCredential.UserName -SecretValue $secretCredential.Password -Expires $secretExpiryDate -ContentType $contentType
        Write-Verbose "Secret $($secretCredential.UserName) added to the key vault $keyVaultName"
    }else {
        Write-Verbose "Update specified for the secret $($secretCredential.UserName) in the key vault $keyVaultName"
        $kyvlt = Set-AzKeyVaultSecret -VaultName $keyVaultName -Name $secretCredential.UserName -SecretValue $secretCredential.Password -Expires $secretExpiryDate -ContentType $contentType
        Write-Verbose "Secret $($secretCredential.UserName) updated to the key vault $keyVaultName"
    }
}
function Remove-Application {
    param
    (
        [string]$applicationName
    )
    
    $adSvcPrincipal = Get-AzADServicePrincipal -SearchString $applicationName  -ErrorAction SilentlyContinue
    if ($adSvcPrincipal)
    {
        Write-Host "Removing Service Principal $($adSvcPrincipal.Id)"
        $res1 = Remove-AzADServicePrincipal -ObjectId $adSvcPrincipal.Id -Force
        $adApplication = Get-AzADApplication -DisplayNameStartWith $applicationName -ErrorAction SilentlyContinue
        Write-Host "Removing AD Application $($adApplication.ObjectId)"
        $res2 = Remove-AzADApplication -ObjectId $adApplication.ObjectId -Force

        Remove-AzKeyVaultSecret -VaultName $keyVaultName -Name $applicationIdentityCertificateName -Force
        Remove-AzKeyVaultSecret -VaultName $keyVaultName -Name $applicationIdentityCertificatePassword -Force
        Remove-AzKeyVaultSecret -VaultName $keyVaultName -Name $applicationName -Force
        Remove-AzAutomationCertificate -AutomationAccountName $automationAccountName -Name $certName -ResourceGroupName $automationResourceGroupName -ErrorAction SilentlyContinue
    }
}
function Set-Application {
    param
    (
        [string]$applicationName,
        [string]$applicationUri,
        [datetime]$endDate
    ) 
    $spnCreated = $false
    $application = Get-AzADApplication -DisplayNameStartWith $applicationName -ErrorAction SilentlyContinue
    if (-not $application) {
        Write-Verbose "Creating new Azure AD Application"
        $application = New-AzADApplication -DisplayName $applicationName -IdentifierUris $applicationUri
        if (-not $application) { return }
        Write-Verbose "Created new Application AD Application"
        #Sync-AppOwners -sourceGroupName $landscapeGroupName -targetApp $application
    }
    else {
        Write-Verbose "Azure AD Application exists"
        #Sync-AppOwners -sourceGroupName $landscapeGroupName -targetApp $application
        
    }
    $applicationId = $application.ApplicationId
    $servicePrincipal = Get-AzADServicePrincipal -SearchString $applicationName -ErrorAction SilentlyContinue
    if (-not $servicePrincipal) {
        Write-Verbose "Creating new Deployment Service Principal"
        $servicePrincipal = New-AzADServicePrincipal -ApplicationId $applicationId -EndDate $endDate -DisplayName $applicationName
        if (-not $application) { return }
        $spnCreated = $true
    }
    elseif ($servicePrincipal.count -gt 1) {
        throw "Found too many SPNs with name $searchString in the Azure Active Directory. Provide the full name to narrow the search."
        return
    }
    else {
        Write-Verbose "Azure AD Service Principal exists"
    }
    $servicePrincipalId = $servicePrincipal.Id

    $users = Get-AzADServicePrincipal -SearchString $applicationName
    if ($users.Count -lt 1) {
        throw "$objType $searchString not found in the Azure Active Directory. Check the name."
    }
    if ($users.Count -gt 1) {
        throw "Found too many ${objType}s with name $searchString in the Azure Active Directory. Provide the full name to narrow the search."
    }
    Write-Verbose "Created Azure AD Application credential"

    Write-Host "Application Name: $applicationName"
    Write-Host "Application Uri: $applicationUri" 
    Write-Host "Application Id: $applicationId"
    Write-Host "ServicePrincipal Id: $servicePrincipalId"
    [hashtable]$Return = @{} 
    $Return.ApplicationId = $applicationId
    $Return.ServicePrincipal = $servicePrincipal
    $Return.spnCreated = $spnCreated
    return $Return
}

Login-AzCore -WebhookData $webhookData -aad
$numberofYearsforClientSecret = 2
$endDate = (Get-Date).AddYears($numberofYearsforClientSecret)
if ($deleteSPN) {
    Write-Host "Removing automation credential and settings"
    Remove-Application -applicationName $applicationName
    return
}
# if a new SPN is created you must grant platform contributor at subscription level
$appSpn = Set-Application -applicationName $applicationName -applicationUri $applicationUri -EndDate $endDate
if ($appSpn -and $appSpn.spnCreated) {
    # A new SPN was created so add its client secret to key vault
    $secretCredential = New-Object System.Management.Automation.PSCredential $applicationName, $appSpn.servicePrincipal.Secret
    $contentType = "The client secret for a specific subscription's automation SPN."
    Set-KeyVaultSecret -secretCredential $secretCredential -secretExpiryDate $endDate -contentType $contentType
    
    # we can hard code the parameter file name 
    $cert = & "$utilitiesFolder\New-Certificate.ps1" -parameterFile $bootStrap.LandscapeParameterFile -applicationName $applicationName -certificateName $certName
    Write-Host "Adding the application identity certificate"

    $rawCert = [System.Convert]::ToBase64String((Get-Content $cert.FilePath -Encoding Byte))
    $identityCertificate = ConvertTo-SecureString -AsPlainText $rawCert -Force
    $secretCredential = New-Object System.Management.Automation.PSCredential ($applicationIdentityCertificateName, $identityCertificate)
    $contentType = "The base64 encoded string for a specific subscription's automation SPN slef signed certificate."
    Set-KeyVaultSecret -secretCredential $secretCredential -secretExpiryDate $endDate -contentType $contentType

    Write-Host "Adding the application identity certificate password"
    $identityCertificateSecurePassword = ConvertTo-SecureString -AsPlainText $cert.Password -Force
    $secretCredential = New-Object System.Management.Automation.PSCredential ($applicationIdentityCertificatePassword, $identityCertificateSecurePassword)
    $contentType = "The password for the automation SPN's self signed certificate."
    Set-KeyVaultSecret -secretCredential $secretCredential -secretExpiryDate $endDate -contentType $contentType

    Select-AzSubscription -SubscriptionId $automationSubscriptionId
    # install the certificate in the automation account
    Write-Host "Installing the application SPN certificate into automation account $automationAccountName"
    if (Get-AzAutomationCertificate -AutomationAccountName $automationAccountName -Name $certName -ResourceGroupName $automationResourceGroupName -ErrorAction SilentlyContinue) {
        # Replace the existing
        Set-AzAutomationCertificate -AutomationAccountName $automationAccountName -Name $certName -Path $cert.FilePath `
        -Password $identityCertificateSecurePassword -ResourceGroupName $automationResourceGroupName -Exportable $False
    } else {
        New-AzAutomationCertificate -AutomationAccountName $automationAccountName -Name $certName -Path $cert.FilePath `
        -Password $identityCertificateSecurePassword -ResourceGroupName $automationResourceGroupName
    }
    # Create the RunAs connection in the automation account
    Remove-AzAutomationConnection -ResourceGroupName $automationResourceGroupName -AutomationAccountName $automationAccountName -Name $applicationName -Force -ErrorAction SilentlyContinue
    $ConnectionFieldValues = @{"ApplicationId" = $appSpn.ApplicationId; "TenantId" = $tenantId; "CertificateThumbprint" = $cert.Thumbprint; "SubscriptionId" = $subscriptionId}
    New-AzAutomationConnection -ResourceGroupName $automationResourceGroupName -AutomationAccountName $automationAccountName -Name $applicationName -ConnectionTypeName AzureServicePrincipal -ConnectionFieldValues $ConnectionFieldValues

    Select-AzSubscription -SubscriptionId $subscriptionId
}

return $appSpn
