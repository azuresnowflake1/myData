$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"
$managerFolder = "{0}\{1}" -f $devOpsProjectFolder, "LandscapeManager"

& "$utilitiesFolder\Test-ADLogin.ps1"
$daDevADGroups = Get-AzADGroup -SearchString "SEC-ES-DA-D-"

foreach ($daDevADGroup in $daDevADGroups){
    if($($daDevADGroup.DisplayName).contains("-azurecontributor")){
        $daDevADGroupArr = $($daDevADGroup.DisplayName).split("-")
        $itsg = $daDevADGroupArr[4]
        $groupName = "SEC-ES-DA-D-$itsg-ProjectAdmins"
        $group = Get-AzADGroup -DisplayName $groupName
        if (-not $group)
        {
            & "$managerFolder\New-AADGroups.ps1" -parameterFile d.$itsg
        }
        & "$managerFolder\Set-AADGroupAdmins.ps1" -parameterFile d.$itsg
    }
}
