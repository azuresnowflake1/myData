Param
(
    [Parameter(Mandatory = $True, HelpMessage = 'Specify the parameter file')]
    [String]$parameterFile,
    [Parameter(Mandatory = $False, HelpMessage = 'Specify if you are creating Sqldb instead of sqldw')]
    [switch]$SqlDb
)
# Add the non functional data ad groups as contained database users
# Grant dbo to the contributor group and readonly to the reader group
#####################################################################
# WARNING
# When this script runs in a CI pipeline it must use the Eco Master 
# service end point called Project-56728-ARMServiceEndPoint.  
#####################################################################
$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"
$managerFolder = "{0}\{1}" -f $devOpsProjectFolder, "LandscapeManager"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile
$tenantId = $parameters.parameters.tenantId.value

$cred = & "$managerFolder\Get-LandscapeServiceAccount" -parameterFile $parameterFile
if ($cred) {
    $sqlUser = $cred.UserName
    $sqlPwd = $cred.Password.SecretValueText
} else {
    Write-Error "The landscape service account credential was not found."
    return
}

Get-Module -Name SqlPS | Remove-Module
$a = Get-Module -ListAvailable -Name SqlServer
if (-not $a)
{
	Write-Host "installing SqlServer modules: start"
	Install-Module -Name SqlServer -Force -AllowClobber
	Write-Host "installing modules: end"
}

# You can use token authenticaton to connect
Function Get-AADToken {
    [CmdletBinding()]
    [OutputType([string])]
    PARAM (
        [String]$TenantID,
        [string]$ServicePrincipalId,
        [securestring]$ServicePrincipalPwd
    )
    Try {
        # Set Resource URI to Azure Database
        $resourceAppIdURI = 'https://database.windows.net/'

        # Set Authority to Azure AD Tenant
        $authority = 'https://login.windows.net/' + $TenantId
        $ClientCred = [Microsoft.IdentityModel.Clients.ActiveDirectory.ClientCredential]::new($ServicePrincipalId, $ServicePrincipalPwd)
        $authContext = [Microsoft.IdentityModel.Clients.ActiveDirectory.AuthenticationContext]::new($authority)
        $authResult = $authContext.AcquireTokenAsync($resourceAppIdURI, $ClientCred)
        #$Token = $authResult.Result.CreateAuthorizationHeader()
        $Token = $authResult.Result.AccessToken
    }
    Catch {
        Throw $_
        Write-Error -Message 'Failed to aquire Azure AD token'
    }
    $Token
}


$dbName = $parameters.parameters.sqlDataWarehouseName.value
if ($SqlDb) {
    $dbName = $parameters.parameters.sqlDatabaseName.value
}
$serverName = $parameters.parameters.sqlServerName.value;
$dataOwnerGroupName = $parameters.parameters.dataOwnerADGroupName.value;
$dataReaderGroupName = $parameters.parameters.dataReaderADGroupName.value;
$dataWriterGroupName = $parameters.parameters.dataWriterADGroupName.value;
$spnName = $parameters.parameters.adApplicationName.value;
$dataFactoryName = $parameters.parameters.dataFactoryName.value;

$createUserSql = "IF NOT EXISTS (SELECT * FROM sys.sysusers WHERE name='{0}')
    CREATE USER [{0}] FROM EXTERNAL PROVIDER
"
$grantRoleSql = "EXEC sp_addrolemember '{0}', '{1}'
"

# This only works if you have the right versions of 13.1 of sqlcmd.  It's required for integrated authentication to AAD.  Use commandlets from SqlServer module not SqlPS.
$sqlCmdConnectString="Server=$serverName.database.windows.net;Initial Catalog=$dbName;Persist Security Info=False;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Authentication=""Active Directory Password"";User ID={0};Password={1}" -f $sqlUser, $sqlPwd

$sqlCommand = $createUserSql -f $dataOwnerGroupName
$sqlCommand += ($grantRoleSql -f "db_owner", $dataOwnerGroupName) 
$sqlCommand += "
"
$sqlCommand += $createUserSql -f $dataReaderGroupName
$sqlCommand += ($grantRoleSql -f "db_datareader", $dataReaderGroupName)
$sqlCommand += "GRANT VIEW DEFINITION TO [{0}]" -f $dataReaderGroupName
$sqlCommand += "GRANT EXECUTE TO [{0}]" -f $dataReaderGroupName

$sqlCommand += "
"
$sqlCommand += $createUserSql -f $dataWriterGroupName
$sqlCommand += ($grantRoleSql -f "db_dataWriter", $dataWriterGroupName)
$sqlCommand += ($grantRoleSql -f "db_dataReader", $dataWriterGroupName)
$sqlCommand += "GRANT VIEW DEFINITION TO [{0}]" -f $dataWriterGroupName
$sqlCommand += "GRANT EXECUTE TO [{0}]" -f $dataWriterGroupName
$sqlCommand += $createUserSql -f $spnName
$sqlCommand += ($grantRoleSql -f "db_dataWriter", $spnName)
if (-not $SqlDb) {
    # grant direct access to the application spn.  Need to do this for polybase loads.  Doesn't work if the permissions are added to the group the SPN belongs to
    $sqlCommand += "
    "
    
    $sqlCommand += ($grantRoleSql -f "staticrc20", $spnName)
    $sqlCommand += "GRANT CONTROL ON DATABASE::[{0}] to [{1}]" -f $dbName, $spnName
    $sqlCommand += $createUserSql -f $dataFactoryName
    $sqlCommand += ($grantRoleSql -f "db_owner", $dataFactoryName) 
    $sqlCommand += "GRANT CONTROL ON DATABASE::[{0}] to [{1}]" -f $dbName, $dataFactoryName
    
}

#Install ODBC 13.1 or higher from here https://www.microsoft.com/en-us/download/details.aspx?id=53339.    
#Install SQLCMD 13.1 minimum or higher required for this to run. Look here https://www.microsoft.com/en-us/download/details.aspx?id=53591. 
########################################################################
# 27/03/2018 : This command cannot execute on a hosted VSTS build agent because the user name and password is in landscape's private
# key vault.  Access using an application's deployment SPN is not possible
Invoke-SqlCmd -Query $sqlCommand -ConnectionString $sqlCmdConnectString

# Now grant connect in the master database
$sqlCmdConnectString="Server=$serverName.database.windows.net;Initial Catalog=master;Persist Security Info=False;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Authentication=""Active Directory Password"";User ID={0};Password={1}" -f $sqlUser, $sqlPwd

$sqlCommand = $createUserSql -f $dataOwnerGroupName
$sqlCommand += "
"
$sqlCommand += $createUserSql -f $dataReaderGroupName
$sqlCommand += "
"
$sqlCommand += $createUserSql -f $dataWriterGroupName
$sqlCommand += "
"
Invoke-SqlCmd -Query $sqlCommand -ConnectionString $sqlCmdConnectString


# #$ServicePrincipalId = $(Get-AzADServicePrincipal -DisplayName ).ApplicationId
# $SecureStringPassword = ConvertTo-SecureString -String $SpnSecret -AsPlainText -Force
# $SQLServerName = $serverName
# Get-AADToken -TenantID $TenantId -ServicePrincipalId $ServicePrincipalId -ServicePrincipalPwd $SecureStringPassword -OutVariable SPNToken


# Write-Verbose "Create SQL connectionstring"
# $conn = New-Object System.Data.SqlClient.SQLConnection 
# $DatabaseName = 'Master'
# $conn.ConnectionString = "Data Source=$SQLServerName.database.windows.net;Initial Catalog=$dbName;Connect Timeout=30"
# $conn.AccessToken = $($SPNToken)
# $conn
# $conn.ConnectionString
# Write-Verbose "Connect to database and execute SQL script"
# $conn.Open() 
# $query = "CREATE user [SEC-ES-da-q-56002-data-owner] from external provider"
# $query = "select GETDATE()"
# $command = New-Object -TypeName System.Data.SqlClient.SqlCommand($query, $conn) 	
# $Result = $command.ExecuteScalar()
# $Result
# $conn.Close() 
