Param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$parameterFile,
    [Parameter(Mandatory = $False, HelpMessage='If you want to set permissions on the dedicated web app key vault')]
    [Switch]$WebApp,
    [Parameter(Mandatory = $False, HelpMessage='If you want to set permissions on the dedicated Machine Learning key vault')]
    [Switch]$MachineLearning
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

$keyVaultResourceGroupName = $parameters.parameters.keyVaultResourceGroupName.value
$keyVaultName = $parameters.parameters.keyVaultName.value

if($WebApp) {
        $keyVaultResourceGroupName = $parameters.parameters.webAppResourceGroupName.value
        $keyVaultName = $parameters.parameters.keyVaultNameWA.value    
        }

if($MachineLearning) {
        $keyVaultResourceGroupName = $parameters.parameters.machineLearningResourceGroupName.value
        $keyVaultName = $parameters.parameters.machineLearningKeyVaultName.value    
    }


# developers/dev Ops get access in dev only so thay can debug powershell deployment scripts
# can't grant access to the contributor NF group because the app SPN is a member.
# In new foundation we don't want the application to have key vault access.
if ("d".Contains($parameters.parameters.projectEnvironment.value)) {
    $objectId = $parameters.parameters.developerADGroupId.value
    Set-AzKeyVaultAccessPolicy -VaultName $keyVaultName -ResourceGroupName $keyVaultResourceGroupName -ObjectId $objectId -PermissionsToSecrets get,list 
    $objectId = $parameters.parameters.supportADGroupId.value
    Set-AzKeyVaultAccessPolicy -VaultName $keyVaultName -ResourceGroupName $keyVaultResourceGroupName -ObjectId $objectId -PermissionsToSecrets get,list
}

# grant access to the automation account
$objectId = $parameters.parameters.landscapeAutomationAccountObjectId.value
Set-AzKeyVaultAccessPolicy -VaultName $keyVaultName -ResourceGroupName $keyVaultResourceGroupName -ObjectId $objectId -PermissionsToSecrets get,list,set

$objectId = $parameters.parameters.deploymentServicePrincipalId.value
Set-AzKeyVaultAccessPolicy -VaultName $keyVaultName -ResourceGroupName $keyVaultResourceGroupName -ObjectId $objectId -PermissionsToSecrets get,list

$objectId = $parameters.parameters.managerADGroupId.value
Set-AzKeyVaultAccessPolicy -VaultName $keyVaultName -ResourceGroupName $keyVaultResourceGroupName -ObjectId $objectId -PermissionsToSecrets get,list,set,delete,backup,restore,recover,purge -PermissionsToKeys decrypt,encrypt,unwrapKey,wrapKey,verify,sign,get,list,update,create,import,delete,backup,restore,recover,purge

$aadSPN = Get-AzAdApplication -DisplayName IANDASPNProd
if ($aadSPN) {
    Set-AzKeyVaultAccessPolicy  -VaultName $keyVaultName -ResourceGroupName $keyVaultResourceGroupName -ObjectId $aadSPN.ObjectId -PermissionsToSecrets Get,List,Set
}