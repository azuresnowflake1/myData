param
(
    [Parameter(Mandatory = $True, HelpMessage = "The name of the parameter file")]
    [string]$parameterFile,

    # The source file to use to create the new file. Use an existing parameter file that works.
    [Parameter(Mandatory = $False, HelpMessage = "The source file to use to create a default ADF ARM parameter file.")]
    [string]
    $templateFile = "Templates\adf.parameters.template.json",

    [Parameter(Mandatory = $false, HelpMessage = "Pass this if adls gen1 storage attached")]
    [switch]$adlsGen1
)

$teamProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName

$devOpsProjectFolder = "{0}\DevOps" -f (Get-Item -Path $teamProjectFolder).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"
$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

$targetFileFullPath = "{0}\Projects\{1}" -f $devOpsProjectFolder, $parameters.parameters.dataFactoryRootParameterFileName.value
$overrideFileFullPath = "{0}\Projects\{1}.json" -f $devOpsProjectFolder, $parameters.parameters.dataFactoryName.value
$templateFileFullPath = "{0}\{1}" -f $devOpsProjectFolder, $templateFile
Write-Verbose "ADF Template parameter file : $templateFileFullPath"
if ($adlsGen1) {
    Write-Verbose "ADF parameter file will be generated for ADLS Gen1"
} else {
    Write-Verbose "ADF parameter file will be generated for ADLS Gen2"
}

Function Get-SharedIRResourceId {
    # param (
    #     OptionalParameters
    # )
    $masterADFResourceGroupName = $parameters.parameters.landscapeDataFactoryResourceGroupName.value
    $masterADFName = $parameters.parameters.landscapeDataFactoryName.value
    $masterIntegrationRuntimeName = $parameters.parameters.landscapeDataFactorySelfHostedIRName.value

    $masterFactory = Get-AzDataFactoryV2 -ResourceGroupName $masterADFResourceGroupName -Name $masterADFName -DefaultProfile $Global:CtxMasterAdf
    if (-not $masterFactory) {
        Write-Error "Unable to determine shared self hosted IR because the master ADF was not found: $masterADFResourceGroupName / $masterADFName"
        return;
    }

    $SharedIR = Get-AzDataFactoryV2IntegrationRuntime -ResourceGroupName $masterADFResourceGroupName -DataFactoryName $masterADFName `
    -Name $masterIntegrationRuntimeName -DefaultProfile $Global:CtxMasterAdf


    return $SharedIR.Id
}

$adfParameters = Get-Content -Path $templateFileFullPath -Raw | ConvertFrom-JSON

$irResourceId = Get-SharedIRResourceId
$sqlDwConnectionString = "Data Source=tcp:{0}.database.windows.net,1433;Initial Catalog={1};Integrated Security=False;Encrypt=True;Connect Timeout=30" -f $parameters.parameters.sqlServerName.value, $parameters.parameters.sqlDataWarehouseName.value
$sqlDbConnectionString = "Data Source=tcp:{0}.database.windows.net,1433;Initial Catalog={1};Integrated Security=False;Encrypt=True;Connect Timeout=30" -f $parameters.parameters.sqlServerName.value, $parameters.parameters.sqlDatabaseName.value

$adfParameters.parameters.factoryName.value = $parameters.parameters.dataFactoryName.value
$adfParameters.parameters.LS_ASDW_properties_typeProperties_connectionString.value = $sqlDwConnectionString
$adfParameters.parameters.LS_ADLS_UDL_properties_typeProperties_dataLakeStoreUri.value = ("adl://{0}.azuredatalakestore.net/" -f $parameters.parameters.sharedAdlStoreName.value)
$adfParameters.parameters.LS_ADLS_UDL_properties_typeProperties_servicePrincipalId.value = $parameters.parameters.applicationId.value
$adfParameters.parameters.LS_ADLS_UDL_properties_typeProperties_servicePrincipalKey_secretName.value = $parameters.parameters.adApplicationName.value
$adfParameters.parameters.LS_ADLS_UDL_properties_typeProperties_subscriptionId.value = "50327adb-f8a0-4908-8d31-aa182df19f02" #UDL is in PROD  Hack Alert!
$adfParameters.parameters.LS_ADLS_UDL_properties_typeProperties_resourceGroupName.value = $parameters.parameters.sharedAdlStoreResourceGroupName.value
if ($adlsGen1) {
    $adfParameters.parameters.LS_ADLS_properties_typeProperties_dataLakeStoreUri.value = ("adl://{0}.azuredatalakestore.net/" -f $parameters.parameters.adlStoreName.value)
} else {
$adfParameters.parameters.LS_ADLS_properties_typeProperties_Url.value = ("https://{0}.dfs.core.windows.net/" -f $parameters.parameters.adlStoreName.value)
}
$adfParameters.parameters.LS_ADLS_properties_typeProperties_servicePrincipalId.value = $parameters.parameters.applicationId.value
$adfParameters.parameters.LS_ADLS_properties_typeProperties_servicePrincipalKey_secretName.value = $parameters.parameters.adApplicationName.value
$adfParameters.parameters.LS_ADLS_properties_typeProperties_subscriptionId.value =  $parameters.parameters.subscriptionId.value
$adfParameters.parameters.LS_ADLS_properties_typeProperties_resourceGroupName.value = $parameters.parameters.adlStoreResourceGroupName.value

if ([string]::IsNullOrEmpty($parameters.parameters.pslzStoreName.value)) 
    {
    $properties = $adfParameters.parameters | Get-Member -MemberType Properties | Select-Object
        ForEach($property in $properties) 
                {
                if($property.name -like "LS_ADLS_PSLZ_*") 
                    {
                    $adfParameters.parameters.psobject.properties.remove($property.Name)
                    }
                 }
    }
else {
    $adfParameters.parameters.LS_ADLS_PSLZ_properties_typeProperties_dataLakeStoreUri.value = ("adl://{0}.azuredatalakestore.net/" -f $parameters.parameters.pslzStoreName.value)
    $adfParameters.parameters.LS_ADLS_PSLZ_properties_typeProperties_servicePrincipalId.value = $parameters.parameters.applicationId.value
    $adfParameters.parameters.LS_ADLS_PSLZ_properties_typeProperties_servicePrincipalKey_secretName.value = $parameters.parameters.adApplicationName.value
    $adfParameters.parameters.LS_ADLS_PSLZ_properties_typeProperties_subscriptionId.value =  $parameters.parameters.pslzSubscriptionId.value
    $adfParameters.parameters.LS_ADLS_PSLZ_properties_typeProperties_resourceGroupName.value = $parameters.parameters.pslzStoreResourceGroupName.value
    }
 

$adfParameters.parameters.LS_KV_LOCAL_properties_typeProperties_baseUrl.value = ("https://{0}.vault.azure.net/" -f $parameters.parameters.keyVaultName.value)
$adfParameters.parameters.("dfgw-onprem_properties_typeProperties_linkedInfo_resourceId").value = $irResourceId

$adfParameters.parameters.LS_ASQL_properties_typeProperties_servicePrincipalId.value = $parameters.parameters.applicationId.value
$adfParameters.parameters.LS_ASQL_properties_typeProperties_servicePrincipalKey_secretName.value = $parameters.parameters.adApplicationName.value
$adfParameters.parameters.LS_ASQL_properties_typeProperties_connectionString.value = $sqlDbConnectionString


$adfParameters.parameters.PL_PAUSE_AAS_properties_0_typeProperties_url.value = $parameters.parameters.WebhookAasPause.value
$adfParameters.parameters.PL_RESUME_AAS_properties_0_typeProperties_url.value = $parameters.parameters.WebhookAasResume.value
$adfParameters.parameters.PL_PAUSE_SQLDW_properties_0_typeProperties_url.value = $parameters.parameters.webhookSqlDwPause.value
$adfParameters.parameters.PL_RESUME_SQLDW_properties_0_typeProperties_url.value = $parameters.parameters.webhookSqlDwResume.value
$adfParameters.parameters.PL_RESUME_SQLDW_WITH_CALLBACK_properties_0_typeProperties_url.value = $parameters.parameters.webhookSqlDwResume.value

$adfParameters.parameters.PL_SCALE_AAS_properties_0_typeProperties_url.value = $parameters.parameters.webhookScaleUpDownAAS.value
$adfParameters.parameters.PL_SCALE_SQLDB_properties_0_typeProperties_url.value = $parameters.parameters.webhookScaleUpDownSql.value
$adfParameters.parameters.PL_SCALE_SQLDW_properties_0_typeProperties_url.value = $parameters.parameters.webhookScaleUpDownSql.value

$adfParameters | ConvertTo-JSON -Depth 10 | Out-File -filepath $targetFileFullPath -Force
Write-Host "ADF root ARM parameter file created at $targetFileFullPath"
$adfParameters.PSObject.properties.remove('parameters')
$adfParameters = $adfParameters | Add-Member -NotePropertyMembers @{parameters=@{}} -PassThru

if (Test-Path -Path $overrideFileFullPath -PathType Leaf) {
    Write-Warning "The developer controlled parameter file $(Split-Path -path $overrideFileFullPath -Leaf) already exists.  Skipping creation."
} else {
    $adfParameters | ConvertTo-JSON -Depth 10 | Out-File -filepath $overrideFileFullPath -NoClobber
}

return $targetFileFullPath