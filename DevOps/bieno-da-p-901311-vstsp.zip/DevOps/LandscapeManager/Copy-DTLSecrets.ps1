param(
    [Parameter(Mandatory=$true)] [string]$kvSource="bnlweda04dtl96e55164", # Phils KV
	[Parameter(Mandatory=$true)] [string]$kvTarget,
	$dtlResourceGroupNAme = "bnlwe-da04-p-00000-dtl-rg"
)
# Copy the DTL secrets from one key vault (Phil's) to another. These secrets are used by the VM formula
# When a user connects to DTL the lab creates a key vault in the lab resource group for that person.  This script
# seeds the key vault with the vaules from another.
# In order for this to work you have to edit the access policy of the Key vault so you can read the source and write to
# the target.  You always have read access on your own.  It's a pain to workout whose key vault you are writing to.
# Only way from the portal is to open the access policy and see who has access.

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.Parent.FullName

$secrets = Get-AzKeyVaultSecret -VaultName $kvSource
foreach($secret in $secrets)
{
	$secret = Get-AzKeyVaultSecret -VaultName $kvSource -Name $secret.Name
	
	$keyName = $secret.name
	#$keyValue = ConvertTo-SecureString -AsPlainText $secret.SecretValueText -Force
	$keyValue = $secret.SecretValue
	Write-Host "Adding secret $keyName to $kvTarget"
		$secretCredential = New-Object System.Management.Automation.PSCredential ($keyName, $keyValue)
		Set-AzKeyVaultSecret -VaultName $kvTarget -Name $secretCredential.UserName -SecretValue $secretCredential.Password
}
Write-Host "Secret copy is completed."