Param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$parameterFile,

    [Parameter(Mandatory = $False, HelpMessage = "Pass this if the env is a data science environment")]
    [switch]$dataScienceEnvironment
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"
$managerFolder = "{0}\{1}" -f $devOpsProjectFolder, "LandscapeManager"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile
$cred = & "$managerFolder\Get-LandscapeServiceAccount" -parameterFile $parameterFile
if (!$cred){
    Write-Error "The landscape service account credential was not found."
    return
}

function Compare-AdGroup {
    param( [string]$sourceGroupName, [string]$targetGroupName )
   
    $sourceGroup = Get-AzADGroup -DisplayName $sourceGroupName -DefaultProfile $Global:ctxSPN
    $targetGroup = Get-AzADGroup -DisplayName $targetGroupName -DefaultProfile $Global:ctxSPN
    $sourceMembers = Get-AzADGroupMember -GroupObjectId $sourceGroup.Id -DefaultProfile $Global:ctxSPN
    $targetMembers = Get-AzADGroupMember -GroupObjectId $targetGroup.Id -DefaultProfile $Global:ctxSPN

    $members = @{}

    foreach($member in $sourceMembers) {
        $match = $false
        foreach($gp in $targetMembers) {
            if ($gp.Id -eq $member.Id) {
                # nothing to do
                $match = $true
                break
            }
        }
        if (-not $match) {
            # group is in the source but not the target group.  Need to add it.
            Write-Host "Need to add $($member.Mail)"
            $members.Add($member.Id, $member)
        }
    }
    return $members
}
function New-AdGroup {
    param( [string]$groupName, [string]$description, [string]$managerGroupId)
    $warning = " Do not edit this group without permission from IATech.AzureLandscape@unilever.com."
    $description += $warning
    $group = Get-AzADGroup -DisplayName $groupName -DefaultProfile $Global:ctxSPN
    if (-not $group)
    {
        Write-Host "Creating security group $groupName."
        $group = New-AzADGroup -Description $description -DisplayName $groupName -MailNickName $groupName -DefaultProfile $Global:ctxSPN
        $groupCreated=$true

    } else {
        $groupCreated=$false
        Write-Host "Security group $groupName already exists."
    }

    if (-not $groupCreated) {
        $owners = Get-AzureADGroupOwner -ObjectId $group.Id -All $True
    }  else {
        $owners = @()
    }
    
    $managers = Get-AzADGroupMember -GroupObjectId $managerGroupId -DefaultProfile $Global:ctxSPN
    foreach($manager in $managers)
    {
        if (-not ($owners | Where-Object ObjectId -eq $manager.Id))
        {
            Write-Host "Add landscape manager $($manager.DisplayName) as group owner to $($group.DisplayName)"
            Add-AzureADGroupOwner -ObjectId $group.Id -RefObjectId $manager.Id -ErrorAction SilentlyContinue
        }
        else {
            Write-Host "Landscape manager $($manager.DisplayName) is already a group owner of $($group.DisplayName)"
        }
    }
    # foreach($owner in $owners)
    # {
    #     if (-not ($managers | Where-Object Id -eq $owner.ObjectId))
    #     {
    #         Write-Host "Removing $($owner.DisplayName) as group owner to $($group.DisplayName)"
    #         Remove-AzureADGroupOwner -ObjectId $group.Id -OwnerID $owner.ObjectId -ErrorAction SilentlyContinue
    #     }
    # }
    return $group
}

# Add one group as a member of another group
function Add-InAGroupToGroup {
    param( [string]$groupId, [string]$memberGroupId)
    $members = Get-AzADGroupMember -GroupObjectId $groupId -DefaultProfile $Global:ctxSPN
    #Add if not already a member    
    if (-not ($members | Where-Object Id -eq $memberGroupId)) {
        Add-AzADGroupMember -MemberObjectId $memberGroupId -TargetGroupObjectId $groupId -ErrorAction SilentlyContinue -DefaultProfile $Global:ctxSPN
    }
}
function Add-GroupMembersAsMembers {
    param( [string]$groupId, [string]$memberGroupId)
    $existingMembers = Get-AzADGroupMember -GroupObjectId $groupId -DefaultProfile $Global:ctxSPN
    $newMembers = Get-AzADGroupMember -GroupObjectId $memberGroupId -DefaultProfile $Global:ctxSPN
    foreach($newMember in $newMembers) {
        #Add if not already a member    
        if (-not ($existingMembers | Where-Object Id -eq $newMember.Id)) {
            Add-AzADGroupMember -MemberObjectId $newMember.Id -TargetGroupObjectId $groupId -ErrorAction SilentlyContinue -DefaultProfile $Global:ctxSPN
        }
    }
    
}

function Add-InAGroupMember {
    param( [string]$groupId, 
    [string]$memberName)
    if ($memberName.ToLower().StartsWith("svc_")) { 
        $member = Get-AzADUser -UserPrincipalName $memberName -DefaultProfile $Global:ctxSPN
    }
    elseif ($memberName.StartsWith("svc-")) {
        $member = Get-AzADServicePrincipal -DisplayName $memberName -DefaultProfile $Global:ctxSPN
    } else {
        $member = Get-AzADGroup -DisplayName $memberName -DefaultProfile $Global:ctxSPN
    }
    
    if ($member) {
        Add-InAGroupToGroup -groupId $groupId -memberGroupId $member.Id
    } else {
        Write-Error "Add AD member '$memberName' to group '$groupId' failed because the member doesn't exist."
    }
}

function Remove-InAGroupOwner {
    param ([string]$groupName, [string]$managerGroupId)
    
    $group = Get-AzADGroup -DisplayName $groupName -DefaultProfile $Global:ctxSPN
    $owners = Get-AzureADGroupOwner -ObjectId $group.Id -All $True
    $managers = Get-AzADGroupMember -GroupObjectId $managerGroupId -DefaultProfile $Global:ctxSPN

    foreach($owner in $owners)
    {
        if (-not ($managers | Where-Object Id -eq $owner.ObjectId))
        {
            Write-Host "Removing $($owner.DisplayName) as group owner to $($group.DisplayName)"
            Remove-AzureADGroupOwner -ObjectId $group.Id -OwnerID $owner.ObjectId -ErrorAction SilentlyContinue
        }
    } 
}

$projectAdminADGroupName = $parameters.parameters.projectAdminADGroupName.value
$developerADGroupName = $parameters.parameters.developerADGroupName.value
$testerADGroupName = $parameters.parameters.testerADGroupName.value
$supportADGroupName = $parameters.parameters.supportADGroupName.value
$supportLevel1ADGroupName = $parameters.parameters.supportLevel1ADGroupName.value
$dataReaderADGroupName = $parameters.parameters.dataReaderADGroupName.value
$dataWriterADGroupName = $parameters.parameters.dataWriterADGroupName.value
$dataOwnerADGroupName = $parameters.parameters.dataOwnerADGroupName.value
$landscapeGroupName = $parameters.parameters.managerADGroupName.value
$landscapeCoreGroupName = "SEC-ES-DA-p-56728-azure-admin"
$projectName = $parameters.parameters.projectName.value
$appContributorGroupName = $parameters.parameters.appContributorGroupName.value
$appReaderGroupName = $parameters.parameters.appReaderGroupName.value
$projectEnvironment = $parameters.parameters.projectEnvironment.value
$deploymentAdApplicationName = $parameters.parameters.deploymentAdApplicationName.value
$adApplicationName = $parameters.parameters.adApplicationName.value
$developerSharepointADGroupId = $parameters.parameters.developerSharepointADGroupId.value
$dataScientistADGroupName = $parameters.parameters.dataScientistADGroupName.value
$dataEngineerADGroupName = $parameters.parameters.dataEngineerADGroupName.value

$managerGroup = Get-AzADGroup -DisplayName $landscapeGroupName -ErrorAction SilentlyContinue -DefaultProfile $Global:ctxSPN
$managerCoreGroup = Get-AzADGroup -DisplayName $landscapeCoreGroupName -ErrorAction SilentlyContinue -DefaultProfile $Global:ctxSPN
$projectAdminGroup = New-AdGroup -groupName $projectAdminADGroupName -description "project admin group for $projectName." -managerGroupId $managerCoreGroup.Id
# Add exiting core team as members
Add-GroupMembersAsMembers -groupId $projectAdminGroup.Id -memberGroupId $managerCoreGroup.Id
$developerGroup = New-AdGroup -groupName $developerADGroupName -description "I&A Tech developer group for $projectName." -managerGroupId $managerGroup.Id
$testerGroup = New-AdGroup -groupName $testerADGroupName -description "I&A Tech tester group for $projectName." -managerGroupId $managerGroup.Id
$supportGroup = New-AdGroup -groupName $supportADGroupName -description "I&A Tech AM Support group for $projectName." -managerGroupId $managerGroup.Id
$supportLevel1Group = New-AdGroup -groupName $supportLevel1ADGroupName -description "I&A Tech Level1 AM Support group for $projectName." -managerGroupId $managerGroup.Id
$dataReaderGroup = New-AdGroup -groupName $dataReaderADGroupName -description "I&A Tech data reader group for $projectName." -managerGroupId $managerCoreGroup.Id
$dataWriterGroup = New-AdGroup -groupName $dataWriterADGroupName -description "I&A Tech data writer group for $projectName." -managerGroupId $managerCoreGroup.Id
$dataOwnerGroup = New-AdGroup -groupName $dataOwnerADGroupName -description "I&A Tech data owner group for $projectName." -managerGroupId $managerCoreGroup.Id
# make the app contributor roup email enabled otherwise it can't be set as AAS AD admin
$appContributorGroup = New-AdGroup -groupName $appContributorGroupName -description "I&A Tech contributor group for $projectName." -managerGroupId $managerCoreGroup.Id
$appReaderGroup = New-AdGroup -groupName $appReaderGroupName -description "I&A Tech reader group for $projectName." -managerGroupId $managerCoreGroup.Id

if ($dataScienceEnvironment) {
    $dataScienceGroup = New-AdGroup -groupName $dataScientistADGroupName -description "I&A Tech data scientist group for $projectName." -managerGroupId $managerGroup.Id
    $dataEngineerGroup = New-AdGroup -groupName $dataEngineerADGroupName -description "I&A Tech data engineer group for $projectName." -managerGroupId $managerGroup.Id    
}

# Implement permissions for the operating model by environment
switch ($projectEnvironment) { 
    "d" {
        Add-InAGroupToGroup -groupId $appContributorGroup.Id -memberGroupId $managerGroup.Id
        Add-InAGroupMember -groupId $appContributorGroup.Id -memberName $cred.userName

        Add-InAGroupToGroup -groupId $appContributorGroup.Id -memberGroupId $developerGroup.Id
        Add-InAGroupToGroup -groupId $dataOwnerGroup.Id -memberGroupId $developerGroup.Id

        # Need app reader so they can access ADB workspace pass through cluster
        # Actually this doen't work.  Can see workspace but can't attach scripts to the cluster.
        # Will have to grant contributor instead.
        #Add-InAGroupToGroup -groupId $appReaderGroup.Id -memberGroupId $testerGroup.Id

        Add-InAGroupToGroup -groupId $appContributorGroup.Id -memberGroupId $supportGroup.Id
        Add-InAGroupToGroup -groupId $dataOwnerGroup.Id -memberGroupId $supportGroup.Id

        Add-InAGroupMember -groupId $appContributorGroup.Id -memberName $deploymentAdApplicationName
        Add-InAGroupMember -groupId $dataOwnerGroup.Id -memberName $deploymentAdApplicationName

        Add-InAGroupMember -groupId $dataWriterGroup.Id -memberName $adApplicationName
        Add-InAGroupToGroup -groupId $developerSharepointADGroupId  -memberGroupId $developerGroup.Id

        if ($dataEngineer) {
            Add-InAGroupToGroup -groupId $appReaderGroup.Id -memberGroupId $dataEngineerGroup.Id
            Add-InAGroupToGroup -groupId $dataReaderGroup.Id -memberGroupId $dataEngineerGroup.Id
        }
        
        if ($dataScienceGroup) {
            Add-InAGroupToGroup -groupId $appContributorGroup.Id -memberGroupId $dataScienceGroup.Id
            Add-InAGroupToGroup -groupId $dataWriterGroup.Id -memberGroupId $dataScienceGroup.Id
        }
    }
    "x" {
        # Experiment: This comes in two flavours, vanilla and Data Science.  It's not clear
        # what the difference is right now.  Copy dev for now pending ML Ops decisions
        Add-InAGroupToGroup -groupId $appContributorGroup.Id -memberGroupId $managerGroup.Id
        Add-InAGroupMember -groupId $appContributorGroup.Id -memberName $cred.userName

        Add-InAGroupToGroup -groupId $appContributorGroup.Id -memberGroupId $developerGroup.Id
        Add-InAGroupToGroup -groupId $dataOwnerGroup.Id -memberGroupId $developerGroup.Id

        # Need app reader so they can access ADB workspace pass through cluster
        # Actually this doen't work.  Can see workspace but can't attach scripts to the cluster.
        # Will have to grant contributor instead.
        #Add-InAGroupToGroup -groupId $appReaderGroup.Id -memberGroupId $testerGroup.Id

        Add-InAGroupToGroup -groupId $appContributorGroup.Id -memberGroupId $supportGroup.Id
        Add-InAGroupToGroup -groupId $dataOwnerGroup.Id -memberGroupId $supportGroup.Id

        Add-InAGroupMember -groupId $appContributorGroup.Id -memberName $deploymentAdApplicationName
        Add-InAGroupMember -groupId $dataOwnerGroup.Id -memberName $deploymentAdApplicationName

        Add-InAGroupMember -groupId $dataWriterGroup.Id -memberName $adApplicationName
        Add-InAGroupToGroup -groupId $developerSharepointADGroupId  -memberGroupId $developerGroup.Id

        if ($dataEngineer) {
            Add-InAGroupToGroup -groupId $appReaderGroup.Id -memberGroupId $dataEngineerGroup.Id
            Add-InAGroupToGroup -groupId $dataReaderGroup.Id -memberGroupId $dataEngineerGroup.Id
        }
        
        if ($dataScienceGroup) {
            Add-InAGroupToGroup -groupId $appContributorGroup.Id -memberGroupId $dataScienceGroup.Id
            Add-InAGroupToGroup -groupId $dataWriterGroup.Id -memberGroupId $dataScienceGroup.Id
        }
    }
    "q" {
        #Add-InAGroupToGroup -groupId $appContributorGroup.Id -memberGroupId $managerGroup.Id
        Add-InAGroupMember -groupId $appContributorGroup.Id -memberName $cred.userName

        Add-InAGroupToGroup -groupId $appReaderGroup.Id -memberGroupId $developerGroup.Id
        Add-InAGroupToGroup -groupId $dataReaderGroup.Id -memberGroupId $developerGroup.Id

        Add-InAGroupToGroup -groupId $appReaderGroup.Id -memberGroupId $testerGroup.Id
        Add-InAGroupToGroup -groupId $dataWriterGroup.Id -memberGroupId $testerGroup.Id
        
        Add-InAGroupToGroup -groupId $appReaderGroup.Id -memberGroupId $supportGroup.Id
        Add-InAGroupToGroup -groupId $dataReaderGroup.Id -memberGroupId $supportGroup.Id

        Add-InAGroupToGroup -groupId $appReaderGroup.Id -memberGroupId $supportLevel1Group.Id
        Add-InAGroupToGroup -groupId $dataReaderGroup.Id -memberGroupId $supportLevel1Group.Id

        Add-InAGroupMember -groupId $appContributorGroup.Id -memberName $deploymentAdApplicationName
        Add-InAGroupMember -groupId $dataOwnerGroup.Id -memberName $deploymentAdApplicationName

        Add-InAGroupMember -groupId $dataWriterGroup.Id -memberName $adApplicationName
      
        if ($dataScienceGroup) {
            Add-InAGroupToGroup -groupId $appReaderGroup.Id -memberGroupId $dataScienceGroup.Id
            Add-InAGroupToGroup -groupId $dataReaderGroup.Id -memberGroupId $dataScienceGroup.Id
        }
    }
    "b" {
        #Add-InAGroupToGroup -groupId $appContributorGroup.Id -memberGroupId $managerGroup.Id
        Add-InAGroupMember -groupId $appContributorGroup.Id -memberName $cred.userName

        Add-InAGroupToGroup -groupId $appReaderGroup.Id -memberGroupId $testerGroup.Id
        Add-InAGroupToGroup -groupId $dataReaderGroup.Id -memberGroupId $testerGroup.Id
        
        Add-InAGroupToGroup -groupId $appReaderGroup.Id -memberGroupId $supportGroup.Id
        Add-InAGroupToGroup -groupId $dataReaderGroup.Id -memberGroupId $supportGroup.Id

        Add-InAGroupToGroup -groupId $appReaderGroup.Id -memberGroupId $supportLevel1Group.Id
        Add-InAGroupToGroup -groupId $dataReaderGroup.Id -memberGroupId $supportLevel1Group.Id

        Add-InAGroupMember -groupId $appContributorGroup.Id -memberName $deploymentAdApplicationName
        Add-InAGroupMember -groupId $dataOwnerGroup.Id -memberName $deploymentAdApplicationName

        Add-InAGroupMember -groupId $dataWriterGroup.Id -memberName $adApplicationName
    }
    "u" {
        #Add-InAGroupToGroup -groupId $appContributorGroup.Id -memberGroupId $managerGroup.Id
        Add-InAGroupMember -groupId $appContributorGroup.Id -memberName $cred.userName

        #Add-InAGroupToGroup -groupId $appReaderGroup.Id -memberGroupId $testerGroup.Id
        #Add-InAGroupToGroup -groupId $dataWriterGroup.Id -memberGroupId $testerGroup.Id
        
        Add-InAGroupToGroup -groupId $appContributorGroup.Id -memberGroupId $supportGroup.Id
        Add-InAGroupToGroup -groupId $dataOwnerGroup.Id -memberGroupId $supportGroup.Id

        Add-InAGroupToGroup -groupId $appReaderGroup.Id -memberGroupId $supportLevel1Group.Id
        Add-InAGroupToGroup -groupId $dataReaderGroup.Id -memberGroupId $supportLevel1Group.Id

        Add-InAGroupMember -groupId $appContributorGroup.Id -memberName $deploymentAdApplicationName
        Add-InAGroupMember -groupId $dataOwnerGroup.Id -memberName $deploymentAdApplicationName

        Add-InAGroupMember -groupId $dataWriterGroup.Id -memberName $adApplicationName
    }
    "p" {
        #Add-InAGroupToGroup -groupId $appContributorGroup.Id -memberGroupId $managerGroup.Id
        Add-InAGroupMember -groupId $appContributorGroup.Id -memberName $cred.userName
        
        Add-InAGroupToGroup -groupId $appReaderGroup.Id -memberGroupId $supportGroup.Id
        Add-InAGroupToGroup -groupId $dataReaderGroup.Id -memberGroupId $supportGroup.Id

        Add-InAGroupToGroup -groupId $appReaderGroup.Id -memberGroupId $supportLevel1Group.Id
        Add-InAGroupToGroup -groupId $dataReaderGroup.Id -memberGroupId $supportLevel1Group.Id
        
        Add-InAGroupMember -groupId $appContributorGroup.Id -memberName $deploymentAdApplicationName
        Add-InAGroupMember -groupId $dataOwnerGroup.Id -memberName $deploymentAdApplicationName

        Add-InAGroupMember -groupId $dataWriterGroup.Id -memberName $adApplicationName
    }
    "r" {
        # DR: Identical to PROD
        #Add-InAGroupToGroup -groupId $appContributorGroup.Id -memberGroupId $managerGroup.Id
        Add-InAGroupMember -groupId $appContributorGroup.Id -memberName $cred.userName
        
        Add-InAGroupToGroup -groupId $appReaderGroup.Id -memberGroupId $supportGroup.Id
        Add-InAGroupToGroup -groupId $dataReaderGroup.Id -memberGroupId $supportGroup.Id

        Add-InAGroupMember -groupId $appContributorGroup.Id -memberName $deploymentAdApplicationName
        Add-InAGroupMember -groupId $dataOwnerGroup.Id -memberName $deploymentAdApplicationName

        Add-InAGroupMember -groupId $dataWriterGroup.Id -memberName $adApplicationName
    }
    default {
        Write-Error "Project Environment unknown. Use d for development, q for testing, b for UAT, u for pre-prod and p for production"  
    }
}


Remove-InAGroupOwner -groupName $projectAdminADGroupName -managerGroupId $managerCoreGroup.Id
Remove-InAGroupOwner -groupName $developerADGroupName -managerGroupId $managerGroup.Id
Remove-InAGroupOwner -groupName $testerADGroupName -managerGroupId $managerGroup.Id
Remove-InAGroupOwner -groupName $supportADGroupName -managerGroupId $managerGroup.Id
Remove-InAGroupOwner -groupName $dataReaderADGroupName -managerGroupId $managerCoreGroup.Id
Remove-InAGroupOwner -groupName $dataWriterADGroupName -managerGroupId $managerCoreGroup.Id
Remove-InAGroupOwner -groupName $dataOwnerADGroupName -managerGroupId $managerCoreGroup.Id
Remove-InAGroupOwner -groupName $appContributorGroupName -managerGroupId $managerCoreGroup.Id
Remove-InAGroupOwner -groupName $appReaderGroupName -managerGroupId $managerCoreGroup.Id

