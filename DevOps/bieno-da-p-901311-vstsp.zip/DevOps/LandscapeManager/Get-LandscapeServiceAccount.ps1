Param
(
    [Parameter(Mandatory = $True, HelpMessage = 'Specify the parameter file')]
    [String]$parameterFile
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile


$keyVaultName = "bnlwe-da04-d-56731-kv-01"
$secretUser = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name "ServiceAccountName" 
if (-not $secretUser)
{
    Write-Error "The landscape admin service account username credential was not found in key vault $keyVaultName.  Please add then try again."
    return $null
}
$secretPwd = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name "ServiceAccountPassword"
if (-not $secretPwd)
{
    Write-Error "The landscape admin service account password credential was not found in key vault $keyVaultName.  Please add then try again."
    return $null
}
$cred = @{ userName = $secretUser.SecretValueText; password = $secretPwd; }
return $cred