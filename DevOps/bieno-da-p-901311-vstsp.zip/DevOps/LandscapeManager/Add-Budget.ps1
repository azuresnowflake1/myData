
   Param
   (
       [Parameter(Mandatory = $True, HelpMessage = 'Specify the parameter file')][String]$parameterFile,
        ##[Parameter(Mandatory = $True, HelpMessage = 'Enter Email ID''s Separated by , ')][array]$EmailLists,
        [Parameter( Mandatory = $false, HelpMessage = 'Specify the Amount')][ValidateRange(1,100000)][int]$budgetAmount,
        [Parameter(Mandatory = $false , HelpMessage = 'Specify the threshold')][ValidateRange(1,100)][int]$budgetThreshold
   )
   $EmailLists = @()
   Write-Host $writeEmptyLine 
   Write-Host "Enter Email ID to Send Budget Alert Notifications Click Enter after Each ID" 
   Write-Host "Click just Enter if no more IDs"
   Write-Host $writeEmptyLine
    do {
        $input = (Read-Host "Email ID")
        if ($input -ne '') {$EmailLists += $input}
        }
    until ($input -eq '')

    ##$EmailLists

   if ($budgetAmount -eq 0)    {$budgetAmount=1000}
   if ($budgetThreshold -eq 0)  {$budgetThreshold=80}
   $devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
   $utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"
   
   $parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile
   $bearerToken = & "$utilitiesFolder\Get-Bearer2oAuthToken" -parameterFile $parameterFile
    $ResourceGroupName = $parameters.parameters.budgetAlertResourceGroupName.value
    $subscriptionId = $parameters.parameters.subscriptionId.value
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    $headers.Add("ContentType", "application/json")
    $headers.Add("Authorization", "Bearer $bearerToken")
    $headers.Add("Content-Type", "application/json")
    $type = "Microsoft.Consumption/budgets"
    $budgetName = "$ResourceGroupName-budget"
    $budgetCategory = "Cost"
    $timeGrain = "Monthly"
    $startDate=$(Get-Date -Day 1 )
    $endDate=(get-date -Day 1).addyears(10).adddays(-1)
    $operator = "GreaterThanOrEqualTo"
    $threshold = "budgetThreshold"
    $contactEmails = @()
    $contactRoles = "Contributor","Reader"
    $contactGroups = @()
    $resourcesFilter = @()
    $metersFilter = @()
    $ShortName=$ResourceGroupName.split("-")
    $actionGroupName=$ShortName[2]+'-'+$ShortName[3]+"-BudgetMonitoring-Group"
    $actionGroupShortName=$ShortName[2]+'-'+$ShortName[3]
    

    ### Create Action Grpup############################
    $emailReceiver=@()
        foreach ($EmailList in $EmailLists)
        {
  

            $emailReceiverName=$EmailList.split(".")
  
            $Name='SendMailTo'+$emailReceiverName[0]
            $emailReceiver += New-AzActionGroupReceiver -Name $Name -EmailReceiver -EmailAddress $EmailList
 
        }
        Write-Host $writeEmptyLine
        Write-Host $writeEmptyLine +" Started Creating Action Group $actionGroupName " -warningaction ignore

        Set-AzActionGroup -Name $actionGroupName -ResourceGroup $ResourceGroupName -ShortName $actionGroupShortName -Receiver $emailReceiver -warningaction ignore
 
        Write-Host ($writeEmptyLine + " Action Group $actionGroupName created" + $writeSeperator + $time)
        $ContactGroupsID=(Get-AzActionGroup -ResourceGroup $ResourceGroupName -Name $actionGroupName -warningaction ignore).id
        ### Create Action Grpup Complete ############################
    $Url='https://management.azure.com/subscriptions/'+$subscriptionId+'/resourceGroups/'+$ResourceGroupName+'/providers/Microsoft.Consumption/budgets/'+$budgetName+'?api-version=2018-03-31'
    
      $body = '{
        "type": "Microsoft.Consumption/budgets",

"properties": {

    "timePeriod": {

        "startDate": "2020-06-01T00:00:00Z",

        "endDate": ""

    },

    "timeGrain": "Monthly",

    "amount": "1000",

    "currentSpend": {

        "amount": 0.0,

        "unit": "GBP"

    },

    "category": "Cost",

    "notifications": {

        "actual_GreaterThan_85_Percent": {

            "enabled": true,

            "operator": "GreaterThan",

            "threshold": 85.00,

            "contactEmails": [  ""
            ],

            "contactRoles": ["Contributor"],

            "contactGroups":[],

            "thresholdType": "Actual"

        }

    },

    "currencySetting": "None"

}

}'

$body = $body | convertfrom-json
$body.properties.timePeriod.startDate = "$startDate"
$body.properties.timePeriod.endDate = "$endDate"
$body.properties.amount=$budgetAmount
$body.properties.notifications.actual_GreaterThan_85_Percent.threshold ="$budgetThreshold"
$body.properties.notifications.actual_GreaterThan_85_Percent.contactEmails=@($EmailLists[0])
$body.properties.notifications.actual_GreaterThan_85_Percent.contactGroups=@($ContactGroupsID)
$bodyText = $body | ConvertTo-Json -Depth 10

if ((Get-AzConsumptionBudget -ResourceGroupName $ResourceGroupName -Name $budgetName).name -eq $budgetName )
{Get-AzConsumptionBudget -ResourceGroupName $ResourceGroupName -Name $budgetName | Remove-AzConsumptionBudget }
Write-Host $writeEmptyLine
Write-Host $writeEmptyLine +" Started Creating Budget $budgetName " -warningaction ignore   
 
$response = Invoke-RestMethod $Url -Method 'PUT' -Headers $headers -Body $bodyText
##$response | ConvertTo-Json
Write-Host $writeEmptyLine
Get-AzConsumptionBudget -ResourceGroupName $ResourceGroupName -Name $budgetName
Write-Host $writeEmptyLine
Write-Host ($writeEmptyLine + " Budget Group $budgetName created" + $writeSeperator + $time)


