[CmdletBinding()]
Param(
    [Parameter(Mandatory = $true, Position = 1)] [string] $parameterFile,
    [string] $resourceUri="https://management.core.windows.net/"
)
# only landscape personnel can run this script
$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

$tenantId = $parameters.parameters.tenantId.value
$clientSecret = & "$utilitiesFolder\Get-KeyVaultSecret" -parameterFile $parameterFile -secretName $parameters.parameters.deploymentAdApplicationName.value -landscape

try {
    $AuthContext = [Microsoft.IdentityModel.Clients.ActiveDirectory.AuthenticationContext]"https://login.microsoftonline.com/$tenantId"
    $cred = New-Object -TypeName Microsoft.IdentityModel.Clients.ActiveDirectory.ClientCredential -ArgumentList ($parameters.parameters.deploymentApplicationId.value, $clientSecret.SecretValueText)
    $result = $AuthContext.AcquireTokenAsync($resourceUri, $cred).GetAwaiter().GetResult()
    return $result
}
catch {
    $ErrorMessage = $_.Exception.Message
    $StatusDescription = $_.Exception.Response.StatusDescription
    $false

    Throw $ErrorMessage + " " + $StatusDescription + " ClientID: $($parameters.parameters.deploymentApplicationId.value), Scope: $Scope, GrantType: https://login.microsoftonline.com, DirectoryID: $tenantId"
}