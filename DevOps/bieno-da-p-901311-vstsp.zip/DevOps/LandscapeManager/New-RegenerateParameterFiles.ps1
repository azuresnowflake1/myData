param(
    [Parameter(Mandatory = $True, HelpMessage = "The project ITSG for the dev environment")]
    [string]$devProjectNumber,
    # Pass the ITSGs for higher environments
    [string]$qaProjectNumber,
    [string]$ppdProjectNumber,
    [string]$prodProjectNumber,
    [string]$uatProjectNumber,
    [switch]$experiment,
    [switch]$dataScience,
    [string]$vstsBranchName = "develop",
    [string]$vstsRepoName, # If the project has multiple repos
    [switch]$includeDR
)


$parameterfile = "parameters.d.{0}.json" -f $devProjectNumber



#if (-not $(Try { Test-Path $parameterFilePath.trim() } Catch { $false }) ) { 
    # All parameter files are backed up to landscape's prod storage account
 
 function Get-ParameterFilesToLocal {
     param  (
         [string]$parameterFile
     )
    Write-Host "The requested parameter file '$parameterFile' was not found on your disk.  Trying to access from landscape backup.."
    Write-Warning "If you see this warning in your VSTS log then your specified parameter file is missing.  Check it exists in your DevOps\Projects folder."
    $parameterFilePath = "{0}\Projects\{1}" -f $devOpsProjectFolder, $parameterFile
    $accountKeys = Get-AzStorageAccountKey -ResourceGroupName "bnlwe-da01-p-56728-rg" -Name "bnlwestgunileverda56728" -DefaultProfile $Global:CtxProd
    $storageContext = New-AzStorageContext -StorageAccountName "bnlwestgunileverda56728" -StorageAccountKey $accountKeys[0].Value
    $containerName = "parameterfiles"
        
    if(-not(Get-AzStorageContainer -Name $containerName -Context $storageContext.Context -DefaultProfile $arg1.DefaultProfile)) 
    {
        throw "'$parameterFile': The landscape parameter file backup container '$containerName' was not found in storage account $($args1.ResourceGroupName).$($args1.Name)."
    }
    $n=Get-AzStorageBlobContent -Destination $parameterFilePath -Container $containerName -Blob $parameterFile -Context $storageContext.Context -Force
}


#go to prod storage account -01 get them all


#run this script from ecomaster project directory
$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"
$managerFolder = "{0}\{1}" -f $devOpsProjectFolder, "LandscapeManager"

if ($includeDR -and -not $prodProjectNumber) {
    throw ("You must supply the prod ITSG in order to generate parameters for a DR environment.")
}
function New-ParameterFile {
    param(
        [string]$pDevProjectNumber, [string] $pProjectNumber, [string]$pProjectEnvironment
    )

    $paramFile = "parameters.{0}.{1}.json" -f $pProjectEnvironment, $pProjectNumber
    $parameterProjectFile = "{0}\Projects\{1}" -f $devOpsProjectFolder, $paramFile
    
    Write-Host "Select subscription for ITSG# $($pProjectNumber)"
    & "$managerFolder\Set-GlobalScope.ps1"

    Get-ParameterFilesToLocal -parameterFile $paramFile       
    $parameters = & "$utilitiesFolder\Get-Parameters.ps1" -parameterfile $paramfile 

    $pSubscriptionId = $parameters.parameters.subscriptionId.value
    $overridesFile = "overrides.$pProjectEnvironment.$pProjectNumber.json"
    $teamProjectFile = "parameters.teamproject.$pProjectEnvironment.$pProjectNumber.json"
    #& "$managerFolder\Set-GlobalScope.ps1" -parameterfile $paramfile
    $params = @{
        projectNumber=$pProjectNumber
        projectName=$projectName
        projectEnvironment=$pProjectEnvironment
        tagCostCentre=$tagCostCentre
        tagIcc=$tagIcc
        devProjectNumber=$pDevProjectNumber
        subscriptionId=$pSubscriptionId
    }
    if ($marketEnvironment) {
        $params.marketEnvironment=$true
    }
    if ($dataScienceEnvironment) {
        $params.dataScienceEnvironment=$true
    }
   
    #Create the DevOps/environment parameter file, #this command is going to generate new parameter, override
    & "$vstsmanagerFolder\New-EnvironmentParameterFile.ps1" @params

    #check the local ADLS 
    
    "Created: new parameter file $pProjectEnvironment.$pProjectNumber"
    $params = @{
        parameterFile=$paramfile
    }
    $parameters = & "$utilitiesFolder\Get-Parameters.ps1" -parameterFile $paramfile
    $parameters.parameters.storageAccountResourceGroupName.value
    if ($adlsGen1) {
        $params.adlsGen1 = $true
        #check name for ADLS Gen1 matches parameter file
        $adlsGen1ParameterName = $parameters.parameters.adlStoreNameGen1.value
        $storageAccountResourceGroupName = $parameters.parameters.storageAccountResourceGroupName.value
        Write-Host $storageAccountResourceGroupName
        $storageAccounts = Get-AzResource -ResourceGroupName $storageAccountResourceGroupName -ResourceType "Microsoft.DataLakeStore/accounts" 
       
        if ($storageAccounts.Name -ne $adlsGen1ParameterName) {
                Write-Host "Adls Gen1 Name $($storageAccounts.Name) doesn't match regenerated parameter $($adlsGen1ParameterName)."
                $regenParameters = Get-Content -Path "$vstsFolderName\$vstsRepoName\DevOps\Projects\$($parameterFile)" | ConvertFrom-Json
                $regenParameters.parameters.adlStoreNameGen1.Value = $storageAccounts.Name 
                $regenParameters | ConvertTo-JSON -Depth 10 | Out-File -filepath $parameterProjectFile -Force
              } 
        
    }
    $adfParameterfile = & "$vstsmanagerFolder\New-DataFactoryParameterFile.ps1" @params
    "Created: new ADF ARM parameter file $(Split-Path -path $adfParameterfile -Leaf)"
    #delete newly generated override file
    Remove-Item "$vstsdevOpsFolder\Projects\$overridesFile"
    "Removed : $vstsdevOpsFolder\Projects\$overridesFile"
 
    #get-override file from backup
    & "$vstsUtilitiesFolder\Get-Parameters.ps1" -parameterfile $overridesFile | Out-Null
    "Override : $overridesFile file downloaded"

    #Merge the file with get parameters using override, # delta will be replaced from override
    & "$vstsUtilitiesFolder\Get-Parameters.ps1" -parameterfile $paramfile -overrideFile $overridesFile  | Out-Null
    "Merged : $paramfile with $overridesFile"

    #Set Backup 
    & "$vstsManagerFolder\Set-ParameterfileBackup" -parameterFile $paramfile -Force
    & "$vstsManagerFolder\Set-ParameterfileBackup" -parameterFile $paramfile -parameterFileName (Split-Path -Path $adfParameterfile -Leaf) -Force
    "Backup: parameter file backedup"
}

& "$managerFolder\Set-GlobalScope.ps1" -parameterfile $parameterfile

#get parameters
try {
    $devParameters = & "$utilitiesFolder\Get-Parameters.ps1" -parameterfile $parameterfile
}
catch {
    Write-Error "Parameter file not found ...."
    return
}


"#Get the resource group name from parameter, connect to Azure to get Tag details."
$devResourceGroup = Get-AzResourceGroup -Name $devParameters.parameters.storageAccountResourceGroupName.value -DefaultProfile $Global:CtxDeploy
$adlsGen1 = Get-AzResource -ResourceGroupName $devParameters.parameters.storageAccountResourceGroupName.value -ResourceType "Microsoft.DataLakeStore/accounts" -DefaultProfile $Global:CtxDeploy
if ($adlsGen1) {
    Write-Host "Regeneration detected ADLS Gen1"
}

Write-Verbose "Got Dev REsoruce group $($devParameters.parameters.storageAccountResourceGroupName.value) $($Global:CtxDeploy)"
if ($devResourceGroup) {
    $tagIcc = $devResourceGroup.Tags["Icc"]
    $tagCostCentre = $devResourceGroup.Tags["CostCentre"]
    $projectName = $devResourceGroup.Tags["ServiceName"]
    $marketEnvironment = ($devResourceGroup.Tags["Environment"] -match "Market")
    $dataScienceEnvironment = ($devResourceGroup.Tags["Environment"] -match "Data Science")
} else {
    throw "Failed to access details from the development resource group $($devParameters.parameters.storageAccountResourceGroupName.value)"
    return
}
$vstsAccountName = $devParameters.parameters.vstsAccountName.value
$vstsTeamProjectName = $devParameters.parameters.vstsTeamProjectName.value
if (-not $vstsRepoName) {
    $vstsRepoName = $vstsTeamProjectName
}

$vstsUrl = "https://{0}.visualstudio.com/{1}/_git/{2}" -f $vstsAccountName, $vstsTeamProjectName, $vstsRepoName
"vstsUrl $($vstsUrl)"

"#location where DEV branch code will be downloaded in TEMP folder"
$vstsFolderName = [System.IO.Path]::GetTempPath()
$vstsTeamProjectFolder = $vstsFolderName + $vstsRepoName   
$vstsDevOpsFolder =  $vstsTeamProjectFolder + "\DevOps"
$vstsmanagerFolder = $vstsDevOpsFolder + "\LandscapeManager"
$vstsUtilitiesFolder = $vstsDevOpsFolder + "\Utilities"

"#remove files from temp folder, which is used for project"
Remove-Item ($vstsTeamProjectFolder) -Recurse -ErrorAction Ignore -Force

Push-Location
try
{
    #new temp folder
    "cloning to $vstsFolderName"
    Set-Location -Path $vstsFolderName
    #clone code  from VSTS to local temp folder
    git clone $vstsUrl
    #root folder of cloned repository, it creates
    "setting path $vstsRepoName" 
    Set-Location -Path $vstsRepoName 
    #checkout develop branch for commiting new scripts from ecomaster.
    git checkout $vstsBranchName

    #create a array of folders in source, copy folders except custom and projects by iterating through foler list
    $sourceFolders = Get-ChildItem -Path $devOpsProjectFolder -Directory -Force -ErrorAction SilentlyContinue | Select-Object FullName
    foreach ($sourceFolder in $sourceFolders)
    {     
        $sourceFolderArray = ($sourceFolder.fullname).split('\') 
        $sourceFoldername = $sourceFolderArray[$sourceFolderArray.count-1] 
        if (-Not($sourceFoldername -eq "Custom" -Or $sourceFoldername -eq "Projects"))
        {
            "Copying:  from $sourceFoldername to $vstsDevOpsFolder"    
            Copy-Item -Path $sourceFolder.fullname -Destination $vstsDevOpsFolder -Force -Recurse
        }
    }

    #copy readme.md file from \EcoSystemProvisioning folder of ecomaster
    $devOpsEcomaster = ((Get-Item -Path $PSScriptRoot).Parent).Parent.FullName
    Copy-Item  "$devOpsEcomaster\readme.md" -Destination $vstsTeamProjectFolder
    
    # Search and replace the readme.md file for this particular project
    & "$vstsmanagerFolder\Set-Readme.ps1" -parameterFile $parameterfile -gitDirectory $vstsTeamProjectFolder

    # Regenerate the dev environment
    if ($experiment) {
        Write-Host "Regenerating the experiment parameter file for $devProjectNumber"
        New-ParameterFile -pDevProjectNumber $devProjectNumber -pProjectNumber $devProjectNumber -pProjectEnvironment "x"
    } else {
        Write-Host "Regenerating the dev parameter file for $devProjectNumber"
        New-ParameterFile -pDevProjectNumber $devProjectNumber -pProjectNumber $devProjectNumber -pProjectEnvironment "d"
    }

    if ($qaProjectNumber) {
        Write-Host "Regenerating the qa parameter file for $qaProjectNumber"
        New-ParameterFile -pDevProjectNumber $devProjectNumber -pProjectNumber $qaProjectNumber -pProjectEnvironment "q"
    }
    if ($ppdProjectNumber) {
        Write-Host "Regenerating the ppd parameter file for $ppdProjectNumber"
        New-ParameterFile -pDevProjectNumber $devProjectNumber -pProjectNumber $ppdProjectNumber -pProjectEnvironment "u"
    }
    if ($prodProjectNumber) {
        Write-Host "Regenerating the prod parameter file for $prodProjectNumber"  
        New-ParameterFile -pDevProjectNumber $devProjectNumber -pProjectNumber $prodProjectNumber -pProjectEnvironment "p"
    }
    if ($uatProjectNumber) {
        Write-Host "Regenerating the uat parameter file for $uatProjectNumber"
        New-ParameterFile -pDevProjectNumber $devProjectNumber -pProjectNumber $uatProjectNumber -pProjectEnvironment "b"
    }
    if ($includeDR) {
        Write-Host "Regenerating the DR parameter file for $prodProjectNumber"
        New-ParameterFile -pDevProjectNumber $devProjectNumber -pProjectNumber $prodProjectNumber -pProjectEnvironment "r"
    }

    #add new files
    git add .

    #Commit changes
    git commit -am "Regenerate parameter files"
    
    #push commited files from local version to origin
    git push --set-upstream origin $vstsBranchName    
}
finally
{
    Pop-Location
    $path = "{0}/{1}" -f $vstsFolderName, $vstsRepoName
    Remove-Item $path -Recurse -Force
}