param
(
    [Parameter(Mandatory = $True, HelpMessage = "The name of the parameter file")]
    [string]$parameterFile,

    # The source file to use to create the new file. Use an existing parameter file that works.
    [Parameter(Mandatory = $False, HelpMessage = "The source file to use to create a default adls folders parameter file.")]
    [string]
    $foldersTemplateFile = "Templates\folders.template.json",

    [Parameter(Mandatory = $false, HelpMessage = "Store a copy of the parameter file in landscape's BLOB account")]
    [switch]
    $backupParameterFile,
    [switch]
    $forDREnvironment

)

$teamProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName

$devOpsProjectFolder = "{0}\DevOps" -f (Get-Item -Path $teamProjectFolder).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"
$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile
$projectEnvironment = $parameters.parameters.projectEnvironment.value
if($forDREnvironment){
    $projectEnvironment = "r"
}
$projectNumber = $parameters.parameters.projectNumber.value

$adlsFoldersProjectFile = "{0}\Projects\folders.{1}.{2}.json" -f $devOpsProjectFolder, $projectEnvironment, $projectNumber
$parameterFileName = (Split-Path -Path $adlsFoldersProjectFile -Leaf).ToLower()

$foldersTemplateFileFullPath = "{0}\{1}" -f $devOpsProjectFolder, $foldersTemplateFile
Write-Verbose "Parameter Template file : $foldersTemplateFileFullPath"
$folderParameters = Get-Content -Path $foldersTemplateFileFullPath -Raw | ConvertFrom-JSON

$adlsTemplateFile = "{0}\{1}" -f $devOpsProjectFolder, $foldersTemplateFile
Write-Verbose "ADLS Folders Definition file : $adlsTemplateFile"

$adlStoreName = $parameters.parameters.adlStoreNameGen1.value
$manageADGroupName = $parameters.parameters.managerADGroupName.value
$deploySpnName = $parameters.parameters.deploymentAdApplicationName.value
$appSpnName = $parameters.parameters.adApplicationName.value
$dataReaderADGroupName = $parameters.parameters.dataReaderADGroupName.value
$dataWriterADGroupName = $parameters.parameters.dataWriterADGroupName.value

$folderParameters.adlStoreName = $adlStoreName
$totalCount = $folderParameters.folders.Count
for ($i = 0; $i -lt $totalCount ; $i++) {
    $folderName = $folderParameters.folders[$i].folderName
    Write-Verbose "Processing folder number $i with name $folderName"
    $permCount = $folderParameters.folders[$i].permissions.Count
    Write-Verbose "Number of permissions $permCount"
    for ($j = 0; $j -lt $permCount ; $j++) {
        $granteeName = $folderParameters.folders[$i].permissions[$j].Grantee.AADName
        #$granteeType = $folderParameters.folders[$i].permissions[$j].Grantee.AADType
        if ($granteeName.EndsWith('landscape')) {
            $granteeName = $manageADGroupName
            $granteeId = $parameters.parameters.managerADGroupId.value
        }
        elseif ($granteeName.EndsWith("-ina-aadprincipal")) {
            $granteeName = $appSpnName
            $granteeId = $parameters.parameters.servicePrincipalId.value
        }
        elseif ($granteeName.EndsWith("-ina-deployment")) {
            $granteeName = $deploySpnName
            $granteeId = $parameters.parameters.deploymentServicePrincipalId.value
        }
        elseif ($granteeName.EndsWith('azure-data-reader')) {
            $granteeName = $dataReaderADGroupName
            $granteeId = $parameters.parameters.dataReaderADGroupId.value
        }
        elseif ($granteeName.EndsWith('azure-data-writer')) {
            $granteeName = $dataWriterADGroupName
            $granteeId = $parameters.parameters.dataWriterADGroupId.value
        } 
        else {
            Write-Error "Unsupported grantee $($folderParameters.folders[$i].permissions[$j].Grantee.AADName)"
            $granteeName = $folderParameters.folders[$i].permissions[$j].Grantee.AADName -f $devProjectEnvironment, $devProjectNumber
            $granteeId = ""
        }        
        Write-Verbose "Processing folder number $i with name $folderName for grantee $granteeName"
        $folderParameters.folders[$i].permissions[$j].Grantee.AADName = $granteeName
        $folderParameters.folders[$i].permissions[$j].Grantee.Id = $granteeId        
    }
}

$folderParameters | ConvertTo-JSON -Depth 10 | Out-File -filepath $adlsFoldersProjectFile -Force
Write-Output "ADLS folders definition file created. File is at $adlsFoldersProjectFile"

if ($backupParameterFile) {
    & "$devOpsProjectFolder\LandscapeManager\Set-ParameterFileBackup" -parameterFile $parameterFile -parameterFileName $parameterFileName -Force
}
