Param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter files')]
    [String]$parameterFiles[],
    [Parameter(Mandatory = $True, HelpMessage='How month to expiry from today')]
    [switch]$monthsToExpiry
)
# Add or update the expiry tag on an environment
$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$expiryDate = (Get-Date).Add-Months($monthsToExpiry).ToString("yyyy-MM-dd")
foreach($parameterFile in $parameterFiles) {
    $parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile
    $tags = (Get-AzureRmResourceGroup -Name $parameters.parameters.dataFactoryResourceGroupName.value).Tags
    $tags.ExpiryDate = $expiryDate
    Set-AzureRmResourceGroup -Name $parameters.parameters.dataFactoryResourceGroupName.value -Tag $tags
}