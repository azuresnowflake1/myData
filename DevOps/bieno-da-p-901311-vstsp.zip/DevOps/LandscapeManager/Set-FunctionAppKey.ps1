Param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$parameterFile,
    [Parameter(Mandatory = $True, HelpMessage='Specify master key for the functiona app')]
    [String]$defaultKey,
    [Parameter(Mandatory = $False, HelpMessage='Specify to foce update to an existing secret')]
    [switch] $updateSecret

)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"
$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

$args = @{
    parameterFile=$parameterFile
    secretName=$parameters.parameters.functionAppName.value
    secretValue=$defaultKey
    secretExpiryTermYears=2,
    contentType="The key for your function app {0}." -f $parameters.parameters.functionAppName.value
}
if ($updateSecret) {
    $args.updateSecret= $True
}
& "$utilitiesFolder\Set-KeyVaultNameValue.ps1" @args
