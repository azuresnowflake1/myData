param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$parameterFile,
   
    [Parameter(Mandatory = $True, HelpMessage='The personal access token used to authorize vsts requests')]
    [String]$personalAccessToken,

    [Parameter(Mandatory = $False, HelpMessage='Specify the parameter file')]
    [String]$cibuildDefinitionFile = "ci.build.definition.template.json",    

    [Parameter(Mandatory = $False, HelpMessage='Specify the parameter file')]
    [String]$nightlybuildDefinitionFile = "nightly.build.definition.template.json"   
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters.ps1" -parameterFile $parameterFile

$vstsAccountName = $parameters.parameters.vstsAccountName.value
$vstsTeamProjectName = $parameters.parameters.vstsTeamProjectName.value
$vstsTeamProjectCIBuildDefinitionName = $parameters.parameters.vstsTeamProjectCIBuildDefinitionName.value
$vstsSourceControlDevBranch = $parameters.parameters.vstsSourceControlDevBranch.value
$vstsHostedAgentName = $parameters.parameters.vstsHostedAgentName.value
Write-Verbose "The default source control branch is $vstsSourceControlDevBranch"

$patString = "{0}:{1}" -f "", $personalAccessToken
$base64PatString =  [System.Convert]::ToBase64String([System.Text.Encoding]::ASCII.GetBytes($patString))


try 
{

    $vstsURL = "https://{0}.visualstudio.com/DefaultCollection/{1}/_apis/distributedtask/queues?api-version=3.0-preview.1" -f $vstsAccountName, $vstsTeamProjectName
    $params = @{    
        ContentType = 'application/json'
        Headers = @{
            'Authorization'="Basic $base64PatString"
        }
        Method = 'Get'    
        URI = $vstsURL
    }
    Write-Verbose "Getting the queue definitions for team project $vstsTeamProjectName"
    $authZResponse =  Invoke-RestMethod @params
    $vstsQueue = $authZResponse.value | Where-Object {$_.name -eq $vstsHostedAgentName}
    $vstsQueueId = $vstsQueue.id

    Write-Verbose "Hosted Queue Id for $vstsTeamProjectName is $vstsQueueId"    


    $vstsURL = "https://{0}.visualstudio.com/DefaultCollection/{1}/_apis/build/definitions?api-version=2.0" -f $vstsAccountName, $vstsTeamProjectName
    $params = @{    
        ContentType = 'application/json'
        Headers = @{
            'Authorization'="Basic $base64PatString"
        }
        body = $body
        Method = 'Get'    
        URI = $vstsURL
    }
    Write-Verbose "Getting the build definitions for team project $vstsTeamProjectName"
    $authZResponse =  Invoke-RestMethod @params
    $ciBuildDef = ($authZResponse.value | Where-Object {$_.name -eq $vstsTeamProjectCIBuildDefinitionName})

    $vstsTeamProjectUrl = "https://{0}.visualstudio.com/_git/{1}" -f $vstsAccountName, $vstsTeamProjectName
    $vstsDefaultBranch = "refs/heads/{0}" -f $vstsSourceControlDevBranch 
    $branchFilter = "+{0}" -f $vstsDefaultBranch
    $branchFilters += @($branchFilter)

    if (!$ciBuildDef)
    {
        $cibuildDefinitionFilePath = "{0}\Templates\{1}" -f $devOpsProjectFolder, $cibuildDefinitionFile
        $buildDefinition = Get-Content -Path $cibuildDefinitionFilePath -Raw | ConvertFrom-Json
        $buildDefinition.name = $vstsTeamProjectCIBuildDefinitionName
        $buildDefinition.queue.id = $vstsQueueId
        $buildDefinition.triggers[0].branchFilters = $branchFilters
        $buildDefinition.repository.name = $vstsTeamProjectName
        $buildDefinition.repository.defaultBranch = $vstsDefaultBranch
        $buildDefinition.repository.url = $vstsTeamProjectUrl
        $body = $buildDefinition | ConvertTo-JSON -Depth 10

        $vstsURL = "https://{0}.visualstudio.com/DefaultCollection/{1}/_apis/build/definitions?api-version=2.0" -f $vstsAccountName, $vstsTeamProjectName
        $params = @{    
            ContentType = 'application/json'
            Headers = @{
                'Authorization'="Basic $base64PatString"
            }
            body = $body
            Method = 'Post'    
            URI = $vstsURL
        }
        Write-Verbose "Creating the CI build definitions for team project $vstsTeamProjectName"
        $authZResponse =  Invoke-RestMethod @params
        $buildDefinitionId = $authZResponse.id
        Write-Verbose "CI Build Definition Id: $buildDefinitionId"
        Write-Output "CI Build Definition Id: $buildDefinitionId"
    }
    else
    {
        $buildDefinitionId = $ciBuildDef.id
        Write-Output "CI Build Definition exists with Id: $buildDefinitionId"
    }

    # if ($scheduledBuildDef -eq $null)
    # {
    #     $nightlybuildDefinitionFilePath = "{0}\Templates\{1}" -f $devOpsProjectFolder, $nightlybuildDefinitionFile
    #     $buildDefinition = Get-Content -Path $nightlybuildDefinitionFilePath -Raw | ConvertFrom-Json
    #     $buildDefinition.name = $vstsTeamProjectScheduledBuildDefinitionName
    #     $buildDefinition.queue.id = $vstsQueueId
    #     $buildDefinition.triggers[0].schedules[0].branchFilters = $branchFilters
    #     $buildDefinition.repository.name = $vstsTeamProjectName
    #     $buildDefinition.repository.defaultBranch = $vstsDefaultBranch
    #     $buildDefinition.repository.url = $vstsTeamProjectUrl
    #     $body = $buildDefinition | ConvertTo-JSON -Depth 10
        
    #     $vstsURL = "https://{0}.visualstudio.com/DefaultCollection/{1}/_apis/build/definitions?api-version=2.0" -f $vstsAccountName, $vstsTeamProjectName
    #     $params = @{    
    #         ContentType = 'application/json'
    #         Headers = @{
    #             'Authorization'="Basic $base64PatString"
    #         }
    #         body = $body
    #         Method = 'Post'    
    #         URI = $vstsURL
    #     }
    #     Write-Verbose "Creating the Scheduled build definitions for team project $vstsTeamProjectName"
    #     $authZResponse =  Invoke-RestMethod @params
    #     $buildDefinitionId = $authZResponse.id
    #     Write-Verbose "Scheduled Build Definition Id: $buildDefinitionId"
    #     Write-Output "Scheduled Build Definition Id: $buildDefinitionId"
    # }
    # else
    # {
    #     $buildDefinitionId = $scheduledBuildDef.id
    #     Write-Output "Scheduled Build Definition exists with Id: $buildDefinitionId"
    # }       
}
catch
{
    Write-Host "StatusCode:" $_.Exception.Response.StatusCode.value__ 
    Write-Host "StatusDescription:" $_.Exception.Response.StatusDescription
    throw
}
