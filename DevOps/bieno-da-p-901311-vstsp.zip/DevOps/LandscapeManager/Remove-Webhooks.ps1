Param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$parameterFile
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"
$scriptsFolder = "{0}\{1}" -f $devOpsProjectFolder, "Scripts"
$managerFolder = "{0}\{1}" -f $devOpsProjectFolder, "LandscapeManager"

$parameters = & "$managerFolder\RunBooks\Import-PlatformCore.ps1"

$exclude = @("01","04","09","12","17")
$subs = Get-SubScriptions -all
foreach($key in $subs.Keys) {
    if ($exclude.Contains($key)) {
        Write-Verbose "Excluding subscription $key"
        continue
    }
    $boot = Get-BootStrap -SubscriptionNumber $key
    if ($boot.LandscapeResourceGroupName -ne $boot.AutomationResourceGroupName) {
        Write-Warning "Removing webhooks from sub $key"
        Remove-AzKeyVaultSecret -VaultName $boot.KeyVaultName -Name "WebHook-SqlDwPause" -force
        Remove-AzKeyVaultSecret -VaultName $boot.KeyVaultName -Name "WebHook-SqlDwResume" -force
        Remove-AzKeyVaultSecret -VaultName $boot.KeyVaultName -Name "WebHook-SSASPause" -force
        Remove-AzKeyVaultSecret -VaultName $boot.KeyVaultName -Name "WebHook-SSASResume" -force
        Remove-AzKeyVaultSecret -VaultName $boot.KeyVaultName -Name "Webhook-ScaleUpDownSql" -force
        Remove-AzKeyVaultSecret -VaultName $boot.KeyVaultName -Name "Webhook-ScaleUpDownAAS" -force
        Remove-AzKeyVaultSecret -VaultName $boot.KeyVaultName -Name "WebHook-SSASProcessCube" -force
    } else {
        Write-Host "Skipping sub $key"
    }
}
