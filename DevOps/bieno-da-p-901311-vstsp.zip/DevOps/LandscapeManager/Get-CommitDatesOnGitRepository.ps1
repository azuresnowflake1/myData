#"#Store log file"
$StorageAccountName = '070bienobrunilevercomstg' #ITSG 56728
$containerName = 'gitcommitstatus'
$keyvault = 'bieno-da-p-56728-appk-01'
$sastokenkey = '070bienobrunilevercomstg-sastoken-irupgradestatslog'
$sastoken = Get-AzKeyVaultSecret -VaultName $keyvault -Name $sastokenkey    
$StorageContext = New-AzStorageContext $StorageAccountName -SasToken $sastoken.SecretValueText
$outputfile = "gitCommitStatus.csv"
$header1 = "VSTSProject,Email,Date,Comment"
Add-Content $outputfile $header1

#utilities folder
$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

# this is a hack but doesn't matter so long as 80167 is a real amsterdam app.
$secret = & "$utilitiesFolder\Get-KeyVaultSecret.ps1" -parameterFile "d.56731" -secretName "PersonalAccessToken" -landscape
if ($secret) {
    $personalAccessToken = $secret.SecretValueText
} else {
    Write-Error "Failed to access a valid VSTS personal access token.  Please add one to landscape's development key vault and try again."
    return
}

try {
    #get VSTS Git repositories
    $accountUrl = "https://bnlwe-p-56728-ia-01-unilevercom-vsts.visualstudio.com/_apis/git/repositories/"
    $base64AuthInfo = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(("{0}:{1}" -f "",$personalAccessToken)))
    $result=Invoke-RestMethod -Method Get -Uri $accountUrl -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)} -ContentType "application/json"

    #get Commit details from VSTS
    $fromDate = ((Get-Date).AddMonths(-2))
    $toDate = Get-Date
    foreach($resultValue in $result.value){
        $projectUrl = "$($resultValue.url)/commits/?fromDate=$fromDate&toDate=$toDate"
        $resultCommits=Invoke-RestMethod -Method Get -Uri $projectUrl -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)} -ContentType "application/json"
        if($null -ne $resultCommits){
            $outputtext = "$($resultValue.name),$($resultCommits.value[0].committer.email),$($resultCommits.value[0].committer.date),$($resultCommits.value[0].comment)"
        }else{
            $outputtext = "$($resultValue.name),,,"
        }
        Add-Content $outputfile $outputtext                     
        Write-Host $outputtext
    }
}
catch {
    Write-Error $_.Exception.Message
}

#write file to blob storage
try{
    Set-AzStorageBlobContent -File $outputfile -Container $containerName -Context $StorageContext `
    -Blob $outputfile -Force -WarningAction SilentlyContinue
    Write-Host "Log file: $outputfile generated at storage $StorageAccountName in container $containerName"
    Remove-Item $outputfile -Force
}catch{
    #throw
    Write-Error $_.Exception.Message
}