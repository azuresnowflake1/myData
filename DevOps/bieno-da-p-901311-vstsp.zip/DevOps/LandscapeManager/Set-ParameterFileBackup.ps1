param
(
    # The environment parameter file
    [Parameter(Mandatory = $true, HelpMessage = "The name of the file to backup.")]
    [string]
    $parameterFile,
    [Parameter(Mandatory = $false, HelpMessage = "The name of the file to backup.")]
    [string]
    $parameterFileName=$parameterFile,
    [Parameter(Mandatory = $False, HelpMessage = "Specify to overwrite an existing file silently.")]
    [switch]
    $force
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile
$landscapeResourceGroupName = $parameters.parameters.landscapeResourceGroupName.value
$landscapeStorageAccountName = $parameters.parameters.landscapeStorageAccountName.value
$filePath = "{0}\Projects\{1}" -f $devOpsProjectFolder, $parameterFileName
$containerName = "parameterfiles"

$accountKeys = Get-AzStorageAccountKey -ResourceGroupName $landscapeResourceGroupName -Name $landscapeStorageAccountName -DefaultProfile $Global:CtxBootstrap.DefaultProfile
$storageContext = New-AzStorageContext -StorageAccountName $landscapeStorageAccountName -StorageAccountKey $accountKeys[0].Value 

if(-not(Get-AzStorageContainer -Name $containerName -Context $storageContext -ErrorAction SilentlyContinue)) 
{
    Write-Host "Creating Container for parameter file backup"
    New-AzStorageContainer -Name $containerName -Context $storageContext
    Start-Sleep -Seconds 5
}
$args = @{
    File=$filePath;
    Container=$containerName;
    Blob=$parameterFileName;
    Context=$storageContext;
}
if ($Force) {
    $args.Add("Force", $force);
}

Write-Host "Backing up $(Split-Path -Path $filePath -Leaf) to local landscape storage $landscapeStorageAccountName."
Set-AzStorageBlobContent @args | Out-Null

# Also store a copy in the prod storage account
$accountKeys = Get-AzStorageAccountKey -ResourceGroupName "bnlwe-da01-p-56728-rg" -Name "bnlwestgunileverda56728" -DefaultProfile $Global:CtxProd
$storageContext = New-AzStorageContext -StorageAccountName "bnlwestgunileverda56728" -StorageAccountKey $accountKeys[0].Value

if(-not(Get-AzStorageContainer -Name $containerName -Context $storageContext -DefaultProfile $Global:CtxProd -ErrorAction SilentlyContinue)) 
{
    Write-Host "Creating Container for parameter file backup"
    New-AzStorageContainer -Name $containerName -Context $storageContext -DefaultProfile $Global:CtxProd
    Start-Sleep -Seconds 5
}
$args["Context"]=$storageContext
Write-Host "Backing up $(Split-Path -Path $filePath -Leaf) to production landscape storage bnlwestgunileverda56728."
Set-AzStorageBlobContent @args | Out-Null
