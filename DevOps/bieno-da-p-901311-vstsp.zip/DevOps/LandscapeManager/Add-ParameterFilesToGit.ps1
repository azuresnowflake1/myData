param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$parameterFile,
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$devOpsParameterFile
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters.ps1" -parameterFile $parameterFile
$overridesFile = $devOpsParameterFile.Replace("parameters", "overrides")
$devOpsParameters = & "$utilitiesFolder\Get-Parameters.ps1" -parameterFile $devOpsParameterFile

$vstsAccountName = $parameters.parameters.vstsAccountName.value
$vstsTeamProjectName = $parameters.parameters.vstsTeamProjectName.value
$parameterFilePath = "{0}\Projects\{1}" -f $devOpsProjectFolder, $devOpsParameterFile
$overridesFilePath  = "{0}\Projects\{1}" -f $devOpsProjectFolder, $overridesFile
$adfParameterFilePath =  Join-Path -Path $devOpsProjectFolder -ChildPath ("Projects\{0}.json" -f $devOpsParameters.parameters.dataFactoryName.value)
$adfRootParameterFilePath =  Join-Path -Path $devOpsProjectFolder -ChildPath ("Projects\landscape.adf.da{0}.{1}.{2}.json" -f $Global:CtxBootStrap.SubscriptionNumber, $Global:CtxBootStrap.ProjectEnvironment, $devOpsParameters.parameters.ProjectNumber.value)
$folderFilePath = $parameterFilePath.Replace("parameters.", "folders.")

$vstsUrl = "https://{0}.visualstudio.com/{1}/_git/{1}" -f $vstsAccountName, $vstsTeamProjectName

$vstsFolderName = [System.IO.Path]::GetTempPath() 
$vstsDevBranch = $parameters.parameters.vstsSourceControlDevBranch.value
$vstsProjectsFolder = $vstsFolderName + $vstsTeamProjectName + "\DevOps\Projects"
Remove-Item ($vstsFolderName + $vstsTeamProjectName) -Recurse -ErrorAction Ignore -Force
Push-Location
try
{
    Set-Location -Path $vstsFolderName
    git clone $vstsUrl
    Set-Location -Path $vstsTeamProjectName
    git checkout develop
    if (-not (Test-Path $parameterFilePath)) {
        $fileName = Split-Path -Path $parameterFilePath -Leaf
        & "$utilitiesFolder\Get-Parameters.ps1" -parameterFile $fileName | Out-Null
    }
    Copy-Item -Path $parameterFilePath -Destination $vstsProjectsFolder -Force
    if (-not (Test-Path $folderFilePath)) {
        $fileName = Split-Path -Path $folderFilePath -Leaf
        & "$utilitiesFolder\Get-Parameters.ps1" -parameterFile $fileName | Out-Null
    }
    Copy-Item -Path $folderFilePath -Destination $vstsProjectsFolder -Force
    if (-not (Test-Path $overridesFilePath)) {
        $fileName = Split-Path -Path $overridesFilePath -Leaf
        & "$utilitiesFolder\Get-Parameters.ps1" -parameterFile $fileName | Out-Null
    }
    Copy-Item -Path $overridesFilePath -Destination $vstsProjectsFolder -Force
    Copy-Item -Path $adfParameterFilePath -Destination $vstsProjectsFolder -Force
    Copy-Item -Path $adfRootParameterFilePath -Destination $vstsProjectsFolder -Force
    
    git add .
    git commit -am "Update parameter files"
    git push --set-upstream origin $stsDevBranch    
    git checkout -b $vstsDevBranch    
}
finally
{
    Pop-Location
    $path = "{0}/{1}" -f $vstsFolderName, $vstsTeamProjectName
    Remove-Item $path -Recurse -Force
}