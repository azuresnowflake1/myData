Param
(
    [Parameter(Mandatory = $True, HelpMessage = 'Specify the parameter file')]
    [String]$parameterFile,

    [Parameter(Mandatory = $True, HelpMessage = 'Specify the ADLS parameter file.')]
    [string]$folderFile
)

# Loop over the folder permission defined in folder config file and set them
function Set-FolderPermissions {
    param
    (
        [object] $folders
    )    
    $folderName = $folders.folderName
    foreach ($objP in $folders.permissions) {
                
        $granteeId = $objP.Grantee.Id
        $granteeName = $objP.Grantee.AADName
        $permission = $objP.Permission
        $aceType = $objP.AceType

        Write-Verbose "Granting $aceType $granteeName with Id $granteeId permissions $permission to folder $folderName"
        if ($objP.GrantAs -eq "AccessDefault") {
            Write-Verbose "Granting $aceType $granteeName with Id $granteeId permissions"
            Set-AzDataLakeStoreItemAclEntry -Account $adlStoreName -Path $folderName -AceType $aceType -Id $granteeId -Permissions $permission
            Set-AzDataLakeStoreItemAclEntry -Account $adlStoreName -Path $folderName -AceType $aceType -Id $granteeId -Permissions $permission -Default
        }
        elseif ($objP.GrantAs -eq "Access") {
            Set-AzDataLakeStoreItemAclEntry -Account $adlStoreName -Path $folderName -AceType $aceType -Id $granteeId -Permissions $permission

        } elseif ($objP.GrantAs -eq "Default") {
            Set-AzDataLakeStoreItemAclEntry -Account $adlStoreName -Path $folderName -AceType $aceType -Id $granteeId -Permissions $permission -Default
        }    
        
    }
}
Write-Verbose "PSScriptRoot is: $PSScriptRoot"
$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
Write-Verbose "DevOps Project Folder: $devOpsProjectFolder"
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"
Write-Verbose "Utilties folder: $utilitiesFolder"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile
$folderParameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $folderFile

$subscriptionId = $parameters.parameters.subscriptionId.value
$ownerId = $parameters.parameters.servicePrincipalId.value
$ownerGroupId = $parameters.parameters.dataOwnerADGroupId.value
$adlStoreName = $folderParameters.adlStoreName

$applicationId = $parameters.parameters.deploymentApplicationId.value
Write-Verbose "Deploy AppId : $applicationId"

foreach ($obj in $folderParameters.folders) {
    if ($obj.folderName -eq "/") {
        # This is the adls root
        Set-FolderPermissions -folders $obj
    }
    else {
        Try {
            # Create the folder so long as it doesn't already exist.
            if (!(Get-AzDataLakeStoreItem -Account $adlStoreName -Path $obj.folderName -ErrorAction Ignore)) {
                New-AzDataLakeStoreItem -Folder -Account $adlStoreName -Path $obj.folderName
                Set-AzDataLakeStoreItemOwner -Account $adlStoreName -Path $obj.folderName -Type User -Id $ownerId
                Set-AzDataLakeStoreItemOwner -Account $adlStoreName -Path $obj.folderName -Type Group -Id $ownerGroupId
            }            
        } Catch {
            Write-Error $_.Exception.Message
        }
        Set-FolderPermissions -folders $obj
    }
}

