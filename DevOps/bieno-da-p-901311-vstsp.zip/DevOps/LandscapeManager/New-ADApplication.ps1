Param
(
    [Parameter(Mandatory = $True, HelpMessage = 'Specify the parameter file')]
    [String]$parameterFile 
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"
$managerFolder = "{0}\{1}" -f $devOpsProjectFolder, "LandscapeManager"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

$subscriptionId = $parameters.parameters.subscriptionId.value
$resourceGroupName = $parameters.parameters.dataFactoryResourceGroupName.value
$landscapeGroupName = $parameters.parameters.managerADGroupName.value


<#
try 
{ 
    $var = Get-AzureADTenantDetail 
} 
catch [Microsoft.Open.Azure.AD.CommonLibrary.AadNeedAuthenticationException] 
{ 
    Write-Host "You're not connected to Azure AD."; 
    Connect-AzureAD
}
#>

function Sync-AppOwners {
    # This is bust by PS6 because it doesnn't support AzureAD module.  However, now landscape have ApplicationAdmin role we
    # don't need to set the owners
    param( [string]$sourceGroupName, [Microsoft.Azure.Commands.ActiveDirectory.PSADApplication]$targetApp )
   
    $sourceGroup = Get-AzADGroup -SearchString $sourceGroupName
    $targetMembers = Get-AzureADApplicationOwner -ObjectId $targetApp.ObjectId -All $True
    $sourceMembers = Get-AzADGroupMember -GroupObjectId $sourceGroup.Id
    # Add the automation account SPN so we can replace certificates using runbooks
    $sourceMembers += (Get-AzADServicePrincipal -ObjectId $parameters.parameters.landscapeAutomationAccountObjectId.value)
    
    foreach($member in $sourceMembers) {
        $match = $false
        foreach($gp in $targetMembers) {
            if ($gp.ObjectId -eq $member.ObjectId) {
                # nothing to do
                $match = $true
                break
            }
        }
        if (-not $match) {
            # group is in the source but not the target group.  Need to add it.
            Add-AzureADApplicationOwner -ObjectId $targetApp.ObjectId -RefObjectId $member.ObjectId
        }
    }
    foreach($member in $targetMembers) {
        $match = $false
        foreach($gp in $sourceMembers) {
            if ($gp.ObjectId -eq $member.ObjectId) {
                # nothing to do
                $match = $true
                break
            }
        }
        if (-not $match) {
            # group is in the source but not the target group.  Need to add it.
            Remove-AzureADApplicationOwner -ObjectId $targetApp.ObjectId -OwnerId $member.ObjectId
        }
    }
}
function Set-Application {
    param
    (
        [string]$applicationName,
        [string]$applicationUri,
        [datetime]$endDate,
        [string]$role,
        [string]$scope
    ) 

    $spnCreated = $false
    $application = Get-AzADApplication -DisplayNameStartWith $applicationName -DefaultProfile $Global:CtxSPN -ErrorAction SilentlyContinue
    if (-not $application) {
        Write-Verbose "Creating new Azure AD Application"
        $application = New-AzADApplication -DisplayName $applicationName -IdentifierUris $applicationUri -DefaultProfile $Global:CtxSPN
        if (-not $application) { return }
        Write-Verbose "Created new Application AD Application"
        #Sync-AppOwners -sourceGroupName $landscapeGroupName -targetApp $application
    }
    else {
        Write-Verbose "Azure AD Application exists"
        #Sync-AppOwners -sourceGroupName $landscapeGroupName -targetApp $application
        
    }
    $applicationId = $application.ApplicationId
    $servicePrincipal = Get-AzADServicePrincipal -SearchString $applicationName -DefaultProfile $Global:CtxSPN -ErrorAction SilentlyContinue
    if (-not $servicePrincipal) {
        Write-Verbose "Creating new Deployment Service Principal"
        $servicePrincipal = New-AzADServicePrincipal -ApplicationId $applicationId -EndDate $endDate -DisplayName $applicationName -DefaultProfile $Global:CtxSPN # -Role $role -Scope $scope        
        if (-not $application) { return }
        $spnCreated = $true
    }
    elseif ($servicePrincipal.count -gt 1) {
        throw "Found too many SPNs with name $searchString in the Azure Active Directory. Provide the full name to narrow the search."
        return
    }
    else {
        Write-Verbose "Azure AD Service Principal exists"
    }

    #Create new secret for SPN if it is not generated while creting the SPN
    if(-not $servicePrincipal.Secret) {
        $spnCredentials = New-AzADSpCredential -ObjectId $servicePrincipal.Id  -EndDate $endDate -DefaultProfile $Global:CtxSPN
        $servicePrincipalSecret= $spnCredentials.Secret
    }
    else {
        $servicePrincipalSecret=  $servicePrincipal.Secret
    }

    $servicePrincipalId = $servicePrincipal.Id

    $users = Get-AzADServicePrincipal -SearchString $applicationName -DefaultProfile $Global:CtxSPN
    if ($users.Count -lt 1) {
        throw "$objType $searchString not found in the Azure Active Directory. Check the name."
    }
    if ($users.Count -gt 1) {
        throw "Found too many ${objType}s with name $searchString in the Azure Active Directory. Provide the full name to narrow the search."
    }
    Write-Verbose "Created Azure AD Application credential"

    Write-Host "Application Name: $applicationName"
    Write-Host "Application Uri: $applicationUri" 
    Write-Host "Application Id: $applicationId"
    Write-Host "ServicePrincipal Id: $servicePrincipalId"
    [hashtable]$Return = @{} 
    $Return.ApplicationId = $applicationId
    $Return.ServicePrincipal = $servicePrincipal
    $Return.ServicePrincipalSecret = $servicePrincipalSecret
    $Return.spnCreated = $spnCreated
    return $Return
}
$applicationName = $parameters.parameters.adApplicationName.value
$numberofYearsforClientSecret = $parameters.parameters.numberofYearsforClientSecret.value
$endDate = (Get-Date).AddYears($numberofYearsforClientSecret)
$applicationUri = $parameters.parameters.adApplicationUri.value
$scope = "/subscriptions/{0}/resourceGroups/{1}" -f $subscriptionId, $resourceGroupName
$role = "Reader"

$appSpn = Set-Application -applicationName $applicationName -applicationUri $applicationUri -EndDate $endDate -Role $role -Scope $scope

if ($appSpn -and $appSpn.spnCreated) {
    # A new SPN was created so add its client secret to key vault
    $contentType = "The client secret for your application SPN.  Landscape monitor the expiry date and will auto renew it."
    $secretCredential = New-Object System.Management.Automation.PSCredential $applicationName, $appSpn.ServicePrincipalSecret
    & "$utilitiesFolder\Set-KeyVaultSecret" -parameterFile $parameterFile -secretCredential $secretCredential -updateSecret $true -secretExpiryTermYears 2 -contentType $contentType
    $certName = "HDI-ADLS-SPI-ecosystem-{0}.pfx" -f $parameters.parameters.projectNumber.value
    $cert = & "$utilitiesFolder\New-Certificate.ps1" -parameterFile $parameterFile -applicationName $applicationName -certificateName $certName
    Write-Host "Adding the application identity certificate"

    $applicationIdentityCertificateName = $parameters.parameters.applicationIdentityCertificateName.value
    $rawCert = [System.Convert]::ToBase64String((Get-Content $cert.FilePath -Encoding Byte))
    $identityCertificate = ConvertTo-SecureString -AsPlainText $rawCert -Force
    $secretCredential = New-Object System.Management.Automation.PSCredential ($applicationIdentityCertificateName, $identityCertificate)
    $contentType = "A base64 encoded string representation of the self signed certificate attached to your application SPN.  Landscape monitor the expiry date and will auto renew it."
    & "$utilitiesFolder\Set-KeyVaultSecret.ps1" -parameterFile $parameterFile -secretCredential $secretCredential -updateSecret $true -secretExpiryTermYears 2 -contentType $contentType

    Write-Host "Adding the application identity certificate password"
    $applicationIdentityCertificatePassword = "{0}-Password" -f $parameters.parameters.applicationIdentityCertificateName.value
    $identityCertificateSecurePassword = ConvertTo-SecureString -AsPlainText $cert.Password -Force
    $secretCredential = New-Object System.Management.Automation.PSCredential ($applicationIdentityCertificatePassword, $identityCertificateSecurePassword)
    $contentType = "The password for your application SPN's self signed certificate.  Landscape monitor the expiry date and will auto renew it."
    & "$utilitiesFolder\Set-KeyVaultSecret.ps1" -parameterFile $parameterFile -secretCredential $secretCredential -updateSecret $true -secretExpiryTermYears 2 -contentType $contentType

    # install the certificate in the automation account
    Write-Host "Installing the application SPN certificate into automation account $($parameters.parameters.landscapeAutomationAccountName.value)"
    if (Get-AzAutomationCertificate -AutomationAccountName $parameters.parameters.landscapeAutomationAccountName.value -Name $certName -ResourceGroupName $parameters.parameters.landscapeAutomationResourceGroupName.value -DefaultProfile $Global:CtxAuto -ErrorAction SilentlyContinue) {
        # Replace the existing
        Set-AzAutomationCertificate -AutomationAccountName $parameters.parameters.landscapeAutomationAccountName.value -Name $certName -Path $cert.FilePath `
        -Password $identityCertificateSecurePassword -ResourceGroupName $parameters.parameters.landscapeAutomationResourceGroupName.value -Exportable $False -DefaultProfile $Global:CtxAuto
    } else {
        New-AzAutomationCertificate -AutomationAccountName $parameters.parameters.landscapeAutomationAccountName.value -Name $certName -Path $cert.FilePath `
        -Password $identityCertificateSecurePassword -ResourceGroupName $parameters.parameters.landscapeAutomationResourceGroupName.value -DefaultProfile $Global:CtxAuto
    }
}

$applicationName = $parameters.parameters.deploymentAdApplicationName.value
$applicationUri = $parameters.parameters.deploymentAdApplicationUri.value
$role = "Reader"

$appSpn = Set-Application -applicationName $applicationName -applicationUri $applicationUri -EndDate $endDate -Role $role -Scope $scope


if ($appSpn -and $appSpn.spnCreated) {
    # A new SPN was created so add its client secret to Landscape's key vault
    $secretCredential = New-Object System.Management.Automation.PSCredential ($applicationName, $appSpn.ServicePrincipalSecret)
    $contentType = "The client secret for the deployment SPN {0}.  Landscape monitor the expiry date and will auto renew it." -f $applicationName
    & "$utilitiesFolder\Set-KeyVaultSecret" -parameterFile $parameterFile -secretCredential $secretCredential -updateSecret $true -landscape -secretExpiryTermYears 2 -contentType $contentType
}
return $appSpn