Param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$parameterFile,

    [Parameter(HelpMessage='Specify whether to remove the storage account')]
    [Switch]$Storage,

    [Parameter(HelpMessage='Specify whether to remove the sql database')]
    [Switch]$SqlDb,

    [Parameter(HelpMessage='Specify whether to remove the sql data warehouse')]
    [Switch]$SqlDW,

    [Parameter(HelpMessage='Specify whether to remove the data factory')]
    [Switch]$DataFactory,

    [Parameter(HelpMessage='Specify whether to remove the batch account')]
    [Switch]$Batch,

    [Parameter(HelpMessage='Specify whether to remove the data lake store')]
    [Switch]$ADLStore,

    [Parameter(HelpMessage='Specify whether to remove the data lake analytics')]
    [Switch]$ADLAnalytics,

    [Parameter(HelpMessage='Specify whether to remove the key vault')]
    [Switch]$KeyVault,    

    [Parameter(HelpMessage='Specify whether to remove the service principal')]
    [Switch]$ServicePrincipal,

    [Parameter(HelpMessage='Specify whether to remove the HDInsight cluster')]
    [Switch]$HDInsight,
    
    [Parameter(HelpMessage='Specify whether to remove the Analysis Services')]
    [Switch]$AnalysisServices,
    
    [Parameter(HelpMessage='Specify whether to remove the IoT Hub')]
    [Switch]$IoTHub,

    [Parameter(HelpMessage='Specify whether to remove the IoT Device Provisioning')]
    [Switch]$IoTDeviceProv,
    
    [Parameter(HelpMessage='Specify whether to remove the Time Series Insights')]
    [Switch]$TimeSeriesInsights,
    
    [Parameter(HelpMessage='Specify whether to remove the Databrick workspace')]
    [Switch]$Databricks
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile


Function RemoveResources()
{
    Param
    (        
        [string]$resourceGroupName,
        [string]$resourceName
    )
    $res = Get-AzResource -ResourceGroupName $resourceGroupName -ResourceName $resourceName -ErrorAction SilentlyContinue
    if ($res)
    {
        $resourceId = $res.ResourceId
        Write-Verbose "Removing resource $resourceId"
        Write-Output "Removing resource $resourceName in resource group $resourceGroupName"
        try 
        {
            Remove-AzResource -ResourceId $resourceId -Force -ErrorAction SilentlyContinue
        }
        catch
        {
            Write-Output "Removal of resource $resourceName in resource group $resourceGroupName needs verifying"
        }
    }
    else
    {
        Write-Verbose "Resource $resourceName in resource group $resourceGroupName does not exist"
    }
}

if ($Storage)
{    
    $storageAccountResourceGroupName = $parameters.parameters.storageAccountResourceGroupName.value 
    $storageAccountName = $parameters.parameters.storageAccountName.value    
    RemoveResources -resourceGroupName $storageAccountResourceGroupName -resourceName $storageAccountName
}

if ($SqlDb -or $SqlDW)
{
    $sqlServerResourceGroupName = $parameters.parameters.sqlServerResourceGroupName.value
    $sqlServerName = $parameters.parameters.sqlServerName.value
    RemoveResources -resourceGroupName $sqlServerResourceGroupName -resourceName $sqlServerName
}

if ($DataFactory)
{
    $dataFactoryResourceGroupName = $parameters.parameters.dataFactoryResourceGroupName.value
    $dataFactoryName = $parameters.parameters.dataFactoryName.value
    RemoveResources -resourceGroupName $dataFactoryResourceGroupName -resourceName $dataFactoryName
}

if ($Batch)
{
    $batchAccountResourceGroupName = $parameters.parameters.batchAccountResourceGroupName.value
    $batchAccountName = $parameters.parameters.batchAccountName.value
    RemoveResources -resourceGroupName $batchAccountResourceGroupName -resourceName $batchAccountName    
}

if ($ADLAnalytics)
{
    $adlAnalyticsResourceGroupName = $parameters.parameters.adlAnalyticsResourceGroupName.value 
    $adlAnalyticsName = $parameters.parameters.adlAnalyticsName.value
    RemoveResources -resourceGroupName $adlAnalyticsResourceGroupName -resourceName $adlAnalyticsName    
}

if ($ADLStore)
{
    $adlStoreResourceGroupName = $parameters.parameters.adlStoreResourceGroupName.value 
    $adlStoreName = $parameters.parameters.adlStoreName.value
    RemoveResources -resourceGroupName $adlStoreResourceGroupName -resourceName $adlStoreName
}


if ($KeyVault)
{
    $keyVaultResourceGroupName = $parameters.parameters.keyVaultResourceGroupName.value 
    $keyVaultName = $parameters.parameters.keyVaultName.value
    RemoveResources -resourceGroupName $keyVaultResourceGroupName -resourceName $keyVaultName
}


if ($ServicePrincipal)
{
    $adlStoreName = $parameters.parameters.adlStoreName.value
    $adApplicationName = $parameters.parameters.adApplicationName.value
    $adSvcPrincipal = Get-AzADServicePrincipal -SearchString $adApplicationName  -ErrorAction SilentlyContinue
    $rootPath = '/'
    if ($adSvcPrincipal)
    {
        $objectId = $adSvcPrincipal.Id
        Write-Verbose "Azure AD Service Principal exists"
        $dlentry = Get-AzDataLakeStoreItemAclEntry -Account $adlStoreName -Path $rootPath -ErrorAction SilentlyContinue
        if ($dlentry) 
        {
            Write-Verbose "Removing data lake acl entry"
            Remove-AzDataLakeStoreItemAclEntry -Account $adlStoreName -Path $rootPath -AceType User -Id $objectId
            Write-Verbose "Removed data lake acl entry"
        }
        Write-Verbose "Removing AD service principal"
        Remove-AzADServicePrincipal -ObjectId $objectId -Force
        Write-Verbose "Removed AD service principal"
    }
    $adApplication = Get-AzADApplication -DisplayNameStartWith $adApplicationName -ErrorAction SilentlyContinue
    if ($adApplication)
    {
        Write-Verbose "Removing AD Application"
        $objectId = $adApplication.ObjectId
        Remove-AzADApplication -ObjectId $objectId -Force
        Write-Verbose "Removed AD Application"        
    }
}

if ($HDInsight)
{
    $clusterResourceGroupName = $parameters.parameters.clusterResourceGroupName.value 
    $clusterName = $parameters.parameters.clusterName.value
    RemoveResources -resourceGroupName $clusterResourceGroupName -resourceName $clusterName
}
if ($AnalysisServices)
{
    $analysisServicesResourceGroupName = $parameters.parameters.analysisServicesResourceGroupName.value 
    $analysisServicesName = $parameters.parameters.analysisServicesName.value
    RemoveResources -resourceGroupName $analysisServicesResourceGroupName -resourceName $analysisServicesName
}
if ($IoTHub)
{
    $iotHubResourceGroupName = $parameters.parameters.iotHubResourceGroupName.value
    $iotHubName = $parameters.parameters.iotHubName.value
    RemoveResources -resourceGroupName $iotHubResourceGroupName -resourceName $iotHubName
}
if ($IoTDeviceProv)
{
    $iotHubResourceGroupName = $parameters.parameters.iotHubResourceGroupName.value
    $iotHubName = $parameters.parameters.iotHubName.value
    $deviceProvName = "{0}-dev" -f $iotHubName
    RemoveResources -resourceGroupName $iotHubResourceGroupName -resourceName $deviceProvName
}
if ($TimeSeriesInsights)
{
    $tsInsightsResourceGroupName = $parameters.parameters.tsInsightsResourceGroupName.value
    $tsInsightsName = $parameters.parameters.tsInsightsName.value
    RemoveResources -resourceGroupName $tsInsightsResourceGroupName -resourceName $tsInsightsName
}
if ($Databricks)
{    
    $resourceGroupName = $parameters.parameters.databricksResourceGroupName.value 
    $accountName = $parameters.parameters.databricksWorkspaceName.value    
    RemoveResources -resourceGroupName $resourceGroupName -resourceName $accountName
}