Param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$parameterFile,
    [Parameter(Mandatory = $False, HelpMessage='Specify the name of the AAD group you want to sync to')]
    [String]$aadGroupName="",
    [Parameter(Mandatory = $False, HelpMessage='Specify the region')]
    [String]$region="westeurope"
)
# Synchronise the ADB group membership with the entries from an AAD security group
# Allow cluster create added for all users
$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

$keyVaultName = $parameters.parameters.keyVaultName.value
$tokenSecretName = $parameters.parameters.databricksTokenSecretName.value
if (-not $tokenSecretName)
{
    $tokenSecretName = "DatabricksAccessToken"
}
$secret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $tokenSecretName -ErrorAction SilentlyContinue
$accessToken = $secret.SecretValueText

$uriBase = "https://$region.azuredatabricks.net/api/2.0"

add-type @"
using System.Net;
using System.Security.Cryptography.X509Certificates;
public class TrustAllCertsPolicy : ICertificatePolicy {
    public bool CheckValidationResult(
        ServicePoint srvPoint, X509Certificate certificate,
        WebRequest request, int certificateProblem) {
        return true;
    }
}
"@
$AllProtocols = [System.Net.SecurityProtocolType]'Ssl3,Tls,Tls11,Tls12'
[System.Net.ServicePointManager]::SecurityProtocol = $AllProtocols
#[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPoli 

function Get-Users {
        $uri = "$uriBase/preview/scim/v2/Users"
        $head = @{authorization = "Bearer $accessToken" }
        
    Invoke-RestMethod -Uri $uri -Method 'GET' -Headers $head -ContentType "application/scim+json"
}
function Get-AdminUsers {
    $admins = @{}
    $users = Get-Users

    foreach($user in $users.Resources){
        $isAdmin = $False
        foreach($group in $user.groups) {
            if ($group.display -eq "admins") {
                $admins[$user.userName] = $user
                break
            }
        }
    }
    return $admins
}
function New-User {
    param([string]$groupName, [string]$principal)
        $uri = "$uriBase/preview/scim/v2/Users"
        $head = @{authorization = "Bearer $accessToken" }
        $body = @"
        {
            "schemas":[
              "urn:ietf:params:scim:schemas:core:2.0:User"
            ],
            "userName":"$principal",
            "groups":[],
            "entitlements":[{"value":"allow-cluster-create"}]
          }
"@
    Invoke-RestMethod -Uri $uri -Body $Body -Method 'POST' -Headers $head -ContentType "application/scim+json"
}
function Remove-Member {
    param([string]$groupName, [string]$principal)
        $uri = "$uriBase/groups/remove-member"
        $head = @{authorization = "Bearer $accessToken" }
        $body = @"
        {
            "user_name":"$principal",
            "parent_name":"$groupName"
        }
"@
    Invoke-RestMethod -Uri $uri -Body $Body -Method 'POST' -Headers $head -ContentType "application/json"
}
function Get-Member {
    param([string]$emailAddress, [object]$members)
    # test if a specified email address is a member of and exiting ADB group    
    foreach($member in $members) {
        if ($member.mail -eq $emailAddress) {
            return $True;
        }
    }
    return $False;
}
  
# $group = Get-Group $groupName
# if (-not $group){
#     $group = New-Group -groupName $groupName
# }
$existingMembers = Get-Users

$aadGroup = Get-AzADGroup -DisplayName $aadGroupName -ErrorAction SilentlyContinue
if (-not $aadGroup) {
    Write-Error "The specified AAD group '$groupName' was not found.  Cannot sync to this unknown group."
    return
}
$adMembers = Get-AzADGroupMember -GroupObjectId $aadGroup.Id
$new = @{}

# remove adb members that are no long in the AAD group
foreach($member in $existingMembers.resources)
{
    $new.Add($member.userName, $member.userName)
    # if (-not (Get-Member -emailAddress $member.user_name -members $adMembers) ) {
    #     Write-Output "User $($member.user_name) is no longer a member of the group '$groupName' and will be removed."
    #     Remove-Member -groupName $groupName -principal $member.user_name
    # }
}

# Add new members
foreach($member in $adMembers)
{
    if (-not $new[$member.UserPrincipalName]) {
        Write-Host "Adding user $($member.UserPrincipalName) to the workspace"
        New-User -principal $member.UserPrincipalName
    } else {
        Write-Host "User $($member.UserPrincipalName) is already a member of this workspace"
    }
}


    
    

