Param
(
    [Parameter(Mandatory = $True, HelpMessage = 'Specify the parameter file')]
    [String]$parameterFile,

    [Parameter(Mandatory = $True, HelpMessage = 'Specify the ADLS parameter file.')]
    [string]$folderFile
)

# Create the ADLS Gen2 folder system based on the folder parameter file

# Set the ACLs on a folder using information from a folder json file.  This supports standard turnkey principles by
# pattern matching the name or explicitly if the principle object id is present.
function Set-FolderPermissions {
    param
    (
        [object] $folders
    )    
    $folderName = $folders.folderName
    $acls = @()
    foreach ($objP in $folders.permissions) {
                
        $granteeId = $objP.Grantee.Id
        $grantAs = $objP.GrantAs
        $granteeName = $objP.Grantee.AADName
        $aadType = $objP.Grantee.AADType
        $permission = $objP.Permission
        $aceType = $objP.AceType

        if (-not ($permission -match "[r-][w-][x-]" -and $permission.length -eq 3)) {
            Write-Warning "Unable to set the ACL for $granteeName on folder $folderName because the permissions value '$permission' is unsupported.  Allowed values are 3 chars long containing only charaters rwx-"
        }
        if (-not $granteeId) {
            # try to lookup the principal id from the parameter file
            if ($granteeName -like "SEC-ES-da-*azure-data-owner") {
                $granteeId = $parameters.parameters.dataOwnerADGroupId.value
            } elseif ($granteeName -like "SEC-ES-da-*azure-data-writer") {
                $granteeId = $parameters.parameters.dataWriterADGroupId.value
            } elseif ($granteeName -like "SEC-ES-da-*azure-data-reader") {
                $granteeId = $parameters.parameters.dataReaderADGroupId.value
            } elseif ($granteeName -like "svc-b-da-*-ina-aadprincipal") {
                $granteeId = $parameters.parameters.servicePrincipalId.value
            } elseif ($granteeName -like "svc-b-da-*-ina-deployment") {
                $granteeId = $parameters.parameters.deploymentServicePrincipalId.value
            } else {
                Write-Warning "Unable to determine the ACL principalId for if $granteeName on folder $folderName."
                continue
            }
        }
        if ($aadType -eq "SPN") {
            $aadType = "user"
        } elseif ($aadType -eq "user") {
            $aadType = "user"
        } elseif ($aadType -eq "group") {
            $aadType = "group"
        } else {
            Write-Warning "Unable to set the ACL for $granteeName on folder $folderName because the Grantee.AADType value '$aadType' is unsupported.  Allowed values are: User, SPN or Group"
            continue
        }
        
        if ($grantAs -eq "Access") {
            $acls += "{0}{1}:{2}:{3}" -f "", $aadType, $granteeId, $permission
        } elseif ($grantAs -eq "Default") {
            $acls += "{0}{1}:{2}:{3}" -f "default:", $aadType, $granteeId, $permission
        } elseif ($grantAs -eq "AccessDefault") {
            $acls += "{0}{1}:{2}:{3}" -f "", $aadType, $granteeId, $permission
            $acls += "{0}{1}:{2}:{3}" -f "default:", $aadType, $granteeId, $permission
        } else {
            Write-Warning "Unable to set the ACL for $granteeName on folder $folderName because the GrantAs value '$grantAs' is unsupported.  Allowed values are: Access, Default or AccessDefault"
            continue
        }
    }
    if ($acls.count -gt 0) {
        Write-Verbose "Setting ACLs on folder $folderName"
        & "$utilitiesFolder\Set-ADLS2FolderAcls" -parameterFile $parameterFile -path $folderName -acls $acls -bearerToken $bearerToken
    }
}
$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile
$folderParameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $folderFile

$bearerToken = & "$utilitiesFolder\Get-ADLS2oAuthToken" -parameterFile $parameterFile
if (-not (& "$utilitiesFolder\Get-ADLS2FileSystem" -parameterFile $parameterFile -bearerToken $bearerToken)) {
    Write-Host "Creating ADLS Gen2 file system"
    & "$utilitiesFolder\New-ADLS2FileSystem" -parameterFile $parameterFile -bearerToken $bearerToken
} else {
    Write-Host "ADLS Gen2 file system already exists"
}

foreach ($obj in $folderParameters.folders) {
    if ($obj.folderName -eq "/" -or $obj.folderName -eq "") {
        # This is the adls root
        Write-Host "Setting file system permissions at the root"
        Set-FolderPermissions -folders $obj
        Write-Host "Creating ADLS gen2 folders"
    }
    else {
        Try {
            Write-Verbose "Create folder $($obj.folderName)"
            & "$utilitiesFolder\New-ADLS2Folder" -parameterFile $parameterFile -pathToCreate $obj.folderName -bearerToken $bearerToken
        
        } Catch {
            Write-Error $_.Exception.Message
        }
        Set-FolderPermissions -folders $obj
    }
}


