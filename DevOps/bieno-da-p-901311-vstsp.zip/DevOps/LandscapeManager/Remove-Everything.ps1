Param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$parameterFile,
    [Parameter(Mandatory = $false, HelpMessage='Specify if you want to also remove SPNs')]
    [switch] $adApplication,
    [Parameter(ParameterSetName='vsts',Mandatory = $false, HelpMessage='Specify if you want to also remove the team Project')]
    [switch] $teamProject
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$managerFolder = "{0}\{1}" -f $devOpsProjectFolder, "LandscapeManager"
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

& $managerFolder\Set-GlobalScope.ps1 -parameterFile $parameterFile | Out-Null

if ($teamProject) {
    $secret = Get-AzKeyVaultSecret -VaultName "bnlwe-da04-d-56731-kv-01" -secretName "PersonalAccessToken" -ErrorAction Stop
    if ($secret) {
        $personalAccessToken = $secret.SecretValueText
    } else {
        Write-Error "Failed to access a valid VSTS personal access token.  Please add one to landscape's development key vault and try again."
        return
    }
}

& $managerFolder\Remove-ResourceGroups.ps1 -parameterFile $parameterFile
& $managerFolder\Remove-ADGroups.ps1 -parameterFile $parameterFile
if ($teamProject) {
    & $managerFolder\Remove-TeamProject.ps1 -parameterFile $parameterFile -personalAccessToken $personalAccessToken
}

if ($adApplication) {
    & $managerFolder\Remove-ADApplication.ps1 -parameterFile $parameterFile
}
