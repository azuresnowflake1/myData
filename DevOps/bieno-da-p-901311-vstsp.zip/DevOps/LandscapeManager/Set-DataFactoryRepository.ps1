Param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$parameterFile   
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"
$managerFolder = "{0}\{1}" -f $devOpsProjectFolder, "LandscapeManager"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

$location = $parameters.parameters.location.value
$subscriptionId = $parameters.parameters.subscriptionId.value
$tenantId = $parameters.parameters.tenantId.value
$dataFactoryName = $parameters.parameters.dataFactoryName.value
$resourceGroupName = $parameters.parameters.dataFactoryResourceGroupName.value
$vstsTeamProjectName = $parameters.parameters.vstsTeamProjectName.value

function Copy-TemplatesToGitRepository{
    $EcoSystemFolder = (Get-Item -Path $devOpsProjectFolder).Parent.FullName
    $RootFolder = (Get-Item -Path $EcoSystemFolder).Parent.FullName

    $vstsTeamProjectName= $parameters.parameters.vstsTeamProjectName.value
    $vstsAccountName = $parameters.parameters.vstsAccountName.value
    $vstsUrl = "https://{0}.visualstudio.com/{1}/_git/{1}" -f $vstsAccountName, $vstsTeamProjectName

    $vstsFolderName = [System.IO.Path]::GetTempPath() 
    $vstsDevBranch = $parameters.parameters.vstsSourceControlDevBranch.value
    $vstsFolder = $vstsFolderName + $vstsTeamProjectName 
    $vstsDataFactoryFolder = $vstsFolderName + $vstsTeamProjectName + "\Adf\$dataFactoryName\"
    $vstsDataFactoryStartTriggerFolder = $vstsFolderName + $vstsTeamProjectName + "\Adf\$dataFactoryName\start"
    $vstsDataFactoryStopTriggerFolder = $vstsFolderName + $vstsTeamProjectName + "\Adf\$dataFactoryName\stop"

    $adfTemplateFilePath =  Join-Path -Path $RootFolder -ChildPath ("Adf-01\{0}" -f "publish_config.json")
    $adfPublishProfileFilePath =  Join-Path -Path $RootFolder -ChildPath ("Adf-01\{0}" -f "arm-template-parameters-definition.json")

    $adfstartTriggerReadmePath =  Join-Path -Path $RootFolder -ChildPath ("Adf-01\{0}" -f "start\readme.txt")
    $adfstopTriggerReadmePath =  Join-Path -Path $RootFolder -ChildPath ("Adf-01\{0}" -f "stop\readme.txt")

    Remove-Item ($vstsFolderName + $vstsTeamProjectName) -Recurse -ErrorAction Ignore -Force
    Push-Location

    try
    {
        Set-Location -Path $vstsFolderName
        git clone $vstsUrl
        Set-Location -Path $vstsTeamProjectName
        git checkout develop
        
        try{
            New-Item -Path $vstsFolder -Name "Adf" -ItemType Directory -ErrorAction Ignore 
        }catch{
            
        }

        New-Item -Path $vstsDataFactoryFolder -Name $dataFactoryName -ItemType Directory
        
        Copy-Item -Path $adfTemplateFilePath -Destination $vstsDataFactoryFolder -Force
        Copy-Item -Path $adfPublishProfileFilePath -Destination $vstsDataFactoryFolder -Force

        Copy-Item -Path $adfstartTriggerReadmePath -Destination $vstsDataFactoryStartTriggerFolder -Force
        Copy-Item -Path $adfstopTriggerReadmePath -Destination $vstsDataFactoryStopTriggerFolder -Force
        
        git add .
        git commit -am "Added adf ARM template, publish profile"
        git push --set-upstream origin $stsDevBranch    
        git checkout -b $vstsDevBranch    
    }
    finally
    {
        Pop-Location
        $path = "{0}/{1}" -f $vstsFolderName, $vstsTeamProjectName
        Remove-Item $path -Recurse -Force
    }

}
function Set-DataFactoryRepository {
    Param(
        [string] $bearerToken
    )
    # Rest documentation:
    # https://docs.microsoft.com/en-us/powershell/module/azurerm.datafactoryv2/set-azurermdatafactoryv2?view=azurermps-6.13.0

    # Configure git repo for a datafactory
    $authHeader = @{
        'Content-Type'='application/json'
        'Accept'='application/json'
        'Authorization'=$bearerToken
    }
    
    $URI = "https://management.azure.com/subscriptions/$subscriptionId/resourcegroups/$resourceGroupName/providers/Microsoft.DataFactory/factories/$($dataFactoryName)?api-version=2018-06-01"
    
    try {
        $adf=Invoke-RestMethod -Method GET -Uri $URI -Header $authHeader
        
        $ht2 = @{}
        $adf.psobject.properties | ForEach-Object { $ht2[$_.Name] = $_.Value }
        $repo = @{
            type="FactoryVSTSConfiguration"
            accountName="bnlwe-p-56728-ia-01-unilevercom-vsts"
            repositoryName=$vstsTeamProjectName
            projectName=$vstsTeamProjectName
            collaborationBranch="develop"
            rootFolder="/Adf/$dataFactoryName"
            tenantId=$tenantId
            lastCommitId=""
        }
        $ht2["properties"] | Add-Member -MemberType NoteProperty -Name "repoConfiguration" -Value $repo -Force
        $adf=Invoke-RestMethod -Method PUT -Uri $URI -Header $authHeader -Body ($ht2 | ConvertTo-Json)
    }
    catch {
        $ErrorMessage = $_.Exception.Message
        $StatusDescription = $_.Exception.Response.StatusDescription

        Throw $ErrorMessage + " " + $StatusDescription
    }
}


$oAuth = & "$managerFolder\Get-oAuthToken" -parameterFile $parameterFile
$bearerToken = $oAuth.CreateAuthorizationHeader()

#Write-Output "Set Data Factory Repository"
#Set-DataFactoryRepository -bearerToken $bearerToken

Write-Output "Copy Teplates to Git Repository"
Copy-TemplatesToGitRepository
