Param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$parameterFile,
    [Parameter(Mandatory = $False, HelpMessage='Specify to synch the developer ad group membership')]
    [switch]$developer,
    [Parameter(Mandatory = $False, HelpMessage='Specify to synch the tester ad group membership')]
    [switch]$tester,
    [Parameter(Mandatory = $False, HelpMessage='Specify to synch the dev ops ad group membership')]
    [switch]$devOps
)
#devops create cluster prod and QA
#testers don't need cluster admin but currently will get it by default
# Synchronise the ADB workspace users with the entries from an AAD security group
$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"
$managerFolder = "{0}\{1}" -f $devOpsProjectFolder, "LandscapeManager"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

if ($parameters.parameters.projectEnvironment.value -eq 'p' -and -not $devOps) {
    Write-Error "You must not run this script against a production environment for non Dev Ops personnel.  This breaks our operating model!"
    return
}
if ($devOps -and $parameters.parameters.projectEnvironment.value -ne 'd') {
    $adGroup = $parameters.parameters.supportADGroupName.value
    & "$managerFolder\Set-DataBricksGroupMembership" -parameterFile $parameterFile -aadGroupName $adGroup
}
if ($parameters.parameters.projectEnvironment.value -eq 'q') {
    if ($developer) {
        $adGroup = $parameters.parameters.developerADGroupName.value 
        & "$managerFolder\Set-DataBricksGroupMembership" -parameterFile $parameterFile -aadGroupName $adGroup
    }
    
    if ($tester) {
        $adGroup = $parameters.parameters.testerADGroupName.value
        & "$managerFolder\Set-DataBricksGroupMembership" -parameterFile $parameterFile -aadGroupName $adGroup
    }
}
if ($parameters.parameters.projectEnvironment.value -eq 'd') {
    if ($tester) {
        $adGroup = $parameters.parameters.testerADGroupName.value
        & "$managerFolder\Set-DataBricksGroupMembership" -parameterFile $parameterFile -aadGroupName $adGroup
    }
}

