Param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$parameterFile,
    [Parameter(Mandatory = $False, HelpMessage='The name of the container for the ADLS filesystem')]
    [string]$fileSystemName="unilever",
    [Parameter(Mandatory = $False, HelpMessage='Pass this if you want use Gen1')]
    [switch]$adlsGen1
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"
$managerFolder = "{0}\{1}" -f $devOpsProjectFolder, "LandscapeManager"


$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile


if ($Global:ctxBootstrap.Environment -eq 'DR') {
    #use the Gen2 Redundant Storage
    return
}

if ($adlsGen1) {
    Write-Output "Creating the Gen1 Data Lake Store"
    & "$utilitiesFolder\New-Resources" -parameterFile $parameterFile -ADLStoreGen1
    $folderFile = $parameters.parameters.adlStoreFoldersFile.value
    $appResourceGroupName = $parameters.parameters.adlStoreResourceGroupName.value
    $resourceName = $parameters.parameters.adlStoreNameGen1.value
    $roleName = "InA Tech Data Owner"
    $granteeObjectId = $parameters.parameters.dataOwnerADGroupId.value
    $resourceType = "Microsoft.DataLakeStore/accounts"
    $assignment = Get-AzRoleAssignment -ResourceGroupName $appResourceGroupName -ResourceName $resourceName -RoleDefinitionName $roleName -ResourceType $resourceType -ObjectId $granteeObjectId
    if (-not $assignment) {
        New-AzRoleAssignment -ResourceGroupName $appResourceGroupName -ResourceName $resourceName -RoleDefinitionName $roleName -ResourceType $ResourceType -ObjectId $granteeObjectId
    } else {
        Write-Verbose "ADLS Gen1 role assignment already exists for $roleName on object $resourceName."
    }
    & "$managerFolder\Set-ADLSOwnerGroup.ps1" -parameterFile $parameterFile
    Write-Host "Set gen1 data lake store owner"
    & "$managerFolder\Add-DataLakeFolders.ps1" -parameterFile $parameterFile -folderFile $folderFile
    Write-Host "Created gen1 data lake folders"
    return
}

$subscriptionId = $parameters.parameters.subscriptionId.value
$granteeDataOwnerId = $parameters.parameters.dataOwnerADGroupId.value

# Write-Output "Creating the Gen2 Data Lake Store"
& "$utilitiesFolder\New-Resources.ps1" -parameterFile $parameterFile -ADLStore
& "$utilitiesFolder\New-RoleAssignment.ps1" -parameterFile $parameterFile -roleName "InA Tech Data Owner" -granteeObjectId $granteeDataOwnerId -adls

# Create the file system container
$rgName = $parameters.parameters.adlStoreResourceGroupName.value
$accountName = $parameters.parameters.adlStoreName.value
$accountKeys = Get-AzStorageAccountKey -ResourceGroupName $rgName -Name $accountName
$storageContext = New-AzStorageContext -StorageAccountName $accountName -StorageAccountKey $accountKeys[0].Value 

try {
    Get-AzStorageContainer -Context $storageContext -Name $fileSystemName -ErrorAction Stop | Out-Null
    }
catch {
    # Assume the container wasn't found
    New-AzStorageContainer -Context $storageContext -Name $fileSystemName -Permission Off
    }
finally {
        # Set ACL permissions for the data groups
        $acl = @("user::rwx",
        "user:$($parameters.parameters.dataWriterADGroupId.value):rwx",
        "default:user:$($parameters.parameters.dataWriterADGroupId.value):rwx",
        "user:$($parameters.parameters.dataReaderADGroupId.value):r-x",
        "default:user:$($parameters.parameters.dataReaderADGroupId.value):r-x",
        "group::r--,other::---")
    
        $token = & "$utilitiesFolder\Get-ADLS2oAuthToken.ps1" -parameterFile $parameterFile
        & "$utilitiesFolder\Set-ADLS2FolderAcls.ps1" -parameterFile $parameterFile -path "/" -acls $acl -bearerToken $token
    
}
