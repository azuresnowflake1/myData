Param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$token,
    [Parameter(Mandatory=$False,HelpMessage='Number of days before the secret expires.  USe the same number as the token itself')]
    [int]$secretExpiryDays
)
# Add a VSTS personal access token to landscape's key vault.  This is used during the turnkey


$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$secretExpires = (Get-Date).AddDays($secretExpiryDays)
$keyName = "PersonalAccessToken"
$keyValue = ConvertTo-SecureString -AsPlainText $token -Force
$secretCredential = New-Object System.Management.Automation.PSCredential ($keyName, $keyValue)
$contentType ="An Azure DevOps personal access token for a landscape member.  Used by turnkey to create a team project."
function Set-Secret {
    param([string]$keyVaultName)
    Remove-AzKeyVaultSecret -VaultName $keyVaultName -Name $secretCredential.UserName -Force
    Set-AzKeyVaultSecret -VaultName $keyVaultName -Name $secretCredential.UserName -SecretValue $secretCredential.Password -Expires $secretExpires -ContentType $contentType
}

Set-Secret -keyVaultName "bnlwe-da04-d-56731-kv-01"
Set-Secret -keyVaultName "bnlwe-da03-q-56730-kv-01"
Set-Secret -keyVaultName "bnlwe-da02-u-56732-kv-01"
Set-Secret -keyVaultName "bnlwe-da01-p-56728-kv-01"
Set-Secret -keyVaultName "bnlwe-da16-d-56731-kv-01"
Set-Secret -keyVaultName "bnlwe-da13-d-56731-kv-01"



