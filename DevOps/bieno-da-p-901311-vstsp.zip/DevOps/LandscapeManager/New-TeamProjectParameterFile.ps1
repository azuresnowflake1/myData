param
(
    # The project# to create the parameter file
    [Parameter(Mandatory=$True, HelpMessage="The project# to create the parameter file")]
    [string] $projectNumber,

    [Parameter(Mandatory=$False, HelpMessage="The project# for vsts")]
    [string] $vstsProjectNumber = $projectNumber,

    # The environment this parameter file maps to. 
    [Parameter(Mandatory = $False, HelpMessage = "The environment this parameter file maps to.d=development,q=testing,u=preprod, b=uat, p=production, r=DR, x=DS or Experiment")]
    [ValidatePattern("^(d|q|u|p|b|r|x)$")]
    [string] $projectEnvironment = "d",

    [Parameter(Mandatory = $True, HelpMessage = "The I&A platform subscription id i.e da{n}")]
    [string] $platform,

    # The name of the project
    [Parameter(Mandatory = $False, HelpMessage = "The name of the visual studio team services account")]    
    [string] $vstsAccountName = "bnlwe-p-56728-ia-01-unilevercom-vsts",

    # The source file to use to create the new file. Use an existing parameter file that works.
    [Parameter(Mandatory = $False, HelpMessage = "The source file to use to create the new file. Use an existing parameter file that works.")]
    [string] $parameterTemplateFile = "Templates\parameters.teamproject.template.json"
)
if (-not $Global:CtxBootStrap) {
    throw "Your powershell session is not initialsed to run the turnkey.  Call Set-GlobalScope and try again."
}
$namePrefix = $Global:CtxBootStrap.NamePrefix

switch ($projectEnvironment) { 
    "d" {
		$branchName = "develop"
		$branchNameVSTS = "develop"
    }
    "q" {
        $branchName = "qa"
		$branchNameVSTS = "develop"
    }
    "b" {
        $branchName = "uat"
		$branchNameVSTS = "develop"		
    }
    "u" {
        $branchName = "preprod"
		$branchNameVSTS = "master"
    }
    "p" {
        $branchName = "prod"
		$branchNameVSTS = "master"		
    }
    "r" {
        $branchName = "prod"
		$branchNameVSTS = "master"		
    }
    "x" {
        $branchName = "develop"
		$branchNameVSTS = "develop"		
    }
    default {
        Write-Error "Project Environment unknown. Use d for development, q for testing, b for UAT, u for pre-prod and p for production"  
    }
}

$teamProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName

# Unilever has introduced the concept of a "platform" to indentify the business owner of azure resources.
# Each platform has a two letter code that is included in component naming.  For I&A Eco System applications the
# platform is called "Core Data Eco System" denoted by the code DA.
$parameterProjectFile = "{0}\Projects\parameters.teamproject.{1}.{2}.json" -f $teamProjectFolder, $projectEnvironment, $projectNumber
 
$paramTemplateFile = "{0}\{1}" -f $teamProjectFolder, $parameterTemplateFile
Write-Verbose "Parameter Template file : $paramTemplateFile"
$parameters = Get-Content -Path $paramTemplateFile -Raw | ConvertFrom-JSON  

$selectedBranchName = $branchName -replace "/", "_"

$parameters.parameters.vstsAccountName.value = $vstsAccountName
if($platform -ne "da"){
    # for DR environment, if platform is DA01, DA02, DA03 etc. it still uses vsts project naming as "da"    
    $parameters.parameters.vstsTeamProjectName.value = "{0}-{1}-p-{2}-vstsp" -f $namePrefix, "da", $vstsProjectNumber
}else{
    $parameters.parameters.vstsTeamProjectName.value = "{0}-{1}-p-{2}-vstsp" -f $namePrefix, $platform, $vstsProjectNumber
}
$parameters.parameters.vstsSourceControlDevBranch.value = $branchNameVSTS
$parameters.parameters.vstsTeamProjectCIBuildDefinitionName.value = "{0}_{1}" -f $selectedBranchName, $parameters.parameters.vstsTeamProjectCIBuildDefinitionName.value
$parameters.parameters.vstsTeamProjectScheduledBuildDefinitionName.value = "{0}_{1}" -f $selectedBranchName, $parameters.parameters.vstsTeamProjectScheduledBuildDefinitionName.value
$parameters.parameters.vstsTeamProjectCIReleaseDefinitionName.value = "{0}_{1}" -f $selectedBranchName, $parameters.parameters.vstsTeamProjectCIReleaseDefinitionName.value
$parameters.parameters.vstsTeamProjectScheduledReleaseDefinitionName.value = "{0}_{1}" -f $selectedBranchName, $parameters.parameters.vstsTeamProjectScheduledReleaseDefinitionName.value

$parameters.parameters.vstsTeamProjectCIBuildDefinitionNameMLOps.value = "{0}_{1}" -f $selectedBranchName, $parameters.parameters.vstsTeamProjectCIBuildDefinitionNameMLOps.value
$parameters.parameters.vstsTeamProjectScheduledBuildDefinitionNameMLOps.value = "{0}_{1}" -f $selectedBranchName, $parameters.parameters.vstsTeamProjectScheduledBuildDefinitionNameMLOps.value
$parameters.parameters.vstsTeamProjectCIReleaseDefinitionNameMLOps.value = "{0}_{1}" -f $selectedBranchName, $parameters.parameters.vstsTeamProjectCIReleaseDefinitionNameMLOps.value
$parameters.parameters.vstsTeamProjectScheduledReleaseDefinitionNameMLOps.value = "{0}_{1}" -f $selectedBranchName, $parameters.parameters.vstsTeamProjectScheduledReleaseDefinitionNameMLOps.value

if($platform -ne "da"){
    # new service connection is created for DR environment
    $parameters.parameters.vstsProjectARMServiceEndPointName.value = $parameters.parameters.vstsProjectARMServiceEndPointName.value -f $platform + $projectNumber
}else{
    $parameters.parameters.vstsProjectARMServiceEndPointName.value = $parameters.parameters.vstsProjectARMServiceEndPointName.value -f $projectNumber
}

$parameters | ConvertTo-JSON -Depth 10 | Out-File -filepath $parameterProjectFile -Force
Write-Host "Team project parameter file created. File is at $parameterProjectFile"
return Split-Path -Path $parameterProjectFile -Leaf