Param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$parameterFile
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"
$managerFolder = "{0}\{1}" -f $devOpsProjectFolder, "LandscapeManager"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

function Remove-Group
{
    Param
    (
        [string]$groupName
    )
    $adGroup = Get-AzADGroup -DisplayName $groupName -ErrorAction SilentlyContinue
    if ($adGroup)
    {
        Remove-AzADGroup -ObjectId $adGroup.Id -PassThru -Force -DefaultProfile $global:CtxSPN | Out-Null
        Write-Verbose "Group $groupName removed"
    }
    else{
        Write-Verbose "Group $groupName does not exist"
    }
}

if("dx".Contains($parameters.parameters.projectEnvironment.value)){
    Write-Host "Deleting AD group $($parameters.parameters.projectAdminADGroupName.value)"
    Remove-Group -groupName $parameters.parameters.projectAdminADGroupName.value    
    Write-Host "Deleting AD group $($parameters.parameters.developerADGroupName.value)"
    Remove-Group -groupName $parameters.parameters.developerADGroupName.value
    Write-Host "Deleting AD group $($parameters.parameters.testerADGroupName.value)"
    Remove-Group -groupName $parameters.parameters.testerADGroupName.value
    if ($parameters.parameters.supportLevel1ADGroupName.value) {
        Write-Host "Deleting AD group $($parameters.parameters.supportLevel1ADGroupName.value)"
        Remove-Group -groupName $parameters.parameters.supportLevel1ADGroupName.value
    }
    Write-Host "Deleting AD group $($parameters.parameters.supportADGroupName.value)"
    Remove-Group -groupName $parameters.parameters.supportADGroupName.value
}

Write-Host "Deleting AD group $($parameters.parameters.dataReaderADGroupName.value)"
Remove-Group -groupName $parameters.parameters.dataReaderADGroupName.value
Write-Host "Deleting AD group $($parameters.parameters.dataWriterADGroupName.value)"
Remove-Group -groupName $parameters.parameters.dataWriterADGroupName.value
Write-Host "Deleting AD group $($parameters.parameters.dataOwnerADGroupName.value)"
Remove-Group -groupName $parameters.parameters.dataOwnerADGroupName.value
Write-Host "Deleting AD group $($parameters.parameters.appContributorGroupName.value)"
Remove-Group -groupName $parameters.parameters.appContributorGroupName.value
Write-Host "Deleting AD group $($parameters.parameters.appReaderGroupName.value)"
Remove-Group -groupName $parameters.parameters.appReaderGroupName.value

Write-Host "Deleting AD group $($parameters.parameters.dataScientistADGroupName.value)"
Remove-Group -groupName $parameters.parameters.dataScientistADGroupName.value

Write-Host "Deleting AD group $($parameters.parameters.dataEngineerADGroupName.value)"
Remove-Group -groupName $parameters.parameters.dataEngineerADGroupName.value
