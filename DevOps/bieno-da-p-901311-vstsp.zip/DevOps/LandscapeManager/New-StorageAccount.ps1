Param
(
    [Parameter(Mandatory = $True, HelpMessage='Specify the parameter file')]
    [String]$parameterFile
)

$devOpsProjectFolder = (Get-Item -Path $PSScriptRoot).Parent.FullName
$utilitiesFolder = "{0}\{1}" -f $devOpsProjectFolder, "Utilities"

$parameters = & "$utilitiesFolder\Get-Parameters" -parameterFile $parameterFile

$owner = $parameters.parameters.dataOwnerADGroupId.value
$storageAccountResourceGroupName = $parameters.parameters.storageAccountResourceGroupName.value 
$storageAccountName = $parameters.parameters.storageAccountName.value
$secretExpiryYears = $parameters.parameters.keyVaultSecretExpiryTerm.value

Write-Verbose "Creating the Storage account"
& "$utilitiesFolder\New-Resources.ps1" -parameterFile $parameterFile -Storage

# data reader and writer is set at RG level
#& "$utilitiesFolder\New-RoleAssignment.ps1" -parameterFile $parameterFile -roleName "InA Tech Data Reader" -granteeObjectId $reader -storageAccount
#& "$utilitiesFolder\New-RoleAssignment.ps1" -parameterFile $parameterFile -roleName "InA Tech Data Writer" -granteeObjectId $writer -storageAccount
& "$utilitiesFolder\New-RoleAssignment.ps1" -parameterFile $parameterFile -roleName "InA Tech Data Owner" -granteeObjectId $owner -storageAccount
$storageAccountKey = (Get-AzStorageAccountKey -ResourceGroupName $storageAccountResourceGroupName -Name $storageAccountName)[0].Value

if ($storageAccountKey)
{
    $connection = "DefaultEndpointsProtocol=https;AccountName={0};AccountKey={1}" -f $storageAccountName, $storageAccountKey
    $secretCredential = New-Object System.Management.Automation.PSCredential $parameters.parameters.storageAccountConnectionSecretName.value, (ConvertTo-SecureString -AsPlainText $connection -Force)
    $contentType = "The BLOB connection string for your storage account, added by the turnkey during provisioning.  Use this in your ADF linked service."
    & "$utilitiesFolder\Set-KeyVaultSecret" -parameterFile $parameterFile -secretCredential $secretCredential -updateSecret $true -secretExpiryTermYears $secretExpiryYears -contentType $contentType

    $contentType = "The storage account key for your storage account {0}, added by the turnkey during provisioning.  Used in ADB to mount your BLOB data." -f $storageAccountName
    $secretCredential = New-Object System.Management.Automation.PSCredential "$($parameters.parameters.storageAccountName.value)", (ConvertTo-SecureString -AsPlainText $storageAccountKey -Force)
    & "$utilitiesFolder\Set-KeyVaultSecret" -parameterFile $parameterFile -secretCredential $secretCredential -updateSecret $true -secretExpiryTermYears $secretExpiryYears -contentType $contentType
}
else {
    Write-Error "Failed to add the storage account key to key vault"
}